## 3.0.0

- platform interface to 3.0.0

## 2.1.1

- Use automatic plugin registration
- update Flutter SDK to >=1.20.0

## 2.1.0

- add toMap to models

## 2.0.0

- device_info_plus_platform_interface upgrade to 2.0.0

## 1.0.1

- Improve documentation

## 1.0.0

- Migrated to null safety
- Update dependencies.

## 0.2.1

- Update dependencies.

## 0.2.0

- Rename method channel to avoid conflicts.

## 0.1.0

- Intial release and transfer to plus-plugins monorepo
