// The connectivity_plus_platform_interface defaults to MethodChannelConnectivity
// as its instance, which is all the Windows implementation needs. This file
// is here to silence warnings when publishing to pub.
