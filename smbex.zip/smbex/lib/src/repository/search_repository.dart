import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

void setRecentSearch(search) async {
  if (search != null) {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Set<String> set = {search};
    if (prefs.containsKey('recent_search')) {
      String latSearch = prefs.get('recent_search').toString();
      List<String> latSearchList = json.decode(latSearch);
      while(latSearchList.length > 5){
        latSearchList.removeAt(latSearchList.length -1);
      }
      set.addAll(latSearchList);
    }
    search = json.encode([...set]);

    await prefs.setString('recent_search', search);
  }
}

Future<List<String>> getRecentSearch() async {
  List<String> _search = [];
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (prefs.containsKey('recent_search')) {
    String search = prefs.get('recent_search').toString();
    json.decode(search).map((x) => _search.add(x.toString()));
  }
  return _search;
}
