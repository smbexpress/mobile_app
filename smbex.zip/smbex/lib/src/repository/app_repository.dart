import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../api.dart';
import '../models/address.dart';
import '../models/app.dart';
import '../models/model.dart';
import '../models/shipment.dart';

List<Country> get countries  => Api().company.countries ;

ValueNotifier<Address> pickupAddress = new ValueNotifier(new Address());
ValueNotifier<Map<String,Currency>> currencyMap = new ValueNotifier({});


Future<ResultItems<Country>> getCountries() async {
  return ResultItems.of(Api().get('countries/list', withAuth:false), (data) => Country.fromJson(data));
}
Future<ResultItems<Country>> getCountriesWithArgs(Map args) async {
  return ResultItems.of(Api().get('countries/list', data: args, withAuth:false), (data) => Country.fromJson(data));
}

Future<ResultItem<Country>> getCountry(int id) async {
  return ResultItem.of(Api().get('countries/$id', withAuth:false), (data) => Country.fromJson(data)) ;
}

Future<ResultItems<City>> getCities(int countryId, {pickup:'a', dropoff: 'a'}) async {
  var domain =[["country_id", "=", countryId]];

  return ResultItems.of(Api().get('cities', data: {"filter": "country_id=$countryId"}, withAuth:false), (data) => City.fromJson(data));
}

Future<ResultItem<City>> getCity(int id) async {
  return ResultItem.of(Api().get('cities/$id', withAuth:false), (data) => City.fromJson(data)) ;
}

Future<ResultItems<City>> cityLookup(int countryId, String keyword, {pickup:'a', dropoff: 'a'}) async {
  String filter = 'country=${countryId} & keywords % "|$keyword"';
  print("city filter:$filter");
  return ResultItems.of(Api().get('cities/list', data: {"country": '$countryId', 'search': keyword}, withAuth:false), (data) => City.fromJson(data)) ;
}

Future<ResultItem<City>> cityReverse(double lat, double lng) async {

  return ApiRequest.of('cities/search_points',
      data: {"lat": '$lat', 'lng': '$lng'},
      withAuth:false,
      serializer: (data) => City.fromJson(data)
  ).
  once();
}

Future<Address> getCurrentPickupLocation([bool force=true]) async {
  if(force || pickupAddress.value.lat == null){
    // await setCurrentPickupLocation();
  }
  else if(pickupAddress.value.lat == null){
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if(prefs.containsKey('pickup_address')){
      pickupAddress.value = Address.fromJSON(prefs.get('pickup_address'));
    }
  }

  return pickupAddress.value;
}
