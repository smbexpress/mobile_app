
import 'package:http/http.dart' as http;

import '../api.dart';
import '../models/model.dart';
import '../models/payment.dart';
import '../models/shipment.dart';

Shipment _toShipment(data) => Shipment.fromJSON(data);
const _listFields = ['id', 'name', 'from', 'to', 'order_date', 'status'];

Future<ResultItem<Shipment>> getShipment(shipmentId) async {
  var response = Api().post('shipments/$shipmentId', withAuth:true);
  return ResultItem.of(response, (data) => Shipment.fromJSON(data));
}

Future<ResultItems<Shipment>> getRecentShipments() async {
  var response = Api().post('shipments/list', data:{'limit': 10, "fields": _listFields}, withAuth:true);
  return ResultItems.of(response, (data) => Shipment.fromJSON(data)) ;
}

Future<ResultItems<Shipment>> getDraftShipments() async {
  return ResultItems.of(Api().post('shipments/list', data:{'limit': 20, "fields": _listFields}, withAuth:true)
      , (data) => Shipment.fromJSON(data)) ;
}

Future<ResultItems<Status>> getShipmentStatus() async {
  return ResultItems.of(Api().get('shipment_status/list', withAuth:true), (data) => Status.fromJSON(data));
}

Future<ResultItems<TimeWindow>> getPickupTimes() async {
  return ResultItems.of(Api().get('pickup_time/list', withAuth:true), (data) => TimeWindow.fromJSON(data));
}

Future<ResultItem<Shipment>> addPayment(Shipment order, Payment payment) async {
  var paymentMap = payment.toMap();
  paymentMap['shipment_id'] = order.id;
  http.Response response = await Api().post('payment/update', data:paymentMap);

  ResultItem<Payment> paymentResult = await ResultItem.fromResponse(response, (data) => Payment.fromJSON(data));
  if(!paymentResult.hasError){
    order.payment = paymentResult.item;
    ResultItem<Shipment> resultShipment = await getShipment(order.id);
    return resultShipment;
  }

  return ResultItem(error: paymentResult.error);
}

Future<ResultItems<Shipment>> getShipmentsWith(Map<String,dynamic> args) async {
  if (args == null){
    args = {'limit': 20};
  }
  return ResultItems.of(Api().post('shipments/list', data: args), _toShipment);
}

Future<ResultItem<Shipment>> doSave(Map<String,dynamic> args) async {
  return ResultItem.of(Api().post('shipment', kwargs: args), _toShipment);
}

Future<ResultItem<Map<String, dynamic>>> doSome(String action, {Map<String,dynamic> args, Map<String, dynamic> kwargs}) async {
  return ResultItem.of(Api().post('shipments/$action', data: args, kwargs: kwargs), (data) => data);
}

Future<ResultItem<Shipment>> getCartShipment() async{
  return ResultItem<Shipment>();
}

Future<ResultItems<Status>> getStatus() async{
  return ResultItems<Status>();
}