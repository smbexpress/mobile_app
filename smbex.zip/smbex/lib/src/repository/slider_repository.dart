import '../api.dart';
import '../models/model.dart';
import '../models/slider.dart';

Future<ResultItems<Slider>> getSliders() async {
  return ResultItems.of(Api().send('app/group/home_slider'), (data) => Slider.fromJSON(data))  ;
}
