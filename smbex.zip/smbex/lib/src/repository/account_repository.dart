import 'dart:async';
import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../api.dart';
import '../config.dart';
import '../helpers/helper.dart';
import '../models/account.dart';
import '../models/address.dart';
import '../models/model.dart';

ValueNotifier<Account> currentAccount = _AccountNotifier();
ValueNotifier<bool> loginNotifier = new ValueNotifier(false);
ValueNotifier<bool> accountUpdateNotifier = new ValueNotifier(false);
String sendToken;
String otpToken;
bool disableAccountChange = false;
Account _toAccount(dynamic data) {
  final otp_token = data['otp_token'];

  if (otp_token != null){
    otpToken = otp_token;
    SharedPreferences.getInstance().
      then((pref) => pref.setString('otp_token', otpToken));
  }

  print("AccountRepo::_toAccount:$data");

  return Account.fromJSON(data);
}


Future<String> _getFcmToken() async{
  final pref = await SharedPreferences.getInstance();
  var token = pref.getString("device_token");

  if (token == null && !kIsWeb) {
    final firebaseMessaging = FirebaseMessaging.instance;
    token = await firebaseMessaging.getToken();
    pref.setString("device_token", token);
  }
  return token;
}

Future<ResultItem<Account>> login(Account account) async {
  var map = account.toLogin;
  map['device_token'] = await _getFcmToken();
  return _send(account.toLogin, endPoint: 'account/login', withPlatform: true);
}

Future<ResultItem<Account>> test(Account account) async {
  var map = account.toLogin;
  map['device_token'] = await _getFcmToken();
  return _send(account.toLogin, endPoint: 'account/test', withPlatform: true);
}

Future<ResultItem<Account>> updateToken([String token]) async {
  final pref = await SharedPreferences.getInstance();
  final storedToken = pref.getString("device_token");
  token = token ?? (await _getFcmToken());
  if (storedToken == token)
      return null;

  pref.setString("device_token", token);
  final map = {
    'device_token': token
  };
  return _send(map, endPoint: 'account', withPlatform: true);
}

Future<ResultItem<Account>> register(Account account) async {

  if(account.password == null || account.password.trim().isEmpty){
    account.password = "******";
  }
  var map = account.toMap(false);
  map['device_token'] = await _getFcmToken();
  map['lang'] = Api().lang;

  map['otp_token'] = otpToken;
  map['otp'] = sendToken;
  map['city'] = map.remove('city_id');

  return _send(map, endPoint: 'account/register', withPlatform: true);
}

Future<ResultItem<Account>> verify(Account account) async {
  Map map = account.toVerify;
  if (otpToken != null) {
    map['otp_token'] = otpToken;
    map['otp'] = sendToken;
  }
  map['device_token'] = await _getFcmToken();

  return _send(map, endPoint: 'account/verify', withPlatform: true);
}

Future<ResultItem<Account>> confirm(Account account) async {
  return _send(account.toVerify, endPoint: 'account/confirm', withPlatform: true);
}

Future<ResultItem<Account>> forget(Account account) async {
  return _send(account.toLogin, endPoint: 'account/forget', withPlatform: true);
}

Future<ResultItem<Account>> updateWithData(Map<String,dynamic> args) async {
  return _send(args, endPoint: 'account', withPlatform: true);
}

Future<void> logout() async {

  Api().get('account/logout');
  currentAccount.value.logout();
  loginNotifier.value = false;
  otpToken = sendToken = null;

  return forceLogout();

}

Future<void> forceLogout() async{
  //currentAccount.value = new Account();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.remove('current_account');
  loginNotifier.value = false;
  currentAccount.value = Account();
  Api().initContext();
}

void setCurrentAccount(Account account, {merge: false}) async {
    Account curr = currentAccount.value;
    loginNotifier.value = account.valid;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool changeDisabled = disableAccountChange;
    if(merge){
      curr.update(account);
      account = curr;
    }
    currentAccount.value = account;
    if (!account.valid){
      prefs.remove('current_account');
      loginNotifier.value = false;
      return;
    }
    await prefs.setString('current_account', json.encode(account.toMap()));
    Api().initContext();
    if (!changeDisabled)
      accountUpdateNotifier.value = !accountUpdateNotifier.value;
}

Future<Account> getCurrentAccount() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  if (!currentAccount.value.valid && prefs.containsKey('current_account')) {
    Account ac = Account.fromJSON(json.decode(await prefs.get('current_account')));
    if (!ac.valid){
      //prefs.remove('current_account');
      //loginNotifier.value =
    } else{

      Account old = currentAccount.value;
      currentAccount.value = ac;
      loginNotifier.value = ac.valid;

      ResultItem<Account> accountResult = await ResultItem.of(Api().get("account/test",
          withAuth: true), (map) => Account.fromJSON(map));

      if (accountResult.hasError){

      }
      else if (accountResult.item.valid) {
        currentAccount.value = accountResult.item;
      } else {
        //currentAccount.value = old;
        //prefs.remove('current_account');
      }
    }
    print("Current account get:valid::${ac.valid}");

  } else {
    print("Current account is not set yet!");
    currentAccount.value = Account();
  }

  otpToken = prefs.getString('otp_token');
  // ignore: invalid_use_of_visible_for_testing_member, invalid_use_of_protected_member
  //currentAccount.notifyListeners();
  return currentAccount.value;
}


Future<ResultItem<Account>> update(Account account, {endPoint: 'account'}) async {
  return _send(account.toMap(), endPoint: endPoint);
}

Future<ResultItem<Account>> saveAccount(Map map, {endPoint: 'account', bool saveUser:true}) async {
  return _send(map, endPoint: endPoint, saveUser: saveUser, withAuth: true);
}

Future<ResultItem> deleteAccount(Map reason) async {
  return ResultItem.of(
         Api().send("account/delete_account", data: reason, withAuth:true),
         null
  );
}

Future<ResultItem<Account>> _send(Map map, {endPoint: 'account', withPlatform: false, saveUser:true, withAuth: false}) async {
  if (withPlatform) {
    if (!kIsWeb){
      Map<String, String> device = await Api().getPlatformInfo();
      map['platform'] = device.remove('platform');
      map['device_uuid'] = device.remove('device_uuid');
      map['device'] = device;
    } else {
      map['platform'] = "chrome";
      map['device_uuid'] = "test_with_app_1233";
      map['device'] = {};
    }
  }
  map['version'] = Config.version;

  print("Account Repo send: $map");
  Future<ResultItem<Account>> accountResult =
    ResultItem.of(Api().send(endPoint, data: map, withAuth:withAuth), _toAccount);
  print("Account Repo send api2");
  return accountResult.then((ResultItem<Account> result)  async{
    //print("Account Repo receive account: $result");

    if (!result.hasError && saveUser && result.item.valid){
      await setCurrentAccount(result.item, merge: true);
      result.item = currentAccount.value;
    }
    if (result.hasError && currentAccount.value.valid &&
        result.error.code >= 100 && result.error.code <= 103){
      await forceLogout();
      await Api().initContext();
    }
    return result;
  });
}


Future<AuthResponseInfo> sendAuth({
      endPoint: 'account/auth',
      int action,
      String phone,
      String email,
      String otpToken,
      String otp,
      String password,
      Map<String, dynamic> data,
      withPlatform: false,
      withAuth: false
    }) async {

  data ??= {};

  if (withPlatform && !kIsWeb) {
      Map<String, String> device = await Api().getPlatformInfo();
      data['platform'] = device.remove('platform');
      data['device_uuid'] = device.remove('device_uuid');
      data['device'] = device;
  }
  AuthRequest request = AuthRequest(
      action: action,
      phone: phone,
      email: email,
      otpToken: otpToken,
      otp: otp,
      password: password,
      data: data,
  );

  final req = await ResultItem.of(Api().post(endPoint, data: request.toMap()), null);

  final otpInfoMap = req.item['otp_info'];
  final todo = req.item['todo'];
  final success = req.item['success']??true;
  final otpInfo = otpInfoMap != null
      ? OtpInfo(
        otpToken: otpInfoMap['otp_token'],
        count: otpInfoMap['count']?.toInt(),
        string: otpInfoMap['string']
      )
      : null;
  final authResponse =  AuthResponseInfo(
    request: request,
    response: AuthResponse(
      otpInfo: otpInfo,
      todo: todo,
      success: success,
    ),
  );

  if (success && req.item['account'] != null){
    await setCurrentAccount(_toAccount(req.item['account']));
  }

  return authResponse;
}

Future<ResultItems<Address>> getAddresses(bool pickup)  {
  String filter = pickup ? 'type=p' : 'type=d';

  return ResultItems.of(Api().get('addresses/list', data: {"filter": filter} ), (data) => Address.fromJSON(data));
}

Future<ResultItems<Address>> searchAddress(String query, bool pickup, bool forceBranch)  {
  String filter = (pickup ? 'type=p' : 'type=d') + '&q="$query"';
  
  final domain = [['type', '=', (pickup ? 'p' : 'd')]];
  if (query != null && query.trim().isNotEmpty) {
    domain.add(['q', '=', query]);
  }

  if (forceBranch == true) {
    domain.add(['location_id', '!=', null]);
  }

  return ResultItems.of(Api().post('addresses/list', data: {"domain": domain} ), (data) => Address.fromJSON(data));
}

Future<ResultItem<Address>> addAddress(Address address) async {
  final addressDate = Helper.removeNulls(address.toMap(true));
  Config.log("addAddress: ${address.toMap(true)}");
  return ResultItem.of(Api().post('addresses', data: addressDate), (data) => Address.fromJSON(data));
}

Future<ResultItem<Address>> updateAddress(Address address) async {
  return ResultItem.of(Api().put('addresses/${address.id}', data: address.toMap(true)), (data) => Address.fromJSON(data));
}

Future<ResultItem> removeAddress(Address address) async {
  return ResultItem.of(Api().delete('addresses/${address.id}'), null);
}

class _AccountNotifier extends ValueNotifier<Account> {
  _AccountNotifier(): super(Account());

  void notifyListeners() {
    if (disableAccountChange) {
      return;
    }

    print("_AccountNotifier::notifyListeners");
    super.notifyListeners();
  }

}