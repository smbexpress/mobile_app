import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/src/helpers/helper.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../helpers/custom_trace.dart';
import '../helpers/maps_util.dart';
import '../models/address.dart';
import '../models/model.dart';
import '../models/setting.dart';

ValueNotifier<Setting> settingNotifier = new ValueNotifier(Setting.fromJSON({}));
ValueNotifier<Address> deliveryAddress = new ValueNotifier(new Address());


//LocationData locationData;

Future<Setting> initSettings() async {
  Setting _setting;
  try {
    //final response = await Api().get('app/group/settings');
    ResultItem result = await ResultItem.of(Api().get('app/settings'), (data) => data);
    if (!result.hasError) {

        _setting = Setting.fromJSON(result.item);
        settingNotifier.value = _setting;
    } else {
      settingNotifier.value = Setting.fromJSON({});
      print(CustomTrace(StackTrace.current, message: Helper.getError(result.error)).toString());
    }
  } catch (e, stack) {
    debugPrintStack(stackTrace: stack, label: "$e");
    //print(CustomTrace(StackTrace.current, message: e).toString());
    return Setting.fromJSON({});
  }

  return settingNotifier.value;
}


Setting get kSettings => settingNotifier.value;

Future<Address> changeCurrentLocation(Address _address) async {
  //SharedPreferences prefs = await SharedPreferences.getInstance();
  //await prefs.setString('delivery_address', json.encode(_address.toMap()));
  return _address;
}

Future<Address> getCurrentLocation() async {
  return Address.Pickup();
}

void setBrightness(Brightness brightness) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  brightness == Brightness.dark ? prefs.setBool("isDark", true) : prefs.setBool("isDark", false);
}

Future<void> setDefaultLanguage(String language) async {
  if (language != null) {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', language);
    LocaleSettings.setLocaleRaw(language);
    Api().initContext();
  }
}

Future<String> getDefaultLanguage(String defaultLanguage) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (prefs.containsKey('language')) {
    defaultLanguage = await prefs.get('language');
  }
  return defaultLanguage;
}



Future<void> saveMessageId(String messageId) async {
  if (messageId != null) {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('google.message_id', messageId);
  }
}

Future<String> getMessageId() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return await prefs.get('google.message_id');
}


