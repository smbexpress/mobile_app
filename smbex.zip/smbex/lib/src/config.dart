import 'package:flutter/cupertino.dart';
import 'package:package_info_plus/package_info_plus.dart';

const int INVALID_PICKUP_ADDRESS = 1;
const int INVALID_DELIVERY_ADDRESS = 2;
const int INVALID_RETURN_ADDRESS = 4;
const int DELIVERY_DATE_SOONER = 8;
const int W_ARRIVED_STATION = 16;
const int W_PICKED = 32;
const int W_SHIPPED = 64;
const int W_RECEIVED = 128;
const int W_ARRIVED_DESTINATION = 256;
const int W_ARRIVED_END = 512;
const int W_REQUEST_RETURN = 1024;
const int W_DELIVERY_SAME_STATION = 2048;
const int W_DELIVERED = 4096;
const int W_PICKED_OR_RECEIVED = W_PICKED | W_RECEIVED;
const int W_SHIPPED_AND_ARRIVED_DET = W_SHIPPED | W_ARRIVED_DESTINATION;

class Config {
  /* Replace your sire url and api keys */
  static String _version = "1.0.3";
  static String _build = "25";

  static String get version => Config._version;
  static String get buildNumber => _build;

  //String url = "http://smbexpress.onecs.com.my/api/v1/";
  String url = "https://mobile.smb.express/";
  String mapApiKey = 'AIzaSyAFN-W8CtWMKALwgJc6ch2q7XFjzotxq78';

  static Config _singleton = new Config._internal();

  static const bool isDebug = true;
  static const bool debugResult = false;
  static const SENTRY_DNS = '';

  factory Config() {
    return _singleton;
  }

  Config._internal();

  Map<String, dynamic> appConfig = Map<String, dynamic>();

  Config loadFromMap(Map<String, dynamic> map) {
    appConfig.addAll(map);
    return _singleton;
  }

  dynamic get(String key) => appConfig[key];

  bool getBool(String key) => appConfig[key];

  int getInt(String key) => appConfig[key];

  double getDouble(String key) => appConfig[key];

  String getString(String key) => appConfig[key];

  void clear() => appConfig.clear();

  @Deprecated("use updateValue instead")
  void setValue(key, value) => value.runtimeType != appConfig[key].runtimeType
      ? throw ("wrong type")
      : appConfig.update(key, (dynamic) => value);

  void updateValue(String key, dynamic value) {
    if (appConfig[key] != null &&
        value.runtimeType != appConfig[key].runtimeType) {
      throw ("The persistent type of ${appConfig[key].runtimeType} does not match the given type ${value.runtimeType}");
    }
    appConfig.update(key, (dynamic) => value);
  }

  void addValue(String key, dynamic value) =>
      appConfig.putIfAbsent(key, () => value);

  add(Map<String, dynamic> map) => appConfig.addAll(map);

  static String defaultCountryCode = '+966';
  static const String defaultCurrency = 'SAR';

  static void log(Object data, [Type type]) {
    debug(data, type);
  }

  static void debug(Object data, [Type type]) {
    if (isDebug) {
      if (type != null) {
        debugPrint('${type.toString()}::$data');
      } else {
        debugPrint('$data');
      }
    }
  }

  static void result(Object data, [Type type]) {
    if (debugResult) {
      if (type != null) {
        debugPrint('response: ${type.toString()}::$data');
      } else {
        debugPrint('response: $data');
      }
    }
  }

  static void error(Object data, StackTrace trace, [Type type]) {
    if (isDebug) {
      if (type != null) {
        debugPrintStack(label: '${type.toString()}::$data', stackTrace: trace);
      } else {
        debugPrintStack(label: '$data', stackTrace: trace);
      }
    }
  }

  static Future setCurrentVersion() async {
    PackageInfo info = await PackageInfo.fromPlatform();
    _version = info.version;
    _build = info.buildNumber;
  }
}
