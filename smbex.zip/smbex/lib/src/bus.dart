// @dart=2.12

import 'dart:async';

import 'helpers/helper.dart';

class Bus {

  final _controller = StreamController.broadcast();

  //StreamSubscription subscrip();
  BusSubscription<dynamic?> on(BusCall call, void onData(dynamic event)?,
      {Function? onError, void onDone()?, bool? cancelOnError}) {
    final sub = _controller.stream.transform(
      StreamTransformer.fromHandlers(
        handleData: (data, sink) {
          if (data['model'] == call.model && data['method'] == call.method) {
            sink.add(data['args']);
          }
        },
      ),
    ).listen(onData, onError: onError, onDone: onDone, cancelOnError: cancelOnError);
    return _BusSubscriptionImpl._(sub, call);
  }

  void odIt(){

  }
}

class BusCall {
  final String model;
  final String method;
  final Map<String, dynamic>? args;
  final DateTime? last;

  BusCall({
        required this.model,
        required this.method,
        this.args,
        this.last});

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is BusCall &&
        model == other.model &&
        method == other.method;
  }

  Map<String, dynamic> toMap(String key) => {
    "key": key,
    "model": model,
    "method": method,
    if (args != null) "args": args,
    if (last != null) "last": Helper.formatDatetime(last)
  };

}


abstract class BusSubscription<E> extends StreamSubscription<E>{
  BusCall _call;
  BusSubscription._(this._call);

}


class _BusSubscriptionImpl<T> extends BusSubscription<T>{
  StreamSubscription<T> delegate;
  _BusSubscriptionImpl._(this.delegate, BusCall call) : super._(call);

  @override
  Future<E> asFuture<E>([E? futureValue]) {
    return delegate.asFuture(futureValue);
  }

  @override
  Future<void> cancel() {
    return delegate.cancel();
  }

  @override
  bool get isPaused => delegate.isPaused;

  @override
  void onData(void handleData(T data)?) {
    delegate.onData(handleData);
  }

  @override
  void onDone(void handleDone()?) {
    delegate.onDone(handleDone);
  }

  @override
  void onError(Function? handleError) {
    delegate.onError(handleError);
  }

  @override
  void pause([Future<void>? resumeSignal]) {
    delegate.pause(resumeSignal);
  }

  @override
  void resume() {
    delegate.resume();
  }


}