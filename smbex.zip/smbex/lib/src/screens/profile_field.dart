import 'dart:async';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/controllers/account_controller.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code_picker.dart';
import 'package:smbex_app/src/widgets/CommonWidget.dart';
import 'package:smbex_app/src/widgets/FadeAnimation.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../helpers/size_config.dart';
import '../repository/app_repository.dart' as appRepo;
import '../theme/extention.dart';
import '../theme/text_styles.dart';

String sentMobile;

class ProfileFieldScreen extends StatefulWidget {
  static String TAG = '/ProfileFieldScreen';

  final int action;

  ProfileFieldScreen({Key key, this.action: Account.ACT_UPDATE_NAME});

  @override
  ProfileFieldScreenState createState() => ProfileFieldScreenState();
}

class ProfileFieldScreenState extends StateMVC<ProfileFieldScreen> {
  Timer _timer;
  int _start = 60;
  AccountController _con;
  int otp;
  int insetOtp;
  bool validOtp = false;
  bool isDone = false;

  bool dialCodeSet = true;
  String mobile;
  String fullMobile;
  String name;
  String password;
  String email;
  String dialCode;
  bool hidePassword = true;

  TextEditingController _mobileController = TextEditingController();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  ScrollController _scrollController = ScrollController();
  ProfileFieldScreenState() : super(AccountController()) {
    _con = controller;
    otp = _con.account.otp;
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
      (Timer timer) => setState(
        () {
          if (_start < 1) {
            timer.cancel();
          } else {
            _start = _start - 1;
          }
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    mobile = _con.account.mobile;
    name = _con.account.name;
    email = _con.account.email;

    _emailController.text = email;
    _nameController.text = name;
    _mobileController.text = mobile;

    if (widget.action == Account.ACT_VERIFY) {
      Future.delayed(Duration(milliseconds: 1000), () {
        startTimer();
      });
    }
    _scrollController.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    if (_timer != null) _timer.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //changeStatusColor(Theme.of(context).primaryColor);

    ThemeData th = Theme.of(context);
    if (widget.action != Account.ACT_VERIFY) {
      Widget child;
      IconData icon;
      String title;
      switch (widget.action) {
        case Account.ACT_UPDATE_NAME:
          child = createNameWidget(context, th);
          title = t.full_name;
          icon = Icons.person;
          break;
        case Account.ACT_UPDATE_PASSWORD:
        case Account.ACT_UPDATE_FORGET_PASSWORD:
          child = createPasswordWidget(context, th);
          title = t.password;
          icon = Icons.lock;
          break;
        case Account.ACT_UPDATE_EMAIL:
          child = createEmailWidget(context, th);
          icon = Icons.mail_outline;
          title = t.email;
          break;
        case Account.ACT_UPDATE_MOBILE:
          child = createMobileWidget(context, th);
          icon = Icons.phone_iphone;
          title = t.mobile;
          break;
        default:
          child = Container();
      }

      return LayoutBuilder(builder: (context, box) {
        var mq = MediaQuery.of(context);
        Widget titleWidget;
        if (icon != null) {
          titleWidget = IconTheme(
              data: IconThemeData(color: Colors.white, size: 20),
              child: DefaultTextStyle(
                style: TextStyles.title.bold.white,
                child: Column(
                  children: [
                    SizedBox(
                      height: mq.viewPadding.top,
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    FadeAnimation(
                      1.5,
                      Icon(icon, size: 110),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    FadeAnimation(1.5, Text(title))
                  ],
                ),
              ));
        }

        Widget header =
            buildPageHeader(context, title: titleWidget, height: getProportionateScreenHeight(300));
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Positioned(
              top: mq.padding.top + kToolbarHeight,
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                color: Theme.of(context).scaffoldBackgroundColor,
              ),
            ),
            Positioned(
              top: -mq.padding.top - mq.viewInsets.bottom,
              left: 0,
              right: 0,
              child: header,
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              top: 0,
              //top: mq.padding.top + 300,
              child: Scaffold(
                backgroundColor: Colors.transparent,
                appBar: appBar(
                  context,
                  titleText: title,
                  isSecondary: true,
                  //backgroundColor: Colors.transparent,
                ),
                body: SizedBox.expand(
                  child: Container(
                    padding: EdgeInsets.only(
                        top: max(0.0, getProportionateScreenHeight(300.0) - mq.viewInsets.bottom)),
                    //color: th.scaffoldBackgroundColor,
                    child: Material(
                      color: th.scaffoldBackgroundColor,
                      child: SingleChildScrollView(
                        controller: _scrollController,
                        //padding: EdgeInsets.only(top: 300),
                        child: Material(
                          color: th.scaffoldBackgroundColor,
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 30, horizontal: 10),
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.stretch,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Form(
                                      key: _con.loginFormKey,
                                      child: FadeAnimation(
                                          1.5, child, 0)),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  child: FadeAnimation(
                                    1.5,
                                    ElevatedButton(
                                      child: Text(t.save),
                                      onPressed: () {
                                        if (widget.action ==
                                            Account
                                                .ACT_UPDATE_MOBILE) {
                                          sentMobile = fullMobile;
                                        }
                                        _con.update(widget.action,
                                            _getSavedData());


                                      },
                                    ),
                                    50),
                                )
                              ],
                            ),
                          )
                        )
                      ),
                    )
                  )
                )
              ),
            )
          ],
        );
      });
    }

    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: _con.scaffoldKey,
          body: SafeArea(
            child: Column(
              children: <Widget>[
                title(S.of(context).verify, context),
                Expanded(
                  child: SingleChildScrollView(
                      child: createOtpWidget(context, th)),
                )
              ],
            ),
          ),
        ));
  }

  Widget createMobileWidget(BuildContext context, ThemeData th) {
    if (dialCodeSet) {
      dialCodeSet = false;
      if (mobile != null) {
        mobile = Helper.correctPhone(mobile);

        final countryDial = Api().company.allCountries.firstWhere(
            (country) => mobile.startsWith(country.dial),
            orElse: () => null);

        if (countryDial != null) {
          dialCode = countryDial.dial;
        }
      }
      if (dialCode == null) {
        if (appRepo.pickupAddress.value.country.dial == null) {
          appRepo.getCurrentPickupLocation().then((address) => {
                if (address != null)
                  {
                    setState(() {
                      dialCode = address.country.dial;
                    })
                  }
              });
        } else {
          dialCode = appRepo.pickupAddress.value.country.dial;
        }
      }
    }

    if (dialCode != null && mobile != null) {
      if (mobile.startsWith(dialCode)) {
        fullMobile = mobile;
        mobile = mobile.substring(dialCode.length);
        _mobileController.text = mobile;
      } else {
        fullMobile = '$dialCode$mobile';
      }
    }

    return Directionality(
        textDirection: TextDirection.ltr,
        child: textField(context,
            hintText: t.phone,
            controller: _mobileController, validator: (value) {
          if (value.isEmpty || dialCode == null) {
            return t.not_a_valid_phone;
          }
          return null;
        }, onSaved: (value) {
          setState(() {
            mobile = value;
            fullMobile = '$dialCode$value';
          });
        },
            prefixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 5,
                ),
                CountryCodePicker(
                    initialSelection: dialCode,
                    textStyle: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).textTheme.bodyText1.color),
                    showFlag: true,
                    onChanged: (code) {
                      setState(() {
                        dialCode = code.rawDialCode;
                      });
                    }),
                Container(
                  height: 25.0,
                  width: 1.0,
                  color: Theme.of(context).dividerColor,
                  margin: const EdgeInsets.only(left: 5.0, right: 5.0),
                ),
              ],
            ),
            //icon: UiIcons.phone_call,
            keyboardType: TextInputType.phone));
  }

  Widget createEmailWidget(BuildContext context, ThemeData th) {
    return Directionality(
        textDirection: TextDirection.ltr,
        child: textField(context,
            hintText: t.email,
            controller: _emailController, validator: (value) {
          if (value.isEmpty) {
            return t.not_a_valid_email;
          }
          return null;
        }, onSaved: (value) {
          email = value;
          _con.account.email = email;
        }, icon: Icons.mail, keyboardType: TextInputType.emailAddress));
  }

  Widget createNameWidget(BuildContext context, ThemeData th) {
    return textField(context,
        hintText: t.full_name, controller: _nameController, validator: (value) {
      if (value.isEmpty) {
        return t.not_a_valid_full_name;
      }
      return null;
    }, onSaved: (value) {
      name = value;
    }, icon: Icons.person, keyboardType: TextInputType.name);
  }

  Widget createPasswordWidget(BuildContext context, ThemeData th) {
    return textField(
      context,
      onSaved: (input) => password = input,
      validator: (input) => input.length < 3
          ? S.of(context).should_be_more_than_3_characters
          : null,
      obscureText: hidePassword,
      hintText: t.password,
      icon: Icons.lock,
      controller: _passwordController,
      suffixIcon: IconButton(
        onPressed: () {
          setState(() {
            hidePassword = !hidePassword;
          });
        },
        color: Theme.of(context).primaryColorDark.withOpacity(0.4),
        icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
      ),
    );
  }

  Widget createOtpWidget(BuildContext context, ThemeData th) {
    return Column(
      children: <Widget>[
        Text(
          t.verify_your_account,
          style: Theme.of(context).textTheme.headline5,
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 10),
        Icon(
          Icons.lock,
          size: 80.0,
        ),
        Text(
          t.otpSentTo(sentMobile),
          style: Theme.of(context).textTheme.bodyText1,
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 16,
        ),
        Form(
          key: _con.loginFormKey,
          child: Directionality(
              textDirection: TextDirection.ltr,
              child: pinCodeTextField(
                context,
                onTextChanged: (text) {},
                onDone: (String code) {
                  isDone = true;
                  insetOtp = int.tryParse(code);
                  setState(() {
                    validOtp = insetOtp == otp;
                    if (validOtp) _con.verify();
                  });
                },
                hasError: _con.error != null || (isDone && insetOtp != otp),
              )),
        ),
        SizedBox(
          height: 50,
        ),
        Container(
          margin: EdgeInsets.only(left: 16, right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              _start == 0
                  ? Text(S.of(context).resend,
                          style: TextStyles.title.bold
                              .copyWith(color: LightColor.blue))
                      .p(8)
                      .ripple(() {
                      _con.account.action = Account.ACT_UPDATE_MOBILE;
                      Navigator.of(context).pop();
                    })
                  : Text("$_start Seconds", style: TextStyles.title),
            ],
          ),
        )
      ],
    );
  }

  Map<String, dynamic> _getSavedData() {
    switch (widget.action) {
      case Account.ACT_UPDATE_NAME:
        return {'name': _nameController.text};
      case Account.ACT_UPDATE_PASSWORD:
      case Account.ACT_UPDATE_FORGET_PASSWORD:
        return {'password': _passwordController.text};
      case Account.ACT_UPDATE_EMAIL:
        return {'email': _emailController.text};
      case Account.ACT_UPDATE_MOBILE:
        return {'mobile': fullMobile};
    }
  }
}
