import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/models/payment_method.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/CreditCardCVVSheetWidget.dart';
import 'package:smbex_app/src/widgets/PaymentMethodsSheetWidget.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';

import '../../i18n/i18n.dart';
import '../controllers/cart_controller.dart';
import '../helpers/helper.dart';
import '../models/route_argument.dart';
import '../widgets/CartItemWidget.dart';
import '../widgets/SmbWidget.dart';
import '../widgets/message_placeholder.dart';

class CartWidget extends StatefulWidget {
  final RouteArgument routeArgument;
  CartWidget({Key key, this.routeArgument}) : super(key: key);

  @override
  _CartWidgetState createState() => _CartWidgetState();
}

class _CartWidgetState extends StateMVC<CartWidget> {
  CartController _con;

  _CartWidgetState() : super(CartController()) {
    _con = controller;
  }

  @override
  void initState() {
    _con.loadCart();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Theme.of(context).cardColor,
        appBar: appBar(
          context,
          titleText: S.of(context).cart,
          isSecondary: true
        ),

        body: LoadingWidget(
          isLoading: _con.loading,
          child: RefreshIndicator(
            onRefresh: _con.loadCart,
            child: _con.cart.items?.isEmpty ?? true
                ? MessagePlaceholder.empty(message: tr.empty_cart,)
                : Stack(
              fit: StackFit.expand,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(bottom: 150),
                  padding: EdgeInsets.only(bottom: 15),
                  child: SingleChildScrollView(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        if (_con.error != null)Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                            child: Text(
                                Helper.getError(_con.error.message),
                                style: TextStyles.title.copyWith(color: Theme.of(context).errorColor)
                            )
                        ),
                        if (_con.message != null)Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                            child: Text(
                                _con.message,
                                style: TextStyles.title.copyWith(color: Theme.of(context).errorColor)
                            )
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20, right: 10),
                          child: ListTile(
                            contentPadding: EdgeInsets.symmetric(vertical: 0),
                            leading: Icon(
                              Icons.shopping_cart,
                              color: Theme.of(context).hintColor,
                            ),
                            title: Text(
                              S.of(context).shopping_cart,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.headline5,
                            ),
                          ),
                        ),
                        Divider(height: 1),
                        ListView.separated(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          primary: false,
                          shrinkWrap: true,
                          itemCount: _con.cart.items.length,
                          separatorBuilder: (context, index) {
                            return Divider(height: 1);
                          },
                          itemBuilder: (context, index) {
                            return CartItemWidget(
                              cart: _con.cart.items.elementAt(index),
                              route: _con.cart.route,
                              currency: _con.cart.currency,
                              onDismissed: () {
                                _con.removeCartItem(_con.cart.items.elementAt(index));
                              },
                            );
                          },
                        ),
                        SizedBox(height: 10,),
                        ListView(
                          shrinkWrap: true,
                          children: [
                            Divider(height: 1,),
                            ListTile(
                              leading: Text(
                                S.of(context).payment_mode,
                                style: TextStyles.bodySm,
                              ),
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.end ,
                                children: [
                                  if (_con.cart.paymentMethod != null)
                                    ...[
                                      SizedBox(width: 2,),
                                      CachedNetworkImage(
                                        imageUrl: _con.cart.paymentMethod.icon,
                                        placeholder: (context, url) => CircularProgressIndicator(),
                                        errorWidget: (context, url, error) => Icon(Icons.credit_card) ,
                                        width: 24,
                                        height: 24,
                                      ),
                                      SizedBox(width: 5,),
                                      Text(_con.cart.paymentMethod.name??'', style: TextStyles.bodySm),
                                    ],
                                  SizedBox(width: 5,),
                                  Container(
                                    padding: EdgeInsets.symmetric(vertical: 7, horizontal: 5),
                                    decoration: BoxDecoration(
                                        color: Theme.of(context).primaryColorDark,
                                        borderRadius: BorderRadius.circular(5),
                                        shape: BoxShape.rectangle
                                    ),
                                    child: Text("Change",
                                        style: TextStyles.body.copyWith(color: Theme.of(context).cardColor)),
                                  )

                                ],
                              ),
                              dense: true,
                              onTap: () {

                                _showCardSheetWidget(context);
                              },
                            ),
                            Divider(height: 1,)
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                Positioned(
                  bottom: 0,
                  child: Container(
                    height: _con.cart.tax!= null && _con.cart.tax > 0 ? 140 : 96,
                    padding: EdgeInsets.only(left: 20, right: 20, top: 15),
                    decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        border: Border(top: BorderSide(color: Theme.of(context).dividerColor))
                    ),
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width - 40,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          if(_con.cart.tax!= null && _con.cart.tax > 0) Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  S.of(context).subtotal,
                                  style: Theme.of(context).textTheme.bodyText2,
                                ),
                              ),
                              Helper.getPrice(_con.cart.subtotal, context, currency: _con.cart.currency, style: Theme.of(context).textTheme.subtitle2)
                            ],
                          ),
                          if(_con.cart.tax!= null && _con.cart.tax > 0) SizedBox(height: 5),
                          if(_con.cart.tax!= null && _con.cart.tax > 0) Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  S.of(context).tax,
                                  style: Theme.of(context).textTheme.bodyText2,
                                ),
                              ),
                              Helper.getPrice(_con.cart.tax, context, currency: _con.cart.currency, style: Theme.of(context).textTheme.subtitle2)
                            ],
                          ),
                          SizedBox(height: 10),
                          Stack(
                            fit: StackFit.loose,
                            alignment: AlignmentDirectional.centerEnd,
                            children: <Widget>[
                              SizedBox(
                                width: MediaQuery.of(context).size.width - 40,
                                child: ElevatedButton(
                                  onPressed: _con.cart.paymentMethod != null ? () {
                                    if (_con.cart.paymentMethod.ref is PaymentCard){
                                      _showPaymentCardCVVSheetWidget(context);
                                    } else {
                                      _con.goCheckout(context, _con.cart.paymentMethod);
                                    }
                                  } : null,

                                  child: Text(
                                    S.of(context).checkout,
                                    textAlign: TextAlign.start,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: Helper.getPrice(
                                  _con.cart.total,
                                  context,
                                  currency: _con.cart.currency,
                                  style: Theme.of(context).textTheme.headline5.merge(TextStyle(color: Theme.of(context).cardColor)),
                                ),
                              )
                            ],
                          ),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        )

    );
  }

  void _showCardSheetWidget(BuildContext gContext) async {
    final double height = MediaQuery.of(gContext).size.height * .8;
    showModalBottomSheet(
      context: gContext,
      isDismissible: true,

      builder: (context) {
        return PaymentMethodsSheetWidget(
          height: height,
          paymentType: _con.cart.type,
          onSelect: (PaymentMethodItem item) {
              _con.setPaymentMethod(context, item);
              Navigator.of(context).pop();
              setState(() {});

              if (_con.cart.paymentMethod.ref is PaymentCard){
                _showPaymentCardCVVSheetWidget(gContext);
                //Future.delayed(Duration(seconds: 1), () => _showPaymentCardCVVSheetWidget(gContext));
              } else if(_con.cart.paymentMethod.method != null && _con.cart.paymentMethod.method.provider == 'hyperpay'){
                _con.goCheckout(gContext, _con.cart.paymentMethod);
              }
          },
        );
      },
    );
  }

  void _showPaymentCardCVVSheetWidget(BuildContext context) async {
    final double height = MediaQuery.of(context).size.height * .7;
    GlobalKey<FormState> formKey = new GlobalKey<FormState>();
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      isScrollControlled: true,
      enableDrag: false,
      builder: (context) {
        return Container(
            height: height,
            width: MediaQuery.of(context).size.width,
            child: CreditCardCVVSheetWidget(
              onChange: (){
                if (formKey.currentState.validate()){
                  Navigator.of(context).pop();
                  _con.goCheckout(context, _con.cart.paymentMethod);
                }
              },
              formKey: formKey,
              paymentCard: _con.cart.paymentMethod.ref as PaymentCard,
              cardNumberDecoration: InputDecoration(
                labelText: 'Card number',
                hintText: 'XXXX XXXX XXXX XXXX',
                prefix: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: CachedNetworkImage(
                    imageUrl: _con.cart.paymentMethod.icon,
                    placeholder: (context, url) => CircularProgressIndicator(),
                    errorWidget: (context, url, error) => Icon(Icons.credit_card) ,
                    width: 32,
                    height: 32,
                  ),
                )
              ),
            )
        );
      },
    );
  }

}
