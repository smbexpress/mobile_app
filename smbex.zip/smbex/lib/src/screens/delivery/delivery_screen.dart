import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/controllers/shipment_controller.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/screens/shipment/shipment_actions.dart';
import 'package:smbex_app/src/screens/signin.dart';
import 'package:smbex_app/src/theme/theme.dart';
import 'package:smbex_app/src/widgets/CommonWidget.dart';
import 'package:smbex_app/src/widgets/connection_status_widget.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';
import 'package:smbex_app/src/widgets/stack_body.dart';

import '../../../i18n/i18n.dart';
import '../../helpers/helper.dart';
import '../../models/tody_tip.dart';
import '../../notification_provider.dart';
import '../../repository/account_repository.dart';
import '../../repository/settings_repository.dart';
import '../../theme/light_color.dart';
import '../../theme/text_styles.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/checkout_widget.dart';
import '../../widgets/icon_text.dart';
import '../../widgets/payment_list_tile.dart';
import '../../widgets/refreshaple.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
import '../../widgets/tip_widget.dart';
import '../checkout/checkout_provider.dart';
import 'delivery_provider.dart';


class DeliveryScreen extends StatefulWidget {
  RouteArgument args;
  int shipmentId;
  Shipment shipment;
  DeliveryScreen({
    Key key,
    this.shipmentId = 0,
    args,
  }) {
    if (args is RouteArgument) {
      this.args = args;
      shipmentId = int.tryParse(args.id);
      if (shipmentId == 0){
        shipment = this.args.param as Shipment;
      }
    }
  }

  @override
  _DeliveryScreenState createState() => _DeliveryScreenState();
}

class _DeliveryScreenState extends State<DeliveryScreen>
    with SystemUiOverlayMixin, Refreshaple {
  Shipment shipment;
  NotificationProvider _provider;

  bool _hasCheckout = false;


  @override
  void initState() {
    super.initState();
    if (widget.shipmentId != 0)
      context.read<DeliveryProvider>().loadShipment(widget.shipmentId);
    else if(widget.shipment != null){
      context.read<DeliveryProvider>().shipment = widget.shipment;
    }

    _provider = context.read<NotificationProvider>();
    _provider
        .addLiveCommand(
            LiveCommand(
                key: 'currentDelivery',
                model: 'deliveries',
                method: 'changed',
                listener: _liveTrigger,
                last: DateTime.now(),
                args: {
                  'id': widget.shipmentId != 0
                      ? widget.shipmentId
                      :  widget.shipment.id
                }
            ),
    );

    _provider.addMessageListener(_onRemoteMessage);
    context.read<CheckoutProvider>().reset();
  }
  @override
  void dispose() {
    _provider.removeMessageListener(_onRemoteMessage);
    _provider.removeLiveCommand('currentDelivery');
    super.dispose();
  }

  void _liveTrigger(dynamic item){
    _reload();
  }

  void _onRemoteMessage(RemoteMessage message){
    if (mounted && message.data['model'] == 'deliveries'
        && message.data['res_id'] == context.read<DeliveryProvider>().shipment?.id)
      _reload();
  }

  void _reload() async{
    if (mounted)
      context.read<DeliveryProvider>()
          .loadShipment(widget.shipment?.id ?? widget.shipmentId)
          .then((value){
            if (mounted && !value.hasError) {
              _provider.updateCommandWith('currentDelivery', last: DateTime.now());
            }
      });
  }

  @override
  Widget build(BuildContext context) {

    final provider = Provider.of<DeliveryProvider>(context);

    if ( provider.error ==null && provider.shipment != null) {
      shipment = provider.shipment;
    }


    Provider.of<CheckoutProvider>(context);

    return ConnectionChangeWidget(
      builder: (context, isConnected) {
        Config.log("change connection to: $isConnected",  runtimeType);
        if (isConnected && provider.needsReload || (shipment == null || !shipment.valid) ) {
          Config.log("reload shipment ..",  runtimeType);
          _reload();
        }
        ThemeData theme = Theme.of(context);

        Widget child = SingleChildScrollView(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Column(
              children: <Widget>[
                if (shipment != null)
                  ...createBody(context, shipment),

                if (provider.error != null && shipment == null)
                  MessagePlaceholder.error(
                      error: provider.error,
                      onRetry: _reload
                  )
              ]
          ),
        );
        final validateWidget = shipment != null
            ? createValidateAddressWidget(shipment)
            : null;

        if (validateWidget != null) {
          child = Column(
            children: [
              Material(
                color: theme.cardColor,
                child: Container(
                  //height: 96,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    //color: theme.cardColor,
                      border: Border(bottom: BorderSide(color: theme.dividerColor))
                  ),
                  child: validateWidget,
                ),
              ),
              Expanded(child: child)
            ],
          );
        }

        return Scaffold(
            appBar: appBar(
              context,
              key: provider.scaffoldKey,
              isSecondary: true,
              rounded: true,
              titleText: S.of(context).shipmentDetail,
              actions: <Widget>[
                if(shipment != null && false)
                  IconButton(
                    icon: Icon(Icons.help_outline),
                    onPressed: (){
                      Navigator.of(context).pushNamed(
                          "/DeliveryValidation",
                          arguments: RouteArgument(id: shipment.id.toString())
                      );
                      //showShipmentBottomSheet(context, shipment, _reload);
                    },
                  ),
              ],
            ),
            body: !currentAccount.value.valid
                ? SignInWidget()
                : StackBodyWidget(
                    body: RefreshIndicator(
                      onRefresh: () async{
                        if (shipment.valid)
                          return provider.loadShipment(shipment.id);

                        return true;
                      },
                      child: LoadingWidget(
                          isLoading: shipment == null && provider.error == null,
                          child: child
                      )
                    ),
                    footer: createFooter(context, shipment),
            )
        );
      },
    );
  }

  List<Widget> createBody(BuildContext context, Shipment shipment) {
    ThemeData theme = Theme.of(context);

    Widget tips = shipment.meta != null
        ? _createTipWidget(shipment.meta['tips']) : null;

    return [

      if (tips != null)
        Padding(
            padding: EdgeInsets.symmetric(
                horizontal: 20.0, vertical: 15),
            child: tips,
        ),

      cartWidget(context,
        child: renderShipmentAddressAll(context, shipment.order_date,
            shipment.status, shipment.from, shipment.to,
            withHeader: true, trackingCode: shipment.name,
            onSelect: (address) =>
                Navigator.of(context).pushNamed('/AddressShow',
                    arguments: RouteArgument(
                        id: address.id.toString(),
                        param: {'shipment_id': shipment.id}))
        ),
        horizontal: 0.0,
        borderRadius: 0.0,
      ),



      if (shipment.payment != null)
        createPaymentWidget(context, shipment),

      createPaymentMethod(context, shipment),
      const SizedBox(height: 16,),
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 15, 20, 0),
        child: Container(
          alignment: AlignmentDirectional.centerStart,
          child: Text(tr.packageInfo, style: TextStyles.body, textAlign: TextAlign.justify,),
        ),
      ),

      cartWidget(context,
        horizontal: 0.0,
        borderRadius: 0.0,
        child: ListView(
          shrinkWrap: true,
          primary: false,
          children: <Widget>[
            ListTile(
              onTap: () {},
              dense: false,
              title: Text(
                tr.packageType,
                style: theme.textTheme.bodyMedium,
              ),
              trailing: Text(
                shipment.package.name??'',
                style: theme.textTheme.titleSmall,
              ),
            ),
            ListTile(
              onTap: () {},
              dense: true,
              title: Text(
                tr.service,
                style: theme.textTheme.bodyMedium,
              ),
              trailing: Text(
                shipment.service.name??'',
                style: theme.textTheme.titleSmall,
              ),
            ),
            ListTile(
              onTap: () {},
              dense: true,
              title: Text(
                tr.weight,
                style: theme.textTheme.bodyMedium,
              ),
              trailing: Text(
                (shipment.weight?.toString()?? "")+ " KG",
                style: theme.textTheme.titleSmall,
              ),
            ),

          ],
        ),
      )
    ];
  }

  Widget createValidateAddressWidget(Shipment shipment){
    if (_canValidate(shipment)) {
      return Container(
        width: double.infinity,
        child: TextButton(
          onPressed: () =>
              Navigator.of(context).pushNamed(
                  "/DeliveryValidation",
                  arguments: RouteArgument(id: shipment.id.toString())
              ),
          child: IconText(
            icon: Icon(Icons.location_on_outlined, color: Colors.green,),
            text: tr.deliveryConfirm,
          ),
          style: TextButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: Theme.of(context).dividerColor)
              )
          ),
          //contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        ),
      );
    }
    return null;
  }


  Widget createPaymentMethod(BuildContext context, Shipment shipment){
    ThemeData theme = Theme.of(context);
    if (shipment == null)
      return const SizedBox();
    if (shipment.amountToDue != null && shipment.amountToDue >= .5){
      if (!_hasCheckout){
        _hasCheckout = true;
        context.read<CheckoutProvider>().paymentStatus.addListener(_reload);
      }
      return Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            child: Row(
              children: [
                Icon(Icons.credit_card, size: 22, color: theme.colorScheme.secondary,),
                const SizedBox(width: 5,),
                Text(
                  S.of(context).payment_mode,
                )
              ],
            ),
          ),
          CheckoutWidget(type: 'deliveries', id: shipment.id)
        ],
      );
    }
    return const SizedBox();
  }

  Widget createPaymentWidget(BuildContext context, Shipment shipment){
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Row(
            children: [
              Icon(Icons.credit_card, size: 22,
                color: Theme.of(context)
                    .colorScheme.secondary,),
              const SizedBox(width: 5,),
              Text(
                S.of(context).payment_mode,
              )
            ],
          ),
        ),
        cartWidget(
          context,
          child : PaymentListTile(payment: shipment.payment,),
          horizontal: 0.0,
          borderRadius: 0.0,
        ),

      ],
    );
  }

  Widget createFooter(BuildContext context, Shipment shipment){

    if (!isWaitingPayment(shipment)){
      return SizedBox();
    }
    final checkoutProvider = context.read<CheckoutProvider>();
    ThemeData theme = Theme.of(context);
    return Container(
      //height: 96,
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
          color: theme.cardColor,
          border: Border(top: BorderSide(color: theme.dividerColor))
      ),
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 40,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    t.total,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
                Helper.getPrice(
                    shipment.amountToDue,
                    context,
                    style: theme.textTheme.titleSmall,
                    currency: shipment.amountToDueCurrency
                )
              ],
            ),
            const SizedBox(height: 5),
            SizedBox(
                width: MediaQuery.of(context).size.width - 40,
                child: ValueListenableBuilder(
                  valueListenable: checkoutProvider.paymentMethodListenable,
                  builder: (context, value, child) =>
                      ElevatedButton(
                        onPressed: checkoutProvider.paymentMethod!= null
                            ? () => checkoutProvider.onCheckout(context)
                            : null,
                        child: Text(
                          t.checkout,
                        ),
                      ),
                )
            ),
          ],
        ),
      ),
    );
  }


  @override
  void refresh() {
    _reload();
  }

  Widget _createTipWidget(dynamic data) {
    TipWidget widget = _createTipWidget0(data) ;
    if (widget != null) {
      return Padding(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          child: widget,
      );
    }
    return const SizedBox.shrink();
  }

  TipWidget _createTipWidget0(dynamic data) {
    if (data is String) {
      return TipWidget(
        assignTips: [
          TodayTip(
          id: '0',
          content: data,
          type: TodayTipType.tip,
          created: DateTime.now(),
        )],
        tipType: TodayTipType.tip,
      );
    }
    if (data is Map) {
      final tip = TodayTip.fromMap(data);
      return TipWidget(
        assignTips: [tip],
        tipType: tip.type,
      );
    }
    if (data is List) {
      return TipWidget(
          assignTips: data.map((data) => TodayTip.fromMap(data))
            .toList().cast<TodayTip>(),
          tipType: TodayTipType.tip,
      );
    }

    return null;
  }

  bool _canValidate(Shipment shipment) {
    final flags = shipment.flags ?? 0;
    print("_canValidate:: flags: $flags");
    return (flags & (W_REQUEST_RETURN|W_DELIVERED)) == 0 &&
        (flags & INVALID_DELIVERY_ADDRESS) != 0;
  }

}
