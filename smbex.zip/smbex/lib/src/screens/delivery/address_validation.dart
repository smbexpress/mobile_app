import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/icon_text.dart';

import '../../../i18n/i18n.dart';
import '../../api.dart';
import '../../config.dart';
import '../../helpers/Debouncer.dart';
import '../../helpers/helper.dart';
import '../../models/address.dart';
import '../../models/model.dart';
import '../../models/route_argument.dart';
import '../../models/shipment.dart';
import '../../notification_provider.dart';
import '../../repository/settings_repository.dart';
import '../../theme/theme.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/calendar_appbar.dart';
import '../../widgets/connection_status_widget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/picker/place_picker/entities/entities.dart';
import '../../widgets/picker/place_picker/place_picker.dart';
import '../../widgets/stack_body.dart';
import '../../widgets/system_ui_overlay_mixin.dart';

class AddressesValidateScreen extends StatefulWidget {
  final RouteArgument args;
  final ValueChanged<Address> onSelect;
  final bool isDelivery;
  AddressesValidateScreen({
    Key key,
    this.args,
    this.onSelect,
    bool isDelivery,
  }) :
        this.isDelivery =
          isDelivery == null
            ? args != null  && args.param != null
              ? args.param['isDelivery'] ?? true
              : true
            : isDelivery,
        super(key: key);

  @override
  _AddressesValidateScreenState createState() =>
      _AddressesValidateScreenState();
}

class _AddressesValidateScreenState extends State<AddressesValidateScreen>
    with SystemUiOverlayMixin, SingleTickerProviderStateMixin {
  //final _debouncer = Debouncer();
  final LoadState<_VShipment> shipmentState =
      LoadState(null, until: Duration(minutes: 5));
  int currentPage = 0;
  LocationResult locationResult;
  bool mapVisible = false;
  bool hasChanges = false;
  @override
  void initState() {
    super.initState();
    initSystemUiOverlay(AppTheme.whiteOverlayStyle);
    shipmentState.addListener(_loadingStateChanged);
    //shipmentState.reload();
    _load();
    //WidgetsBinding.instance.endOfFrame.then((value) => _load());
  }

  @override
  void dispose() {
    shipmentState.removeListener(_loadingStateChanged);
    shipmentState.dispose();
    super.dispose();
    leave();
  }

  void _loadingStateChanged() {}

  void _load() async{
    if (shipmentState.isLoading) return;

    shipmentState.reload();
    WidgetsBinding.instance.endOfFrame.then((value) => setState(() {}));

    final route = widget.isDelivery ? 'deliveries' : 'shipments';
    final fields = widget.isDelivery
        ? 'to_address,delivery_time'
        : 'from_address,pickup_time,pickup_date';
    try {
      final value = await ResultItem.of(
          Api().get("$route/confirmation/${widget.args.id}", data: {'fields': fields}),
              (data) =>
          widget.isDelivery
              ? _VShipment._fromDelivery(data)
              : _VShipment._fromPickup(data));

      shipmentState.update(value.item, value.error);
    } finally{
      if (shipmentState.isLoading)
        shipmentState.update(null);

      setState(() {});
    }

  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: _createAppBar(),
        body: LoadingWidget(
          isLoading: shipmentState.isLoading,
          error: shipmentState.error,
          onRetry: _load,
          child: ConnectionChangeWidget(
              builder: (context, connect) {
                if (connect &&
                    !shipmentState.isLoading && (
                    shipmentState.value == null ||
                        shipmentState.error?.isNetwork == true)) {

                  WidgetsBinding.instance.endOfFrame.then((value) => _load());
                }
                return StackBodyWidget(
                  headerConstraints: BoxConstraints(maxHeight: 48),
                  //header: _createHeaderWidget(),
                  body: _createMapWidget(),
                  footer: _createFooterButtons(),
                );
              }
          ),
        )
      ),
    );
  }

  Widget _createAppBar() {
    if (shipmentState.value != null && false) {
      return CalendarAppBar(
        lastDate: DateTime.now().add(Duration(days: 6)),
        firstDate: DateTime.now(),
        fullCalendar: false,
        accent: Theme.of(context).colorScheme.secondary,
        onDateChanged: (date) {
            print("Date change: $date");
        },
        locale: LocaleSettings.baseLocale.name,
        systemOverlayStyle: AppTheme.blueOverlayStyle,
      );
    }
    return appBar(context,
        automaticallyImplyLeading: false,
        showBack: false,
        isSecondary: false,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        titleText: widget.isDelivery
            ? tr.deliveryConfirm
            : tr.pickupConfirm,
        actions: [
          IconButton(
            onPressed: () {
              //_onWillPop();
              Navigator.of(context).pop();
            },
            icon: Icon(Icons.close),
            tooltip: tr.close,
          )
        ]);
  }

  void _showMap() async{
    if (!mapVisible) {
      mapVisible = true;
      final address = shipmentState.value.address;
      final latLng = address.isUnknown()
          ? LatLng(24.688331, 46.684109)
          : LatLng(address.lat, address.lng);
      print("Address to LatLng: $latLng");
      await Navigator.of(context).push(
          MaterialPageRoute(builder: (context) =>
              PlacePicker(
                settingNotifier.value.googleMapsKey,
                displayLocation: latLng,
                acceptLocation: _acceptLocation,
                onWillPop: _onWillPop,
              )));
      mapVisible = false;
    }

  }

  Widget _createMapWidget() {


    final shipment = shipmentState.value;
    if (shipment == null) {
      return const SizedBox.shrink();
    }

    if (!mapVisible){
      //WidgetsBinding.instance.endOfFrame.then((__) => _showMap());
    }

    Widget row(String title, String value, {bool useNew=true, Widget icon, VoidCallback action}) {
      return ListTile(
        onTap: action,
        leading: icon,
        title: useNew
          ? Text('$title:')
          : Row(
          children: [
            Text('$title:'),
            const SizedBox(width: 10,),
            Expanded(child: Text(value??''))
          ],
        ),
        subtitle: useNew ? Text(value??'') : null,
      );
    }

    return Column(
      children: [
        _createHeaderWidget(),
        const Divider(height: 2, thickness: 1.0),
        Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                const SizedBox(height: 20,),
                row(tr.full_name, shipment.address.name, useNew: true,
                    icon: Icon(Icons.person)),
                const Divider(height: 2, thickness: 1.0),
                row(tr.country, shipment.address.country?.name,
                    useNew: true, icon: Icon(Icons.map)),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.city, shipment.address.city?.name,
                    icon: Icon(Icons.location_city)),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.zip, shipment.address.zip,
                    icon: Icon(Icons.local_post_office_outlined)),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.street, shipment.address.street, useNew: true,
                    icon: Icon(Icons.location_on_outlined)),
                //const Divider(height: 2, thickness: 1.0,),
                SizedBox(height: 20,),

                //const Divider(height: 2, thickness: 1.0,),

              ],
            )
        )
      ],
    );
  }

  _createHeaderWidget() {
    /*
    IconText(
              icon: Icon(Icons.location_on, color: Colors.green,),
              text: tr.selectOnMap,
          )
     */
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Container(
          width: double.infinity,
          child: TextButton(
            onPressed:_showMap,
            child: IconText(
              icon: const Icon(Icons.location_on, color: Colors.green,),
              text: tr.selectOnMap,
            ),
            style: TextButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: Theme.of(context).dividerColor)
                )
            ),
            //contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          ),
        )
    );
  }

  _createFooterButtons() {
    ThemeData theme = Theme.of(context);
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
          color: theme.cardColor,
          border: Border(top: BorderSide(color: theme.dividerColor))),
      child:  ElevatedButton(
        onPressed: hasChanges
            ? sendValidation
            : null,
        child: Text(
          tr.buttons.confirm,
        ),
      ),
    );
  }

  Future<bool> _onWillPop() async{
    //alert(context, tr.ar)
    return false;
  }



  Future<dynamic> _acceptLocation(LocationResult result) async{
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    try {
      final route = widget.isDelivery ? 'deliveries' : 'shipments';
      final data = {
        'lat': result.latLng.latitude,
        'lng': result.latLng.longitude,
        'city': result.city.shortName ?? result.locality,
        'country': result.country.shortName,
        'street': result.formattedAddress
      };

      //Localizations.of(context).

      Config.debug("check_address: $data", widget.runtimeType);

      ResultItem validateRequest = await ApiRequest.post(
          "$route/${widget.args.id}/check_address",
          data: data)
      .once();


      if (validateRequest.hasError) {
        //Helper.hideLoader(loader);

        showSnackBar(
            PlacePicker.context ,
            error: validateRequest.error,
            borderRadius: BorderRadius.circular(8),
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.fromLTRB(20, 0, 20, 68)
        );

        return null;
      } else {
        final address = shipmentState.value.address;
        address.city = City.fromJson(validateRequest.item['city']);
        address.street = result.formattedAddress;

        locationResult = result;

        hasChanges = true;
        setState(() {});
      }
      return true;
    }
    finally{
      Helper.hideLoader(loader);
    }
  }

  void sendValidation() async{
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    try {
      final address = Helper.removeNulls({
        'lat': locationResult.latLng.latitude,
        'lng': locationResult.latLng.longitude,
        'city': locationResult.city.shortName,
        'country': locationResult.country,
        'district': locationResult.district,
        'location': locationResult.formattedAddress
      });
      final data = Helper.removeNulls({
        'address': address,
        'time_window': shipmentState.value.timeWindow?.toMap(),
        'date': shipmentState.value.date
      });

      final route = widget.isDelivery ? 'deliveries' : 'shipments';
      ResultItem validateRequest = await ApiRequest.post(
            "$route/${widget.args.id}/commit_address",
            data: data
          )
          .once();
      if (validateRequest.hasError) {
        showNotifyDialog(context,
            error: validateRequest.error,
            contentType: ContentType.WARNING
        );
      } else {
        context.read<NotificationProvider>()
            .dispatch(
              RemoteMessage(
                data: {
                  'model': route,
                  'res_id': shipmentState.value.id,
                }
              )
            );

        showSuccessSnackBar(context);
        Navigator.of(context).pop();
      }

    } finally{
      Helper.hideLoader(loader);
    }

  }



}

class _VShipment {
  final int id;
  final String trackingCode;
  final Address address;
  final String date;
  final TimeWindow timeWindow;

  _VShipment({this.id, this.trackingCode, this.address, this.date, this.timeWindow});

  factory _VShipment._fromDelivery(dynamic map) {
    return _VShipment(
        id: map['id']?.toInt(),
        trackingCode: map['tracking_code'],
        address: Address.fromJSON(map['to_address'] ?? {}),
        timeWindow: map['delivery_time'] != null
            ? TimeWindow.fromJSON(map['delivery_time'])
            : null);
  }

  factory _VShipment._fromPickup(dynamic map) {
    return _VShipment(
        id: map['id']?.toInt(),
        trackingCode: map['tracking_code'],
        address: Address.fromJSON(map['from_address'] ?? {}),
        timeWindow: map['pickup_time'] != null
              ? TimeWindow.fromJSON(map['pickup_time'])
              : null,
        date: map['pickup_date']);
  }

  _VShipment copyWith({
    String date,
    TimeWindow timeWindow,
    Address address
   }) =>
      _VShipment(
          id: id,
          trackingCode: trackingCode,
          address: address?? this.address,
          timeWindow: timeWindow ?? this.timeWindow,
          date: date ?? this.date
      );

}
