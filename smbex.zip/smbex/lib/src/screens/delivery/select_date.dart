
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smbex_app/src/helpers/helper.dart';

import '../../../i18n/i18n.dart';
import '../../config.dart';
import '../../controllers/shipment_controller.dart';
import '../../helpers/measure_util.dart';
import '../../models/shipment.dart';
import '../../theme/text_styles.dart';
import '../../widgets/time_range/time_range.dart';

class SelectDate extends StatefulWidget {

  final ShipmentController controller;

  const SelectDate({Key key, this.controller}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _SelectDateState();

}

class _SelectDateState extends State<SelectDate> with SingleTickerProviderStateMixin{
  AnimationController _animationController;
  Animation<double> _heightFactor;
  ScrollController _scrollController;
  List<WorkingTime> _pickupTimes = [];
  WorkingTime _selectedWorkingTime;
  TimeWindow _selectedTimeWindow;
  ScrollController _gridController;
  bool _changed = false;
  final DateFormat _dayOfWeekFormat = DateFormat('EEEE');
  final DateFormat _monthOfYearFormat= DateFormat('MMMM');
  final ValueNotifier<bool> _isFocused = ValueNotifier(false);
  final FocusNode _timeWindowFocusNode = FocusNode();
  Size _maxSize;

  void initState(){
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _heightFactor = _animationController.drive(CurveTween(curve: Curves.easeInOutQuart));
    _scrollController = ScrollController();
    _gridController = ScrollController();
    _timeWindowFocusNode.addListener(_timeWindowFocus);
    workingTimesLoadState.addListener(_recreatePickupTimes);
    _animationController.value = (workingTimesLoadState.value?.items?.isEmpty??true) ? 0.0 : 1.0;
    _recreatePickupTimes();
  }

  void dispose(){
    _timeWindowFocusNode.removeListener(_timeWindowFocus);
    workingTimesLoadState.removeListener(_recreatePickupTimes);
    _animationController.dispose();
    super.dispose();
  }

  void _recreatePickupTimes() {

    _pickupTimes.clear();
    _selectedWorkingTime = null;
    _selectedTimeWindow = null;

    if (workingTimesLoadState.isLoading ||
        workingTimesLoadState.error != null ||
        workingTimesLoadState.value == null) {
      _animationController.reverse();
      setState(() {});
      return;
    }


    final items = workingTimesLoadState.value.items ?? [];
    _pickupTimes.addAll(items);
    Config.debug("workingTimesLoadState count: ${items.length}", SelectDate);
    _setSelection();
    if (items.isNotEmpty)
      _animationController.forward();
    else{
      _animationController.reverse();
    }

  }

  void _setSelection() {
    final shipment = widget.controller.shipment;
    final pickupDate = Helper.parseDate(shipment?.pickupDate);
    if (pickupDate != null) {

      for (var workingTime in _pickupTimes) {
        if (workingTime.date == pickupDate){

          if (workingTime.timeSpans.isNotEmpty &&
          !(shipment.pickupTime.isEmpty ?? true) &&
              shipment.pickupTime.start >= workingTime.timeSpans.first &&
              shipment.pickupTime.end <= workingTime.timeSpans.last) {
            _selectedWorkingTime = workingTime;
            _selectedTimeWindow = shipment.pickupTime;
          }
        }
      }
      shipment.pickupDate = Helper.formatDate(_selectedWorkingTime?.date);
      shipment.pickupTime = _selectedTimeWindow;
    } else {
      widget.controller.shipment.pickupTime = null;
    }

    if (_maxSize == null) {
      _maxSize = MeasureUtil.measureWidget(
          _createWorkingTime(
            WorkingTime(
              date: DateTime.utc(2023, 9, 30),
              timeSpans: []
            ),
            true
          )
      );
    }
    _syncWorkingTime();
    setState(() {});

  }

  void _syncWorkingTime() {
    if (_selectedWorkingTime != null) {

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if(mounted && _gridController.hasClients) {
          final renderContext = GlobalObjectKey(_selectedWorkingTime?.date)
            .currentContext;
          RenderBox box = renderContext.findRenderObject();

          // Get its offset
          ScrollPosition position = _gridController.position;
          position.ensureVisible(box,
              duration: const Duration(milliseconds: 400));

        }
      });

    }
  }

  void _timeWindowFocus(){
    _isFocused.value = _timeWindowFocusNode.hasFocus;
  }

  @override
  Widget build(BuildContext context) {
   return Material(

     child: Column(
         crossAxisAlignment: CrossAxisAlignment.start,
         children: [
           if (!workingTimesLoadState.isLoading)
            Text(tr.pickupDate, style: TextStyles.titleM,),
           const SizedBox(height: 10,),
           Center(
               child: workingTimesLoadState.isLoading
                   ? CircularProgressIndicator()
                   : AnimatedBuilder(
                       animation: _animationController,
                       builder: (context, child) => ClipRect(
                           child: Material(
                             color: Theme.of(context).scaffoldBackgroundColor,
                             child: Padding(
                               padding: const EdgeInsets.
                                symmetric(vertical: 5, ),
                               child: Align(
                                   heightFactor: _heightFactor.value,
                                   child: _buildWorkingTimeField(_selectedWorkingTime)
                               ),
                             )
                           )
                       )

                   )

           ),

           if (_selectedWorkingTime != null
               && _selectedWorkingTime.timeSpans.isNotEmpty)
             Padding(
               padding: EdgeInsets.symmetric(vertical: 20),
               child: _buildTimeWindowField(_selectedTimeWindow),
             )
         ],
     ),
   );
  }
  Widget _buildWorkingTimeField(WorkingTime value) {
    return FormField(
        validator: _validateWorkingTime,
        initialValue: value,
        builder: (FormFieldState<WorkingTime> state) {

      if (state.value != _selectedTimeWindow) {
        WidgetsBinding.instance.endOfFrame.then((__) {
          state.didChange(_selectedWorkingTime);
        });
      }

      return SizedBox(
        height: _maxSize?.height ?? 120,
        child: ListView(
          children: List.generate(_pickupTimes.length, (index) =>
              _createWorkingTime(_pickupTimes[index])
          ),
          scrollDirection: Axis.horizontal,
          controller: _gridController,
          shrinkWrap: true,
        ),
      );
    });

  }

   Widget _createWorkingTime(WorkingTime item, [bool test = false]) {
     //WorkingTime item = _pickupTimes[index];
     final shipment = widget.controller.shipment;
     return Container(
       key: GlobalObjectKey(item.date),
       margin: EdgeInsetsDirectional.only(end: 5, ),
       padding: EdgeInsets.all(0),
       decoration: ShapeDecoration(
         shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(6),
           side: test
             ? BorderSide(width: 3)
             : BorderSide(
                 color: _selectedWorkingTime == item
                     ? Theme.of(context).primaryColorDark
                     : Theme.of(context).dividerColor,
                 width: _selectedWorkingTime == item ? 3 : 1,
               ),
         ),
       ),
       child: SizedBox(
         height: _maxSize?.height,
         width: _maxSize?.width,
         child: InkWell(
           borderRadius: BorderRadius.circular(12),
           onTap: () {
             if (_selectedWorkingTime != item) {

               _selectedWorkingTime = item;
               _selectedTimeWindow = null;

               setState(() {});
               _syncWorkingTime();

             }

             _showCardSheetWidget(
                 context,
                 item.timeSpans.first,
                 item.timeSpans.last,
                 selectedTimeWindow: _selectedTimeWindow,
                 onChange: (value) {
                   if (value == null) {
                     _selectedWorkingTime = null;
                   }
                   _selectedTimeWindow = value;

                   shipment.pickupDate =
                       Helper.formatDate(_selectedWorkingTime?.date);
                   shipment.pickupTime = value;

                   widget.controller.validate(0, context);
                   setState(() {});
                   //_syncWorkingTime();
                 }
             );
           },
           child: Padding(
             padding: const EdgeInsets.symmetric(vertical: 5),
             child: FittedBox(
               child: Column(
                 children: [
                   Text(_dayOfWeekFormat.format(item.date),
                     style: TextStyles.body
                         .copyWith(fontWeight: FontWeight.w500),),
                   const SizedBox(height: 5,),
                   Padding(
                     padding: EdgeInsets.all(10),
                     child: Text(_monthOfYearFormat.format(item.date)),
                   ),
                   const SizedBox(height: 5,),
                   Text(item.date.day.toString(),
                     style: TextStyles.title
                         .copyWith(fontWeight: FontWeight.w600),)
                 ],
               )
             ),
           )
         ),
       )
     );
   }

  Widget _buildTimeWindowField(TimeWindow value) {
    return FormField(
      validator: _validateTimeWindow,
      initialValue: value,
      builder: (FormFieldState<TimeWindow> state) {
        String timeFormat = '';

        if (state.value != null && !state.value.isEmpty) {
          final fl = MaterialLocalizations.of(context);
          final startTimeOfDay = _toTimeOfDay(state.value.start);
          final endTimeOfDay = _toTimeOfDay(state.value.end);
          timeFormat = fl.formatTimeOfDay(startTimeOfDay) +
              ' - ' + fl.formatTimeOfDay(endTimeOfDay);

        }
        if (state.value != _selectedTimeWindow) {
          WidgetsBinding.instance.endOfFrame.then((__) {
            state.didChange(_selectedTimeWindow);
          });
        }

        return InputDecorator(
            isEmpty: state.value == null ,
            isFocused: false,
            child: Text(timeFormat,
              textAlign: TextAlign.center,
              style: TextStyles.title.copyWith(fontWeight: FontWeight.w500),
            ),
            decoration: InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(12, 6, 12, 6),
            )
        );
      },

    );
  }

  String _validateWorkingTime(WorkingTime tm) {
      return tm == null ? tr.form.requiredErrorText : null;
  }

  String _validateTimeWindow(TimeWindow tm) {
    return tm == null ? tr.form.requiredErrorText : null;
  }

}

TimeOfDay _toTimeOfDay(double time){
  int hour = time.floor();
  int minute = (time.remainder(hour.toDouble()) * 60.0).ceil();

  if (minute >= 60) {
    minute = 0;
    hour += 1;

  }
  if (hour >= 24) {
    minute = 59;
    hour = 23;
  }
  return TimeOfDay(hour: hour, minute:minute);
}

double _toFloatTime(TimeOfDay timeOfDay) {
  return timeOfDay.hour.toDouble()
      + (timeOfDay.minute.toDouble() / 60.0 * 100)
          .roundToDouble() / 100.0;
}

void _showCardSheetWidget(BuildContext gContext,
   double startTime, double endTime, {
      int minimalTimeRange,
      int timeStep,
      TimeWindow selectedTimeWindow,
      void onChange(TimeWindow wi)
  }) async {

  final fl = MaterialLocalizations.of(gContext);
  TimeRangeResult initialRange = null;
  if (selectedTimeWindow != null) {
    initialRange = TimeRangeResult(
        _toTimeOfDay(selectedTimeWindow.start),
        _toTimeOfDay(selectedTimeWindow.end)
    );
  }

  showModalBottomSheet(
    context: gContext,
    isDismissible: false,
    isScrollControlled: true,
    enableDrag: false,
    useSafeArea: false,
    builder: (context) {
      return SafeArea(
          child: LayoutBuilder(
              builder: (context, box) {
                final mq = MediaQuery.of(gContext);
                final top = max(mq.padding.top, 20.0);
                final height = min((box.maxHeight - top) * .5, 300.0);
                return ConstrainedBox(
                  constraints: BoxConstraints(
                      minWidth: min(600, box.maxWidth),
                      maxHeight: height
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      //Container(height: top, color: Colors.transparent,),
                      SizedBox(
                        height: 48.0,
                        child: Card(
                          margin: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(fl.cancelButtonLabel,),

                                InkWell(
                                  child: Icon(Icons.close),
                                  onTap: () {
                                    Navigator.of(context).pop();
                                    if (initialRange == null) {
                                      onChange?.call(null);
                                    }

                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      ConstrainedBox(
                        constraints: BoxConstraints(maxHeight: height - 48.0),
                        child: TimeRange(
                          firstTime: _toTimeOfDay(startTime),
                          lastTime: _toTimeOfDay(endTime),
                          timeStep: timeStep ?? 60,
                          minimalTimeRange: minimalTimeRange ?? 120,
                          timeBlock: 120,
                          initialRange: initialRange,
                          fromTitle: Text(tr.from, style: TextStyles.titleM.copyWith(fontWeight: FontWeight.w500)),
                          toTitle: Text(tr.to, style: TextStyles.titleM.copyWith(fontWeight: FontWeight.w500)),
                          onRangeCompleted: (result) {
                            if (result != null) {
                              onChange?.call(
                                  TimeWindow.of(
                                      _toFloatTime(result.start),
                                      _toFloatTime(result.end),
                                      fl.formatTimeOfDay(result.start) +
                                          ' - ' +
                                          fl.formatTimeOfDay(result.end)
                                  )
                              );
                              Navigator.of(context).pop();
                            }
                          },
                        ),
                      )

                    ],
                  ),
                );
              }
          )
      );
    },
  );

}