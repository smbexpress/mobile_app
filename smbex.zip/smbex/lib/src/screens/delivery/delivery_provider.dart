

import 'package:flutter/material.dart';

import '../../api.dart';
import '../../models/address.dart';
import '../../models/model.dart';
import '../../models/shipment.dart';

class DeliveryProvider extends ChangeNotifier{
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Shipment _shipment;
  ErrorResult _errorResult;
  Function _retryFunc;
  bool _needsReload = true;
  bool _loading = false;

  bool get isLoading => _loading;

  ErrorResult get error => _errorResult;

  Shipment get shipment => _shipment;
  void set shipment(Shipment shipment){
    _shipment = shipment;
  }


  Future<ResultItem<Shipment>> loadShipment(int shipmentId) async{
    if (_loading)
      return ResultItem(item: shipment);
    _loading = true;
    _needsReload = true;
    _errorResult = null;
    _retryFunc  = null;
    WidgetsBinding.instance.endOfFrame.then((value) => notifyListeners());

    Future<ResultItem<Shipment>> future =
      ResultItem.of(Api().get("deliveries/$shipmentId"),
            (data) {
          print("Received delivery amount due: ${data['cod_amount_due']}");
          return Shipment.ofDelivery(data);
        });
    ResultItem<Shipment> resultItem;
    future.then((result) {
      resultItem = result;
      if (result.hasError) {
        _errorResult = result.error;
        this.shipment = null;
        _retryFunc = () => loadShipment(shipmentId);
      } else{
        this.shipment = result.item;

        _retryFunc = null;
        _needsReload = false;
      }
      _errorResult = result.error;

    }).catchError((onError)=>{
      if (onError is ErrorResult)
        _errorResult = onError,
    }) .whenComplete((){
      _loading=false;
      notifyListeners();
      return resultItem;
    });

    return future;
  }

  static Future<ResultItems<TinyShipment>> _getLoadMore(LoadArgs loadArgs, int offset) async {
    Map<String, dynamic> args = Map.of(loadArgs.args);

    args['offset'] = offset;
    Future<ResultItems<TinyShipment>> result= ResultItems.of(Api().post("deliveries/list", data: args),
            (data) => TinyShipment.fromJSON(data));
    //final ResultItems<Shipment> result = await repo.getShipmentsWith(args);
    return result;
  }

  static LoadMore<TinyShipment> getShipmentLoadMore(
      Map<String, dynamic> args, LoadMoreNotify<TinyShipment> onLoadMore) {
    LoadArgs loadArgs = LoadArgs(args: args);
    var loadMore = LoadMore<TinyShipment>(loadArgs, loadMoreProvider: _getLoadMore, onLoadMore:onLoadMore);

    return loadMore;
  }

  void checkout() {

  }

  bool get needsReload => _needsReload;


}

