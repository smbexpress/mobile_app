import 'package:flutter/material.dart';
import 'package:settings_ui/settings_ui.dart';

import '../../../i18n/i18n.dart';
import '../../widgets/SmbWidget.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({Key key}) : super(key: key);

  @override
  _NotificationsScreenState createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState
    extends State<NotificationsScreen> {
  bool useNotificationDotOnAppIcon = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).cardColor,
      appBar: appBar(
        context,
        titleText: tr.notification_settings,
        isSecondary: false
      ),
      body: SettingsList(
        platform: PlatformUtils.detectPlatform(context),
        lightTheme: SettingsThemeData(settingsListBackground: Colors.transparent),
        darkTheme: SettingsThemeData(settingsListBackground: Colors.transparent),
        sections: [
          SettingsSection(
            //title: Text('General'),
            tiles: [

              SettingsTile.switchTile(
                title: Text('Shipment status'),
                initialValue: false,
                onToggle: (_) {},
                description: Text('Received when the shipment status is updated'),
              ),

              SettingsTile.switchTile(
                title: Text('Delivery status'),
                initialValue: false,
                onToggle: (_) {},
                description: Text('Received when the delivery status is updated'),
              ),

              SettingsTile.switchTile(
                title: Text('Offers and promotions'),
                initialValue: false,
                onToggle: (_) {},
                description: Text('Received when new offers become available'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
