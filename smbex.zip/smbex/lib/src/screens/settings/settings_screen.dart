import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:settings_ui/settings_ui.dart';
import 'package:share/share.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:smbex_app/src/config.dart';

import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/repository/settings_repository.dart';
import 'package:smbex_app/src/theme/extention.dart';
import 'package:smbex_app/src/theme/theme.dart';

import '../../../i18n/i18n.dart';
import '../../helpers//navigation.dart';
import '../../helpers/helper.dart';
import '../../helpers/upgrader.dart';
import '../../models/model.dart';
import '../../models/route_argument.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/feedback_widget.dart';
import 'notifications_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    Key key,
  }) : super(key: key);

  //@override
  Widget build00(BuildContext context) {
    final query = MediaQuery.of(context);
    return Stack(
      fit: StackFit.expand,
      children: [
        /*
        Positioned(
            top: -50,
            height: 100,
            left: 0,
            right: 0,
            child: AnnotatedRegion<SystemUiOverlayStyle>(
              value: AppTheme.whiteOverlayStyle,
              child: Container(
                //color: AppTheme.blueOverlayStyle.statusBarColor,
                constraints: BoxConstraints.expand(),
              ),
            )
        ),

         */
        //build0(context)
      ],
    );
  }

  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).cardColor,
      //appBar: AppBar(title: Text('Settings')),
      child: SettingsList(
        platform:
            DevicePlatform.android, //PlatformUtils.detectPlatform(context),
        lightTheme:
            SettingsThemeData(settingsListBackground: Colors.transparent),
        darkTheme:
            SettingsThemeData(settingsListBackground: Colors.transparent),
        sections: [
          //if (!currentAccount.value.valid)

          if (!currentAccount.value.valid)
            SettingsSection(tiles: [
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/Login'),
                title: Padding(
                  padding: const EdgeInsets.only(top: 30),
                  child: Text(tr.login),
                ),
                description: Text(tr.loginOrSignupDes),
                leading: Icon(Icons.person),
              ),
            ]),
          if (currentAccount.value.valid)
            SettingsSection(tiles: [
              CustomSettingsTile(
                  child: AnnotatedRegion<SystemUiOverlayStyle>(
                value: AppTheme.blueOverlayStyle,
                child: UserAccountsDrawerHeader(
                  decoration: BoxDecoration(
                      color: AppTheme.blueOverlayStyle.statusBarColor,
                      image: DecorationImage(
                          image: AssetImage("assets/img/logo1.png"),
                          alignment: AlignmentDirectional.centerEnd)),
                  accountName: Text(
                    currentAccount.value.name,
                    style: Theme.of(context).textTheme.subtitle1.white,
                  ),
                  accountEmail: Text(
                    currentAccount.value.email ??
                        currentAccount.value.mobile ??
                        '',
                    style: Theme.of(context).textTheme.caption.white,
                  ),
                  currentAccountPicture: CircleAvatar(
                      backgroundColor: Theme.of(context).colorScheme.secondary,
                      child: Container(
                        child: Icon(
                          Icons.person,
                          color: Colors.white,
                        ),
                      )),
                ),
              ))
            ]),
          if (currentAccount.value.valid)
            SettingsSection(title: Text(tr.accountSettings), tiles: [
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/Profile'),
                title: Text(tr.accountSettings),
                description: Text(tr.accountSettingsDes),
                leading: Icon(Icons.person),
              ),
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/PaymentMethods'),
                title: Text(tr.paymentMethods),
                description: Text(tr.payment_options),
                leading: Icon(Icons.payment),
              ),
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/Transactions'),
                title: Text(tr.transactions),
                description: Text(tr.transactions),
                leading: Icon(Icons.money),
              ),
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/Bills'),
                title: Text(tr.myBills),
                description: Text(tr.bills),
                leading: Icon(Icons.monetization_on_outlined),
              ),
              /*
              SettingsTile(
                onPressed: (context) => toNotificationsScreen(context),
                title: Text(tr.notification_settings),
                description: Text('Notification history, conversations'),
                leading: Icon(Icons.notifications_none),
              ),
              */
              SettingsTile(
                onPressed: confirmLogout,
                title: Text(tr.log_out),
                leading:
                    Icon(Icons.power_settings_new, color: Colors.redAccent),
              ),
            ]),
          if (currentAccount.value.valid)
            SettingsSection(
              title: Text(tr.addresses),
              tiles: [
                SettingsTile(
                  onPressed: (context) => Navigator.of(context).pushNamed(
                      '/Addresses',
                      arguments: RouteArgument(id: '1')),
                  title: Text(tr.pickup_addresses),
                  description: Text(tr.browsePickupAddressDes),
                  leading: Icon(Icons.gps_fixed),
                ),
                SettingsTile(
                  onPressed: (context) =>
                      Navigator.of(context).pushNamed('/Addresses'),
                  title: Text(tr.delivery_addresses),
                  description: Text(tr.browseDeliveryAddressDes),
                  leading: Icon(Icons.location_on),
                ),
              ],
            ),


          SettingsSection(
            title: Text(tr.general),
            tiles: [
              SettingsTile(
                onPressed: (context) =>
                    Navigator.of(context).pushNamed('/Languages'),
                title: Text(tr.languages),
                description: Text(tr.select_your_preferred_languages),
                leading: Icon(Icons.translate),
              ),
              SettingsTile(
                onPressed: (context) => Helper.launchWebsite('help'),
                title: Text(tr.help_supports),
                description: Text(tr.helpTopicsDes),
                leading: Icon(Icons.help),
              ),
              SettingsTile(
                onPressed: (context) => Helper.launchWebsite('privacy'),
                title: Text(tr.privacy),
                description: Text(tr.openPrivacyDes),
                leading: Icon(Icons.privacy_tip),
              ),
              SettingsTile(
                onPressed: (context) =>
                    Helper.launchWebsite('term-and-conditions'),
                title: Text(tr.termAndConditions),
                description: Text(tr.openTermsDes),
                leading: Icon(Icons.volume_up_outlined),
              ),
              SettingsTile(
                onPressed: (context) => Helper.launchWebsite('about-us'),
                title: Text(tr.about),
                description: Text(tr.infoAboutDes),
                leading: Icon(Icons.info),
              ),
              SettingsTile(
                onPressed: _showFeedbackBottomSheet,
                title: Text(tr.senFeedback),
                description: Text(tr.senFeedbackDes),
                leading: Icon(Icons.feedback),
              ),
              SettingsTile(
                onPressed: (context) => _shareApp(context),
                title: Text(tr.shareApp),
                //description: Text('Send feed back to support '),
                leading: Icon(Icons.share),
              ),
              if (settingNotifier.value.enableVersion)
                SettingsTile(
                  title: Text(tr.version),
                  //description: Text(Config.version),
                  description:  Text('${Config.version} (${Config.buildNumber})' )
                  //leading: Icon(Icons.vers),
                ),
            ],
          ),
        ],
      ),
    );
  }

  void toNotificationsScreen(BuildContext context) {
    Navigation.navigateTo(
      context: context,
      screen: NotificationsScreen(),
      style: NavigationRouteStyle.cupertino,
    );
  }

  void _shareApp(BuildContext context){
    final platform = Theme.of(context).platform;
    final shareUrl = kSettings.shareUrl ?? '${Config().url}share';

    Share.share('${tr.shareText} $shareUrl', subject: tr.shareTitle);

  }

  void confirmLogout(BuildContext context) async {
    final content = Padding(
      padding: EdgeInsets.all(10),
      child: Text(tr.logoutConfirm),
    );
    //on logout Navigator.of(context).pushNamedAndRemoveUntil('/Home', (Route<dynamic> route) => false)
    bool result =
        await alert(context, content: content, confirmText: tr.log_out);
    if (result == true) {
      logout();
      Navigator.of(context)
          .pushNamedAndRemoveUntil('/Home', (Route<dynamic> route) => false);
    }
  }

  void _showFeedbackBottomSheet(BuildContext context) {

    final sendFeedback = (FeedbackResult result) async{
      final loader = Helper.overlayLoader(context);
      Overlay.of(context).insert(loader);

      try{
        ResultItem response =
            await ApiRequest.post('app/feedback',
                data: {
                  'subject': result.subject,
                  'body': result.body,
                  'rate': result.rate
                })
            .once();

        if (!response.hasError) {
          showSuccessSnackBar(context);
        }

      } finally {
        Helper.hideLoader(loader);
      }

    };

    FeedbackInfo feedback = FeedbackInfo(
      hasRate: true,
      hasSubject: true,
      bodyHelp: tr.writeFeedbackToUs,
      sheetTitle: tr.writeFeedback,
      submitTitle: tr.senFeedback,
      callback: (BuildContext context, FeedbackResult result) {
        Navigator.of(context).pop();
        sendFeedback(result);
      }
    );

    showFeedbackBottomSheet(context, feedback);
  }
}
