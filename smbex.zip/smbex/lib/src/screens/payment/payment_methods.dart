import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../../i18n/i18n.dart';
import '../../models/model.dart';
import '../../models/payment_method.dart';
import '../../models/route_argument.dart';
import '../../widgets/PaymentMethodsSheetWidget.dart';
import '../../widgets/payment_method_list_tile.dart';
import '../../widgets/ShoppingCartButtonWidget.dart';


class PaymentMethodsWidget extends StatefulWidget {
  final RouteArgument routeArgument;

  PaymentMethodsWidget({Key key, this.routeArgument}) : super(key: key);

  @override
  _PaymentMethodsWidgetState createState() => _PaymentMethodsWidgetState();
}

class _PaymentMethodsWidgetState extends State<PaymentMethodsWidget> {
  PaymentMethodList list;

  @override
  void initState() {
    list = new PaymentMethodList();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar(
        context,
        titleText: tr.paymentMethods,
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(
                child: PaymentMethodsSheetWidget(
                  data: {'providers': 'hyperpay'},
                  showCardsOnly: true,
                  onDelete: _deletePaymentCard,
                  paymentType: 'payments',

                  //onSelect: (item) {},
                ))
          ],
        ),
      )

    );
  }

  Widget createPaymentMethodItemTile(
      BuildContext context, PaymentCard item,
      {
        bool isSelected,
        bool selectable,
        VoidCallback onEdit,
        VoidCallback onDelete,
        VoidCallback onTap
      }) {

    Widget trailing = PopupMenuButton(
        icon: Icon(Icons.more_vert),
        itemBuilder: (BuildContext context) {
          List<PopupMenuEntry> items = [
            if (onEdit != null)
              PopupMenuItem(
                onTap: onEdit,

                child: Row(
                  children: [
                    const Icon(Icons.edit),
                    const SizedBox(width: 10,),
                    Text(tr.edit)
                  ],
                ),
              ),
            if (onDelete != null)
              PopupMenuItem(
                onTap: onDelete,
                child: Row(
                  children: [
                    const Icon(Icons.delete, color: Colors.redAccent,),
                    const SizedBox(width: 10,),
                    Text(tr.buttons.remove)
                  ],
                ),
              ),
          ];

          return items;

        }
    );

    return ListTile(
        key: ValueKey(item.id),
        title: Row(
          children: [
            Text('**** **** ${item.name}')
          ],
        ),
        subtitle: item.expire?.isNotEmpty == true
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //Text(item.name, style: TextStyles.titleM),
              Text( item.expire ?? "",
                style: item.expired
                    ? TextStyle(color: Theme.of(context).colorScheme.error)
                    : null,
              ),
          ],
        ) : null,
        leading: Container(
          height: double.infinity,
          //width: 60,
          child: item.icon.startsWith('http')
              ? CachedNetworkImage(
                  imageUrl: item.icon,
                  placeholder: (context, url) => CircularProgressIndicator(),
                  errorWidget: (context, url, error) => Icon(Icons.credit_card),
                  width: 60,
                  height: 60,
              )
              : Image.asset(
                  item.icon,
                  width: 40,
                  height: 40,
                ),
        ),
        trailing: trailing,
        dense: false,
        //isThreeLine: true,
        onTap: onTap
    );
  }

  Future<bool> _deletePaymentCard(
      BuildContext context, PaymentCard pc) async {

    final ok = await alert(context,
        content: Text(tr.confirmDeleteItem(tr.paymentCard, pc.name)),
        title: Text(tr.confirmation)
    );
    if ( ok == true ){
      ResultItem<bool> result =
        await ApiRequest
            .post(
            'payments/removeCard/${pc.id}',
            serializer: (data) => (data == true)
        ).once();

      if (result.hasError) {
        //showSnackBar(context, error: result.error);
        showErrorDialog(context, error: result.error, fullWidth: true);
        return false;
      }

      return result.data == true;

    }

    return false;
  }

}
