import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/models/cart.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';
//import 'package:webview_flutter/webview_flutter.dart';

import '../../../i18n/i18n.dart';
import '../../controllers/hyperpay_controller.dart';

// ignore: must_be_immutable
class HyperpayPaymentWidget extends StatefulWidget {
  Cart cart;
  Transaction tx;
  String url;
  HyperpayPaymentWidget({Key key, this.cart, this.tx, this.url}) : super(key: key);
  @override
  _HyperpayPaymentWidgetState createState() => _HyperpayPaymentWidgetState(HyperpayController(url));
}

class _HyperpayPaymentWidgetState extends StateMVC<HyperpayPaymentWidget> {
  HyperpayController _con;
  _HyperpayPaymentWidgetState(HyperpayController controller) : super(controller) {
    _con = controller;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      appBar: appBar(context, titleText: S.of(context).payment_options),
      body: Stack(
        children: <Widget>[
          /*
          WebView(
            initialUrl: _con.url,
            onPageStarted: (String url) {

              if (url.startsWith("com.smb.smbex.oppwa:")){

              }

              setState(() {
                _con.url = url;
              });
              var apiUrl = Api().config.url;
              Uri uri = Uri.tryParse(url);
              if (uri != null){
                  var lurl = "${uri.scheme}://${uri.host}";
                  if (uri.port != null && uri.port != 80){
                    lurl += ":${uri.port}/";
                  } 
                  lurl += "/${uri.path}";
                  if (lurl == "${apiUrl}payment/process") {
                    Map<String, String> parama = uri.queryParameters;
                    var route = widget.cart?.route;
                    Navigator.of(context).pop();

                    //Future<ResultItem<dynamic>> result = ResultItem.get<dynamic>("payment/status/poll?id=${parama['id']}");

                    //Navigator.of(context).pushReplacementNamed('/Home', arguments: 3);

                  }
              }


              
            },
            onPageFinished: (String url) {
              if (url.startsWith("com.smb.smbex.oppwa:")){
                Navigator.of(context).pop();
              }
            },

            onProgressChanged: (InAppWebViewController controller, int progress) {
              setState(() {
                _con.progress = progress / 100;
              });
            },
          ),
          */
          _con.progress < 1
              ? SizedBox(
            height: 3,
            child: LinearProgressIndicator(
              value: _con.progress,
              backgroundColor: Theme.of(context).primaryColorDark
            ),
          )
              : SizedBox(),
        ],
      ),
    );
  }
}
