import 'package:flutter/material.dart';
import 'package:smbex_app/src/screens/wallet/widgets/money_presets_group.dart';
import 'package:smbex_app/src/screens/wallet/widgets/wallet_card_view.dart';
import 'package:smbex_app/src/theme/extention.dart';

import '../../../i18n/i18n.dart';
import '../../theme/text_styles.dart';
import '../../widgets/SmbWidget.dart';
import 'widgets.dart';

class Wallet extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;
  Wallet({Key key, this.parentScaffoldKey}) : super(key: key);
  @override
  _WalletState createState() => _WalletState();
}

class _WalletState extends State<Wallet> {

  double _opacity = 0.0;

  @override
  Widget build(BuildContext context) {

    if (_opacity == 0.0)
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        _opacity = 1.0;
        setState((){});
      });

    return Scaffold(
      //backgroundColor: Color(0xffdee4eb),
      appBar: appBar(
        context,
        titleText: "Wallet",
        isSecondary: false,
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add,
              color: Colors.black54,
            ),
            onPressed: _addCredit,
          ),
          /*
          IconButton(
            icon: Container(
              height: 21,
              width: 21,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.notifications,
                    color: Colors.black54,
                  ),
                ],
              ),
            ),
            onPressed: () {},
          ),

           */
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[

            /*
            AnimatedOpacity(
              opacity: _opacity,
              duration: Duration(milliseconds: 300),
              child: Container(
                padding: EdgeInsets.only(bottom: 26),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 5.0,
                        color: Colors.grey[300],
                        spreadRadius: 5.0),
                  ],
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(51),
                    bottomLeft: Radius.circular(51),
                  ),
                  color: Colors.white,
                ),
                child: Hero(
                  tag: "card",
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      child: CreditCardContainer(),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) {
                              return Cards(title: "My Cards");
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),

            SizedBox(height: 10,),
            AnimatedOpacity(
              opacity: _opacity,
              duration: const Duration(milliseconds: 1600),
              child: CustomContainer(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    CustomIconButton(
                      circleColor: IconColors.send,
                      icon: Icons.send,
                      buttonTitle: "CHARGE",
                      onTap: () {},
                    ),
                    CustomIconButton(
                      circleColor: IconColors.transfer,
                      icon: Icons.move_to_inbox,
                      buttonTitle: "REFUND",
                      onTap: () {},
                    ),
                    CustomIconButton(
                      circleColor: IconColors.passbook,
                      icon: Icons.compass_calibration,
                      buttonTitle: "REPORT",
                      onTap: () {},
                    ),
                    CustomIconButton(
                      circleColor: IconColors.more,
                      icon: Icons.more,
                      buttonTitle: "MORE",
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            ),
            */
            const SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: AnimatedOpacity(
                opacity: _opacity,
                duration: const Duration(milliseconds: 800),
                child: WalletCardView(
                  currency: 'SAR',
                  credit: 0.0,
                  onAdddCredit: _addCredit,
                  onRedeemGiftCard: (){},
                ),
              )
            ),
            const SizedBox(height: 20,),
            AnimatedOpacity(
              opacity: _opacity,
              duration: const Duration(milliseconds: 800),
              child: CustomContainer(
                padding: const EdgeInsets.symmetric(vertical: 15.0),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            "Last Transactions",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          OutlinedButton(
                            onPressed: () {},
                            child: Text(tr.more),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Theme.of(context).colorScheme.secondary),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: const BorderRadius.all(
                                      const Radius.circular(15.0)
                                  )
                              )
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15.0,
                    ),
                    ListView(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      children: <Widget>[
                        HistoryListTile(
                          iconColor: IconColors.transfer,
                          onTap: () {},
                          transactionAmount: "+SAR00.00",
                          icon: Icons.download,
                          transactionName: "Charge",
                          transactionType: "2022/08/22",
                        ),
                        HistoryListTile(
                          iconColor: IconColors.transfer,
                          onTap: () {},
                          transactionAmount: "-SAR00.00",
                          icon: Icons.upload,
                          transactionName: "Refund",
                          transactionType: "2022/08/18",
                          nigative: true,
                        ),
                        HistoryListTile(
                          iconColor: IconColors.send,
                          onTap: () {},
                          transactionAmount: "-SAR00.00",
                          icon: Icons.send,
                          transactionName: "Payment",
                          transactionType: "2022/08/17",
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }

  void _addCredit(){
    final th = Theme.of(context);

    showModalBottomSheet(
        context: context,
        isDismissible: false,
        isScrollControlled: true,
        backgroundColor: th.cardColor,
        shape: const RoundedRectangleBorder(
          borderRadius: const BorderRadius.only(
              topLeft: const Radius.circular(12.0),
              topRight: const Radius.circular(12.0),
          ),
        ),
        builder: (context) {
          final mq = MediaQuery.of(context);
          ValueNotifier<double> amount = ValueNotifier<double>(0.0);
           return SafeArea(
             minimum: EdgeInsets.only(
                 top: mq.padding.top,
                 bottom: mq.viewInsets.bottom
             ),
             child: Material(
               //padding: const EdgeInsets.symmetric(horizontal: 20),
               //color: th.cardColor,
               child: Column(
                 mainAxisAlignment: MainAxisAlignment.start,
                 mainAxisSize: MainAxisSize.min,
                 children: [
                   SizedBox(
                     height: 2.0,
                   ),
                   /*
                   Row(
                     mainAxisAlignment: MainAxisAlignment.center,
                     children: <Widget>[
                       Container(
                         width: 50,
                         height: 5,
                         decoration: BoxDecoration(
                           color: Colors.grey[300],
                           //borderRadius: BorderRadius.all(Radius.circular(12.0))
                         ),
                       ),
                     ],
                   ),

                    */
                   Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Row(
                         //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                         children: <Widget>[
                           Icon(
                             Icons.highlight_remove_rounded,
                             size: 32,
                           ).p(6).ripple(()=> Navigator.of(context).pop(),
                               shape: const CircleBorder(),
                               splashColor: th.shadowColor
                           ),
                           SizedBox(width: 5.0,),
                           Text(
                             'Add payment',
                             style: TextStyles.titleMedium,
                           ),
                         ],
                       ),
                       Padding(
                         padding: EdgeInsets.symmetric(horizontal: 15.0),
                         child: ValueListenableBuilder(
                           valueListenable: amount,
                           builder: (context, value, widget)=>
                               OutlinedButton(
                                   onPressed: amount.value > 0 ? (){

                                   } : null,
                                   child: Text(
                                       tr.submit
                                   )
                               ),
                         )
                       )
                     ],
                   ),
                   Divider(
                     height: 1,
                     thickness: .6,
                   ),
                   SizedBox(
                     height: 8.0,
                   ),
                   MoneyPresetsGroup(
                       onAmountChanged: (inAmount){
                         amount.value = inAmount;
                       }
                   )
                 ],
               ),
             ),
           ) ;
        }
    );
  }


}
