
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../../i18n/i18n.dart';
import '../../models/payment_method.dart';
import '../../theme/text_styles.dart';

class IconColors {
  static const Color send = Color(0xffecfaf8);
  static const Color transfer = Color(0xfffdeef5);
  static const Color passbook = Color(0xfffff4eb);
  static const Color more = Color(0xffeff1fe);
}


class HistoryListTile extends StatelessWidget {
  final Color iconColor;
  final String transactionName,
      transactionType,
      transactionAmount;
  final IconData icon;
  final bool nigative;
  final GestureTapCallback onTap;
  const HistoryListTile({
    Key key,
    this.iconColor,
    this.transactionName,
    this.transactionType,
    this.transactionAmount,
    this.icon,
    this.onTap,
    this.nigative=false
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: ListTile(
        title: Text(transactionName),
        subtitle: Text(transactionType),
        trailing: Text(transactionAmount , style: TextStyle(color: nigative ? Colors.redAccent : Colors.green),),
        leading: CircleAvatar(
          radius: 25,
          child: Icon(
            icon,
            size: 25
          ),
          backgroundColor: iconColor,
        ),
        enabled: true,
        onTap: onTap,
        //contentPadding: EdgeInsets.zero,
      ),
    );
  }
}

class CustomRoundedButton extends StatelessWidget {
  final Color color;
  final String buttonText;
  final GestureTapCallback onTap;
  CustomRoundedButton({
    @required this.color,
    @required this.buttonText,
    @required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return Material(
      child: InkWell(
        onTap: () {},
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 13.0, vertical: 7.0),
          decoration: BoxDecoration(
            color: Colors.transparent,
            border: Border.all(color: color),
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Text(
            "More",
            style: TextStyle(color: color),
          ),
        ),
      ),
    );
  }
}

class CustomIconButton extends StatelessWidget {
  final String buttonTitle;
  final GestureTapCallback onTap;
  final IconData icon;
  final Color circleColor;
  const CustomIconButton({
    @required this.circleColor,
    @required this.buttonTitle,
    @required this.icon,
    @required this.onTap,
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.all(5.0),
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                radius: 30,
                backgroundColor: circleColor,
                child: Icon(
                  icon,
                  size: 26
                ),
              ),
              SizedBox(
                height: 8.0,
              ),
              Text(
                buttonTitle,
                overflow: TextOverflow.clip,
                style: TextStyle(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CreditCardContainer extends StatelessWidget {
  final PaymentCard card;
  const CreditCardContainer({
    Key key,
    this.card
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final expire = card?.expire?.split('/') ?? ['00', '00'];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 18, vertical: 21),
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
              blurRadius: 5.0, color: Colors.red[200], offset: Offset(0, 5)),
        ],
        borderRadius: BorderRadius.circular(15.0),
        gradient: LinearGradient(
          colors: [
            const Color(0xffff8964),
            const Color(0xffff5d6e),
            //const Color(0xFF3383CD),
            //const Color(0xFF11249F),
          ],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: 16,),
            Container(
              child: Icon(Icons.tab_rounded, color: Colors.white, size: 40,),
            ),
            SizedBox(height: 16,),
            Text(
              card?.name?? "**** **** **** 9010",
              style: TextStyle(color: Colors.white, fontSize: 25),
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Text(
                      tr.expiry_date,
                      style: TextStyle(color: Colors.white, fontSize: 11.0),
                    ),
                    Text(
                      '${expire[0]}/${expire[1].length > 2 ? expire[1].substring(2) : expire[1]}',
                      style: TextStyle(color: Colors.white, fontSize: 17),
                    ),
                  ],
                ),
                SizedBox(
                  width: 21,
                ),
              ],
            ),
            SizedBox(
              height: 11,
            ),
            Text(
              card?.holder ?? "No Name",
              style: TextStyle(
                color: Colors.white,
                fontSize: 19,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomContainer extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  CustomContainer({@required this.child, this.padding=const EdgeInsets.symmetric(vertical: 15.0, horizontal: 21)});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      margin: EdgeInsets.all(15.0),
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            blurRadius: 5.0,
            color: Colors.grey[300],
            spreadRadius: 5.0,
          ),
        ],
        borderRadius: BorderRadius.circular(26),
        color: Colors.white,
      ),
      child: child,
    );
  }
}


