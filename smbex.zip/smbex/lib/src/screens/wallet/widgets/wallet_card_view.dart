// @dart=2.12
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../i18n/i18n.dart';
import '../../../repository/account_repository.dart';
import '../../../theme/theme.dart';

const MaterialColor primaryColors = MaterialColor(
  0xff226bf2, // 0% comes in here, this will be color picked if no shade is selected when defining a Color property which doesn’t require a swatch.
  <int, Color>{
    50: Color(0xfffafbfc), //10%
    100: Color(0xffedf3ff), //20%
    200: Color(0xffd0e0ff), //30%
    300: Color(0xffc4d9ff), //40%
    400: Color(0xff89b3ff), //50%
    500: Color(0xff5892fa), //60%
    600: Color(0xff094ac3), //70%
    700: Color(0xff0037a5), //80%
    800: Color(0xff002771), //90%
    900: Color(0xff031e52), //100%
  },
);

class WalletCardView extends StatelessWidget {
  final String currency;
  final double credit;
  final Function() onAdddCredit;
  final Function()? onRedeemGiftCard;

  const WalletCardView(
      {required this.currency,
      required this.credit,
      required this.onAdddCredit,
      this.onRedeemGiftCard,
      Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        //clipper: ThemPageHeaderClipper(),
        child: Container(
          padding: const EdgeInsets.only(left: 20.0, top: 15.0, right: 20.0, bottom: 10.0),

          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                const Color(0xFF3383CD),
                const Color(0xFF11249F),
              ],
            ),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x29000000),
                  offset: Offset(0, 5),
                  blurRadius: 15,
                  spreadRadius: 0)
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                tr.balance,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(color: primaryColors.shade50, fontSize: 22.0),
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                        color: primaryColors.shade100,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text(
                        NumberFormat.simpleCurrency(name: currency).currencySymbol,
                        style: Theme.of(context).textTheme.displayMedium),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    currency + ' ' +
                        NumberFormat.decimalPercentPattern(locale: 'en-US', decimalDigits: 2)
                            .format(credit).replaceAll("%", ""),
                    style: Theme.of(context)
                        .textTheme
                        .displayMedium
                        ?.copyWith(color: primaryColors.shade100),
                  )
                ],
              ),
              const SizedBox(height: 20),
              Text(
                currentAccount.value.name??'',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(color: primaryColors.shade50, fontSize: 20.0),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  CupertinoButton(
                      padding: EdgeInsets.zero,
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                                color: primaryColors.shade300,
                                borderRadius: BorderRadius.circular(30)),
                            child: Icon(
                              Icons.add_rounded,
                              size: 20,
                              color: primaryColors.shade600,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "Add Credit",
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                color: primaryColors.shade200),
                          )
                        ],
                      ),
                      onPressed: () => onAdddCredit()

                  ),
                  const SizedBox(width: 8),
                  if (onRedeemGiftCard != null)
                    SizedBox(
                      width: 1,
                      height: 20,
                      child: Container(color: primaryColors.shade200),
                    ),
                  const SizedBox(width: 8),
                  if (onRedeemGiftCard != null)
                    CupertinoButton(
                        padding: EdgeInsets.zero,
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                  color: primaryColors.shade300,
                                  borderRadius: BorderRadius.circular(30)),
                              child: SizedBox(
                                width: 20,
                                height: 20,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 1),
                                  child: Icon(Icons.wallet_giftcard,
                                      size: 16,
                                      color: primaryColors.shade600),
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text("Redeem gift card",
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                    color: primaryColors.shade200))
                          ],
                        ),
                        onPressed: () => onRedeemGiftCard!()),
                ],
              )
            ],
          ),
        )
    );
  }



}
