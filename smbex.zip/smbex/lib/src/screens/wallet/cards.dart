import 'package:flutter/material.dart';

import '../../widgets/SmbWidget.dart';
import 'widgets.dart';

class Cards extends StatefulWidget {
  Cards({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _CardsState createState() => _CardsState();
}

class _CardsState extends State<Cards> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar(
        context,
        titleText: widget.title,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(
            Icons.sort,
            color: Colors.black54,
          ),
          onPressed: () {},
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add,
              color: Colors.black54,
            ),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      blurRadius: 5.0,
                      color: Colors.grey[300],
                      spreadRadius: 5.0),
                ],
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(51),
                  bottomLeft: Radius.circular(51),
                ),
                color: Colors.white,
              ),
              child: Hero(
                tag: "card",
                child: Material(
                color: Colors.transparent,
                  child: InkWell(
                    child: CreditCardContainer(),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                )
              ),
            ),
            CustomContainer(
              child: FittedBox(
                child: Row(
                  children: <Widget>[
                    CustomIconButton(
                      icon: Icons.send,
                      buttonTitle: "UNLOCK PIN/CVV",
                      circleColor: IconColors.send,
                      onTap: () {},
                    ),
                    CustomIconButton(
                      icon: Icons.credit_card,
                      buttonTitle: "FREEZE CARD",
                      circleColor: Colors.lime[100],
                      onTap: () {},
                    ),
                    CustomIconButton(
                      icon: Icons.lock,
                      buttonTitle: "SHOW SECRET CODE",
                      circleColor: Colors.pink[100],
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            ),
            Container(
              child: CustomContainer(
                child: ListView(
                  shrinkWrap: true,
                  children: <Widget>[
                    Material(
                      color: Colors.transparent,
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.atm),
                          radius: 20,
                        ),
                        title: Text(
                          "ATM CARDLESS",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        enabled: true,
                        onTap: () {},
                      ),
                    ),
                    Material(
                      color: Colors.transparent,
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.location_on),
                          radius: 20,
                        ),
                        title: Text(
                          "ATM LOCATOR",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        enabled: true,
                        onTap: () {},
                      ),
                    ),
                    Material(
                      color: Colors.transparent,
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.security),
                          radius: 20,
                        ),
                        title: Text(
                          "SECURITY CARD",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        enabled: true,
                        onTap: () {},
                      ),
                    ),
                    Material(
                      color: Colors.transparent,
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.assessment),
                          radius: 20,
                        ),
                        title: Text(
                          "LIMITS",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        enabled: true,
                        onTap: () {},
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}