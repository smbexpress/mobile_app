
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/DoLinkWidget.dart';


class SmbMainScreen extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;

  SmbMainScreen({Key key, this.parentScaffoldKey}) : super(key: key);


  @override
  _SmbMainScreenState createState() => _SmbMainScreenState();
}

class _SmbMainScreenState extends State<SmbMainScreen>
    with TickerProviderStateMixin {
  Animation<double> topBarAnimation;
  AnimationController animationController;
  List<Widget> listViews = <Widget>[];
  final ScrollController scrollController = ScrollController();
  double topBarOpacity = 0.0;
  Animation tween1;
  Animation tween2;
  Animation tween3;

  @override
  void initState() {

    animationController = AnimationController(duration: Duration(seconds: 1), value: 0, vsync:this);
    scrollController.addListener(() {
      if (scrollController.offset >= 24) {
        if (topBarOpacity != 1.0) {
          setState(() {
            topBarOpacity = 1.0;
          });
        }
      } else if (scrollController.offset <= 24 &&
          scrollController.offset >= 0) {
        if (topBarOpacity != scrollController.offset / 24) {
          setState(() {
            topBarOpacity = scrollController.offset / 24;
          });
        }
      } else if (scrollController.offset <= 0) {
        if (topBarOpacity != 0.0) {
          setState(() {
            topBarOpacity = 0.0;
          });
        }
      }
    });
    tween1 = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
        parent: animationController,
        curve: Interval(0, 1, curve: Curves.fastOutSlowIn)));
    /*
    tween1.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState((){
          animationController.forward();
        });
        print("tween1::completed");
      }
    });

     */

    tween2 = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
            parent: animationController,
            curve: Interval(.5, 1.0, curve: Curves.fastOutSlowIn)));

    topBarAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(

            parent: animationController,
            curve: Interval(0, 0.5, curve: Curves.fastOutSlowIn)));

    tween3 = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
            parent: animationController,
            curve: Interval(.7, 1.0, curve: Curves.fastOutSlowIn)));


    animationController.forward();
    super.initState();
  }

  Future<bool> getData() async {
    await Future<dynamic>.delayed(const Duration(milliseconds: 500));
    return true;
  }

  @override
  Widget build(BuildContext context) {

      return Container(
        color: LightColor.background,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              getMainListViewUI(),
              getAppBarUI(),
              SizedBox(
                height: MediaQuery.of(context).padding.bottom,
              )
            ],
          ),
        ),
    );
  }

  Widget getMainListViewUI() {

    return FutureBuilder<bool>(
      future: getData(),
      builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
        if (!snapshot.hasData|| !mounted) {
          return const SizedBox();
        } else {
          final listViews = [
            DoLinkWidget(
              animation: tween1,
              animationController: animationController,
            ),
            RunningViewWidget(
              animation: tween2,
              animationController: animationController,
            ),
            GeneralAnimatedWidget(
              animation: tween3,
              animationController: animationController,
              builder: createGlassWidget,
            ),
          ];
          return ListView.builder(
            controller: scrollController,
            shrinkWrap: true,
            padding: EdgeInsets.only(
              top: AppBar().preferredSize.height + MediaQuery.of(context).padding.top + 24,
              bottom: 62 + MediaQuery.of(context).padding.bottom,
            ),
            itemCount: listViews.length,
            scrollDirection: Axis.vertical,
            itemBuilder: (BuildContext context, int index) {
              animationController.forward();
              return listViews[index];
            },
          );
        }
      },
    );
  }

  Widget getAppBarUI() {
    return Column(
      children: <Widget>[
        AnimatedBuilder(
          animation: animationController,
          builder: (BuildContext context, Widget child) {
            return FadeTransition(
              opacity: topBarAnimation,
              child: Transform(
                transform: Matrix4.translationValues(
                    0.0, 30 * (1.0 - topBarAnimation.value), 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: LightColor.white.withOpacity(topBarOpacity),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(32.0),
                    ),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                          color: LightColor.grey
                              .withOpacity(0.4 * topBarOpacity),
                          offset: const Offset(1.1, 1.1),
                          blurRadius: 10.0),
                    ],
                  ),
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: MediaQuery.of(context).padding.top,
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: 16,
                            right: 16,
                            top: 16 - 8.0 * topBarOpacity,
                            bottom: 12 - 8.0 * topBarOpacity),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'SMB Express',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 22 + 6 - 6 * topBarOpacity,
                                    letterSpacing: 1.2,
                                    color: LightColor.subTitleTextColor,
                                  ),
                                ),
                              ),
                            ),
                            /*
                            SizedBox(
                              height: 38,
                              width: 38,
                              child: InkWell(
                                highlightColor: Colors.transparent,
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(32.0)),
                                onTap: () {},
                                child: Center(
                                  child: Icon(
                                    Icons.keyboard_arrow_left,
                                    color: LightColor.grey,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                left: 8,
                                right: 8,
                              ),
                              child: Row(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8),
                                    child: Icon(
                                      Icons.calendar_today,
                                      color: LightColor.grey,
                                      size: 18,
                                    ),
                                  ),
                                  Text(
                                    '15 May',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.normal,
                                      fontSize: 18,
                                      letterSpacing: -0.2,
                                      color: LightColor.subTitleTextColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 38,
                              width: 38,
                              child: InkWell(
                                highlightColor: Colors.transparent,
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(32.0)),
                                onTap: () {},
                                child: Center(
                                  child: Icon(
                                    Icons.keyboard_arrow_right,
                                    color: LightColor.grey,
                                  ),
                                ),
                              ),
                            ),

                             */
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        )
      ],
    );
  }

  Widget createGlassWidget(BuildContext context) {
    TextDirection dir = Directionality.of(context);
    bool rtl = dir == TextDirection.rtl;
      return Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(
                    left: 24, right: 24, top: 0, bottom: 24),
                child: Stack(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFD7E0F9),
                          borderRadius: BorderRadius.all(Radius.circular(8.0))
                        ),
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsetsDirectional.only(
                                  start: 68, bottom: 12, end: 16, top: 12),
                              child: Text(
                                'Prepare your stomach for lunch with one or two glass of water',
                                textAlign: TextAlign.justify,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  letterSpacing: 0.0,
                                  color: LightColor.accent .withOpacity(0.6),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned.directional(
                      top: -12,
                      start: 0,
                      textDirection: dir,
                      child: SizedBox(
                        width: 80,
                        height: 80,
                        child: Image.asset("assets/img/glass.png"),
                      ),
                    )
                  ],
                ),
              ),
            ],
          );
    }

}
