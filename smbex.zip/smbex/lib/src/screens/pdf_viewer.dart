import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:printing/printing.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../widgets/SmbWidget.dart';

class PdfViewer extends StatefulWidget {
  final String url;
  final String title;
  final bool showDownload;
  final bool share;
  final bool needsAuth;
  PdfViewer({
    Key key,
    this.url,
    this.title,
    this.showDownload,
    this.share,
    this.needsAuth = true
  }): super(key: key);

  @override
  _PdfViewerState createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewer> {
  bool isLoading = true;
  ErrorResult error;
  Response response;

  void initState() {
    super.initState();
    _loadDocument(true);
  }

  void _loadDocument([bool first=false]) async{
    try {
      if (!first) {
        setState((){
          isLoading = true;
          error = null;
          this.response = null;
        });
      }

      final response = await Api().getResponse(widget.url, withAuth: widget.needsAuth);
      Config.debug('_loadDocument:response statusCode: ${response.statusCode}', widget.runtimeType);
      if (response.statusCode >= 400) {
        error = ErrorResult.tryError(response);
      } else {
        this.response = response;
      }

   } catch(e, stack){
      error = ErrorResult.tryError(e, stack);
   }
    if (error != null)
      Config.debug('_loadDocument: $error', widget.runtimeType);
    if (response != null)
      Config.debug('_loadDocument:response reasonPhrase: ${response.reasonPhrase}', widget.runtimeType);

    setState((){
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar(
        context,
        titleText: widget.title??"",
        actions: [
          if (widget.showDownload == true && response != null )
            IconButton(
                onPressed: (){
                  final fileName = Uri.parse(widget.url).pathSegments.last;
                  Api().savePdf(response, fileName);
                },
                icon: Icon(Icons.download)
            )
        ]
      ),
      body: LoadingWidget(
        isLoading: isLoading,
        onRetry: _loadDocument,
        error: error,
        child: response != null
            ? PdfPreview(
                build: (format) => response.bodyBytes,
                canChangeOrientation: false,
                canChangePageFormat: false,
                canDebug: false,
                maxPageWidth: 800,
            )
            : const SizedBox.shrink(),
      )
    );
  }
}