

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/tracking_info.dart';

class TrackingHistoryProvider extends ChangeNotifier{

  static const int _VERSION = 1;
  static TrackingHistoryProvider _instance = TrackingHistoryProvider._();

  factory TrackingHistoryProvider() => _instance;

  TrackingHistoryProvider._();

  List<TrackingHistory> _historyList = [];
  bool _dirty = false;
  int _count = 0;
  bool _counted = false;

  void init() async {
    await saveHistory();
    _historyList.clear();
    final pref = await SharedPreferences.getInstance();
    final data = pref.getString("tracking_history_data");
    if (data != null) {
      final historyData = jsonDecode(data);
      historyData['history_list'].forEach((element) {
        _historyList.add(TrackingHistory.fromMap(element));
      });
    }
    _counted = true;
    _count = _historyList.length;
    notifyListeners();
  }

  void dispose(){
    saveHistory();
    super.dispose();
  }

  void add(TrackingHistory history){
    _dirty = true;
    _historyList.remove(history);
    _historyList.insert(0, history);

    while (_historyList.length > 20){
      _historyList.removeLast();
    }
    _count = _historyList.length;
    notifyListeners();
  }

  void remove(TrackingHistory history){
    _historyList.remove(history);
    _dirty = true;
    _count = _historyList.length;
    notifyListeners();

  }

  void update(TrackingHistory history){
    _dirty = true;
    _historyList.remove(history);
    _historyList.insert(0, history.update(DateTime.now().millisecondsSinceEpoch));
    _sort();
  }

  bool hasTrackingCode(String code) => _historyList.any((item) => item.code == code);


  List<TrackingHistory> get histories => List.unmodifiable(_historyList);

  void saveHistory() async{

    if (_dirty && _historyList.isNotEmpty){
      final pref = await SharedPreferences.getInstance();
      final historyListMap = _historyList.map((e) => e.toMap()).toList();

      final historyData = {
        'version': _VERSION,
        'history_list': historyListMap
      };
      pref.setString("tracking_history_data", jsonEncode(historyData));
      pref.setInt("tracking_history_count", _historyList.length);

      _dirty = false;
    }
  }

  void _sort(){
    _historyList.sort((a, b) => b.lastUsed - a.lastUsed);
    notifyListeners();
  }

  void close(){
    saveHistory();
  }

  void readCount() async{
    if (!_counted){
      _counted = true;
      final pref = await SharedPreferences.getInstance();
      _count = pref.getInt('tracking_history_count') ?? 0;
      if (_count != 0){
        notifyListeners();
      }
    }
  }

  int get length => _count;

  TrackingHistory get(String code) => _historyList.firstWhere((item) => item.code == code);
}