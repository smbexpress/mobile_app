import 'package:flutter/material.dart';
import 'package:smbex_app/i18n/i18n.dart';

class Search extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback onTrack;
  final bool inSearch;
  Search({this.controller, this.onTrack, this.inSearch=false});

  @override
  _SearchState createState() => _SearchState();
}

class _SearchState extends State<Search> {
  // var height = MediaQuery.of(context).size.height;

  void doTrack(String data) {
    if (data == null || data.isEmpty)
      return;
    widget.onTrack?.call();

  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      margin: EdgeInsets.fromLTRB(15, 20, 15, 0),
      width: widget.inSearch ? 45 : width,
      height: widget.inSearch ? 45 : 45,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: widget.inSearch
            ? BorderRadius.circular(100)
            : BorderRadius.circular(10),
        boxShadow: widget.inSearch ? [
          BoxShadow(
            color: Color(0x3f000000),
            blurRadius: 40,
            offset: Offset(0, 23),
          ),
        ] : [],
      ),
      child: !widget.inSearch
          ? TextFormField(
              controller: widget.controller,
              //autofocus: true,
              onFieldSubmitted: (val) {
                doTrack(val);
              },
              textInputAction: TextInputAction.search,

              decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.qr_code,
                  //size: 24,
                ),
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
                border: InputBorder.none,
                hintText: tr.setTrackingShipment,

              ),
          )
          : Container(
              width: double.infinity,
              constraints: BoxConstraints(minWidth: double.infinity),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: CircularProgressIndicator(),
                ),
              )
          ),
    );
  }
}
