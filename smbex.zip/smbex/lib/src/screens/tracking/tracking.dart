import 'dart:math';
import 'package:flutter/material.dart';

import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/screens/tracking/search.dart';
import 'package:smbex_app/src/screens/tracking/tracking_history_provider.dart';
import 'package:smbex_app/src/screens/tracking/tracking_history.dart';
import 'package:smbex_app/src/screens/tracking/tracking_provider.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';
import 'package:timelines/timelines.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../../i18n/i18n.dart';
import '../../models/address.dart';
import '../../models/tracking_info.dart';
import '../../widgets/SelectAddressWidget.dart';
import '../../widgets/SttepperWidget.dart';
import '../../widgets/icon_text.dart';

String toCurrentDate(date, int offset) {
  if (date) {
    var d = Helper.parseServerDate(date);
    //d = d.subtract(Duration(seconds: offset));
    return Helper.formatDatetime(d);
  }
  return "";
}

class TrackingPage extends StatefulWidget {
  final String trackingCode;
  const TrackingPage({Key key, this.trackingCode}) : super(key: key);
  @override
  _TrackingPageState createState() => _TrackingPageState();
}

class _TrackingPageState extends State<TrackingPage> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  Map<String, String> statusStringMap = {};
  TextEditingController trackingCodeController;
  TrackingProvider provider;
  TrackingHistoryProvider historyProvider;
  bool hasHistory;

  Color getColor(int index) =>
      index <= provider.step ? completeColor : todoColor;

  @override
  void initState() {
    super.initState();
    statusStringMap = {
      "shipped": tr.statusMap.shipped,
      "inTransit": tr.statusMap.inTransit,
      "arrived": tr.statusMap.arrived,
      "delivered": tr.statusMap.delivered
    };

    provider = TrackingProvider();
    historyProvider = TrackingHistoryProvider();

    trackingCodeController = TextEditingController();
    if (widget.trackingCode != null) {
      trackingCodeController.text = widget.trackingCode;
      provider.track(widget.trackingCode);
    }

    provider.addListener(_onChange);
    if (widget.trackingCode == null) {
      historyProvider.addListener(_onChange);
      historyProvider.readCount();
    }
  }

  @override
  void dispose() {
    super.dispose();
    provider?.removeListener(_onChange);
    historyProvider?.removeListener(_onChange);
  }

  void _onChange() {
    if (mounted) setState(() {});
  }

  void refreshTracking() {
    if (provider.loading) return;
  }

  void _refreshTracking([bool updateState = true]) {
    if (trackingCodeController.text.isEmpty) {
      print("Tracking code empty!!");
      return;
    }
    provider.track(trackingCodeController.text);
  }

  @override
  Widget build(BuildContext context) {
    //bool dispalyHistory = widget.trackingCode != null;

    return Scaffold(
        key: scaffoldKey,
        endDrawer: historyProvider.length > 0
            ? Drawer(
                width: 300,
                child: SafeArea(
                  left: false,
                  right: false,
                  bottom: false,
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(vertical: 16.0),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: Divider.createBorderSide(context),
                          ),
                        ),
                        child: Center(
                            child: Text(
                          tr.trackingHistory,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        )),
                      ),
                      Expanded(
                          child: TrackingHistoryWidget(onSelected: (history) {
                        trackingCodeController.text = history.code;
                        _refreshTracking();
                      }))
                    ],
                  ),
                ))
            : null,
        appBar: appBar(context,
            automaticallyImplyLeading: false,
            showBack: false,
            leading: IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: Icon(Icons.arrow_back)),
            titleText: tr.trackShipment,
            //backgroundColor: Colors.transparent,
            isSecondary: true,
            actions: [
              IconButton(
                  onPressed:
                      provider.tracking != null ? _refreshTracking : null,
                  icon: Icon(Icons.refresh)),
              if (historyProvider.length > 0)
                IconButton(
                    onPressed: () => scaffoldKey.currentState.openEndDrawer(),
                    icon: Icon(Icons.list)),
            ]),
        body: LoadingWidget(
          isLoading: widget.trackingCode != null && provider.loading,
          child: Container(
            width: double.infinity,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.trackingCode == null)
                    Search(
                      controller: trackingCodeController,
                      onTrack: _refreshTracking,
                      inSearch: provider.loading,
                    ),

                  const SizedBox(
                    height: 20,
                  ),
                  AnimatedScale(
                    scale: provider.tracking != null ? 1 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: buildHorizontal(context),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  if (widget.trackingCode == null && provider.tracking != null)
                    buildHistoryWidget(),
                  //if (tracking != null)
                  AnimatedScale(
                    scale: provider.error != null ? 1 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: provider.error != null
                        ? SizedBox(
                            child: MessagePlaceholder.error(
                                title: tr.error,
                                error: provider.error,
                                icon: Icons.warning,
                                onRetry: _refreshTracking),
                          )
                        : null,
                  ),
                  AnimatedOpacity(
                    opacity: provider.tracking != null ? 1 : 0,
                    duration: const Duration(milliseconds: 2000),
                    child: buildVertical(context),
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  Widget buildHorizontal(BuildContext context) {
    //_step = tracking?.step??-1;
    var offset =
        0.0; //_scrollViewController.hasClients ? _scrollViewController.offset : 0.0;
    //print("buildHorizontal:: _step: $_step, status: ${tracking?.status}");
    final pad = max(min(-8 * offset / 180 + 8.0, 8), 0).toDouble();
    final rad = max(min(-6 * offset / 180 + 6.0, 6), 0).toDouble();
    final container = Container(
        alignment: Alignment.center,
        height: 110,
        padding: EdgeInsets.symmetric(
          horizontal: 16,
        ),
        child: Container(
          padding: EdgeInsets.only(top: 20),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: [
              BoxShadow(
                  color: Colors.grey,
                  spreadRadius: 0,
                  blurRadius: pad,
                  offset: Offset(0.0, pad / 2))
            ],
            borderRadius: BorderRadius.circular(rad),
            // borderRadius: BorderRadius.circular(5.0),
          ),
          child: StepperWidget(
            selectedIndex: provider.step,
            iconSize: 24.0 * 1.2,
            selectedColor: Theme.of(context).colorScheme.secondary,
            activeColor: Theme.of(context).colorScheme.secondary,
            items: [
              StepItem(tr.statusMap.shipped, Icons.rocket_launch),
              StepItem(tr.statusMap.inTransit, Icons.airline_stops),
              StepItem(tr.statusMap.arrived, Icons.warehouse),
              StepItem(tr.statusMap.delivered, Icons.handshake)
            ],
          ),
        ));

    return container;
  }

  Widget buildVertical(BuildContext context) {
    if (provider.tracking == null) return SizedBox();

    return Column(children: [
      card(
          _TrackingHeader(
            tracking: provider.tracking,
          ),
          margin: widget.trackingCode == null &&
                  !historyProvider
                      .hasTrackingCode(provider.tracking.trackingCode)
              ? EdgeInsets.fromLTRB(12, 0, 12, 15)
              : null),
      card(
        SelectAddressWidget(
          provider.tracking.from,
          provider.tracking.to,
          height: 100,
          onSelect: (isPickup) {
            //_showAddressSheetWidget(context, isPickup, shipment);
          },
        ),
      ),
      card(
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              height: 10,
            ),
            _DeliveryProcesses(processes: provider.tracking.items),
            const Divider(height: 1.0),
            if (provider.tracking.driverInfo?.onTime == true)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Text("Promised"),
                    const Spacer(),
                    Builder(
                      builder: (context) => MaterialButton(
                        onPressed: () {},
                        elevation: 0,
                        shape: StadiumBorder(),
                        color: Color(0xff66c97f),
                        textColor: Colors.white,
                        child: Text('On-time'),
                      ),
                    )
                  ],
                ),
              ),
            if (provider.tracking.driverInfo?.onTime == true)
              const Divider(height: 1.0),
            if (provider.tracking.driverInfo != null)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: _OnTimeBar(driver: provider.tracking.driverInfo),
              ),
          ],
        ),
      ),
    ]);
  }

  Widget card(Widget child,
          {double radios = 8.0,
          Color color = Colors.white,
          EdgeInsets margin}) =>
      Container(
        margin: margin ?? EdgeInsets.symmetric(vertical: 15, horizontal: 12),
        decoration: BoxDecoration(
            color: color,
            border: Border.all(color: Theme.of(context).dividerColor),
            borderRadius: BorderRadius.circular(radios)),
        child: child,
      );
  Widget buildHistoryWidget() {
    final tracking = provider.tracking;
    final exists = historyProvider.hasTrackingCode(tracking.trackingCode);
    if (exists) return SizedBox.shrink();

    final history = exists ? historyProvider.get(tracking.trackingCode) : null;
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 12),
      alignment: Alignment.bottomLeft,
      child: TextButton.icon(
        icon: Icon(exists ? Icons.remove : Icons.add),
        label: Text(exists ? tr.removeTrackingHistory : tr.saveTrackingHistory),
        onPressed: () {
          if (exists) {
            historyProvider.remove(history);
          } else {
            historyProvider.add(TrackingHistory(
                code: tracking.trackingCode,
                from: _toAddressOne(tracking.from),
                to: _toAddressOne(tracking.to),
                orderDate: '',
                lastUsed: DateTime.now().millisecondsSinceEpoch));
          }
          historyProvider.close();
        },
      ),
    );
  }

  String _toAddressOne(Address address) {
    String fullAddress = '';
    String city = address.city.name;
    String country = address.country.name ?? '';
    String cityAndCountrry = '';
    if (city == null)
      cityAndCountrry = country;
    else {
      cityAndCountrry = city + ', ' + country;
    }
    String name = (address.name ?? '');
    return '$name/$cityAndCountrry';
  }
}

class _TrackingHeader extends StatelessWidget {
  const _TrackingHeader({
    Key key,
    @required this.tracking,
  })  : assert(tracking != null),
        super(key: key);

  final TrackingInfo tracking;

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
        style: TextStyle(color: LightColor.lightBlack),
        child: Column(
          children: [
            ListTile(
              title: IconText(
                text: tracking.trackingCode,
                iconData: Icons.copy_rounded,
                copyToClipboard: true,
              ),
              dense: true,
            ),
            Divider(
              height: 1,
            ),
            ListTile(
              title: Text(tr.eta),
              trailing: Text(tracking.eta ?? tr.notSetYet),
              dense: true,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
            ),
            if (tracking.weight != null)
              ListTile(
                  title: Text(tr.weight),
                  trailing: Text('${tracking.weight}${tracking.weightUnit}'),
                  dense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                  visualDensity: VisualDensity.compact),
            if (tracking.cod != null)
              ListTile(
                  title: Text(tr.cash_on_delivery),
                  trailing: Helper.getPrice(tracking.cod, context,
                      currency: tracking.codCurrency),
                  dense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                  visualDensity: VisualDensity.compact),
            if (tracking.packageType != null)
              ListTile(
                  title: Text(tr.packageType),
                  trailing: Text(tracking.packageType),
                  dense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                  visualDensity: VisualDensity.compact)
          ],
        ));
  }
}

class _InnerTimeline extends StatelessWidget {
  const _InnerTimeline({
    @required this.messages,
  });

  final List<TrackingItem> messages;

  @override
  Widget build(BuildContext context) {
    bool isEdgeIndex(int index) {
      return index == 0 || index == messages.length + 1;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: FixedTimeline.tileBuilder(
        theme: TimelineTheme.of(context).copyWith(
          nodePosition: 0,
          connectorTheme: TimelineTheme.of(context).connectorTheme.copyWith(
                thickness: 1.0,
              ),
          indicatorTheme: TimelineTheme.of(context).indicatorTheme.copyWith(
              size: 13.0, position: 0.3, color: LightColor.lightBlack),
        ),
        builder: TimelineTileBuilder(
          indicatorBuilder: (_, index) => Indicator.outlined(borderWidth: 1.0),
          //startConnectorBuilder: (_, index) => Connector.solidLine(),
          //endConnectorBuilder: (_, index) => Connector.solidLine(),
          contentsBuilder: (_, index) {
            return Padding(
              padding: EdgeInsetsDirectional.only(start: 8),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        messages[index].time ?? '',
                        style: DefaultTextStyle.of(context).style.copyWith(
                              fontSize: 14.0,
                            ),
                      ),
                      Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        child: Text(messages[index].status ?? '',
                            style: DefaultTextStyle.of(context).style.copyWith(
                                fontSize: 12.0, fontWeight: FontWeight.w600)),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            border: Border.all(
                                color: Theme.of(context).primaryColorDark)),
                      )
                    ],
                  ),
                  if (messages[index].message != null)
                    Expanded(
                      child: Text(messages[index].message),
                    )
                ],
              ),
            );
          },
          itemExtentBuilder: (_, index) => 30.0,
          //nodeItemOverlapBuilder: (_, index) => isEdgeIndex(index) ? true : null,
          itemCount: messages.length,
        ),
      ),
    );
  }
}

class _DeliveryProcesses extends StatelessWidget {
  const _DeliveryProcesses({Key key, @required this.processes})
      : assert(processes != null),
        super(key: key);

  final List<TrackingItem> processes;
  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: TextStyle(
        color: Theme.of(context).hintColor,
        fontSize: 14.5,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
        child: FixedTimeline.tileBuilder(
          theme: TimelineThemeData(
            nodePosition: 0,
            color: Color(0xff989898),
            indicatorTheme: IndicatorThemeData(
              position: 0,
              size: 20.0,
            ),
            connectorTheme: ConnectorThemeData(
              thickness: 2.5,
            ),
          ),
          builder: TimelineTileBuilder.connected(
            connectionDirection: ConnectionDirection.before,
            itemCount: processes.length,
            contentsBuilder: (_, index) {
              //if (processes[index].isCompleted) return null;
              final item = processes[index];
              return Padding(
                padding: EdgeInsetsDirectional.only(start: 4.0, bottom: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          item.date ?? '',
                          style: DefaultTextStyle.of(context).style.copyWith(
                                fontSize: 14.0,
                              ),
                        ),
                        Container(
                          padding:
                              EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          child: Text(item.status ?? '',
                              style: DefaultTextStyle.of(context)
                                  .style
                                  .copyWith(
                                      fontSize: 12.0,
                                      fontWeight: FontWeight.w600)),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(
                                  color: Theme.of(context).primaryColorDark)),
                        )
                      ],
                    ),
                    Text(
                      item.time ?? '',
                      style: DefaultTextStyle.of(context).style.copyWith(
                            fontSize: 14.0,
                          ),
                    ),
                    if (item.locationDetail != null) ...[
                      SizedBox(
                        height: 10,
                      ),
                      Text(item.locationDetail.location),
                      SizedBox(
                        height: 10,
                      )
                    ],
                    if (item.message != null) Text(item.message),
                    if (item.groups != null &&
                        item.groups.isNotEmpty)
                      _InnerTimeline(messages: item.groups),
                    if (index < processes.length -1)
                    Divider(height: 1, thickness: 1.0)
                  ],
                ),
              );
            },
            indicatorBuilder: (_, index) {
              return DotIndicator(
                color: Theme.of(context).colorScheme.secondary,
                child: Icon(
                  Icons.check,
                  color: Colors.white,
                  size: 12.0,
                ),
              );
            },
            connectorBuilder: (_, index, ___) => SolidLineConnector(
              color: null,
            ),
          ),
        ),
      ),
    );
  }
}

class _OnTimeBar extends StatelessWidget {
  const _OnTimeBar({Key key, @required this.driver})
      : assert(driver != null),
        super(key: key);

  final DriverInfo driver;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        
        if (driver.name != null)
          Expanded(
              child: Text(
                'Driver\n${driver.name}',
                textAlign: TextAlign.start,
              ),
          ),
        Spacer(),
        if (driver.phone != null)
          TextButton.icon(
              onPressed: (){
                launchUrlString("tel://${driver.phone}");
              }, 
              icon: RotatedBox(
                quarterTurns: 90,
                child: Icon(Icons.phone, color: Colors.green,),
              ),
              label: const SizedBox.shrink(),
              style: TextButton.styleFrom(
                shape: CircleBorder(),
                padding: const EdgeInsets.all(10)
              )
          ),
        /*
        SizedBox(width: 12.0),
        Container(
          width: 40.0,
          height: 40.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
          ),
          child: IconButton(
            icon: Icon(Icons.phone),
            onPressed: (){

            },
          ),
        ),

         */
      ],
    );
  }
}
