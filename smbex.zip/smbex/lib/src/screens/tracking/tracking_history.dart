
import 'package:flutter/material.dart';
import 'package:smbex_app/src/screens/tracking/tracking_history_provider.dart';

import '../../models/tracking_info.dart';
import '../../widgets/icon_text.dart';

class TrackingHistoryWidget extends StatefulWidget{

  final Function(TrackingHistory history) onSelected ;

  const TrackingHistoryWidget({Key key, this.onSelected}) : super(key: key);


  @override
  State<StatefulWidget> createState() => _TrackingHistoryWidgetState();
}

class _TrackingHistoryWidgetState extends State<TrackingHistoryWidget> {

  TrackingHistoryProvider _provider;

  @override
  void initState() {
    super.initState();
    _provider = TrackingHistoryProvider();
    _provider.init();
    _provider.addListener(_historyChanged);
  }

  @override
  void dispose() {
    super.dispose();
    _provider.removeListener(_historyChanged);
    _provider.close();
  }

  void _historyChanged(){
    setState((){});
  }

  @override
  Widget build(BuildContext context) {

    final histories = _provider.histories;

    if (histories.isEmpty){
      return Center(
        child: Text("There no items in your bookmark: ${_provider.length} "),
      );
    }

    return ListView.separated(
        shrinkWrap: true,

        itemBuilder: (BuildContext context, int index) {
          TrackingHistory history = histories[index];
          final from = history.from.split("|");
          final to = history.to.split("|");
          return ListTile(
            onTap: () {
              Navigator.of(context).pop();
              widget.onSelected?.call(history);
              _provider.update(history);
            },
            title: Padding(
              padding: EdgeInsets.symmetric(vertical: 10),
              child: IconText(
                text: history.code,
                iconData: Icons.copy_rounded,
                copyToClipboard: true,
              ),
            ),
            subtitle: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.location_on),
                    SizedBox(width: 5,),
                    Expanded(
                      child: Text(history.from),
                    )
                  ],
                ),
                SizedBox(height: 5,),
                Row(
                  children: [
                    Icon(Icons.person),
                    SizedBox(width: 5,),
                    Expanded(
                        child: Text(history.to),
                    )

                  ],
                ),
              ],
            ),
            trailing: IconButton(
              icon: Icon(Icons.close),
              onPressed: () => _provider.remove(history)
            ),
          );

        },
        separatorBuilder: (BuildContext context, int index) =>
            Divider(thickness: 1.5, height: 1.5,),
        itemCount: histories.length
    );

  }

}