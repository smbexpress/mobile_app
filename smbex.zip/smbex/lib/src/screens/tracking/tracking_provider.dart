

import 'package:flutter/widgets.dart';
import 'package:smbex_app/src/api.dart';

import '../../config.dart';
import '../../models/model.dart';
import '../../models/tracking_info.dart';
import '../../repository/account_repository.dart';

class TrackingProvider extends ChangeNotifier{
  bool _loading = false;
  TrackingInfo _tracking;
  ErrorResult _error;
  int _step = -1;


  bool get loading => _loading;
  int get step => _step;
  TrackingInfo get tracking => _tracking;
  ErrorResult get error => _error;

  void track(String trackingCode){
    _loading = true;
    _tracking = null;
    _error = null;
    _step = -1;
    notifyListeners();

    ResultItem.of(
        Api().get("tracking/${trackingCode}", withAuth: currentAccount.value.valid),
        null,
        useUtf: true,
        timeout: 30
    )
    .then((value){
        if(value.hasError){
          _loading = false;
          _tracking = null;
          _error = value.error;

          Config.log(error, runtimeType);
        } else {
          _loading = false;
          _tracking = parseTrackingInfo(value.item);
          _step = _tracking.step;
          _error = null;
        }
        notifyListeners();
      });
  }

}


