import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:settings_ui/settings_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../models/language.dart';
import '../notification_provider.dart';
import '../repository/settings_repository.dart' as settingRepo;
import 'branch/branch_provider.dart';

List<AbstractSettingsTile> buildLanguageList(BuildContext context) =>
    LanguagesList.instance().languages
        .map((lang) =>
        SettingsTile(
          leading: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(40)),
              image: DecorationImage(image: AssetImage(lang.flag), fit: BoxFit.cover),
            ),
          ),
          title: Text(lang.englishName),
          description: Text(lang.localName),
          trailing: lang.selected ? Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(40)),
                border: Border.all(color: Theme.of(context).primaryColorDark, width: 2)
              //color: Theme.of(context).accentColor.withOpacity(_language.selected ? 0.85 : 0),
            ),
            child: Icon(
              Icons.check,
              size: 30,
              color: Theme.of(context).primaryColorDark,
            ),
          ) : null,
          onPressed: (context) {
            //if (lang.selected)
            //  return;
            LanguagesList.instance().languages.forEach((_l) {
              _l.selected = false;
            });
            lang.selected = true;
            //settingRepo.settingNotifier.value.mobileLanguage.value = new Locale(lang.code, '');
            settingRepo.setDefaultLanguage(lang.code);
            settingRepo.settingNotifier.notifyListeners();
            context.read<BranchProvider>().clear();
          },
        )).toList();


class LanguagesScreen extends StatefulWidget {
  final bool showAappBar;
  const LanguagesScreen({
    Key key,
    this.showAappBar=true
  }) : super(key: key);
  @override
  _LanguagesScreenState createState() => _LanguagesScreenState();
}

class _LanguagesScreenState extends State<LanguagesScreen>  {

  void initState(){
    super.initState();
    SharedPreferences.getInstance().then((prefs)  {
      final code = prefs.getString('language');
      for(final lang in LanguagesList.instance().languages){
        lang.selected = lang.code == code;
      }
      setState((){});
    });

  }


  @override
  Widget build(BuildContext context) {
    final child = SingleChildScrollView(
      padding: EdgeInsets.only(bottom: 50),
      child: SettingsList(
          platform: PlatformUtils.detectPlatform(context),
          lightTheme: SettingsThemeData(settingsListBackground: Colors.transparent),
          darkTheme: SettingsThemeData(settingsListBackground: Colors.transparent),
          shrinkWrap: true,
          sections: [
            SettingsSection(
                title: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: ListTile(
                    contentPadding: EdgeInsets.symmetric(vertical: 0),
                    leading: Icon(
                      Icons.translate,
                      color: Theme.of(context).hintColor,
                      size: 32,
                    ),
                    title: Text(
                      S.of(context).app_language,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.headline3,
                    ),
                    subtitle: Text(S.of(context).select_your_preferred_languages),
                  ),
                ),
                tiles: buildLanguageList(context)
            ),
          ]
      ),
    );
    return widget.showAappBar ?
        Scaffold(
            appBar: appBar(
              context,
              titleText: S.of(context).languages,
              isSecondary: false,
            ),
            body: child
        ): child;
  }
}

class LanguageSetupScreen extends StatelessWidget {
  DateTime currentBackPressTime;


  @override
  Widget build(BuildContext context) {
    ValueNotifier langValue = ValueNotifier(null);
    SharedPreferences.getInstance().then((prefs)  {
      langValue.value = prefs.getString('language');
    });
    return WillPopScope(
        onWillPop: onWillPop,
        child: Scaffold(
          body: LanguagesScreen(showAappBar: false,),
          bottomNavigationBar: Container(
            padding: EdgeInsets.all(15),
            child: ValueListenableBuilder(
              valueListenable: langValue,
              builder: (context, value, __) => ElevatedButton(
                child: Text(tr.buttons.next),
                onPressed: value != null
                    ? ()=> Navigator.of(context).pushReplacementNamed("/Home")
                    : null,
              ),
            ),
          ),
      )
      );
  }

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null || now.difference(currentBackPressTime) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: tr.tapBackAgainToLeave);
      return Future.value(false);
    }
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    return Future.value(true);
  }
}