import 'package:flutter/material.dart';
import 'package:smbex_app/src/theme/extention.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/icon_text.dart';

import '../../../i18n/i18n.dart';
import '../../models/address.dart' as model;

// ignore: must_be_immutable
class AddressesItemWidget extends StatelessWidget {
  String heroTag;
  model.Address address;
  ValueChanged<model.Address> onPressed;
  ValueChanged<model.Address> onLongPress;
  ValueChanged<model.Address> onDismissed;

  AddressesItemWidget({Key key, this.address, this.onPressed, this.onLongPress, this.onDismissed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (onDismissed != null && false) {
      return Dismissible(
        key: Key(address.id?.toString()),
        onDismissed: (direction) {
          this.onDismissed(address);
        },
        child: buildItem(context),
      );
    } else {
      return buildItem(context);
    }
  }

  Widget buildItem(BuildContext context) {
    String cityAndCountrry = '';
    if (address.city?.name == null)
      cityAndCountrry = address.country.name??'';
    else{
      cityAndCountrry = address.city?.name + ', ' + (address.country.name??'');
    }
    final tile = ListTile(
      horizontalTitleGap: 0,
      onTap: () => onPressed(address),
      leading: Container(
        child: IntrinsicWidth(
          child: Center(
            child: Icon(address.facility != null
                ? Icons.account_balance
                : Icons.person),
          ),
        ),
      ),
      title: Container(
        width: double.infinity,
        height: 50,
        //constraints: BoxConstraints.,
        child: Row(
          children: [
            Expanded(
                child: IconText(
                    text: address.name,
                    iconData: onDismissed == null ? null : Icons.copy_rounded,
                    copyToClipboard: onDismissed == null
                ),
            ),
            if (onDismissed != null)
            IconButton(
              icon: Icon(Icons.delete_outline, color: Colors.red.withOpacity(.7),),
              onPressed: (){
                onDismissed(address);
              },
            )
          ],
        ),
      ),
      subtitle: Container(
        width: double.infinity,
        child: Column(
          children: [
            Container(
              width: double.infinity,
              child: Text(
                address.facility == null
                ? address?.street ?? ''
                : '${tr.branch}: ${address.facility.name}',
                maxLines: 2,
                overflow: TextOverflow.fade,
              ),
            ),
            SizedBox(height: 5,),
            Container(
              width: double.infinity,
              //color: Colors.blueAccent,
              child: Text(cityAndCountrry, style: TextStyle(fontWeight: FontWeight.bold),),
            )
          ],
        )
      ),
      /*
      trailing: Container(
        child: IntrinsicWidth(
          child: Center(
            child: InkWell(
              child: Padding(
                padding: EdgeInsets.all(6),
                child: Icon(Icons.more_vert),
              ),
              onTap: (){

              },
            ),
          ),
        ),
      )*/
    ) ;
    return tile;


  }
}
