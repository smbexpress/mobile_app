import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/models/branch.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code.dart';
import 'package:smbex_app/src/widgets/picker/place_picker/place_picker.dart';
import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code_picker.dart';

import '../../../i18n/i18n.dart';
import '../../config.dart';
import '../../controllers/address_controller.dart';
import '../../helpers/helper.dart';
import '../../helpers/maps_util.dart';
import '../../models/address.dart';
import '../../repository/app_repository.dart' as app;
import '../../repository/settings_repository.dart';
import '../../theme/theme.dart';
import '../../widgets/CircularLoadingWidget.dart';
import '../../widgets/CommonWidget.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
class AddressWidget extends StatefulWidget {

  //Address address;
  final AddressController controller;
  Address address;
  final bool showMapPickerAtStart;
  final bool showFull;
  final ScrollController scrollController;
  final bool showAppBar;
  final bool showMap;
  final bool showCity;
  final bool showBranch;
  final ValueChanged<Address> callback;
  final bool isPickup;
  final bool forceBranch;
  AddressWidget({Key key,
    this.controller,
    Address address,
    this.showMapPickerAtStart,
    this.showFull:false,
    this.scrollController,
    this.showAppBar = true,
    this.showMap = true,
    this.showCity = false,
    this.showBranch = false,
    this.isPickup = true,
    this.callback,
    this.forceBranch = false})
        : super(key: key){
    this.address = Address().copy(address);
  }

  @override
  _AddressWidgetState createState() => _AddressWidgetState(controller);
}

class _AddressWidgetState extends StateMVC<AddressWidget>
    with  SystemUiOverlayMixin, AutomaticKeepAliveClientMixin{
  final _formKey = GlobalKey<FormState>();
  final AddressController _con;
  _AddressWidgetState(AddressController controller)
       : _con = controller,
        super(controller);


  List<Region> regions;
  TextEditingController _nameController = TextEditingController();
  TextEditingController _streetController = TextEditingController();
  TextEditingController _zipController = TextEditingController();
  
  TextEditingController _emailController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  TextEditingController _mobileController = TextEditingController();
  TextEditingController _provinceController = TextEditingController();
  TextEditingController _commentController = TextEditingController();

  FocusNode _nameNode = new FocusNode();
  bool _showCountry = false;
  bool _canEditCity = true;
  bool _showCheckBranch = false;
  List<Map> countries = [];
  String dialCode;
  
  @override
  void initState() {
    super.initState();
    print("***********8Start Address **************");
    _con.address = widget.controller.address;
    _getCurrentLocation();
    //countryLoading();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _streetController.dispose();
    _zipController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _mobileController.dispose();
    _provinceController.dispose();
    _commentController.dispose();

    super.dispose();
  }

  void _getCurrentLocation() async{
    Address address = widget.controller.address;
    if (address?.valid == false) {
      widget.controller.setCurrentLocation(widget.isPickup).then((value) {
        if (value == null) {
          value = lastAddress.value??currentAccount.value.defaultAddress.copyTo(
              Address.fromJSON({'isPickup': widget.isPickup}));
        }
        address.street = value.street;
        address.lat = value.lat;
        address.city = value.city;
        address.country = value.country;
        address.zip = value.zip;
        address.province = value.province;
        address.district = value.district;
        countryLoading();
      });
    } else {

      countryLoading();
    }
  }

  void countryLoading(){
    app.countries.forEach((country) {
      countries.add({
        'name': country.name,
        'code': country.code,
        'dial_code': country.dial
      });
    });
    Address address = widget.address;
    widget.controller.address = widget.address;
    _nameController.text = address.name;
    _streetController.text = address.street;
    _zipController.text = address.zip;
    _emailController.text = address.email;

    _provinceController.text = address.province;
    _commentController.text = address.comment;

    if (!address.country.valid && app.countries.isNotEmpty){
      address.country = app.countries[0];
    }
    bool enableBranch = widget.callback != null;

    if (widget.showCity || enableBranch) {
      _showCountry = app.countries.length > 1 || !app.countries.contains(address.country);
    }

    var mobile = address.mobile != null ? address.mobile : address.phone;
    mobile = mobile??"";
    if (mobile.startsWith("+")){
      mobile = mobile.substring(1);
    }
    if (mobile.startsWith("00")){
      mobile = mobile.substring(2);
    }
    dialCode = address.country.valid
        ? address.country.dial
        : app.countries.first.dial;
    //print('address: $address');
    bool dialFound = false;
    if(dialCode != null && mobile.startsWith(dialCode)){
      mobile = mobile.substring(dialCode.length);
      dialFound = true;
    } else {
      Map cyMap = countries.firstWhere((country) =>
          mobile.startsWith(country['dial_code']),
          orElse: ()=>null);
      if(cyMap != null){
        String dial = cyMap['dial_code'];
        if(mobile.length - dial.length > 6) {
          dialCode = dial;
          mobile = mobile.substring(dialCode.length);
          dialFound = true;
        }
      }
    }
    if (dialCode == null)
      dialCode = "966";

    if (!dialFound && mobile.length > 7) {
      Map cyMap = countries.firstWhere((country) =>
          mobile.startsWith(country['dial_code']),
          orElse: () => null);
      if (cyMap == null) {
        final countryDial = Api().company.allCountries.firstWhere((country) =>
            mobile.startsWith(country.dial), orElse: () => null);
        if (countryDial != null)
          countries.add({
            'name': countryDial.name,
            'code': countryDial.code,
            'dial_code': countryDial.dial
          });
        else {
          dialCode = "966";
        }
      }
    }

    //print("dialCode: $dialCode,,, countries: $countries, appCountries: ${app.countries}");

    _mobileController.text = mobile;
    _phoneController.text = address.phone != null ? address.phone : mobile;

    _nameNode.requestFocus();
    if(mounted)
      setState(() {});



  }

  void _focusChanged(){
    setState(()=>{});
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        key: _con.scaffoldKey,
        resizeToAvoidBottomInset: true,
        appBar: widget.showAppBar
           ? appBar(
              context,
              titleText: widget.address.id != 0 ? t.edit_address : t.add_address,
              isSecondary: false
          )
          : null,
        backgroundColor: Theme.of(context).cardColor,
        body: countries.isEmpty
            ? CircularLoadingWidget(height: 500)
            : Stack(
                fit: StackFit.expand,
                children: [
                  LoadingWidget(
                    isLoading: widget.controller.loading,
                    child: SingleChildScrollView(
                      controller: widget.scrollController,
                      padding: EdgeInsets.only(top: 30, bottom: 50, left: 15, right: 15),
                      child: buildListView(context),
                    ),
                  )
                ],
              )
    );
  }
  Widget buildListView(BuildContext context) {
    List<Country> countries = app.countries;
    Address address = widget.controller.address;
    _canEditCity = !address.validId || address?.city?.valid != true;
    bool showCity = widget.showCity || widget.showBranch || widget.forceBranch;
    bool showFull = widget.showFull;
    bool forceBranch = address.validId && address.facility != null || widget.forceBranch;
    bool showBranch = forceBranch || (widget.showBranch && _showCheckBranch);
    return Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: textField(context,
                controller: _nameController,
                labelText: t.full_name,
                validator: (value) {
                  if (value.isEmpty) {
                    return t.full_name;
                  }
                  return null;
                },
                onTap: ()=> _nameNode.requestFocus(),
                onSaved: (value) {
                  address.name = value;
                },
                icon: Icons.person,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: TextFormField(
                    controller: _mobileController,
                    validator: (value) {
                      if (value.isEmpty || dialCode == null) {
                        return t.not_a_valid_phone;
                      }
                      return null;
                    },
                    onSaved: (value) {
                      address.phone = address.mobile = dialCode + value;
                    },
                    decoration: InputDecoration(
                        labelText: t.phone,
                        alignLabelWithHint: false,
                        prefixIcon: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            CountryCodePicker(
                                initialSelection: dialCode,
                                textStyle: TextStyle(fontSize: 15.0, fontWeight: FontWeight.w500, color: Theme.of(context).textTheme.bodyText1.color),
                                countries: this.countries,
                                onChanged:(code){
                                  setState(() {
                                    dialCode = code.rawDialCode;
                                  });
                                }
                            ),
                            Container(
                              height: 25.0,
                              width: 1.0,
                              color: Theme.of(context).dividerColor,
                              margin: const EdgeInsets.only(left: 5.0, right: 5.0),
                            ),
                          ],
                        )
                    ),
                    //icon: UiIcons.phone_call,
                    keyboardType: TextInputType.phone,
                  )
              ),
            ),

            if (showBranch && !forceBranch)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: SwitchListTile(
                  value: _showCheckBranch,
                  onChanged: (value) {
                    _showCheckBranch = value;
                    if (!value) {
                      address.facility = null;
                      address.facilityId = null;
                    }
                    setState(() {});
                  },
                  title: Text(widget.isPickup ? tr.shipFromBranch : tr.deliveryToBranch ),
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                ),
              ),
            if(showCity) ...[
              if(_showCountry)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: createSearchDropdown<Country>(context, tr.country, (c) => c.name??c.code??'',
                      //key: ValueKey(address.country),
                      selected:  address.country.valid ? address.country : null,
                      items: countries,
                      popupTitle: tr.select_country,
                      onChanged: (Country c) {

                        if(address.country != c){
                          address.country = c;
                          if (address.city?.country != c.code){
                            address.city = City();
                          }
                          setState(() {});
                        }
                      },
                      validator: (country) {
                        return country == null ? tr.form.requiredErrorText : null;
                      }
                  ),
                ),

              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: createSearchDropdown<City>(context, tr.city, (c) => c.name??'',
                    key: ValueKey(address.city),
                    selected:  address.city.valid ? address.city : null,
                    online: true,
                    enabled: address.country.valid,
                    endpoint: 'cities/search',
                    args: {'country': address.country.code},
                    popupTitle: tr.select_city,
                    convert: (c)  {
                      print("SelectPickupCity::convert: $c");
                      return City.fromJson(c);
                    },
                    onChanged: (City c) {
                      print("SelectPickupCity:: to city: ${c.id}:${c.name}");
                      if(address.city != c) {
                        address.city = c;
                        address.facilityId = null;
                        address.facility = null;
                        setState(() {});
                      }
                    },
                    validator: (city) => city == null ? tr.form.requiredErrorText : null
                ),
              ),

              if (showBranch)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: createSearchDropdown<Branch>(context, tr.branch, (c) => c.name ??'',
                      key: ValueKey('branches_of_city_${address.city?.id}'),
                      selected:  address.facility,
                      online: true,
                      enabled: address.city.valid,
                      endpoint: 'branches/search',
                      args: {'city': '${address.city?.id}', 'fields': 'id,name'},
                      popupTitle: tr.selectBranch,
                      convert: (c)  {
                        return Branch.fromJSON(c);
                      },
                      onChanged: (Branch c) {
                        address.facility = c;
                        address.facilityId = c.id;
                        address.lat = c.lat;
                        address.lng = c.lng;
                        setState(() {});
                      },
                      validator: (branch) => branch == null ? tr.form.requiredErrorText : null
                  ),
                ),
            ],
            if (!showBranch)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: textField(context,
                    controller: _streetController,
                    labelText: t.address,
                    validator: (value) {
                      if (value.isEmpty) {
                        return t.not_a_valid_address;
                      }
                      return null;
                    },
                    onSaved: (value) {
                      address.street = value;
                    },
                    icon: Icons.add_location,
                    readOnly: widget.showMap ? true : false,
                    onTap: (){

                      showPlacePicker(address);
                    },
                ),
              ),
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: textField(context,
                    controller: _commentController,
                    labelText: t.description,
                    onSaved: (value) {
                      address.comment = value;
                    },
                    icon: Icons.comment,
                ),
            ),

            if(showFull)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: textField(context,
                    labelText: t.zip,
                    controller: _zipController,
                    onSaved: (value) {
                      address.zip = value;
                    },
                    icon: Icons.numbers,
                ),
              ),

            if(showFull)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: textField(context,
                    controller: _emailController,
                    labelText: t.email,
                    onSaved: (value) {
                      address.email = value;
                    },
                    icon: Icons.mail,
                    keyboardType: TextInputType.emailAddress,
                ),
              ),

            if (widget.isPickup && address.isPickup && address.validId
                && address.facilityId == null
                && widget.callback== null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: SwitchListTile(
                  value: currentAccount.value.defaultAddress?.id
                      == address.id,
                  onChanged: (value) {
                    if (value)
                      _setAsDefault(address);
                  },
                  title: Text(tr.saveAsDefault),
                  contentPadding: EdgeInsets.zero,
                  //controlAffinity: ListTileControlAffinity.leading,
                )
              ),

            if (!address.valid && !showBranch && widget.callback != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: CheckboxListTile(
                  title: Text(tr.saveToUseLater),
                  value: address.temporary == false,
                  onChanged: (value){
                    address.temporary = !value;
                    setState(() {});
                  },
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            if (address.valid)
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10.0),
                    child: Text(address.formattedRegion),
                ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              //alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ElevatedButton(
                    child: Text(
                      t.submit,
                    ),
                    onPressed: () async {
                      if (_formKey.currentState.validate()) {
                        _formKey.currentState.save();

                        if (address.facility == null && (
                            !address.city.valid || address.isUnknown())){
                          print("City valid: ${address.city.valid}");
                          print("Address isUnknown: ${address.city.valid}");
                          showPlacePicker(address);
                        }
                        else {
                          _con.save(address).then((value) async{
                            if (!value.hasError && widget.callback != null){
                              if (value.item.facilityId != null) {
                                value.item.facility = address.facility;
                                await BranchProvider.syncAddressWithBranch(
                                    context, [value.item]);
                              }

                              widget.callback(value.item);
                              widget.controller.
                                notifier.notifyListeners();
                            }
                            else if(!value.hasError) {
                              Navigator.pop(context, true);
                              widget.controller.
                                notifier.notifyListeners();
                            }
                          });

                        }
                      }
                    },

                  ),
                ]
              )
            ),
          ],
        ),
      );
  }

  void _addressNotSupported(){
    Fluttertoast.showToast(
        msg: tr.addressNotSupported,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
        backgroundColor: Theme.of(context).colorScheme.error,
        textColor: Colors.white
    );
  }

  void _setAsDefault(Address address) async{
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    try {

      ResultItem result =
           await ApiRequest.post('addresses/set_default/${address.id}')
          .once();
      if (result.hasError) {
        showErrorDialog(context, error: result.error);
      } else {
        currentAccount.value.defaultAddress = address;
        setCurrentAccount(currentAccount.value);
        setState(() { });
        Fluttertoast.showToast(
          toastLength: Toast.LENGTH_LONG,
          msg: tr.addresses_refreshed_successfuly,
        );
        widget.controller.
          notifier.notifyListeners();
      }

    } finally {
      Helper.hideLoader(loader);
    }
  }

  void showPlacePicker(Address address) async {


    var pos = !address.isUnknown()
        ? LatLng(address.lat ,address.lng)
        : address.city?.isUnknown() == false
        ? LatLng(address.city.lat ,address.city.lng)
        : null;
    Config.debug("latLng: $pos", widget.runtimeType);
    await Navigator.of(context).push(
        MaterialPageRoute(builder: (context) =>
            PlacePicker(
                settingNotifier.value.googleMapsKey,
                displayLocation:pos,
                acceptLocation: (location) => _acceptLocation(address, location),
            )));

  }

  Future<Address> _acceptLocation(Address address, LocationResult result) async {
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    try {
      if (result != null) {

        Country country = Country.of(result.country.shortName, true);
        if (country == null || !country.valid){
          showErrorDialog(context, error: tr.addressNotSupported, fullWidth: true, warning: true);
          return null;
        }

        ResultItem<City> cityResult = await app.cityReverse(
            result.latLng.latitude,
            result.latLng.longitude
        );
        if (cityResult.hasError) {
          showErrorDialog(context, error: cityResult.error, fullWidth: true);
          return null;
        }

        City city = cityResult.item;
        if (city == null || city.id == 0){
          //_addressNotSupported();
          showErrorDialog(context, error: tr.addressNotSupported, fullWidth: true, warning: true);
          return null;
        }

        address.lat = result.latLng.latitude;
        address.lng = result.latLng.longitude;
        address.country = Country.of(city.country, false);
        address.city = city;
        address.lat = result.latLng.latitude;
        address.lng = result.latLng.longitude;
        address.street = result.formattedAddress;
        address.zip = result.postalCode;
        address.province = result.locality;
        setState(() {
          _streetController.text = "${result.name}, ${result.locality}";
          _zipController.text = result.postalCode;
          _provinceController.text = result.locality;
        });
        return Future.value(address);
      }
    } finally{
      Helper.hideLoader(loader);
    }
    return Future.value();
  }

  @override
  bool get wantKeepAlive => true;
}
