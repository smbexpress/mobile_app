import 'package:flutter/material.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/model.dart';

import '../../../i18n/i18n.dart';
import '../../api.dart';
import '../../models/route_argument.dart';
import '../../models/shipment.dart';
import '../../widgets/SmbWidget.dart';

void _makeRequest(BuildContext context, String confirmMessage, String endpoint, VoidCallback callback) async{
  Navigator.of(context).pop();
  final confirm = await alert(
      context,
      title: Text(tr.confirmation),
      content: Text(confirmMessage)
  );
  if (confirm == true){
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    var result = null;
    try {
      result = await ResultItem.of(Api().post(endpoint), null);
      if(result.hasError) {
        result = result.error;
      }
    } catch(e){
      result = ErrorResult.tryError(e);
    }
    Helper.hideLoader(loader);
    if (result is ErrorResult){
      showSnackBar(context, error: result);
    } else {
      showNotifyDialog(context,
          title: tr.done,
          showMessage: false,
          contentType: ContentType.SUCCESS,
          duration: Duration(seconds: 3)
      );
      callback();
    }
  }
}

void showShipmentBottomSheet(BuildContext context, Shipment shipment, VoidCallback callback) async {

  int childCount = 0;
  if (shipment?.status?.code == 'p') childCount++;
  if(shipment.canEdit) childCount++;
  if (['p', 'm'].contains(shipment?.status?.code)) childCount++;
  if (!['p', 'c', 'd'].contains(shipment?.status?.code)) childCount++;
  if (!['p', 'c', 'd'].contains(shipment?.status?.code)) childCount++;

  if (childCount == 0)
    return;

  final parentContext = context;
  final itemHeight = 60.0;
  final height = childCount * itemHeight + 48.0;

  print("showShipmentBottomSheet: height: $height");
  final mq = MediaQuery.of(context);
  showModalBottomSheet(
    context: context,
    isDismissible: true,
    constraints: BoxConstraints(
      maxWidth: mq.size.width - 32,
    ),
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    shape: const RoundedRectangleBorder(
      borderRadius: const BorderRadius.all(const Radius.circular(12.0)),
    ),
    builder: (context) {
      StateSetter stateSetter;
      bool isLoading = false;
      return SafeArea(
          minimum: EdgeInsets.only(
              top: mq.padding.top,
              bottom: mq.viewInsets.bottom + 16
          ),
          child: Padding(
              padding: EdgeInsets.only(bottom: 12, top: 5),
              //color: Colors.red,
              child: IntrinsicHeight(
                child: Material(
                  color: Theme.of(context).cardColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        height: 10,
                        child: Center(
                          child: Container(
                            width: 40,
                            height: 4,
                            decoration: BoxDecoration(
                              color: Theme.of(context).dividerColor.withOpacity(0.5),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ),
                      ),
                      if(shipment.status?.code == 'p')
                        ListTile(
                          leading: Icon(Icons.send),
                          title: Text(tr.submit),
                          onTap: () async {
                            Navigator.pop(context);
                            final dialog = showNotifyDialog(parentContext,
                                showMessage: false,
                                showTitle: false,
                                contentType: ContentType.PROGRESS,
                                duration: null,
                                show: false,
                                dismissOnTouchOutside: false
                            );
                            dialog.show();
                            ResultItem result = await ResultItem.of(Api().post('shipments/${shipment.id}/confirm'), (data) => data) ;
                            dialog.dismiss();
                            if (result.hasError){
                              showNotifyDialog(parentContext, error: result.error, duration: null);
                            } else {
                              showSuccessDialog(parentContext);
                              callback?.call();
                            }
                          },
                        ),
                      if(shipment.canEdit)
                        ListTile(
                          leading: Icon(Icons.cancel),
                          title: Text(tr.editShipment),
                          onTap: () async {
                            Navigator.of(context).pushReplacementNamed('/ShipmentEdit',
                                arguments: new RouteArgument(id: shipment.id?.toString(), param: shipment));
                          },
                        ),
                      if (['p', 'm'].contains(shipment?.status?.code))
                        ListTile(
                          leading: Icon(Icons.cancel),
                          title: Text(tr.cancelShipment),
                          onTap: () async {
                            //Navigator.of(context).pop();
                            _makeRequest(
                                parentContext,
                                "Are you sure you want to cancel this shipment?",
                                "shipments/${shipment.id}/cancel",
                                callback
                            );
                          },
                        ),
                      if (!['p', 'c', 'r'].contains(shipment?.status?.code))
                        ListTile(
                          leading: Icon(Icons.reply),
                          title: Text(tr.createReturnShipment),
                          onTap: () async {
                            _makeRequest(
                                parentContext,
                                "Are you sure you want to return for this shipment?",
                                "shipments/${shipment.id}/return",
                                callback
                            );
                          },
                        ),
                      SizedBox(height: 6,)

                    ],
                  ),
                ),
              )
          )
      );
    },

  );
}