
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/helpers/maps_util.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/icon_text.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../../i18n/i18n.dart';
import '../../api.dart';
import '../../config.dart';
import '../../helpers/Debouncer.dart';
import '../../helpers/helper.dart';
import '../../models/address.dart';
import '../../models/model.dart';
import '../../models/route_argument.dart';
import '../../models/shipment.dart';
import '../../notification_provider.dart';
import '../../repository/settings_repository.dart';
import '../../theme/theme.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/calendar_appbar.dart';
import '../../widgets/connection_status_widget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/picker/place_picker/entities/entities.dart';
import '../../widgets/picker/place_picker/place_picker.dart';
import '../../widgets/stack_body.dart';
import '../../widgets/system_ui_overlay_mixin.dart';

class AddressesShowScreen extends StatefulWidget {
  final RouteArgument args;
  AddressesShowScreen({
    Key key,
    this.args,
  }) :super(key: key);

  @override
  _AddressesShowScreenState createState() =>
      _AddressesShowScreenState();
}

class _AddressesShowScreenState extends State<AddressesShowScreen>
    with SingleTickerProviderStateMixin {
  //final _debouncer = Debouncer();
  final LoadState<Address> addressesState =
      LoadState(null, until: Duration(minutes: 100));
  int currentPage = 0;
  LocationResult locationResult;
  bool mapVisible = false;
  bool hasChanges = false;
  @override
  void initState() {
    super.initState();
    addressesState.addListener(_loadingStateChanged);
    //addressesState.reload();
    _load();
    //WidgetsBinding.instance.endOfFrame.then((value) => _load());
  }

  @override
  void dispose() {
    addressesState.removeListener(_loadingStateChanged);
    addressesState.dispose();
    super.dispose();
  }

  void _loadingStateChanged() {}

  void _load() async{
    if (addressesState.isLoading) return;

    addressesState.reload();
    WidgetsBinding.instance.endOfFrame.then((value) => setState(() {}));

    try {
      final value = await ResultItem.of(
          Api().get("addresses/${widget.args.id}/relatedShipment", 
              data: widget.args.param),
              (data) => Address.fromJSON(data));

      addressesState.update(
          value.hasError ? null : value.item,
          value.error);
      if (value.item.facilityId != null)
        await BranchProvider.syncAddressWithBranch(context, [value.item]);


    } finally{
      if (addressesState.isLoading)
        addressesState.update(null);

      setState(() {});
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Theme.of(context).cardColor,
        appBar: appBar(context,
            automaticallyImplyLeading: false,
            showBack: false,
            //isSecondary: false,
            //backgroundColor: Theme.of(context).cardColor,
            titleText: tr.address,
            actions: [
              IconButton(
                onPressed: () {
                  //_onWillPop();
                  Navigator.of(context).pop();
                },
                icon: Icon(Icons.close),
                tooltip: tr.close,
              )
            ]),
        body: LoadingWidget(
          isLoading: addressesState.isLoading,
          error: addressesState.error,
          onRetry: _load,
          child: ConnectionChangeWidget(
              builder: (context, connect) {
                if (connect &&
                    !addressesState.isLoading && (
                    addressesState.value == null ||
                            addressesState.error?.isNetwork == true)) {

                  WidgetsBinding.instance.endOfFrame.then((value) => _load());
                }
                return _createBody();
              }
          ),
        )
    );
  }

  void _showMap() async{
    final address = addressesState.value;
      if (address.facility != null && !address.facility.isUnknown())
        await MapsUtil.launchMap(
            address.facility.lat,
            address.facility.lng
      );
      if (address.facility == null && !address.isUnknown())
        await MapsUtil.launchMap(
            address.lat,
            address.lng
        );

  }

  void _openCall() async{
    final address = addressesState.value;
    if (address.mobile != null) {
      var mobile = address.mobile;
      if (!mobile.startsWith('+') && !mobile.startsWith('00')){
          mobile = '+$mobile';
      }
      await launchUrlString(
          'tel:$mobile'
      );
    }

  }

  Widget _createBody() {


    final address = addressesState.value;
    if (address == null) {
      return const SizedBox.shrink();
    }

    Widget row(String title, String value,
        {bool useNew=true, Widget icon, VoidCallback action, Widget trailing}) {
      return ListTile(
        onTap: action,
        leading: icon,
        title: useNew
            ? Text('$title:')
            : Row(
          children: [
            Text('$title:'),
            const SizedBox(width: 10,),
            Expanded(child: Text(value??''))
          ],
        ),
        subtitle: useNew ? Text(value??'') : null,
        trailing: trailing,
      );
    }

    return Column(
      children: [
        const Divider(height: 2, thickness: 1.0),
        Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                const SizedBox(height: 20,),
                row(tr.full_name, address.name, useNew: true,
                    icon: Icon(Icons.person)),
                const Divider(height: 2, thickness: 1.0),
                row(tr.country, address.country?.name,
                    useNew: true, icon: Icon(Icons.map)),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.city, address.city?.name,
                    icon: Icon(Icons.location_city)),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.phone, address.phone,
                    icon: Icon(Icons.phone),
                    action: _openCall
                ),
                const Divider(height: 2, thickness: 1.0,),
                row(tr.zip, address.zip,
                    icon: Icon(Icons.local_post_office_outlined)),
                const Divider(height: 2, thickness: 1.0,),
                if (address.facilityId == null)
                  row(tr.street, address.street, useNew: true,
                      icon: Icon(Icons.location_on_outlined),
                      trailing: Icon(Icons.navigation, color: Colors.blueAccent),
                      action: _showMap
                  ),
                if (address.facilityId != null)
                  row(tr.branch, address.facility?.name,
                      icon: Icon(Icons.account_balance),
                      trailing: Icon(Icons.navigation, color: Colors.blueAccent),
                      action: _showMap
                  ),
                //const Divider(height: 2, thickness: 1.0,),
                SizedBox(height: 20,),

                //const Divider(height: 2, thickness: 1.0,),

              ],
            )
        )
      ],
    );
  }

  Future<bool> _onWillPop() async{
    //alert(context, tr.ar)
    return false;
  }



}
