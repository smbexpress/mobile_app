import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/screens/address/AddressesItemWidget.dart';

import '../../../i18n/i18n.dart';
import '../../controllers/address_controller.dart';
import '../../helpers/Debouncer.dart';
import '../../helpers/helper.dart';
import '../../models/address.dart';
import '../../models/route_argument.dart';
import '../../theme/theme.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
import 'address_edit.dart';

class AddressesScreen extends StatefulWidget {
  final RouteArgument routeArgument;
  final ValueChanged<Address> onSelect;
  final bool isPickup;
  final ScrollController scrollController;
  final bool showAppBar;
  final bool forceBranch;
  AddressesScreen({
    Key key,
    this.routeArgument,
    this.isPickup,
    this.onSelect,
    this.scrollController,
    this.showAppBar = true,
    this.forceBranch = false,
  }) : super(key: key);

  @override
  _AddressesScreenState createState() => _AddressesScreenState();
}

class _AddressesScreenState extends StateMVC<AddressesScreen> with AutomaticKeepAliveClientMixin,
    SystemUiOverlayMixin {
  final FloatingSearchBarController _searchBarController = FloatingSearchBarController();
  final _debouncer = Debouncer();
  AddressController _con;
  bool isPickup;
  _AddressesScreenState() : super(AddressController()) {
    _con = controller;
  }

  @override
  void initState() {
    super.initState();
    isPickup =  widget.isPickup ?? widget.routeArgument?.id == '1';
    _con.searchAddresses(isPickup, null, widget.forceBranch);
    _con.notifier.addListener(_search);
    if (widget.showAppBar)
      initSystemUiOverlay(AppTheme.blueOverlayStyle);
    //_searchBarController.addListener(_search1);
  }
  @override
  void dispose(){
    super.dispose();
    leave();
    _con.notifier.removeListener(_search);
    //_searchBarController.removeListener(_search1);
    _searchBarController.dispose();
  }
  String _addressSearch;
  void _search1(String query){
    if (_addressSearch == query)
        return;
    _addressSearch = query;
    _debouncer(_search);
  }

  void _search(){
    _con.searchAddresses(isPickup, _addressSearch, widget.forceBranch);
  }

  @override
  Widget build(BuildContext context) {

    List<Address> addresses = _con.addressList;
    final body = RefreshIndicator(
        onRefresh: (){
          _search();
          return Future.value();
        },
        child: LoadingWidget(
          isLoading: _con.loading??false,
          onRetry: _search,
          error: _con.error,
          child: ListView.separated(
            controller: widget.scrollController,
            padding: EdgeInsets.only(
                bottom: 15,
                top: widget.showAppBar ? 0.0 : kToolbarHeight + MediaQuery.of(context).padding.top),
            scrollDirection: Axis.vertical,
            //shrinkWrap: true,
            //primary: false,
            itemCount: addresses.length,
            separatorBuilder: (context, index) {
              return Divider(thickness: 1.5,);
            },
            itemBuilder: (context, index) {
              Address address = addresses[index];
              return AddressesItemWidget(
                address: addresses.elementAt(index),
                onPressed: (Address _address) async{
                  final loader = Helper.overlayLoader(context);
                  Overlay.of(context).insert(loader);
                  try {
                    _address = await _con.loadAddress(_address);
                  } finally {
                    Helper.hideLoader(loader);
                  }
                  //_address.city = address.city;
                  if (widget.onSelect != null){
                    widget.onSelect(_address);
                    print("Select city: ${_address.city}");
                    return;
                  }

                  Navigator.push(context,
                      MaterialPageRoute(
                          builder: (context) =>AddressWidget(controller: _con, address: _address),
                          settings: RouteSettings(name : '/Address')
                      )
                  );
                },
                onDismissed: widget.onSelect == null
                  && address.isDefault != true
                  ? (Address address) async {
                      if ( await alert(context,
                          content: Text(tr.confirmDeleteAddress(address.name)),
                          title: Text(tr.confirmation)
                      ) ){
                        await _con.removeAddress(address);

                      }
                }
                : null,
              );
            },
          ),
        )
    );

    if (!widget.showAppBar){
      return Scaffold(
          key: _con.scaffoldKey,
          //backgroundColor: Theme.of(context).cardColor,
          body: Stack(
            fit: StackFit.expand,
            children: [
              Positioned(
                  left: 0,
                  top: -20.0,
                  right: 0,
                  bottom: 0,
                  child: FloatingSearchBar(
                    //controller: controller,
                      backdropColor: Colors.transparent,
                      title: Text(
                        isPickup ? tr.pickup_addresses : tr.delivery_addresses,
                      ),
                      hint: '${tr.search} ...',
                      //isScrollControlled: true,
                      builder: (context, _) {
                        return SizedBox();
                      },

                      clearQueryOnClose: false,
                      //elevation: 8.0,
                      //border: BorderSide(color: Theme.of(context).hintColor),
                      hasSafeArea: true,
                      //padding: EdgeInsets.only(left: 12, right: 16, top: 0.0),
                      //shadowColor: Theme.of(context).shadowColor,
                      transitionDuration: const Duration(milliseconds: 400),
                      transitionCurve: Curves.easeInOutCubic,
                      //debounceDelay: const Duration(milliseconds: 400),
                      physics: const BouncingScrollPhysics(),
                      axisAlignment: -1.0,
                      openAxisAlignment: 0.0,
                      scrollPadding: EdgeInsets.zero,
                      transition: SlideFadeFloatingSearchBarTransition(spacing: 16),
                      automaticallyImplyBackButton: false,
                      onQueryChanged: _search1,
                      //isScrollControlled: true,
                      body: FloatingSearchBarScrollNotifier(
                        child: Material(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            child: body
                        ),
                      )
                  ),
              )

            ],
          )
      );
    }

    return Scaffold(
      key: _con.scaffoldKey,
      backgroundColor: Theme.of(context).cardColor,
      /*
      appBar: appBar(
        context,
        titleText: isPickup ? S.of(context).pickup_addresses : S.of(context).delivery_addresses,
        isSecondary: true
      ),

       */
      floatingActionButton:// _con.cart != null && _con.cart.product.store.availableForDelivery
              FloatingActionButton(
                  onPressed: ()  async{
                    await Navigator.push(context, MaterialPageRoute(
                        builder: (context) =>
                            AddressWidget(controller: _con, address: Address.fromJSON({'isPickup': isPickup}))));
                    //setState(() => _pickedLocation = result);
                  },
                  child: Icon(
                    Icons.add,
                  )),
      //: SizedBox(height: 0),
      body: FloatingSearchAppBar(
        title: Text(isPickup ? S.of(context).pickup_addresses : S.of(context).delivery_addresses,
          style: TextStyle(fontSize: 18, color: LightColor.white),),
        hint: '${tr.search} ...',
        brightness: Brightness.light,
        colorOnScroll: Theme.of(context).colorScheme.secondary,
        color: Theme.of(context).colorScheme.secondary,
        body: body,
        overlayStyle: AppTheme.blueOverlayStyle,
        iconColor: LightColor.white,
        titleStyle: TextStyle(fontSize: 18, color: LightColor.white),
        hintStyle: TextStyle(fontSize: 16, color: LightColor.white),
        onQueryChanged: _search1,

      )
    );
  }


  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
