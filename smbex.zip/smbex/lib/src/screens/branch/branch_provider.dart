import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/helpers/maps_util.dart';
import 'package:smbex_app/src/models/branch.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/repository/account_repository.dart';

import '../../models/address.dart';

class BranchProvider extends ChangeNotifier {

  static BuildContext _context ;
  static BranchProvider _instance ;

  final StreamController<Branch> _locationController =
  StreamController<Branch>.broadcast();
  final ValueNotifier<Branch> changeBranch = ValueNotifier<Branch>(null);
  final ValueNotifier<LatLng> changeLocation = ValueNotifier<LatLng>(null);
  final ValueNotifier<List<Branch>> searchList =
      ValueNotifier<List<Branch>>([]);

  final LoadState<List<Branch>> listBranchState =
    LoadState<List<Branch>>(null, until: Duration(minutes: 20));
  String _filter;
  List<Branch> _listBranch;
  List<Branch> searchedBranchList;
  Stream get branchStream => _locationController.stream;
  LatLng latLang;
  Completer _locationCompleter;
  City _city;
  Future<ResultItems<Branch>> _pending;
  int _loadingCounter = 0;

  BranchProvider(BuildContext context){
    BranchProvider._context = context;
    _instance = this;
  }

  void setCity(City city) {
    if (_city?.id != city?.id) {
      if (_pending != null) {
        _pending = null;
      }
      listBranchState.reset();
      branches();
    }
  }

  void clear(){
    listBranchState.reset();
    searchedBranchList = null;
    changeBranch.value = null;
  }

  Future<List<Branch>> branches() async {
    print("BranchProvider:: branches");
    if (_pending != null)
      return (await _pending).items ?? [];

    if (listBranchState.validate()) {
      print("BranchProvider:: request branches ignore");
      return Future<List<Branch>>.value(listBranchState.value);
    }
    _loadingCounter++;

    int currentLoadingCounter = _loadingCounter;

    _pending = ApiRequest.of('branches/list',
          timeout: 30,
          data: _city != null ? {'city': _city.id} : null,
          serializer: (data) => Branch.fromJSON(data)
      )
      .list();
    try {
      ResultItems<Branch> branchResult = await _pending;
      //check if branches called again
      if (currentLoadingCounter != _loadingCounter){
        return branches();
      }

      _pending = null;

      listBranchState.update(branchResult.items, branchResult.error);
      if (changeLocation.value == null) {
        changeLocation.value = await MapsUtil.getLastLocation();
      }
      sortBranches();
      if (_filter != null) {
        final temp = _filter;
        _filter = null;
        searchBranch(temp);
      } else {
        searchedBranchList = [];
        searchedBranchList.addAll(listBranchState.value);
      }
      notifyListeners();
      searchList.value = searchedBranchList;

      return listBranchState.value ?? [];
    } finally {
      if (_pending != null) {
        listBranchState.update(null);
        _pending = null;
        notifyListeners();
      }

    }
  }

  Future<List<Branch>> searchBranch(String query) async {
    if (_pending != null && _filter == query)
      return searchedBranchList;
    List<Branch> listBranch = await branches();

    if (query == null || query.isEmpty) {
      searchedBranchList = listBranch;
      _filter = query;
      searchList.value = searchedBranchList;
      return searchedBranchList;
    }
    _filter = query;

    query = query.toLowerCase();
    List<Branch> founds = [];
    listBranch.forEach((element) {
      if (element.name != null && element.name.toLowerCase().contains(query) ||
          element.city?.toLowerCase()?.contains(query) == true ||
          element.address?.toLowerCase()?.contains(query) == true)
        founds.add(element);
    });
    searchedBranchList = founds;
    searchList.value = searchedBranchList;
    return searchedBranchList;
  }

  void setSelectedBranch(Branch branch) {
    //_locationController.sink.add(location);
    changeBranch.value = branch;
  }

  @override
  void dispose() {
    _locationController.close();
    changeBranch.dispose();
    super.dispose();
  }

  Future setCurrentLocation() async {
    if (_locationCompleter?.isCompleted == false)
      return _locationCompleter.future;
    Branch validBranch;
    if (searchList.value.isNotEmpty) {
      final validBranches = searchList.value.where((branch) =>
          Helper.isValidCords(branch.lat, branch.lng));
      validBranch = validBranches.isNotEmpty ? validBranches.first : null;
    }

    final lastLstLng = await MapsUtil.getLastLocation();
    _locationCompleter = new Completer();
    bool reSortBranches = true; //changeLocation.value == null;
    changeLocation.value = LatLng(
        selectedBranch?.lat ?? validBranch?.lat ?? lastLstLng?.latitude ?? 0.0,
        selectedBranch?.lng ?? validBranch?.lng ?? lastLstLng?.longitude ?? 90.0);

    var location = new Location();
    location.serviceEnabled()
        .then((value) {

        if (value) {
          location.requestService().then((value) async {
            print("Location requestService: $value");
            if (value == true) {
              location.getLocation().then((_loc) async {
                print("Location getLocation: $_loc");
                if (_loc != null) {
                  changeLocation.value =
                      LatLng(_loc.latitude, _loc.longitude);
                  if (reSortBranches) {
                    sortBranches();
                    notifyListeners();
                  }
                }
                _locationCompleter.complete();
                MapsUtil.setLastLocation(changeLocation.value);
              });
            }
          });
        } else {
          _locationCompleter.complete();
        }
       }
    );

    return _locationCompleter.future;
  }

  set selectedBranch(Branch branch) => changeBranch.value = branch;

  Branch get selectedBranch => changeBranch.value;

  bool get isLoading => _pending != null;

  String get filter => _filter ?? '';

  void sortBranches() {
    print(
        "BranchProvider::sortBranches currentLocation: ${changeLocation.value}");
    if (changeLocation.value != null && listBranchState.value != null) {
      sortBranchList(listBranchState.value, changeLocation.value.latitude,
          changeLocation.value.longitude);
    }
  }

  static List<City> sortCityList(List<City> cities, double lat, double lng) {
    return cities;
  }

  static List<Branch> sortBranchList(
      List<Branch> branches, double lat, double lng) {
    final invalidBranches = <Branch>[];
    final validBranches = <Branch>[];
    for (final branch in branches) {
      if (Helper.isValidCords(branch.lat, branch.lng)) {
        branch.distance =
            Helper.distanceBetween(lat, lng, branch.lat, branch.lng);
        validBranches.add(branch);
      } else {
        invalidBranches.add(branch);
      }
    }
    validBranches.sort((a, b) {
      return a.distance.compareTo(b.distance);
    });

    branches.clear();
    branches.addAll(validBranches);
    branches.addAll(invalidBranches);

    validBranches.forEach((branch) {
      if (Helper.isValidCords(branch.lat, branch.lng)) {
        print("${branch.name}: ${branch.distanceFormat}");
      }
    });

    return branches;
  }

  static int _compare(String a1, String b1, String a2, String b2) {
    if (a1 == null) return 1;
    if (b1 == null) return -1;

    if (a1 == b2) {
      if (a2 == null) return 0;
      if (b2 == null) return 0;

      return a2.compareTo(b2);
    }
    return a1.compareTo(b1);
  }


  static void syncAddressWithBranch(BuildContext context, List<Address> addresses) async{
    if (context?.owner == null)
      context = _context;
    
    final branchProvider = _instance ?? context.read<BranchProvider>();
    List<Branch> branches = await branchProvider.branches();

    for (final address in addresses) {
      if (address.facilityId != null)
        address.facility = branches
            .firstWhere((branch) =>
        branch.id == address.facilityId
      );
    }


  }
}
