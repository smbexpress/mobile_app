import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:smbex_app/src/helpers/Debouncer.dart';
import 'package:smbex_app/src/models/branch.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/SlidingUpPanel.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../../i18n/i18n.dart';
import '../../helpers/maps_util.dart';
import "../../theme/extention.dart";
import 'branch_provider.dart';

class BranchMapView extends StatefulWidget {
  final BranchProvider branchService;
  BranchMapView({Key key, this.branchService}) : super(key: key);

  @override
  _BranchMapViewState createState() => _BranchMapViewState();
}

class _BranchMapViewState extends State<BranchMapView>
    with AutomaticKeepAliveClientMixin<BranchMapView> {
  var scaffoldKey = GlobalKey<ScaffoldState>();
  Completer<GoogleMapController> mapController = Completer();
  LatLng _latLang;
  Set<Marker> _markers = Set();

  PanelController panelController = new PanelController();
  double panelPos;
  final _posDebouncer = Debouncer();
  bool animateCamera = true;
  CameraPosition _cameraPosition;
  Branch lastBranch;



  @override
  void initState() {
    super.initState();
    final service = widget.branchService;
    _latLang = service.changeLocation.value;

    LatLng branchLatLang = service.selectedBranch != null
          && service.selectedBranch.lng != null
          && service.selectedBranch.lat != null
            ? LatLng(service.selectedBranch.lat, service.selectedBranch.lng)
            : null;

    _cameraPosition = CameraPosition(
      target: branchLatLang ?? _latLang ?? LatLng(24.688331, 46.684109),
      zoom: branchLatLang != null || _latLang != null? 16 : 13,
    );


    service.changeLocation.addListener(_addMyMarker);
    service.changeBranch.addListener(_branchChanged);
    if (service.selectedBranch != null) {
      lastBranch = service.selectedBranch;
      _addMakers(context, false);
      _configurePanelController();
    }
  }

  @override
  void dispose() {
    widget.branchService.changeLocation.removeListener(_locationChanged);
    this.widget.branchService.changeBranch.removeListener(_branchChanged);
    super.dispose();
  }

  @override
  void didUpdateWidget(BranchMapView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (lastBranch != widget.branchService.selectedBranch) {
      _configurePanelController();
      _branchChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      key: PageStorageKey<String>('BranchMap'),
      child: Stack(
        alignment: Alignment.topCenter,
        children: <Widget>[
          buildContent(context),
        ],
      ),
    );
  }

  Widget buildContent(BuildContext context) {
    Branch selectedBranch = widget?.branchService.selectedBranch;
    final mq = MediaQuery.of(context);
    Size size = mq.size;
    double rheight = size.height;
    final maxHeight = rheight * 0.7;
    if (panelPos == null) {
      if (selectedBranch == null) {
        panelPos = maxHeight;
      } else {
        panelPos = maxHeight * .3 + 20;
      }
    }

    print(
        "BranchMapView:: Map height: $panelPos, height: ${size.height}, width: ${size.width}, pd: ${mq.padding.top}");
    return Material(
        child: Stack(
      alignment: Alignment.topCenter,
      children: [
        SlidingUpPanel(
          controller: panelController,
          maxHeight: maxHeight,
          minHeight: 0.0,
          parallaxEnabled: true,
          parallaxOffset: 0.5,
          backdropEnabled: false,
          backdropTapClosesPanel: false,
          margin: EdgeInsets.zero,
          padding: EdgeInsets.zero,
          //renderPanelSheet: false,
          snapPoint: .3,
          borderRadius: BorderRadius.zero,
          isDraggable: true,
          //borderRadius: BorderRadius.only(topLeft: Radius.circular(15.0), topRight: Radius.circular(15.0)),
          onPanelSlide: (pos) {
            setState(() {
              panelPos = maxHeight * pos + 20;
              print("BranchMapView:: onPanelSlide: (${pos}, $panelPos)");
            });
            /*
            _posDebouncer(() => setState(() {
              panelPos = rheight - rheight * (pos);
              print("onPanelSlide: (${pos}, $panelPos)");
            })) ;

             */
          },
          //onPanelClosed: () => widget.branchService.selectedBranch = null,
          body: GoogleMap(
            onMapCreated: onMapCreated,
            myLocationEnabled: false,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            initialCameraPosition: _cameraPosition,
            onCameraMove: (camera) {
              _cameraPosition = camera;
            },
            markers: _markers,
          ),
          panelBuilder: (ScrollController sc) => _branchDetail(context, sc),
        ),
        // the fab
        Positioned(
          right: 20.0,
          bottom: panelPos,
          child: FloatingActionButton(
            child: Icon(
              Icons.gps_fixed,
              color: Theme.of(context).primaryColorDark,
            ),
            onPressed: () async {
              await widget.branchService.setCurrentLocation();
              _addMyMarker();
              setState(() {});
              _locationChanged();
            },
            backgroundColor: Colors.white,
          ),
        ),

        Positioned(
            top: 0,
            child: ClipRRect(
                child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).padding.top,
                      color: Colors.transparent,
                    )))),

        //the SlidingUpPanel Title
      ],
    ));
  }

  Widget _branchDetail(BuildContext context, ScrollController sc) {
    Branch branch = lastBranch;
    if (branch == null) {
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        _configurePanelController();
        if (lastBranch != null) {
          setState(() {});
        } else {
          print("BranchMapView:: _branchDetail Branch Still null*******");
        }
      });
      return SizedBox();
    }

    print("BranchMapView:: _branchDetail branch:  ${branch?.name}");
    RenderBox box = context.findRenderObject() as RenderBox;
    Size size = box?.hasSize ?? false ? box.size : MediaQuery.of(context).size;
    final th = Theme.of(context);
    return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: ListView(controller: sc, children: <Widget>[
          SizedBox(
            height: 5.0,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  //borderRadius: BorderRadius.all(Radius.circular(12.0))
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                branch?.name ?? '',
                style: TextStyles.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              Icon(
                Icons.close,
                size: 24,
              ).p(6).ripple(() => panelController.close(),
                  shape: const CircleBorder(), splashColor: th.shadowColor)
            ],
          ).p(10),
          Divider(
            height: 1,
            thickness: .6,
          ),
          SizedBox(
            height: 8.0,
          ),
          Container(
            padding: EdgeInsets.only(bottom: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Icon(
                    Icons.location_on,
                    size: 36,
                    color: LightColor.green,
                  ),
                ),
                Flexible(
                    flex: 4,
                    fit: FlexFit.tight,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 5.0,
                        ),
                        Text(
                          branch?.address ?? '',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        )
                      ],
                    )),
                Flexible(
                  flex: 2,
                  child: Column(children: [
                    Text(branch?.distanceFormat ?? ''),
                    SizedBox(height: 5),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.directions,
                            //color: LightColor.white,
                          ).p(10).ripple(() {
                            if (branch != null &&
                                branch.lat != null &&
                                branch.lng != null)
                              launchUrlString(
                                  "https://maps.google.com/?saddr=${branch.lat},${branch.lng}&daddr=${branch.lat},${branch.lng}");
                          },
                              shape: const CircleBorder(),
                              splashColor: th.shadowColor),
                          IconButton(
                            onPressed: branch?.phone == null
                                ? null
                                : () {
                                    canLaunchUrlString("tel:${branch.phone}");
                                  },
                            icon: Icon(
                              Icons.phone,
                              //color: LightColor.white,
                            ),
                          ),
                        ])
                  ]),
                ),
              ],
            ),
          ),
          Divider(
            height: 1,
          ),
          SizedBox(
            height: 10.0,
          ),
          Text(
            tr.workingTime,
            style: TextStyles.titleM,
            textAlign: TextAlign.center,
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
            child: Column(
              children: (branch?.opening ?? [])
                  .map((opening) => Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(opening.dayName ?? ''),
                          Text('${opening.startString} - ${opening.endString}'),
                        ],
                      ))
                  .toList(),
            ),
          )
        ]));
  }

  void _configurePanelController() {
    if (mounted && panelController.isAttached) {
      if (lastBranch != null && panelController.isPanelClosed) {
        panelController
            .animatePanelToPosition(.3)
            .then((value) => setState(() {}));
      }
      if (lastBranch == null && panelController.isPanelOpen) {
        panelController.close();
      }
    }
  }

  _branchChanged() async {
    Branch branch = widget.branchService.selectedBranch;
    if (branch == lastBranch && branch != null) return;

    print("BranchMapView:: _branchChanged to: ${branch?.name}");

    if (branch == null) {
      _addMakers(context, true);
      lastBranch = null;
      _configurePanelController();
      return;
    }

    lastBranch = branch;
    bool enableAnimate = true;

    if (branch.lat != null && branch.lng != null) {
      GoogleMapController _mapController = await mapController.future;
      if (enableAnimate && animateCamera) {

        final lastZoom = _cameraPosition.zoom;
        await _zoomToFitPoints(LatLng(branch.lat, branch.lng));
        await Future.delayed(Duration(milliseconds: 600));

        await _mapController.animateCamera(CameraUpdate.newLatLngZoom(
            LatLng(branch.lat, branch.lng), max(16, lastZoom)));
      } else {
        Future.delayed(Duration(seconds: 1), () async {
          _mapController.moveCamera(CameraUpdate.newLatLngZoom(
              LatLng(branch.lat, branch.lng), max(16, _cameraPosition.zoom)));
        });
      }
      _addMakers(context, false);
      animateCamera = true;
    }
    _configurePanelController();
    if (mounted) {
      setState(() {});
    }
  }

  _locationChanged() async {
    _latLang = widget.branchService.changeLocation.value;
    GoogleMapController _mapController = await mapController.future;
    //if (mounted) _addMakers(context);
    _mapController.animateCamera(
        CameraUpdate.newLatLngZoom(_latLang, max(16, _cameraPosition.zoom)));
    _latLang = null;
    //
  }

  static BitmapDescriptor markerIcon;
  static BitmapDescriptor selectedMarkerIcon;
  static BitmapDescriptor myMarkerIcon;
  _addMakers(BuildContext context, [bool center = true]) async {
    //BitmapDescriptor des = await BitmapDescriptor.fromAsset("assets/icons/marker.png");

    markerIcon ??= BitmapDescriptor.fromBytes(
        await MapsUtil.getBytesFromAsset('assets/icons/marker.png', 100));
    selectedMarkerIcon ??= BitmapDescriptor.fromBytes(
        await MapsUtil.getBytesFromAsset(
            'assets/icons/marker_selected.png', 100));
    myMarkerIcon ??= BitmapDescriptor.fromBytes(
        await MapsUtil.getBytesFromAsset(
            'assets/img/my_marker.png', 100));



    final selectedBranch = widget.branchService.selectedBranch;
    widget.branchService.branches().then((_branches) {
      var markers = <Marker>{};
      var branches = <Branch>[];
      for (Branch branch in _branches) {
        if (branch.lat == null || branch.lng == null) continue;
        branches.add(branch);
        MarkerId markerId = MarkerId(branch.id.toString());
        Marker marker = Marker(
          markerId: markerId,
          position: LatLng(branch.lat, branch.lng),
          icon:
              branch.id == selectedBranch?.id ? selectedMarkerIcon : markerIcon,
          onTap: () {
            animateCamera = false;
            if (lastBranch == branch) _configurePanelController();
            widget.branchService.selectedBranch = branch;
          },
        );
        markers.add(marker);
        //print("Creating Markere -> $marker");
      }

      _markers = markers;
      _addMyMarker();
      if (mounted) {
        setState(() {
          if (center) this._zoomToFitPlaces(branches);
        });
      } else {
        if (center) this._zoomToFitPlaces(branches);
      }
    });
  }

  Future<void> _zoomToFitPlaces(List<Branch> places) async {
    var controller = await mapController.future;
    _configurePanelController();
    // Default min/max values to latitude and longitude of center.
    var minLat = _latLang.latitude;
    var maxLat = _latLang.latitude;
    var minLong = _latLang.longitude;
    var maxLong = _latLang.longitude;

    for (var place in places) {
      minLat = min(minLat, place.lat);
      maxLat = max(maxLat, place.lat);
      minLong = min(minLong, place.lng);
      maxLong = max(maxLong, place.lng);
    }

    controller.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLong),
          northeast: LatLng(maxLat, maxLong),
        ),
        48.0,
      ),
    );
  }

  Future<void> _zoomToFitPoints(LatLng newPoint) async {
    if (_cameraPosition == null || _cameraPosition.target == null)
      return;

    LatLng lastPoint = _cameraPosition.target;
    final minLat = min(lastPoint.latitude, newPoint.latitude);
    final maxLat = max(lastPoint.latitude, newPoint.latitude);
    final minLong = min(lastPoint.longitude, newPoint.longitude);
    final maxLong = max(lastPoint.longitude, newPoint.longitude);
    var controller = await mapController.future;
    return controller.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLong),
          northeast: LatLng(maxLat, maxLong),
        ),
        48.0,
      ),
    );
  }

  Future<void> onMapCreated(GoogleMapController controller) async {
    mapController.complete(controller);
    if (widget.branchService.selectedBranch == null) {
      //_locationChanged();
      _branchChanged();
    } else {
      _configurePanelController();
    }
  }

  void _addMyMarker(){
    if (widget.branchService.changeLocation.value != null) {
      _markers.removeWhere((marker) => marker.mapsId.value == 'my_location');
      _markers.add(
          Marker(
              markerId: MarkerId("my_location"),
              position: widget.branchService.changeLocation.value,
              icon: myMarkerIcon
          ));
    }
  }

  @override
  bool get wantKeepAlive => true;
}
