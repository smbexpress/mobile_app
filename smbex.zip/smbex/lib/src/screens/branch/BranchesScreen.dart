import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:implicitly_animated_reorderable_list_2/implicitly_animated_reorderable_list_2.dart';
import 'package:implicitly_animated_reorderable_list_2/transitions.dart';
import 'package:material_floating_search_bar/material_floating_search_bar.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/models/branch.dart';
import 'package:smbex_app/src/theme/light_color.dart';

import '../../../i18n/i18n.dart';
import '../../app_state.dart';
import '../../theme/text_styles.dart';
import '../../theme/theme.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
import 'BranchMapView.dart';
import 'branch_provider.dart';

class BranchScreen extends StatefulWidget {

  BranchScreen({Key key} ): super(key: key);

  @override
  _BranchScreenState createState() => _BranchScreenState();
}

class _BranchScreenState extends RefreshStateOnPopMixin<BranchScreen>{

  PageController pageController = PageController(initialPage: 0);
  Color leftColor = LightColor.black;
  Color rightColor = LightColor.white;
  BranchProvider branchService;
  int _currentPage = 0;
  ScrollController _listScrollController ;
  FloatingSearchBarController _floatingSearchBarController;
  @override
  void initState() {
    super.initState();
    _floatingSearchBarController = FloatingSearchBarController();
    branchService = context.read<BranchProvider>();
    branchService.setCurrentLocation();
    branchService.branches();
    branchService.addListener(_repaint);
    //initSystemUiOverlay(AppTheme.blueOverlayStyle);
  }

  @override
  void dispose() {
    _floatingSearchBarController?.dispose();

    pageController.dispose();
    branchService.removeListener(_repaint);

    super.dispose();
  }

  void _repaint(){
    setState((){});
  }

  void _branchChanged(Branch branch){
    branchService.selectedBranch = branch;
    _changeToPage(1);
  }

  void _changeToPage(int index){
    if (index == 1) {
      pageController.animateToPage(index,
          duration: const Duration(milliseconds: 400),
          curve: Curves.decelerate)
      .then((value) => _floatingSearchBarController.show());
    }
    else {
      pageController.animateToPage(index,
          duration: const Duration(milliseconds: 500),
          curve: Curves.decelerate);
    }
  }


  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    print("Screen size: ${mq.size}");
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    final branches = branchService.listBranchState.value??[];
    return WillPopScope(
      onWillPop: () async{
        if (_currentPage == 1){
          _changeToPage(0);
          return false;
        }
        if (_floatingSearchBarController.isOpen){
          _floatingSearchBarController.close();
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
            children: [
              Positioned(
                  top: 0,
                  height: mq.padding.top,
                  left: 0,
                  right: 0,
                  child: AnnotatedRegion<SystemUiOverlayStyle>(
                    value: _currentPage == 0
                        ? AppTheme.whiteOverlayStyle
                        : AppTheme.transOverlayStyle.copyWith(
                        statusBarIconBrightness: Brightness.dark
                    ),
                    child: Container(
                        color: _currentPage == 0
                            ? Colors.white
                            : Colors.transparent
                    ),
                  )
              ),
              Positioned(
                  top: 0,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: FloatingSearchBar(
                      controller: _floatingSearchBarController,
                      hint: tr.search,
                      //isScrollControlled: true,
                      //margins: EdgeInsets.only(top: mq.padding.top),
                      //insets: EdgeInsets.only(top: mq.padding.top),
                      builder: (context, _) {
                        return ValueListenableBuilder<List<Branch>>(
                            valueListenable: branchService.searchList,
                            builder: (context, branches, _) => buildExpandableBody()
                        );
                      },
                      backgroundColor: theme.cardColor,
                      //elevation: 8.0,
                      //border: BorderSide(color: Theme.of(context).hintColor),
                      //hasSafeArea: false,
                      //padding: EdgeInsets.only(left: 12, right: 16, top: 0.0),
                      //shadowColor: Theme.of(context).shadowColor,
                      transitionDuration: const Duration(milliseconds: 400),
                      transitionCurve: Curves.easeInOutCubic,
                      debounceDelay: const Duration(milliseconds: 400),
                      physics: const BouncingScrollPhysics(),
                      axisAlignment: -1.0,
                      openAxisAlignment: 0.0,
                      scrollPadding: EdgeInsets.zero,
                      transition: SlideFadeFloatingSearchBarTransition(spacing: 16),
                      automaticallyImplyBackButton: false,
                      onQueryChanged: (text) => branchService.searchBranch(text),
                      closeOnBackdropTap: true,
                      clearQueryOnClose: true,
                      overlayStyle: AppTheme.whiteOverlayStyle,
                      leadingActions: [
                        FloatingSearchBarAction.icon(
                            icon: Icon(Icons.arrow_back, size: 24),
                            onTap: (){
                              if (_currentPage == 0){
                                Navigator.pop(context);
                              } else {
                                _changeToPage(0);
                              }
                            }
                        )
                      ],
                      actions: [

                        FloatingSearchBarAction.searchToClear(showIfClosed: true,),
                        FloatingSearchBarAction.icon(
                            showIfClosed: true,
                            showIfOpened: false,
                            icon:  _currentPage == 0
                                ? Icons.map
                                : Icons.list,
                            onTap: () {
                              _changeToPage(
                                _currentPage == 0 ? 1 : 0,
                              );

                            }
                        )
                      ],
                      body:LoadingWidget(
                        isLoading: branchService.isLoading,
                        error: branchService.listBranchState.error,
                        onRetry: ()=> branchService.branches(),
                        child: PageView(
                          controller: pageController,
                          scrollDirection: Axis.vertical,
                          pageSnapping: false,
                          physics: const NeverScrollableScrollPhysics(),
                          children: [

                            SafeArea(
                                child: FloatingSearchBarScrollNotifier(
                                  child: Material(
                                      color: Theme
                                          .of(context)
                                          .scaffoldBackgroundColor,
                                      child:Container(
                                        //padding: EdgeInsets.only(top: 20),

                                          child: ListView.separated(
                                              itemBuilder: (context, index) =>
                                              index == 0
                                                  ? SizedBox(height: 50,)
                                                  : ListTile(
                                                leading: Padding(padding: EdgeInsets
                                                    .symmetric(horizontal: 10),
                                                    child: Icon(Icons.location_on)),
                                                title: Text(branches[index - 1].name),
                                                subtitle: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Text(branches[index - 1].address ??
                                                        '',
                                                        maxLines: 2,
                                                        overflow: TextOverflow.ellipsis,
                                                        style: TextStyles.bodySm
                                                    ),
                                                    SizedBox(height: 6,),
                                                    Align(
                                                      alignment: AlignmentDirectional.bottomEnd,
                                                      child: Text(
                                                        branches[index - 1].distanceFormat ??
                                                            '',
                                                        style: textTheme.labelMedium,
                                                        textAlign: TextAlign.end,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                onTap: () {
                                                  _branchChanged(branches[index - 1]);
                                                },
                                              ),
                                              separatorBuilder: (_, __) => Divider(),
                                              itemCount: (branches?.length ?? 0) + 1
                                          )
                                      )
                                  ),
                                )
                            ),
                            BranchMapView(
                              branchService: branchService,
                            )
                          ],
                          onPageChanged: (int i) {
                            _currentPage = i;
                            setState((){});
                          },
                        ),
                      )
                    //isScrollControlled: true,

                  )
              ),

            ]
        ),

      )
    );
  }


  Widget buildExpandableBody() {
    final history = branchService.filter == null
        || branchService.filter.isEmpty;

    final allItems = history
        ? branchService.listBranchState.value??[]
        : branchService.searchedBranchList??[];

    final items = history
        ? allItems.sublist(0, min(4, allItems.length))
        : allItems;
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        clipBehavior: Clip.antiAlias,
        child: ImplicitlyAnimatedList<Branch>(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          items: items,
          insertDuration: const Duration(milliseconds: 700),
          itemBuilder: (context, animation, item, i) {
            return SizeFadeTransition(
              animation: animation,
              child: buildItem(context, items, item, textTheme),
            );
          },
          updateItemBuilder: (context, animation, item) {
            return FadeTransition(
              opacity: animation,
              child: buildItem(context, items, item, textTheme),
            );
          },
          areItemsTheSame: (a, b) => a == b,
        ),
      ),
    );
  }

  Widget buildItem(BuildContext context, List<Branch> items, Branch place, TextTheme textTheme) {
    final history = branchService.filter == null
        || branchService.filter.isEmpty;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        InkWell(
          onTap: () {
            FloatingSearchBar.of(context)?.close();
            Future.delayed(
              const Duration(milliseconds: 500),
                  (){
                branchService.searchBranch(null);
                _branchChanged(place);
              }
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                SizedBox(
                  width: 36,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 500),
                    child: history
                        ? const Icon(Icons.history, key: Key('history'))
                        : const Icon(Icons.place, key: Key('place')),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        place.name,
                        style: textTheme.subtitle1,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        place.address??'',
                        style: textTheme.bodyText2?.copyWith(color: Colors.grey.shade600),
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                      ),
                      /*
                      const SizedBox(height: 2),
                      Align(
                        alignment: AlignmentDirectional.bottomEnd,
                        child: Text(
                          place.distanceFormat??'',
                          style: textTheme.labelMedium,
                          textAlign: TextAlign.end,
                        ),
                      )*/
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (items.isNotEmpty && place != items.last)
          const Divider(height: .5),
      ],
    );
  }

  Widget _buildMenuBar(BuildContext context) {

    return Container(
      width: 300.0,
      height: 44.0,
      decoration: const BoxDecoration(
        color: LightColor.accent,
        borderRadius: BorderRadius.all(Radius.circular(25.0)),
      ),
      child: CustomPaint(
        painter: BubbleIndicatorPainter(
            pageController: pageController,
            dy: 22,
            dxEntry:
            22,
            radius: 17,
            isRtl: Directionality.of(context) == TextDirection.rtl
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Expanded(
              child: TextButton(
                style: ButtonStyle(
                  overlayColor: MaterialStateProperty.all(Colors.transparent),
                ),

                onPressed: () => _changeToPage(0),
                child: Text(
                  'List View',
                  style: TextStyle(
                      color: leftColor,
                      fontSize: 16.0,
                      fontFamily: 'WorkSansSemiBold'),
                ),
              ),
            ),
            //Container(height: 33.0, width: 1.0, color: Colors.white),
            Expanded(
              child: TextButton(
                style: ButtonStyle(
                  overlayColor: MaterialStateProperty.all(Colors.transparent),
                ),
                onPressed: () => _changeToPage(1),
                child: Text(
                  'Map View',
                  style: TextStyle(
                      color: rightColor,
                      fontSize: 16.0,
                      fontFamily: 'WorkSansSemiBold'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BubbleIndicatorPainter extends CustomPainter {
  BubbleIndicatorPainter(
      {this.dxTarget = 125.0,
        this.dxEntry = 25.0,
        this.radius = 21.0,
        this.dy = 25.0,
        this.pageController,
        this.isRtl
      })
      : super(repaint: pageController) {
    painter = Paint()
      ..color = LightColor.white
      ..style = PaintingStyle.fill;
  }

  Paint painter;
  final double dxTarget;
  final double dxEntry;
  final double radius;
  final double dy;
  final bool isRtl;
  final PageController pageController;

  @override
  void paint(Canvas canvas, Size size) {
    final ScrollPosition pos = pageController.position;
    final double fullExtent =
        pos.maxScrollExtent - pos.minScrollExtent + pos.viewportDimension;

    final double pageOffset = pos.extentBefore / fullExtent;

    final bool left2right = dxEntry < dxTarget;
    final Offset entry = Offset(left2right ? dxEntry : dxTarget, dy);
    final Offset target = Offset(left2right ? dxTarget : dxEntry, dy);

    final Path path = Path();
    path.addArc(
        Rect.fromCircle(center: entry, radius: radius), 0.5 * pi, 1 * pi);
    path.addRect(Rect.fromLTRB(entry.dx, dy - radius, target.dx, dy + radius));
    path.addArc(
        Rect.fromCircle(center: target, radius: radius), 1.5 * pi, 1 * pi);

    canvas.translate(size.width * pageOffset, 0.0);
    canvas.drawShadow(path, LightColor.shadow, 3.0, true);
    canvas.drawPath(path, painter);
  }

  @override
  bool shouldRepaint(BubbleIndicatorPainter oldDelegate) => true;
}