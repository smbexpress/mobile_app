import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/widgets/CommonWidget.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../controllers/account_controller.dart';
import '../theme/theme.dart';
import '../widgets/picker/country/country_code_picker.dart';

class SignInWidget extends StatefulWidget {
  bool register;
  SignInWidget({
    Key key,
    routeArgument,
  }) {
    if (routeArgument != null) {
      if (routeArgument is RouteArgument) {
        register = int.parse(routeArgument.id) == 1;
      }
    } else {
      register = false;
    }
  }

  @override
  _SignInWidgetState createState() => _SignInWidgetState();
}

class _SignInWidgetState extends StateMVC<SignInWidget> {
  AccountController _con;
  String code = '966';
  Account account;
  List<Map> countries = [];
  _SignInWidgetState() : super(AccountController()) {
    _con = controller;
  }

  @override
  void initState() {
    account = _con.account;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final action = account.action;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        key: _con.scaffoldKey,
        //backgroundColor: Color(0xff0451A1),
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: AppTheme.whiteOverlayStyle,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 20 + MediaQuery.of(context).padding.top,
                ),
                SizedBox(
                  height: 180,
                  child: Center(
                    child: Image.asset(
                      'assets/img/logo2.png',
                      //color: Colors.white,
                      fit: BoxFit.fitWidth,
                      width: 200,
                    ),
                  ),
                ),
                decorateStack2(
                    context,
                    Form(
                      key: _con.loginFormKey,
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 20),
                          Text(
                              account.action == Account.ACT_LOGIN_PASSWORD
                                  ? S.of(context).password
                                  : S.of(context).yourPhoneNumber,
                              style: Theme.of(context)
                                  .textTheme
                                  .displaySmall
                                  .merge(TextStyle(
                                    fontSize: 20,
                                  ))),
                          SizedBox(height: 20),
                          if (account.action != Account.ACT_LOGIN_PASSWORD)
                            ...createPhoneWidgets(context),
                          if (account.action == Account.ACT_LOGIN_PASSWORD)
                            ...createPasswordWidgets(context),
                          SizedBox(height: 30),
                          ElevatedButton(
                            //padding: EdgeInsets.symmetric(vertical: 12, horizontal: 60),
                            onPressed: () {
                              print("send confirm ${account.action}");
                              if (account.action == Account.ACT_FORGET
                                  || account.action == Account.ACT_FORGET_PASSWORD) {
                                _con.forget();
                              } else if (account.action == Account.ACT_LOGIN_PASSWORD) {
                                _con.login();
                              } else if (account.action == Account.ACT_NORMAL) {
                                _con.confirm();
                              } else {
                                _con.test();
                              }
                            },
                            child: Text(
                              account.action == Account.ACT_LOGIN_PASSWORD
                                  ? S.of(context).login
                                  : S.of(context).verify_phone,
                            ),
                            //color: Theme.of(context).accentColor,
                            //shape: StadiumBorder(),
                          ),
                          SizedBox(height: 10),
                          TextButton(
                            onPressed: () {
                              _con.updateAction(Account.ACT_NORMAL);
                              Navigator.of(context).pushNamedAndRemoveUntil(
                                  '/Home', (Route<dynamic> route) => false);
                              //Navigator.of(context).pushReplacementNamed('/Home', arguments: 2);
                            },
                            style: TextButton.styleFrom(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 30, vertical: 14),
                                foregroundColor: Theme.of(context).hintColor,
                                shape: StadiumBorder()),
                            child: Text(S.of(context).skip),
                          ),
                          SizedBox(height: 5),
                        ],
                      ),
                    ),
                    vertical: 10,
                    top: 0),
                Column(
                  children: <Widget>[
                    if (account.action == Account.ACT_LOGIN_PASSWORD)
                      TextButton(
                        onPressed: () {
                          _con.updateAction(Account.ACT_FORGET_PASSWORD);
                          setState(() { });
                          //Navigator.of(context).pushNamed('/Login');
                        },
                        child: RichText(
                          text: TextSpan(
                            style: Theme.of(context).textTheme.titleMedium.merge(
                                  TextStyle(
                                      fontSize: 16,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.w600),
                                ),
                            children: [
                              TextSpan(
                                  text: tr.i_forgot_password),
                            ],
                          ),
                        ),
                      ),
                    /*
                    if (account.action != Account.ACT_REGISTER)
                      TextButton(
                        onPressed: () {
                          _con.updateAction(Account.ACT_REGISTER);
                          setState(() {});
                          //Navigator.of(context).pushNamed('/SignUp');
                        },
                        child: RichText(
                          text: TextSpan(
                            style: Theme.of(context).textTheme.titleMedium.merge(
                                  TextStyle(
                                      fontSize: 16,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.w600),
                                ),
                            children: [
                              TextSpan(
                                  text: S.of(context).i_dont_have_an_account),
                            ],
                          ),
                        ),
                      ),

                     */
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> createPhoneWidgets(BuildContext context) {
    if (countries.isEmpty) {
      Api().company.countries.forEach((country) {
        countries.add({
          'name': country.name,
          'code': country.code,
          'dial_code': country.dial
        });
      });
    }

    return [
      Directionality(
        textDirection: TextDirection.ltr,
        child: textField(context,
            hintText: '5xxxxxxxx',
            keyboardType: TextInputType.phone,
            onSaved: (input) {
              if (input.startsWith("0")) {
                input = input.substring(1);
              }
              account.mobile = code + input;
              print("Change mobile number: ${account.mobile}");
            },
            validator: (input) =>
                input.length < 6 ? S.of(context).should_be_a_valid_phone : null,
            prefixIcon: Container(
                width: 123,
                padding: EdgeInsets.only(left: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CountryCodePicker(
                        initialSelection: code,
                        textStyle: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.w500,
                            color: Theme.of(context).textTheme.bodyText1.color),
                        countries: countries,
                        onChanged: (countryCode) {
                          setState(() {
                            code = countryCode.rawDialCode;
                          });
                        }),
                    Container(
                      height: 30.0,
                      width: 1.0,
                      color: Theme.of(context).dividerColor,
                      margin: const EdgeInsets.only(left: 5.0, right: 5.0),
                    ),
                  ],
                ))),
      ),
    ];
  }

  List<Widget> createPasswordWidgets(BuildContext context) {
    return [
      textField(
        context,
        onSaved: (input) => account.password = input,
        validator: (input) => input.length < 3
            ? S.of(context).should_be_more_than_3_characters
            : null,
        obscureText: _con.hidePassword,
        hintText: S.of(context).password,
        icon: Icons.lock,
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _con.hidePassword = !_con.hidePassword;
            });
          },
          color: Theme.of(context).primaryColorDark.withOpacity(0.4),
          icon:
              Icon(_con.hidePassword ? Icons.visibility_off : Icons.visibility),
        ),
      ),
    ];
  }
}
