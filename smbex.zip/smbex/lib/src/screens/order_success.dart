import 'package:flutter/material.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../helpers/helper.dart';
import '../models/cart.dart';
import '../models/route_argument.dart';
import '../widgets/CircularLoadingWidget.dart';

class OrderSuccessWidget extends StatefulWidget {
  final RouteArgument args;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  OrderSuccessWidget({Key key, this.args}) : super(key: key);

  @override
  _OrderSuccessWidgetState createState() => _OrderSuccessWidgetState();
}

class _OrderSuccessWidgetState extends State<OrderSuccessWidget> {
  Cart cart;
  Transaction tx;
  
  @override
  void initState() {
    // route param contains the payment method
    if (widget.args.param is Map){
      cart = widget.args.param['cart'] as Cart;
      tx = widget.args.param['tx'] as Transaction;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: widget.scaffoldKey,
        appBar: appBar(context, titleText: S.of(context).confirmation),
        body: cart== null
            ? CircularLoadingWidget(height: 500)
            : Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  Container(
                    alignment: AlignmentDirectional.center,
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 50),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Container(
                              width: 150,
                              height: 150,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(begin: Alignment.bottomLeft, end: Alignment.topRight, colors: [
                                    Colors.green.withOpacity(1),
                                    Colors.green.withOpacity(0.2),
                                  ])
                              ),
                              child: /*_con.loading
                                  ? Padding(
                                      padding: EdgeInsets.all(55),
                                      child: CircularProgressIndicator(
                                        valueColor: new AlwaysStoppedAnimation<Color>(Theme.of(context).scaffoldBackgroundColor),
                                      ),
                                    )
                                  : */Icon(
                                      Icons.check,
                                      color: Theme.of(context).scaffoldBackgroundColor,
                                      size: 90,
                                    ),
                            ),
                            Positioned(
                              right: -30,
                              bottom: -50,
                              child: Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(150),
                                ),
                              ),
                            ),
                            Positioned(
                              left: -20,
                              top: -50,
                              child: Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(150),
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 15),
                        Opacity(
                          opacity: 0.4,
                          child: Text(
                            S.of(context).your_order_has_been_successfully_submitted,
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headline4.merge(TextStyle(fontWeight: FontWeight.w300)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Container(
                      height: 265,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                      decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor,
                          borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20)),
                          boxShadow: [BoxShadow(color: Theme.of(context).focusColor.withOpacity(0.15), offset: Offset(0, -2), blurRadius: 5.0)]),
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width - 40,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.max,
                          children: <Widget>[
                            if (cart.tax != null && cart.tax > 0) Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                    S.of(context).subtotal,
                                    style: Theme.of(context).textTheme.bodyText2,
                                  ),
                                ),
                                Helper.getPrice(cart.subtotal, context, currency: cart.currency,
                                    style: Theme.of(context).textTheme.subtitle2)
                              ],
                            ),
                            SizedBox(height: 3),

                            if (cart.tax != null && cart.tax > 0)SizedBox(height: 3),
                            if (cart.tax != null && cart.tax > 0)Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                    "",//"${S.of(context).tax} (${carts[0].product.store.defaultTax}%)",
                                    style: Theme.of(context).textTheme.bodyText2,
                                  ),
                                ),
                                Helper.getPrice(cart.tax, context, currency: cart.currency, style: Theme.of(context).textTheme.subtitle2)
                              ],
                            ),
                            Divider(height: 30),
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                    S.of(context).total,
                                    style: Theme.of(context).textTheme.subtitle1,
                                  ),
                                ),
                                Helper.getPrice(cart.total, context, currency: cart.currency, style: Theme.of(context).textTheme.subtitle1)
                              ],
                            ),
                            SizedBox(height: 20),
                            SizedBox(
                              width: MediaQuery.of(context).size.width - 40,
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.of(context).pushNamed('/Shipments');
                                },
                                child: Text(
                                  S.of(context).shipment_list,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(color: Theme.of(context).primaryColor),
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ));
  }
}
