import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/controllers/address_controller.dart';
import 'package:smbex_app/src/models/address.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/widgets/picker/place_picker/place_picker.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../controllers/account_controller.dart';
import '../helpers/helper.dart';
import '../models/account.dart';
import '../repository/app_repository.dart' as appRepo;
import '../repository/settings_repository.dart';
import '../widgets/CommonWidget.dart';

class SignUpWidget extends StatefulWidget {
  int route;
  SignUpWidget({
    Key key,
    routeArgument,
  }):
    route = routeArgument is RouteArgument
           ? int.parse(routeArgument.id)
           : 0,
    super(key: key);

  @override
  _SignUpWidgetState createState() => _SignUpWidgetState();
}

class _SignUpWidgetState extends StateMVC<SignUpWidget> {
  AccountController _con;
  int action;
  Country _country;
  City _city;
  bool _acceptTerm = false;
  bool _showCountries = false;
  _SignUpWidgetState() : super(AccountController()) {
    _con = controller;
  }

  @override
  void initState() {
    Account ac = _con.account;
    print("**************SignUpWidget*****************");
    Address accountAddress = ac.defaultAddress;

    _city = ac.defaultAddress?.city;
    _country = ac.defaultAddress?.country ;
    _acceptTerm = action == Account.ACT_REGISTER;
    if ((_country == null || !_country.valid) &&
        Api().company != null &&
        Api().company.countries.isNotEmpty == true){

      _country = Api().company.countries.first;
      _showCountries = Api().company.countries.length > 1;
      ac.defaultAddress?.country = _country;
    }
    action = ac.action;
    super.initState();
  }

  Widget build(BuildContext context) {
    Account ac = _con.account;
    String title = "";
    bool showName = true;
    if (action == Account.ACT_REGISTER) {
      title = t.full_name;
    } else if (action == Account.ACT_UPDATE) {
      title = t.edit_name;
    } else if (action == Account.ACT_REG_PASSWORD) {
      title = t.password;
      showName = false;
    } else if (action == Account.ACT_UPDATE_PASSWORD) {
      title = t.change_password;
      showName = false;
    }

    bool showNext = (showName &&
        (ac.defaultAddress?.isUnknown() == false ||
            (_country != null && _city != null))) ||
        _acceptTerm;

    return Scaffold(
      key: _con.scaffoldKey,
      appBar: appBar(context, titleText: title),
      body: SingleChildScrollView(child: stepOne(context, showName, title)),
      bottomNavigationBar: Container(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 15,
            bottom: 15 + MediaQuery.of(context).padding.bottom),
        child: ElevatedButton(
          child: Text(tr.buttons.next),
          onPressed: showNext
              ? () {
            print("Signup acction ${action}");
            if (showName) {
              if (_con.loginFormKey?.currentState?.validate()) {
                if (ac.defaultAddress == null) {
                  ac.defaultAddress = Address.Pickup();
                }
                if (_city != null) {
                  ac.defaultAddress.city = _city;
                }
                if (_country != null) {
                  ac.defaultAddress.country = _country;
                }
              } else {
                return;
              }
            }

            if (action == Account.ACT_REGISTER ||
                action == Account.ACT_REG_PASSWORD) {
              ac.action = action;
              _con.complete();
            }
          }
              : null,
        ),
      ),
    );
  }

  Widget stepOne(BuildContext context, bool showName, String title) {
    Account ac = _con.account;
    return Column(
      children: <Widget>[
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.0),
          child: Form(
            key: _con.loginFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const SizedBox(height: 25),
                Text(title),
                const SizedBox(height: 20),
                if (showName) ...[
                  textField(context,
                      onSaved: (input) => ac.name = input,
                      validator: (input) => input.length < 3
                          ? S.of(context).should_be_more_than_3_letters
                          : null,
                      hintText: S.of(context).full_name,
                      icon: Icons.person),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Text('${tr.default_address}: '),
                      SizedBox(width: 10,),
                      TextButton(
                          onPressed: () async {
                            final address = await showPlacePicker();
                            if (address != null) {
                              _city = address.city;
                              _country = address.country;

                              setState(() {});
                            }
                          },
                          child: Text(tr.selectOnMap)
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Divider(),
                  if (_showCountries)
                    const SizedBox(height: 20),
                  if (_showCountries)
                    createSearchDropdown<Country>(
                        context, tr.country, (c) => c.name ?? '',
                        key: ValueKey(_country),
                        selected: _country,
                        items: Api().company.countries,
                        popupTitle: tr.select_country,
                        onChanged: (Country c) {
                          if (_country != c)
                            setState(() {
                              _country = c;
                              _city = null;
                            });
                        },
                        validator: (city) =>
                        city != null ? null : tr.form.requiredErrorText),
                  const SizedBox(height: 30),
                  createSearchDropdown<City>(
                      context, tr.city, (c) => c.name ?? '',
                      key: ValueKey(_city),
                      selected: _city,
                      online: true,
                      enabled: _country != null,
                      endpoint: 'cities/search',
                      args: {'country': _country?.code},
                      popupTitle: tr.select_city,
                      convert: (c) {
                        print("SelectPickupCity::convert: $c");
                        return City.fromJson(c);
                      },
                      onChanged: (City c) async {
                        print("SelectPickupCity:: to city: ${c.id}:${c.name}");
                        if (_city != c)
                          setState(() {
                            _city = c;
                          });
                      },
                      validator: (city) =>
                      city != null ? null : tr.form.requiredErrorText),
                ],
                if (!showName) ...[
                  textField(
                    context,
                    onSaved: (input) => ac.password = input,
                    validator: (input) => input.length < 3
                        ? S.of(context).should_be_more_than_3_characters
                        : null,
                    obscureText: _con.hidePassword,
                    hintText: S.of(context).password,
                    icon: Icons.lock,
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          _con.hidePassword = !_con.hidePassword;
                        });
                      },
                      color:
                      Theme.of(context).primaryColorDark.withOpacity(0.4),
                      icon: Icon(_con.hidePassword
                          ? Icons.visibility_off
                          : Icons.visibility),
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                  Container(
                      alignment: AlignmentDirectional.topStart,
                      child: CheckboxListTile(
                        value: _acceptTerm,
                        onChanged: (value) {
                          _acceptTerm = value;
                          setState(() {});
                        },
                        title: Text(tr.acceptTerm),
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.zero,
                      )),
                  Container(
                      alignment: AlignmentDirectional.topStart,
                      child: Container(
                        child: TextButton(
                            onPressed: () {
                              Helper.launchWebsite('term-and-conditions');
                            },
                            child: Text(tr.termAndConditions)),
                      ))
                ],
                SizedBox(height: 40),
              ],
            ),
          ),
        ),
        /*
          TextButton(
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/Login');
            },
            child: RichText(
              text: TextSpan(
                style: Theme.of(context).textTheme.subtitle1.merge(
                  TextStyle(color: Theme.of(context).primaryColor,fontSize: 16,fontWeight: FontWeight.w600),
                ),
                children: [
                  TextSpan(text: S.of(context).i_have_account_back_to_login),
                ],
              ),
            ),
          ),
          */
      ],
    );
  }

  Widget createStack(BuildContext context, Widget content) {
    return Stack(
      children: <Widget>[
        decorateStack1(context),
        decorateStack2(context, content)
      ],
    );
  }

  Future<Address> _acceptLocation(LocationResult result) async {
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    try {
      if (result != null) {


        Country country = Country.of(result.country.shortName, true);
        if (country == null || !country.valid){
          showErrorDialog(context, error: tr.addressNotSupported, fullWidth: true, warning: true);
          return null;
        }

        ResultItem<City> cityResult = await appRepo.cityReverse(
            result.latLng.latitude,
            result.latLng.longitude
        );

        if (cityResult.hasError) {
          showErrorDialog(context, error: cityResult.error, fullWidth: true);
          return null;
        }

        City city = cityResult.item;
        if (city == null || city.id == 0){
          //_addressNotSupported();
          showErrorDialog(context, error: tr.addressNotSupported, fullWidth: true, warning: true);
          return null;
        }

        final address = _con.account.defaultAddress;

        address.lat = result.latLng.latitude;
        address.lng = result.latLng.longitude;
        address.country = Country.of(city.country, false);
        address.city = city;
        address.lat = result.latLng.latitude;
        address.lng = result.latLng.longitude;
        address.street = result.formattedAddress;
        address.zip = result.postalCode;
        address.province = result.locality;
      }
      Fluttertoast.showToast(
          toastLength: Toast.LENGTH_LONG,
          msg: tr.addressNotSupported);
      return null;
    } finally{
      Helper.hideLoader(loader);
    }
  }

  Future<Address> showPlacePicker() async {
    final address = _con.account.defaultAddress;
    LatLng latLng = !address.isUnknown()
          ? LatLng(address.lat, address.lng)
          : address.city?.isUnknown() == false
          ? LatLng(address.city.lat, address.city.lng)
          : null/*LatLng(24.688331, 46.684109)*/;

    //var pos = LatLng(address?.lat ?? 0, address?.lng ?? 0);
    return Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => PlacePicker<Address>(
          settingNotifier.value.googleMapsKey,
          acceptLocation: _acceptLocation,
          displayLocation: latLng
        )));
  }

  void showRetrySnackBar(String message, Function onPress) {
    final snackBar = SnackBar(
      content: Text(message),
      action: SnackBarAction(
        label: 'Retry',
        onPressed: () {
          onPress();
        },
      ),
    );
  }
}