import 'dart:math';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart' hide Slider;
import 'package:flutter/services.dart';
import 'package:lifecycle/lifecycle.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/i18n/i18n.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/screens/home/tracking_button.dart';
import 'package:smbex_app/src/theme/extention.dart';
import '../../app_state.dart';
import '../../models/route_argument.dart';
import '../../models/slider.dart';
import '../../models/tody_tip.dart';
import '../../notification_provider.dart';
import '../../theme/light_color.dart';
import '../../theme/text_styles.dart';
import '../../theme/theme.dart';
import '../../widgets/FadeAnimation.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/carousel_indicator.dart';
import '../../widgets/refreshaple.dart';
import '../../widgets/tip_widget.dart';

class DefaultHomeScreen extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;
  DefaultHomeScreen({Key key, this.parentScaffoldKey}) : super(key: key);
  @override
  _DefaultHomeScreenState createState() => _DefaultHomeScreenState();
}

class _DefaultHomeScreenState extends State<DefaultHomeScreen>
    with Refreshaple<DefaultHomeScreen> {
  final controller = ScrollController();
  double offset = 0;
  Slider homeSlider;
  int _shipmentCount;
  int _deliveryCount;
  NotificationProvider _ntfProvider;
  Map<TodayTipType, TipWidget> _tipMap;
  bool _firstTipReceived = false;
  @override
  void initState() {
    super.initState();
    controller.addListener(onScroll);
    homeSlider = Api().company.slider ??
        Slider(
          slides: [
            Slide(
              imageUrl: 'assets/main/0.png',
            ),
            Slide(
              imageUrl: 'assets/main/1.png',
            )
          ],
          radius: 0.0,
          interval: 60,
        );

    _ntfProvider = context.read<NotificationProvider>();
    _ntfProvider.addLiveCommand(
      LiveCommand(
          key: 'homeShipmentCount',
          model: 'shipments',
          method: 'count',
          listener: _liveTrigger,
          active: false,
          args: {
            'domain': [
              [
                'status',
                'not in',
                ['c', 'd']
              ],
              ['delivery_failed', '!=', true]
            ]
          }),
    );

    _ntfProvider.addLiveCommand(
      LiveCommand(
          key: 'homeDeliveryCount',
          model: 'deliveries',
          method: 'count',
          listener: _liveTrigger,
          active: false),
    );
    _ntfProvider?.addMessageListener(_onRemoteMessage);
    _readStart();
  }

  @override
  void dispose() {
    _ntfProvider?.removeLiveCommand('homeShipmentCount');
    _ntfProvider?.removeLiveCommand('homeDeliveryCount');
    _ntfProvider?.removeLiveCommand('homeTips');
    _ntfProvider?.removeMessageListener(_onRemoteMessage);
    controller.dispose();

    super.dispose();
  }

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  void _readStart() async {
    final pref = await SharedPreferences.getInstance();
    _shipmentCount = pref.getInt('homeShipmentCount');
    _deliveryCount = pref.getInt('homeDeliveryCount');
    final homeTipsLast = pref.getInt('homeTipsLast');

    _ntfProvider.addLiveCommand(
      LiveCommand(
          key: 'homeTips',
          model: 'tips',
          method: 'list',
          last: homeTipsLast != null
              ? DateTime.fromMillisecondsSinceEpoch(homeTipsLast * 1000)
              : null,
          listener: _liveTrigger),
    );
    _tipMap = await TipWidget.fromStore('homeTipList');

    if (_shipmentCount != null || _deliveryCount != null || _tipMap != null) {
      setState(() {});
    }

    Future.delayed(Duration(seconds: 3), _checkUpadater);
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    Widget firstTip = _tipMap?.containsKey(TodayTipType.tip) == true
        ? _tipMap[TodayTipType.tip]
        : null;
    Widget secondTip = _tipMap?.containsKey(TodayTipType.fixedTip) == true
        ? _tipMap[TodayTipType.fixedTip]
        : null;
    Widget popTip = _tipMap?.containsKey(TodayTipType.popup) == true
        ? _tipMap[TodayTipType.popup]
        : null;
    Widget statusTip = _tipMap != null ? _tipMap[TodayTipType.status] : null;
    Widget fixedStatusTip =
        _tipMap != null ? _tipMap[TodayTipType.fixedStatus] : null;

    return LifecycleWrapper(
      onLifecycleEvent: (event) {
        if (event == LifecycleEvent.active) {
          if (currentAccount.value.valid) {
            _ntfProvider.setCommandState('homeShipmentCount', true);
            _ntfProvider.setCommandState('homeDeliveryCount', true);
          }
          _ntfProvider.setCommandState('homeTips', true);
          //_ntfProvider.startPolling(false);
          _ntfProvider.poll();
        } else if (event == LifecycleEvent.inactive) {
          _ntfProvider.setCommandState('homeShipmentCount', false);
          _ntfProvider.setCommandState('homeDeliveryCount', false);
          _ntfProvider.setCommandState('homeTips', false);
        }
      },
      child: Material(
          color: th.scaffoldBackgroundColor,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  controller: controller,
                  child: Column(
                    children: <Widget>[
                      HeaderWidget(
                        image: "assets/img/shipment2.png",
                        textTop: tr.home_init_line1,
                        textBottom: tr.home_init_line2,
                        offset: offset,
                        parentScaffoldKey: widget.parentScaffoldKey,
                      ),
                      const SizedBox(
                        height: 20.0,
                      ),
                      if (firstTip != null) firstTip,
                      if (firstTip != null)
                        const SizedBox(
                          height: 16.0,
                        ),
                      if (secondTip != null) secondTip,
                      if (secondTip != null)
                        const SizedBox(
                          height: 16.0,
                        ),
                      Padding(
                        padding:
                            homeSlider.radius != null && homeSlider.radius > 0
                                ? const EdgeInsets.symmetric(horizontal: 15.0)
                                : EdgeInsets.zero,
                        child: CarouselWidget(slider: homeSlider),
                      ),
                      SizedBox(height: currentAccount.value.valid ? 10 : 20),
                      Material(
                          color: th.cardColor,
                          child: Column(
                            children: [
                              if (currentAccount.value.valid) ...[
                                ListTile(
                                  tileColor: th.cardColor,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 8.0, vertical: 2),
                                  leading: Container(
                                      height: 55,
                                      width: 55,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: LightColor.red.withOpacity(.2),
                                      ),
                                      child: RotatedBox(
                                        quarterTurns: 2,
                                        child: Icon(
                                          Icons.outbond_outlined,
                                          size: 32,
                                          color: LightColor.red,
                                        ),
                                      )),
                                  title: Text(tr.incoming),
                                  subtitle: Text(tr.incomingShipments),
                                  trailing: Material(
                                    //alignment: Alignment.center,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(12.0)),
                                    color: LightColor.red,
                                    child: Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 16),
                                      child: Text(
                                        _deliveryCount?.toString() ?? '',
                                        style: TextStyles.title.white,
                                      ),
                                    ),
                                  ),
                                  onTap: () {
                                    Navigator.of(context).pushNamed(
                                        '/Shipments',
                                        arguments: RouteArgument(id: '1'));
                                  },
                                ),
                                Divider(
                                  height: 1.5,
                                ),
                                ListTile(
                                  tileColor: th.cardColor,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 8.0, vertical: 2),
                                  leading: Container(
                                    height: 55,
                                    width: 55,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: th.primaryColor.withOpacity(.2),
                                    ),
                                    child: Icon(
                                      Icons.outbond_outlined,
                                      size: 32,
                                      color: th.primaryColor,
                                    ),
                                  ),
                                  title: Text(tr.outgoing),
                                  subtitle: Text(tr.outgoingShipments),
                                  trailing: Material(
                                    //alignment: Alignment.center,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(12.0)),
                                    color: th.primaryColorDark,
                                    child: Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 16),
                                      child: Text(
                                        _shipmentCount?.toString() ?? '',
                                        style: TextStyles.title.white,
                                      ),
                                    ),
                                  ),
                                  onTap: () {
                                    Navigator.of(context)
                                        .pushNamed('/Shipments');
                                  },
                                ),
                              ],
                              if (!currentAccount.value.valid)
                                ListTile(
                                  tileColor: th.cardColor,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 8.0, vertical: 6),
                                  leading: Container(
                                    height: 55,
                                    width: 55,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: th.primaryColor.withOpacity(.2),
                                    ),
                                    child: Icon(
                                      Icons.person,
                                      size: 32,
                                      color: th.primaryColor,
                                    ),
                                  ),
                                  title: Text(tr.login),
                                  //subtitle: Text(tr.outgoingShipments),
                                  trailing: Icon(Icons.chevron_right),
                                  onTap: () {
                                    Navigator.of(context)
                                        .popAndPushNamed('/Login');
                                  },
                                ),
                              Divider(
                                height: 1.5,
                              ),
                            ],
                          )),
                      SizedBox(
                        height: 40,
                      )
                    ],
                  ),
                ),
              ),
              if (statusTip != null) statusTip,
              if (statusTip != null && fixedStatusTip != null)
                Divider(
                  height: 1,
                ),
              if (fixedStatusTip != null) fixedStatusTip,
              if (statusTip != null || fixedStatusTip != null)
                SizedBox(
                  height: 16,
                ),
              if (popTip != null) popTip,
            ],
          )),
    );
  }

  void _liveTrigger(Map<String, dynamic> data) async {
    final pref = await SharedPreferences.getInstance();
    if (data['key'] == 'homeShipmentCount') {
      _shipmentCount = data['count']?.toInt() ?? 0;
      pref.setInt('homeShipmentCount', _shipmentCount);
    } else if (data['key'] == 'homeDeliveryCount') {
      _deliveryCount = data['count']?.toInt() ?? 0;
      pref.setInt('homeDeliveryCount', _deliveryCount);
    } else if (data['key'] == 'homeTips') {
      _tipMap = await TipWidget.fromStore('homeTipList',
          data['result'] is List ? data['result'] as List : [data['result']]);
    }
    refresh();
  }

  void _onRemoteMessage(RemoteMessage message) {
    final model = message.data['model'];
    if (model == 'deliveries' || model == 'shipments') {
      _ntfProvider.poll();
    }
  }

  @override
  void refresh() {
    if (mounted) {
      setState(() {
        if (_tipMap != null && !_firstTipReceived) {
          _firstTipReceived = true;
          _checkUpadater();
        }
      });
    }
  }

  void _checkUpadater() async {
    AppState state = context.read<AppState>();
    await state.checkVersion();
  }
}

class HeaderWidget extends StatefulWidget {
  final String image;
  final String textTop;
  final String textBottom;
  final double offset;
  final GlobalKey<ScaffoldState> parentScaffoldKey;
  const HeaderWidget(
      {Key key,
      this.image,
      this.textTop,
      this.textBottom,
      this.offset,
      this.parentScaffoldKey})
      : super(key: key);

  @override
  _HeaderWidgetState createState() => _HeaderWidgetState();
}

class _HeaderWidgetState extends State<HeaderWidget>
    with SingleTickerProviderStateMixin {
  AnimationController animationController;
  Animation<double> tween1;
  void initState() {
    super.initState();
    animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    tween1 = Tween<double>(begin: 1.0, end: 0.0).animate(animationController);
  }

  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    TextDirection dir = Directionality.of(context);
    bool rtl = dir == TextDirection.rtl;
    final validAccount = currentAccount.value.valid;
    //print("Offset: ${widget.offset}");
    //TrackingButton
    return Material(
      elevation: validAccount ? 1.0 : 0.0,
      //shadowColor: Theme.of(context).shadowColor.withOpacity(.5),
      color: validAccount
          ? Colors.white
          : Theme.of(context).scaffoldBackgroundColor,
      child: Container(
          //height: 340.0 + 120.0,
          child: Column(
        children: [
          AnnotatedRegion<SystemUiOverlayStyle>(
            value: AppTheme.transOverlayStyle,
            child: ClipPath(
              clipper: ThemPageHeaderClipper(),
              child: Container(
                padding: const EdgeInsets.only(left: 10, top: 0, right: 10),
                height: 340,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      const Color(0xFF3383CD),
                      const Color(0xFF11249F),
                    ],
                  ),
                  //image: DecorationImage(
                  //  image: AssetImage("assets/img/virus.png"),
                  //),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    const SizedBox(height: 20),
                    Expanded(
                      child: Stack(
                        children: <Widget>[
                          Positioned(
                            top: widget.offset + 60.0,
                            left: -20,
                            child: Image.asset(
                              widget.image,
                              /*SvgPicture.asset(*/
                              //width: 230,
                              //fit: BoxFit.fitWidth,
                              alignment: Alignment.topLeft,
                            ),
                          ),
                          if (widget.offset < 136)
                            Positioned(
                                bottom: 40.0 + widget.offset / 2,
                                right: 10,
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 15),
                                  decoration: BoxDecoration(
                                      color: Color(0xFF2255B7).withOpacity(.5),
                                      borderRadius: BorderRadius.circular(15)),
                                  child: Text(
                                    "${widget.textTop} \n${widget.textBottom}",
                                    style: TextStyles.title.copyWith(
                                      color: Colors.white,
                                      fontSize: 19,
                                    ),
                                  ),
                                )),
                          Positioned(
                              //textDirection: dir,
                              left: 0,
                              right: 0,
                              top: widget.offset - 10,
                              child: const SafeArea(
                                  left: false,
                                  right: false,
                                  child: const TrackingButton())),

                          //Container(), // I dont know why it can't work without container
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (validAccount)
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _userInfo()),
        ],
      )),
    );
  }

  Widget _userInfo() {
    String name = currentAccount.value.name ?? '';
    if (name.split(' ').length > 2) {
      name = name.split(' ').sublist(0, 2).join(' ');
    }
    final userInfo = Container(
        //height: 120,
        child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            InkWell(
              onTap: () async {
                //await animationController.animateTo(200.0, duration: Duration.zero);
                animationController.reset();
                setState(() {});
                await Future.delayed(Duration(milliseconds: 300));
                //animationController.forward();
              },
              child: Text(
                tr.welcome,
                style: TextStyle(color: Colors.black87, fontSize: 25),
              ),
            ),
            SizedBox(
              height: 4,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  child: Icon(
                    Icons.person,
                    color: Colors.black87,
                    size: 28,
                  ),
                ),
                SizedBox(
                  width: 5,
                ),
                Expanded(
                  child: Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    //softWrap: true,
                    style: TextStyle(
                      color: Colors.black87,
                      fontSize: 19,
                    ),
                  ),
                ),
                SizedBox(
                  width: 4,
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        )),
        Material(
          color: Theme.of(context).scaffoldBackgroundColor.darken(5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          clipBehavior: Clip.hardEdge,
          child: InkWell(
            onTap: () {
              Navigator.of(context).pushNamed('/Shipments');
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Icon(
                    Icons.sort,
                    color: Theme.of(context).primaryColorDark,
                  ),
                  const SizedBox(
                    width: 4,
                  ),
                  Text(
                    "Browse",
                    style: TextStyle(fontSize: 11),
                  ),
                  const SizedBox(
                    width: 4,
                  ),
                  Icon(
                    Icons.expand_circle_down_rounded,
                    color: Theme.of(context).primaryColorDark,
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    )
        //color: Colors.red,
        );
    animationController.forward();
    return Material(
      clipBehavior: Clip.hardEdge,
      child: AnimatedBuilder(
          animation: animationController,
          //child: userInfo,
          builder: (context, child) => Transform.translate(
                offset: Offset(0.0, 200 * tween1.value),
                child: userInfo,
              )),
    );
    return FadeAnimation(1, userInfo, 200.0);
  }
}
