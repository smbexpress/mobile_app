import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/helpers/navigation.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/screens/profile_field.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/FadeAnimation.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../notification_provider.dart';
import '../repository/account_repository.dart';
import '../widgets/PermissionDeniedWidget.dart';
import '../widgets/ProfileAvatarWidget.dart';
import '../widgets/loading_widget.dart';
import 'account/delete_account.dart';


class ProfileScreen extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;

  ProfileScreen({Key key, this.parentScaffoldKey}) : super(key: key);
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  NotificationProvider _provider;
  bool _isRefresh = false;
  double _delay = 1.5;
  @override
  void initState() {
    super.initState();
    _provider = context.read<NotificationProvider>();
    _load(true);
  }

  @override
  void dispose() {
    _provider.removeMessageListener(_onRemoteMessage);
    _provider.removeLiveCommand('myAccount');
    super.dispose();

  }

  void _liveTrigger(dynamic item){
    _provider.updateCommandWith('myAccount', last: DateTime.now());
    _load();
  }

  void _onRemoteMessage(RemoteMessage message) {
    final model = message.data['model'];
    if (model == 'account'){
      _liveTrigger(true);
    }
  }

  void _load([bool silent=false]) async{
    if (_isRefresh) return;
    _isRefresh = true;
    if (!silent){
      setState(() {});
    }
    disableAccountChange = true;
    try {
      await test(currentAccount.value);
    } finally {
      _isRefresh = false;
      _delay = 0.0;
      Future.delayed(Duration(seconds: 1), (){
        disableAccountChange = false;
      });
      setState(() {});

    }
    if (silent){
      _provider
          .addLiveCommand(
        LiveCommand(
            key: 'myAccount',
            model: 'account',
            method: 'changed',
            listener: _liveTrigger,
            last: DateTime.now()
        ),
      );
    }

  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).copyWith(dividerColor: Colors.transparent);

    return Scaffold(
      //backgroundColor: Theme.of(context).backgroundColor,
      appBar: appBar(
        context,
        titleText: tr.accountSettings,
        isSecondary: true
      ),
      body: !currentAccount.value.valid
          ? PermissionDeniedWidget()
          : Material (
              child: LoadingWidget(
                isLoading: _isRefresh,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(bottom: 40.0) ,
                    child: ValueListenableBuilder(
                        valueListenable: currentAccount,
                        builder: (BuildContext context, Account update, Widget child) {
                          Account account = currentAccount.value;
                          return Column(
                            children: <Widget>[
                              ProfileAvatarWidget(account: account),
                              SizedBox(height: 20,),
                              Container(
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  child: FadeAnimation(_delay,
                                      listItem(context, account.name, t.full_name,
                                          Icon(Icons.perm_contact_cal_outlined, color: LightColor.background,),
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileFieldScreen(
                                                      action: Account.ACT_UPDATE_NAME,)));
                                          },
                                          padding: 15
                                      )

                                  )
                              ),
                              SizedBox(height: 10,),
                              Container(
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  child: FadeAnimation(_delay,
                                      listItem(context, account.mobile, t.mobile,
                                          Icon(Icons.phone_iphone, color: LightColor
                                              .background),
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileFieldScreen(
                                                        action: Account.ACT_UPDATE_MOBILE)));
                                          },
                                          padding: 15
                                      )
                                  )
                              ),
                              SizedBox(height: 10,),
                              Container(
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  child: FadeAnimation(_delay,
                                      listItem(context, account.email, t.email,
                                          Icon(Icons.mail, color: LightColor.background),
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileFieldScreen(
                                                        action: Account.ACT_UPDATE_EMAIL)));
                                          },
                                          padding: 15
                                      )
                                  )
                              ),
                              SizedBox(height: 10,),
                              Container(
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  child: FadeAnimation(_delay,
                                      listItem(context, S
                                          .of(context)
                                          .change_password, "",
                                          Icon(Icons.lock, color: LightColor.background),
                                          onTap: () {
                                            Navigator.push(context, MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileFieldScreen(
                                                      action: Account.ACT_UPDATE_PASSWORD,)));
                                          },
                                          padding: 15
                                      )
                                  )
                              ),
                              SizedBox(height: 30,),
                              Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 20),
                                child: ListTile(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6.0),
                                      side: BorderSide(color: theme.errorColor, width: 1.5)
                                  ),
                                  leading: Icon(Icons.delete, color: theme.errorColor,),
                                  title: Text(
                                    "Delete your account",
                                    style: TextStyle(color: theme.errorColor),
                                  ),
                                  onTap: (){
                                    Navigation.navigateTo(context: context, screen: DeleteAccountScreen());
                                  },
                                ),
                              ),

                              SizedBox(height: 20,),
                            ],
                          );
                        }
                    )
                ),
              )
          )
    );
  }
}
