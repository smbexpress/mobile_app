

import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lifecycle/lifecycle.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/screens/home/default_home.dart';
import 'package:smbex_app/src/screens/settings/settings_screen.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../app_state.dart';
import '../helpers/live_data_trigger.dart';
import '../models/route_argument.dart';
import '../notification_provider.dart';
import '../theme/light_color.dart';
import '../theme/theme.dart';
import '../widgets/curved_navigation_bar.dart';
import '../widgets/scale_out_transition.dart';
import '../widgets/system_ui_overlay_mixin.dart';


class PagesWidget extends StatefulWidget {
  dynamic currentTab;
  RouteArgument routeArgument;
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  PagesWidget({
    Key key,
    this.currentTab,
  }) {
    currentTab = 2;
  }

  @override
  _PagesWidgetState createState() {
    return _PagesWidgetState();
  }
}

class _PagesWidgetState extends RefreshStateOnPopMixin<PagesWidget> with TickerProviderStateMixin {
  AnimationController animationController;
  final GlobalKey _fabKey = GlobalKey();
  int currentTab = 2;
  Widget currentPage = DefaultHomeScreen(key: GlobalKey(debugLabel: "HomeWidget"));
  DateTime currentBackPressTime;
  bool _visible = false;
  @override
  void initState() {
    animationController = AnimationController(
        duration: const Duration(milliseconds: 600), vsync: this);
    super.initState();
    _selectTab(widget.currentTab, false);

    //context.read<NotificationProvider>().context = context;
  }

  @override
  void dispose(){
    super.dispose();
    animationController.dispose();

  }

  //@override
  void onPopBack() {
    setState((){});
    //super.onPopBack();
  }
  @override
  void onPopDone(){
    setState((){});
    Config.log("onPopDone ", runtimeType);
  }

  @override
  void didUpdateWidget(PagesWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    _selectTab(currentTab, false);
  }

  void _selectTab(int tabItem, [bool navigate=true]) {
    setState(() {
      dynamic lastSelected = currentTab;
      currentTab = tabItem;

      if (tabItem != 2 && tabItem != 0){
        currentTab = 2;
        if (lastSelected != 2 )
          currentPage = DefaultHomeScreen(key: GlobalKey(debugLabel: "HomeWidget"));
      }

      switch (tabItem) {
        case 0:
          currentPage = SettingsScreen();
          break;
        case 1:
          if(navigate)
            Navigator.of(context).pushNamed("/Branches", arguments: _fabKey);
          break;
        case 2:
          if(navigate && lastSelected == 2 && currentAccount.value.valid ){
            Navigator.of(context).pushNamed("/ShipmentEdit", arguments: _fabKey);
            print("Push ShipmentEdit");
            return ;
          }
          if (currentPage is! DefaultHomeScreen)
            currentPage = DefaultHomeScreen(key: GlobalKey(debugLabel: "HomeWidget"));//parentScaffoldKey: widget.scaffoldKey, animationController: animationController,);
          break;
        case 3:
          if (navigate)
            Navigator.of(context).pushNamed("/Shipments");
          break;
        case 4:
          if (navigate)
            Navigator.of(context).pushNamed("/Rate", arguments: _fabKey);
          break;
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    //Listen for app sate change
    Provider.of<AppState> (context);

    return WillPopScope(
      onWillPop: _onWillPop,
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: AppTheme.whiteOverlayStyle,
        child: LifecycleWrapper(
          onLifecycleEvent: (event) {
            Config.log("lifecycleEvent changed: $event", runtimeType);
            if (event == LifecycleEvent.active){
              if (!_visible){
              }
              _visible = true;
            } else if (event == LifecycleEvent.inactive){
              _visible = false;
            }
          },
          child: Scaffold(
              key: widget.scaffoldKey,
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              //resizeToAvoidBottomInset: true,
              //extendBody: true,
              body: SafeArea(
                  top: (currentTab != 0 && currentTab != 2) || (!currentAccount.value.valid && currentTab != 2),
                  child: ScaleOutTransition(
                    child: PageTransitionSwitcher(
                      reverse: currentTab == 2,
                      transitionBuilder: (
                          Widget child,
                          Animation<double> animation,
                          Animation<double> secondaryAnimation,
                          ) {
                        return SharedAxisTransition(
                          animation: animation,
                          secondaryAnimation: secondaryAnimation,
                          transitionType: SharedAxisTransitionType.vertical,
                          child: child,
                        );
                      },
                      child: currentPage,
                    ),
                  )
              ),
              bottomNavigationBar: _bottomNavigation
          ),
        )
      )

    );
  }

  Widget get _bottomNavigation {
    final Animation<Offset> slideIn = Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
        .animate(CurvedAnimation(parent: ModalRoute.of(context).animation, curve: Curves.ease));
    final Animation<Offset> slideOut = Tween<Offset>(begin: Offset.zero, end: const Offset(0, 1))
        .animate(CurvedAnimation(parent: ModalRoute.of(context).secondaryAnimation, curve: Curves.fastOutSlowIn));

    return SlideTransition(
      position: slideIn,
      child: SlideTransition(
        position: slideOut,
        child: BottomAppBar(
          shape: AutomaticNotchedShape(RoundedRectangleBorder(), CircleBorder()),
          notchMargin: 8,
          elevation: 16,
          child: CurvedNavigationBar(
            //type: BottomNavigationBarType.fixed,
            selectedItemColor: Theme.of(context).primaryColorDark,
            unselectedItemColor: Theme.of(context).iconTheme.color,
            color: LightColor.white,
            //selectedFontSize: 10,
            //unselectedFontSize: 10,
            //iconSize: 22,
            //elevation: 16,
            height: 56,
            backgroundColor: LightColor.background,
            //selectedIconTheme: IconThemeData(size: 25, color: Theme.of(context).accentColor),
            notchIndex: 2,
            index: currentTab,
            onTap: (int i) {
              if (i != currentTab || currentTab == 2)
                this._selectTab(i);
            },

            // this will be set when a new tab is tapped
            items: [

              NavbarItem(
                  Icons.more_horiz,
                  tr.more
              ),
              NavbarItem(
                  Icons.storefront,
                  tr.branches
              ),
              NavbarItem(
                  currentAccount.value.valid && currentTab == 2 ? Icons.add : Icons.home,
                  tr.home,
                  key: _fabKey
              ),
              NavbarItem(
                  Icons.token_outlined,
                  tr.shipments
              ),
              NavbarItem(
                  Icons.calculate_outlined,
                  tr.rate
              ),

            ],
          )
        ),
      ),
    );
  }

  Future<bool> _onWillPop() {
    if (currentTab != 2){
      _selectTab(2);
      return Future.value(false);
    }
    DateTime now = DateTime.now();
    if (currentBackPressTime == null || now.difference(currentBackPressTime) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: tr.tapBackAgainToLeave);
      return Future.value(false);
    }
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    return Future.value(true);
  }

  void _liveTrigger(Map<String, dynamic> data){

  }

}
