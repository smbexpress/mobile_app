import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_state.dart';
bool _isFirst = true;
class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin{
  Animation<double> animation;
  AnimationController animationController;
  bool _started = false;
  bool _showLangSelection ;

  @override
  void initState() {
    super.initState();
    animationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 1000));
    animation = new CurvedAnimation(parent: animationController, curve: Curves.easeOut);

    animation.addListener((){
      if (mounted){
        setState(() {});
      }
    });
    animationController.forward();

    _checkStarting();
  }
  void dispose(){
    animationController.dispose();
    super.dispose();
  }

  void _checkStarting() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final lang = prefs.getString('language');

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      setState(() {
        _showLangSelection = lang == null;
      });
    });
  }

  void _goPage(String page){
    _started = true;
    WidgetsBinding.instance.endOfFrame.then(
          (_) {
        if (mounted) Navigator.of(context).pushReplacementNamed(page);
      },
    );

  }

  @override
  Widget build(BuildContext context) {
    AppState state = Provider.of<AppState>(context);
    if (state.setting != null && !_started && animation.isCompleted){
      if (_showLangSelection == false) {
        //final notificationProvider = Provider.of<NotificationProvider>(context, listen: false);
        _goPage('/Home');
        //WidgetsBinding.instance.addPostFrameCallback((timeStamp) => notificationProvider.setupFcm());
      } else if (_showLangSelection == true){
        _goPage('/LanguageSetup');
      }
    }
    return Scaffold(
      body: SizedBox.expand(
        child: Center(
          child: Image.asset(
            'assets/img/logo1.png',
            width: animation.value * MediaQuery.of(context).size.width * .8,
            fit: BoxFit.fitWidth,
          ),
        ),
      )
    );
  }
}
