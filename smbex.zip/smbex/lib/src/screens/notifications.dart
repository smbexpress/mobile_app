// @dart=2.12
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';

import '../../i18n/i18n.dart';
import '../helpers/helper.dart';
import '../notification_provider.dart';
import '../theme/light_color.dart';
import '../widgets/CircularLoadingWidget.dart';
import '../widgets/SmbWidget.dart';
import '../widgets/message_placeholder.dart';

/*

 */

class NotificationsPage extends StatefulWidget {
  final GlobalKey<ScaffoldState>? parentScaffoldKey;
  NotificationsPage({Key? key, this.parentScaffoldKey}) : super(key: key);
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

const kExpandedHeight = 300.0;

class _NotificationsPageState extends State<NotificationsPage> {
  ScrollController? _scrollController;

  @override
  void initState() {
    super.initState();
    Provider.of<NotificationProvider>(context, listen: false)
        .load()
        .then((error) {
      if (error != null) {
        debugPrint("$error");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    NotificationProvider provider = Provider.of<NotificationProvider>(context);
    final cl = Theme.of(context).primaryColorDark;
    return Scaffold(
        appBar: appBar(context, titleText: tr.notifications, isSecondary: true)
            as PreferredSizeWidget,
        body: LoadingWidget(
          isLoading: provider.isLoading,
          onRetry: () => provider.load(),
          error: provider.error,
          child: ListView.separated(
              itemCount: provider.notifications.isEmpty
                  ? 1
                  : provider.notifications.length + 1,
              separatorBuilder: (context, index) =>
                  provider.isLoading ? const SizedBox() : const Divider(),
              itemBuilder: (context, index) {
                if (provider.notifications.isEmpty) {
                  if (index > 0) return const SizedBox.shrink();
                  return Container(
                    child: MessagePlaceholder(
                      message: tr.empty_notification_list,
                      iconColor: Colors.white,
                      background: LightColor.grey.withOpacity(.5),
                    ),
                    alignment: Alignment.center,
                    padding: EdgeInsets.only(top: 100),
                  );
                } else if (index == 0) {
                  return const SizedBox.shrink();
                }
                index--;
                final note = provider.notifications[index];
                return ListTile(
                  title: Text(note.title ?? '', style: TextStyle(fontSize: 20)),
                  subtitle: Container(
                      margin: EdgeInsets.only(top: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            note.body ?? '',
                            style: TextStyle(fontSize: 16),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(Helper.formatDatetime(note.date) ?? '',
                              style: TextStyle(fontSize: 13))
                        ],
                      )),
                  leading: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                        color: cl.withOpacity(.2), shape: BoxShape.circle),
                    child: Icon(
                      Icons.notifications_none_outlined,
                      color: cl,
                      size: 40,
                    ),
                  ),
                );
              }),
        ));
  }
}

class FunctionalButton extends StatefulWidget {
  final String title;
  final IconData icon;
  final Function() onPressed;

  const FunctionalButton(
      {Key? key,
      required this.title,
      required this.icon,
      required this.onPressed})
      : super(key: key);

  @override
  _FunctionalButtonState createState() => _FunctionalButtonState();
}

class _FunctionalButtonState extends State<FunctionalButton> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        RawMaterialButton(
          onPressed: widget.onPressed,
          splashColor: Colors.black,
          fillColor: Colors.blue,
          elevation: 15.0,
          shape: CircleBorder(),
          child: Padding(
              padding: EdgeInsets.all(12.0),
              child: Icon(
                widget.icon,
                size: 50.0,
                color: Colors.white,
              )),
        ),
        SizedBox(
          height: 10,
        ),
        Container(
          margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 2.0),
          child: Text(
            widget.title,
            style: TextStyle(fontSize: 20.0, color: Colors.white),
          ),
        ),
        SizedBox(
          height: 20,
        )
      ],
    );
  }
}

class ProfileButton extends StatefulWidget {
  final String title, rating;
  final IconData icon;
  final Function() onPressed;

  const ProfileButton(
      {Key? key,
      required this.title,
      required this.rating,
      required this.icon,
      required this.onPressed})
      : super(key: key);

  @override
  _ProfileButtonState createState() => _ProfileButtonState();
}

class _ProfileButtonState extends State<ProfileButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onPressed,
      child: Stack(
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ClipOval(
                child: Image.asset(
                  "assets/img/logo.png",
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 2.0),
                child: Text(
                  widget.title,
                  style: TextStyle(fontSize: 20.0, color: Colors.white),
                ),
              ),
              SizedBox(
                height: 20,
              )
            ],
          ),
          Positioned(
            left: 14,
            top: 75,
            child: Container(
              width: 70,
              height: 30,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(50.0)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(widget.rating,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  SizedBox(
                    width: 5,
                  ),
                  Icon(
                    widget.icon,
                    color: Colors.black,
                    size: 16,
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
