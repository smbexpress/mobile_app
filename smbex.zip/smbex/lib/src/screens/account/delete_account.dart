import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/FadeAnimation.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../../i18n/i18n.dart';
import '../../config.dart';
import '../../models/model.dart';
import '../../repository/account_repository.dart';
import '../../theme/text_styles.dart';
import '../../widgets/PermissionDeniedWidget.dart';
import '../../widgets/loading_widget.dart';


class DeleteAccountScreen extends StatefulWidget {
  DeleteAccountScreen({Key key}) : super(key: key);
  @override
  _DeleteAccountScreenState createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  bool _isRefresh = false;
  double _delay = 1.5;
  int _reasonType = 0;
  GlobalKey<FormState> _formKey;
  TextEditingController _reasonController;
  @override
  void initState() {
    super.initState();
    _reasonController = TextEditingController();
    _formKey = GlobalKey<FormState>(debugLabel: "Submit delete");
  }

  @override
  void dispose() {
    super.dispose();
    _reasonController.dispose();
  }

  void _changeDeleteReason(int reason){
    _reasonType = reason;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).copyWith(dividerColor: Colors.transparent);

    return Scaffold(
      //backgroundColor: Theme.of(context).backgroundColor,
        resizeToAvoidBottomInset: true,
        extendBody: false,
        appBar: appBar(
          context,
          titleText: "Account Delete",
          isSecondary: true,

        ),
        body: !currentAccount.value.valid
            ? PermissionDeniedWidget()
            : Material (
            child: LoadingWidget(
              isLoading: _isRefresh,
              child: SingleChildScrollView(
                  padding: EdgeInsets.only(left: 16, right: 16, top: 20, bottom: 20) ,
                  child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: Column(
                      children: <Widget>[

                        DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: theme.errorColor.withOpacity(.1)
                            ),
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Delete account notes",
                                    style: TextStyles.title,
                                  ),
                                  SizedBox(height: 10,),
                                  Row(
                                    children: [
                                      const Icon(Icons.warning, color: Colors.orange,),
                                      const SizedBox(width: 8,),
                                      Expanded(
                                          child: Text("The account cannot be deleted if there are active shipments")
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5,),
                                  Row(
                                    children: [
                                      const Icon(Icons.warning, color: Colors.orange,),
                                      const SizedBox(width: 8,),
                                      Expanded(
                                          child: Text("The account cannot be deleted if there are pending payments")
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5,),
                                  Row(
                                    children: [
                                      const Icon(Icons.warning, color: Colors.orange,),
                                      const SizedBox(width: 8,),
                                      Expanded(
                                          child: Text("The account cannot be deleted if there are unpaid invoices")
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            )
                        ),
                        const SizedBox(height: 20,),

                        InputDecorator(
                          decoration: InputDecoration(
                              labelText: "Select delete reason"
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RadioListTile(
                                title: Text("I don't need account now"),
                                value: _reasonType == 1,
                                onChanged: (val){
                                  _changeDeleteReason(1);
                                },
                                groupValue: true,
                                toggleable: true,
                              ),
                              RadioListTile(

                                title: Text("My,ll re-register later"),
                                value: _reasonType == 2,
                                onChanged: (val){
                                  //if (val)
                                  _changeDeleteReason(2);
                                },
                                groupValue: true,
                                toggleable: true,
                              ),
                              RadioListTile(
                                title: Text("Other"),
                                selected: _reasonType == 3,
                                value: _reasonType == 3,
                                onChanged: (val){
                                  print("Other change: $val");
                                  //if (val)
                                  _changeDeleteReason(3);
                                },
                                groupValue: true,
                              ),

                            ],
                          ),
                        ),
                        const SizedBox(height: 16,),

                        TextFormField(
                          controller: _reasonController,
                          decoration: InputDecoration(
                              labelText: "Other Reason",
                              hintText: ""
                          ),
                          keyboardType: TextInputType.multiline,
                          maxLines: 3,
                          validator: (text){
                            return _reasonType == 3 &&
                                (text == null || text.isEmpty)
                                ? "Please write your other reason"
                                : null;
                          },
                        ),
                        SizedBox(height: 16,),

                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                  onPressed: _reasonType > 0
                                      ? _deleteAccount
                                      : null,
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: theme.errorColor,
                                      padding: const EdgeInsets.symmetric(vertical: 10.0)
                                  ),
                                  child: Text(
                                      "Confirm delete your account",
                                      style: TextStyle(color: theme.backgroundColor, fontSize: 16)
                                  )
                              ),
                            )
                          ],
                        )

                      ],
                    ),
                  )
              ),
            )
        )
    );
  }

  void _deleteAccount() async{
    if (_formKey.currentState.validate()){

      final content = Padding(
        padding: EdgeInsets.all(10),
        child: Text("Are you sure?\nYou want to delete your account?"),
      );
      //on logout Navigator.of(context).pushNamedAndRemoveUntil('/Home', (Route<dynamic> route) => false)
      bool confirm =
          await alert(context, 
              content: content, 
              title: Text(tr.warning),
              confirmStyle: TextStyle(color: Theme.of(context).errorColor)
          );
      if (!confirm)
        return;

      _isRefresh = true;
      setState(() {});
      try {
        ResultItem result = await deleteAccount({
          'reason_type': _reasonType,
          'reason': _reasonController.text
        });
        _isRefresh = false;
        if (result.hasError){
          showNotifyDialog(
              context,
              error: result.error,
              duration: null,
              fullWidth: true
          );
        } else {
          await logout();
          Fluttertoast.showToast(
              msg: "Your account deleted successfully.",
              toastLength: Toast.LENGTH_LONG
          );
        }
      } catch(e, stack){
        _isRefresh = false;
        showNotifyDialog(
            context,
            error: e,
            duration: null,
            fullWidth: true
        );
        Config.error("delete account: $e", stack, runtimeType);
      }
      setState(() {});
    }
  }
}
