import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/models/payment_method.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../controllers/checkout_controller.dart';
import '../helpers/helper.dart';
import '../models/route_argument.dart';
import '../widgets/CircularLoadingWidget.dart';

class CheckoutScreen extends StatefulWidget {
  PaymentMethodItem method;
  CheckoutScreen({Key key, this.method}) : super(key: key);

  @override
  _CheckoutScreenState createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends StateMVC<CheckoutScreen> {
  CheckoutController _con;

  _CheckoutScreenState() : super(CheckoutController()) {
    _con = controller;
  }
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar(context, titleText: S.of(context).checkout, isSecondary: true),
      body: _con.loading
          ? CircularLoadingWidget(height: 400)
          : Stack(
              fit: StackFit.expand,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(bottom: 255),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 20, right: 10),
                          child: ListTile(
                            contentPadding: EdgeInsets.symmetric(vertical: 0),
                            leading: Icon(
                              Icons.payment,
                              color: Theme.of(context).hintColor,
                            ),
                            title: Text(
                              S.of(context).payment_mode,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.headline5,
                            ),
                            subtitle: Text(
                              S.of(context).select_your_preferred_payment_mode,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.caption,
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Container(
                    height: 265,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                    decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        border: Border(top: BorderSide(color: Theme.of(context).dividerColor))
                    ),
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width - 40,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          if(_con.cart.subtotal != _con.cart.total)Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  S.of(context).subtotal,
                                  style: Theme.of(context).textTheme.bodyText2,
                                ),
                              ),
                              Helper.getPrice(_con.cart.subtotal, context, currency: _con.cart.currency, style: Theme.of(context).textTheme.subtitle2)
                            ],
                          ),
                          if(_con.cart.tax != null && _con.cart.tax > 0)SizedBox(height: 3),
                          if(_con.cart.tax != null && _con.cart.tax > 0)Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  "",//"${S.of(context).tax} (${_con.carts[0].product.store.defaultTax}%)",
                                  style: Theme.of(context).textTheme.bodyText2,
                                ),
                              ),
                              Helper.getPrice(_con.cart.tax, context, currency: _con.cart.currency, style: Theme.of(context).textTheme.subtitle2)
                            ],
                          ),
                          Divider(height: 30),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  S.of(context).total,
                                  style: Theme.of(context).textTheme.subtitle1,
                                ),
                              ),
                              Helper.getPrice(_con.cart.total, context, currency: _con.cart.currency, style: Theme.of(context).textTheme.subtitle1)
                            ],
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            width: MediaQuery.of(context).size.width - 40,
                            child: ElevatedButton(
                              onPressed: () {
                                if (false/*_con.creditCard.validated()*/) {
                                  Navigator.of(context).pushNamed('/OrderSuccess', arguments: new RouteArgument(param: 'Credit Card (Stripe Gateway)'));
                                } else {
                                  showSnackBar(
                                    context,
                                    message: S.of(context).your_credit_card_not_valid,
                                    contentType: ContentType.NORMAL
                                  );
                                }
                              },

                              child: Text(
                                S.of(context).confirm_payment,
                                textAlign: TextAlign.start,
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }



}
