import 'package:flutter/material.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../../i18n/i18n.dart';
import '../../api.dart';
import '../../config.dart';
import '../../helpers/navigation.dart';
import '../../models/model.dart';
import '../../models/route_argument.dart';
import '../../widgets/message_placeholder.dart';
import '../pdf_viewer.dart';

class BillList extends StatefulWidget {
  final RouteArgument routeArgument;

  BillList({Key key, this.routeArgument}) : super(key: key);

  @override
  _BillListState createState() => _BillListState();
}

class _BillListState extends State<BillList> {
  LoadMore<dynamic> loadMore;
  bool isRefresh = false;
  ResultItems<dynamic> result = ResultItems();

  @override
  void initState() {
    loadMore = _BillListState.getBillsLoadMore(onLoadMore);
    super.initState();
    _load(false);
  }

  void _load(bool isRefresh){
    this.isRefresh = isRefresh;
    loadMore.loadMore();
  }

  void onLoadMore(ResultItems<dynamic> result) async{
    isRefresh = false;
    if (mounted) {
      setState(() {
        this.result = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    bool isLoading = result.status == LoadStatus.loading;
    return Scaffold(
        appBar: appBar(
            context,
            titleText: tr.myBills
        ),
        body:RefreshIndicator(
            backgroundColor: isLoading ? Colors.transparent : null,
            color: isLoading ? Colors.transparent : null,
            edgeOffset: isLoading ?  -1000.0 : 0.0,
            onRefresh: ()  {
              isRefresh = true;
              final loadFuture = loadMore.reset();
              return loadFuture;
            },
            child: Container(
                constraints: BoxConstraints.expand(),
                child: !isRefresh && result.loading
                    ? Center(child: CircularProgressIndicator())
                    : NotificationListener<ScrollNotification>(
                    onNotification: (ScrollNotification scrollInfo) {
                      if (scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
                        _load(true);
                      }
                      return result.status == LoadStatus.loading;
                    },
                    child:  ListView.separated(
                        shrinkWrap: true,
                        physics: ClampingScrollPhysics(),
                        primary: true,
                        itemCount: result.items.length + 1,
                        separatorBuilder:(_,int i){
                          return const Divider(height: 1.5,);
                        },
                        itemBuilder: (BuildContext context, int index) {
                          if (index < result.items.length) {
                            Map data = result.items[index];
                            final id = data['id']?.toString();
                            final name = data['name']?.toString() ?? '';
                            final total = data['total']?.toDouble();
                            final tax = data['tax']?.toDouble();
                            final currency = data['currency'] ?? '';
                            final date = data['invoice_date'] ?? '';
                            final type = data['type'] ?? '';
                            final payment_state = data['payment_state'] ?? '';
                            return ListTile(
                              key: Key(id),
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(name),
                                  Helper.getPrice(
                                      total,
                                      context,
                                      currency: currency
                                  )
                                ],
                              ),
                              trailing: IconButton(
                                onPressed: (){
                                  showWaybillInvoice(context, id);
                                },
                                icon: const Icon(Icons.picture_as_pdf),
                              ),
                              subtitle: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    date,
                                  ),
                                  Text(
                                    payment_state,
                                  )
                                ],
                              ),
                            );
                          }
                          if (result.hasError) {
                            return MessagePlaceholder.error(
                              error: result.error,
                            );
                          }

                          return isRefresh || isLoading
                              ? Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Center(
                                    child: AnimatedOpacity(
                                      child: isRefresh
                                          ? RefreshProgressIndicator()
                                          : CircularProgressIndicator(
                                        strokeWidth: 2.0,
                                      ),
                                      opacity: isLoading ? 1 : 0,
                                      duration: Duration(milliseconds: 300),
                                    ),
                                  ),
                                )
                              :  result.isEmpty
                                ? MessagePlaceholder.empty(message: tr.emptyItemList(tr.bills),)
                                : const SizedBox.shrink();
                        }
                    )
                )
            )
        )
    );
  }

  void showWaybillInvoice(BuildContext context, String id){
    final url = '${Config().url}web/report/billings/print/${id}';
    Navigation.navigateTo(context: context,
        screen: PdfViewer(title: tr.bill, url: url));
  }

  static Future<ResultItems<dynamic>> _getLoadMore(
      LoadArgs loadArgs, int offset) async {
    Map<String, dynamic> args = Map.of(loadArgs.args);

    args['offset'] = offset;
    Future<ResultItems<dynamic>> result = ResultItems.of(
        Api().post("billings/list", data: args), null, timeout: 15);
    //final ResultItems<Shipment> result = await repo.getShipmentsWith(args);
    return result;
  }

  static LoadMore<dynamic> getBillsLoadMore(LoadMoreNotify<dynamic> onLoadMore) {
    LoadArgs loadArgs = LoadArgs(args: Map());
    var loadMore = LoadMore<dynamic>(loadArgs,
        loadMoreProvider: _getLoadMore, onLoadMore: onLoadMore);

    return loadMore;
  }
}
