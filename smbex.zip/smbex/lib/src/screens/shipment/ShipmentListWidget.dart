import 'package:animations/animations.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/i18n/i18n.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/screens/delivery/delivery_screen.dart';
import 'package:smbex_app/src/theme/extention.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';

import '../../config.dart';
import '../../models/address.dart';
import '../../notification_provider.dart';
import 'shipment_detail.dart';
import '../tracking/tracking.dart';
import '../../widgets/AnimationListView.dart';
import '../../widgets/CommonWidget.dart';
import '../../widgets/copy_to_clipboard.dart';
import '../../widgets/icon_text.dart';

class ShipmentListWidget extends StatefulWidget {
  final LoadMoreFactory<TinyShipment> loadMoreFactory;

  final bool isDelivey;

  final ScrollController controller;
  final bool isConnected;
  ShipmentListWidget({
    Key key,
    this.loadMoreFactory,
    this.controller,
    this.isDelivey = false,
    this.isConnected = true,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() => _ShipmentListWidgetState();
}

class _ShipmentListWidgetState extends State<ShipmentListWidget>
    with AutomaticKeepAliveClientMixin<ShipmentListWidget> {
  ResultItems<TinyShipment> result = ResultItems();
  bool isRefresh = false;
  bool loadingStarting = false;
  LoadMore<TinyShipment> loadMore;
  NotificationProvider _provider;
  String _loadKey;
  void onLoadMore(ResultItems<TinyShipment> result) async {
    //if (!loadingStarting)
    //  return;

    Config.debug("onLoadMore trigger : isLoading: ${result.loading}",
        widget.runtimeType);
    isRefresh = false;
    loadingStarting = true;
    if (mounted) {
      List<Address> toSync = [];
      for (final ship in result.items) {
        if (ship.from?.facilityId != null && ship.from.facility == null)
          toSync.add(ship.from);
        if (ship.to?.facilityId != null && ship.to.facility == null)
          toSync.add(ship.to);
      }

      if (result.loading && toSync.isNotEmpty)
        await BranchProvider.syncAddressWithBranch(context, toSync);

      setState(() {
        this.result = result;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    loadMore = widget.loadMoreFactory(onLoadMore);

    _provider = context.read<NotificationProvider>();
    _loadKey = widget.isDelivey ? 'deliveryListItems' : 'shipmentListItems';
    _provider.addLiveCommand(
      LiveCommand(
          key: _loadKey,
          model: widget.isDelivey ? 'deliveries' : 'shipments',
          method: 'changed',
          listener: _liveTrigger,
          last: DateTime.now()),
    );
    _provider.addMessageListener(_onRemoteMessage);
    _load(false);
  }

  @override
  void dispose() {
    _provider.removeMessageListener(_onRemoteMessage);
    _provider.removeLiveCommand(
        widget.isDelivey ? 'deliveryListItems' : 'shipmentListItems');
    super.dispose();
  }

  @override
  void didUpdateWidget(ShipmentListWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isConnected && result.hasError && loadMore != null) {
      _load(result.isEmpty);
    }
  }

  void _load(bool isRefresh) {
    this.isRefresh = isRefresh;
    loadMore.loadMore();
  }

  void _liveTrigger(dynamic item) {
    isRefresh = true;
    loadMore.reset();
  }

  void _onRemoteMessage(RemoteMessage message) {
    final model = message.data['model'];
    if (widget.isDelivey && model == 'deliveries' ||
        (!widget.isDelivey && model == 'shipments')) {
      _provider.updateCommandWith(_loadKey, last: DateTime.now());
      isRefresh = true;
      loadMore.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final buttonColor = theme.listTileTheme.textColor ?? LightColor.iconColor;
    final shadow = [
      BoxShadow(
        color: theme.shadowColor,
        spreadRadius: -2,
        blurRadius: 7,
        offset: Offset(0, 10), // changes position of shadow
      )
    ];
    bool isLoading = result.status == LoadStatus.loading;
    final buttonStyle = TextButton.styleFrom(
        padding: EdgeInsets.zero,
        foregroundColor: buttonColor,
        textStyle: TextStyle(fontWeight: FontWeight.normal));

    return RefreshIndicator(
        backgroundColor: isLoading ? Colors.transparent : null,
        color: isLoading ? Colors.transparent : null,
        edgeOffset: isLoading ? -1000.0 : 0.0,
        onRefresh: () {
          isRefresh = true;
          final loadFuture = loadMore.reset();
          return loadFuture;
        },
        child: Container(
            constraints: BoxConstraints.expand(),
            child: !isRefresh && isLoading
                ? Center(child: CircularProgressIndicator())
                : NotificationListener<ScrollNotification>(
                    onNotification: (ScrollNotification scrollInfo) {
                      if (scrollInfo.metrics.pixels ==
                          scrollInfo.metrics.maxScrollExtent) {
                        _load(true);
                      }
                      return result.status == LoadStatus.loading;
                    },
                    child: ListView.separated(
                        controller: widget.controller,
                        shrinkWrap: false,
                        physics: ClampingScrollPhysics(),
                        primary: false,
                        itemCount: result.items.length + 1,
                        padding:
                            widget.isDelivey ? const EdgeInsets.all(15) : null,
                        separatorBuilder: (_, int i) {
                          return widget.isDelivey
                              ? const SizedBox(
                                  height: 20,
                                )
                              : const Divider(
                                  height: 1.5,
                                );
                        },
                        itemBuilder: (BuildContext context, int index) {
                          if (index < result.items.length) {
                            TinyShipment shipment =
                                result.items.elementAt(index);
                            return OpenContainer(
                              key: ValueKey(shipment.id),
                              transitionType: ContainerTransitionType.fade,
                              openBuilder:
                                  (BuildContext _, VoidCallback openContainer) {
                                return widget.isDelivey
                                    ? DeliveryScreen(
                                        shipmentId: shipment.id,
                                      )
                                    : ShipmentDetailScreen(
                                        shipmentId: shipment.id,
                                      );
                              },
                              tappable: false,
                              closedShape: widget.isDelivey
                                  ? const RoundedRectangleBorder(
                                      borderRadius: const BorderRadius.all(
                                          const Radius.circular(12.0)))
                                  : null,
                              closedElevation: 0.0,
                              closedColor: Colors.white,
                              closedBuilder:
                                  (BuildContext _, VoidCallback openContainer) {
                                return widget.isDelivey
                                    ? TextButton(
                                        child: renderShipmentAddress(
                                            context,
                                            result.items.elementAt(
                                              index,
                                            ),
                                            vertical: 8,
                                            horizontal: 15),
                                        onPressed: openContainer,
                                        style: buttonStyle)
                                    : ShipmentListTile(
                                        shipment: shipment,
                                        onTap: openContainer);
                              },
                            );
                          }
                          if (result.hasError) {
                            return MessagePlaceholder.error(
                              error: result.error,
                            );
                          }

                          return isRefresh || isLoading
                              ? Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Center(
                                    child: AnimatedOpacity(
                                      child: isRefresh
                                          ? RefreshProgressIndicator()
                                          : CircularProgressIndicator(
                                              strokeWidth: 2.0,
                                            ),
                                      opacity: isLoading ? 1 : 0,
                                      duration: Duration(milliseconds: 300),
                                    ),
                                  ),
                                )
                              : result.isEmpty
                                  ? Center(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(top: 100),
                                        child: MessagePlaceholder.empty(
                                          title: tr.emptyItemList(tr.shipments),
                                        ),
                                      ),
                                      heightFactor: 1,
                                    )
                                  : const SizedBox.shrink();
                          ;
                        }))));
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}

class ShipmentListTile extends StatelessWidget {
  final TinyShipment shipment;
  final VoidCallback onTap;
  const ShipmentListTile({Key key, this.shipment, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      horizontalTitleGap: 0.0,
      //isThreeLine: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          (shipment.name != null && shipment.name != '-')
              ? IconText(
                  text: "#${shipment.name}",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  value: shipment.name,
                  copyToClipboard: true,
                )
              : Text("#"),
          const Spacer(),
          //const SizedBox(height: 30, width: 1,),
          Text(
            shipment.orderDate,
            style: TextStyle(fontSize: 11.0, fontWeight: FontWeight.normal),
          ),
        ],
      ),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 5.0,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.my_location,
                      color: Colors.green,
                    ),
                    const SizedBox(
                      width: 5.0,
                    ),
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          shipment.from.name ?? '',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                          maxLines: 1,
                          overflow: TextOverflow.clip,
                        ),
                        const SizedBox(
                          height: 5.0,
                        ),
                        Text(shipment.from.formattedRegion,
                            style: const TextStyle(fontSize: 13.0)),
                        const SizedBox(
                          height: 5.0,
                        ),
                      ],
                    ))
                  ],
                ),
                const SizedBox(
                  height: 5.0,
                ),
                Row(
                  children: [
                    RotatedBox(
                        quarterTurns: 2,
                        child: Icon(Icons.navigation,
                            color: Theme.of(context).colorScheme.secondary)),
                    const SizedBox(
                      width: 5.0,
                    ),
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          shipment.to.name ?? '',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                          maxLines: 1,
                          overflow: TextOverflow.clip,
                        ),
                        const SizedBox(
                          height: 5.0,
                        ),
                        Text(shipment.to.formattedRegion,
                            style: const TextStyle(fontSize: 13.0)),
                        const SizedBox(
                          height: 5.0,
                        ),
                      ],
                    ))
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Opacity(
                      opacity: 0.0,
                      child: Icon(Icons.date_range),
                    ),
                    const SizedBox(
                      width: 5.0,
                    ),
                    Container(
                      child: Text(
                        shipment.status?.name?.toUpperCase() ?? '',
                        style: TextStyle(
                            color:
                                shipment.status?.getColor(context)?.darken(25),
                            //fontWeight: FontWeight.w400,
                            fontSize: 15.0),
                      ),
                      color:
                          shipment.status?.getColor(context)?.withOpacity(.08),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15.0, vertical: 2.0),
                    )
                  ],
                )
              ],
            ),
          ),
          const Icon(
            Icons.chevron_right,
            size: 28.0,
          )
        ],
      ),
    );
  }
}
