part of 'create_shipment_screen.dart';

class SelectPickup extends StatefulWidget {
  final ShipmentController shipCtr;
  final ScrollController scrollController;
  AddressSelectController addressSelectController;
  SelectPickup(

      this.shipCtr, this.scrollController, this.addressSelectController);

  @override
  _SelectPickupState createState() => _SelectPickupState();
}

class _SelectPickupState extends State<SelectPickup> {
  Shipment shipment;

  _SelectPickupState();

  void initState() {
    shipment = widget.shipCtr.shipment;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        scrollDirection: Axis.vertical,
        controller: widget.scrollController,
        child: Container(
            //height: 500,
            margin: EdgeInsets.symmetric(horizontal: 0.0, vertical: 15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20,
                ),
                Container(
                  alignment: AlignmentDirectional.centerStart,
                  child: IconText(
                    text: tr.from,
                    style: TextStyles.title,
                    icon: RotatedBox(
                      quarterTurns: 2,
                      child: Icon(Icons.navigation,
                          color: Theme.of(context).colorScheme.secondary),
                    ),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 20),
                ),
                createAddressWidget(true),
                SizedBox(
                  height: 20,
                ),
                Container(
                  alignment: AlignmentDirectional.centerStart,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  child: IconText(
                    text: tr.to,
                    style: TextStyles.title,
                    icon: Icon(Icons.location_on, color: Colors.redAccent),
                  ),
                ),
                createAddressWidget(false),
                /*
                SizedBox(height: 20,),
                Card(
                  child: SelectAddressWidget(
                    shipment.from,
                    shipment.to,
                    height: 150,
                    onSelect: (isPickup) {
                      widget.addressSelectController.open(isPickup);
                      //_showAddressSheetWidget(context, isPickup, shipment);
                    },
                  ),
                ),*/
                Container(
                    child: SelectDate(controller: widget.shipCtr,),
                    margin: EdgeInsets.only(top: 20)
                ),


              ],
            ))
        // )
        );
  }


  Widget createDateItem(BuildContext context, String title, String value, onTap,
      [TextStyle valueStyle]) {
    valueStyle = valueStyle ?? TextStyles.titleM;
    return Expanded(
      child: Card(
        margin: EdgeInsets.only(right: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: EdgeInsets.all(5),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.date_range),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                      child: Text(
                    title,
                    style: TextStyle().bold.accent.scale(14),
                  ))
                ],
              ),
            ),
            Container(
              alignment: Alignment.center,
              padding: EdgeInsets.all(10),
              child: Text(value, style: valueStyle),
            )
          ],
        ),
      ).ripple(onTap),
    );
  }

  Widget createDateWidget0(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          child: Card(
            margin: EdgeInsets.only(right: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.all(5),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.date_range),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                          child: Text(
                        tr.pickupDate,
                        style: TextStyle().bold.accent.scale(14),
                      ))
                    ],
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),
                  child: Text(
                      shipment.pickupDate != null ? shipment.pickupDate : "",
                      style: TextStyles.title),
                )
              ],
            ),
          ).ripple(() {
            if (_check_address()) {
              DateTime pickTime = Helper.parseDate(shipment.pickupDate);
              showDatePickDate(context, pickTime).then((value) => {
                    if (value != null)
                      {
                        setState(() {
                          widget.shipCtr.shipment.pickupDate = Helper.formatDate(value);
                          _validate();
                        })
                      }
                  });
            }
          }),
        ),
        Expanded(
          child: Card(
            //margin: EdgeInsets.only(right: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.all(5),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.timer),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                          child: Text(
                        tr.pickupTime,
                        style: TextStyle().bold.accent.scale(14),
                      ))
                    ],
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),
                  child: Text(
                      Helper.formatTimeRange(context, shipment.pickupTime.start,
                          shipment.pickupTime.end),
                      style: TextStyles.body
                          .copyWith(fontSize: 17, letterSpacing: .7)),
                )
              ],
            ),
          ).ripple(() {
            if (_check_address())
              timeRange(context, shipment.pickupTime.start,
                      shipment.pickupTime.end)
                  .then((value) {
                        if (value != null){
                            final pt = widget.shipCtr.shipment.pickupTime;
                            pt.start = value.startTime.hour.toDouble() +
                                (value.startTime.minute.toDouble()/ 60.0);
                            print("Start: $value");
                            pt.end = value.endTime.hour.toDouble() +
                                (value.endTime.minute.toDouble() / 60.0);

                            setState(() {
                                _validate();
                            });
                        }
                      }
                  );
          }),
        )
      ],
    );
  }

  void _validate() {
    widget.shipCtr.validate(0, context);
  }

  bool _check_address() {
    if (widget.shipCtr.packages == null || widget.shipCtr.packages.isEmpty) {
      Fluttertoast.showToast(
          msg: tr.selectValidShippingAddressFirst,
          toastLength: Toast.LENGTH_LONG,
          timeInSecForIosWeb: 8,
          gravity: ToastGravity.CENTER,
          backgroundColor: Theme.of(context).errorColor,
          textColor: Colors.white);
      return false;
    }
    return true;
  }

  Widget createAddressWidget(bool isPickup) {
    final address =
        isPickup ? widget.shipCtr.shipment.from : widget.shipCtr.shipment.to;
    return Material(
        color: Theme.of(context).cardColor,
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          constraints: BoxConstraints(
            maxHeight: 180,
          ),
          height: 160,
          child: CustomPaint(
            painter: DashPainter(
              borderType: BorderType.RRect,
              radius: Radius.circular(12),
              dashPattern: [10, 10],
              color: Colors.grey,
              strokeWidth: 2,
            ),
            child: InkWell(
                onTap: () => widget.addressSelectController.open(isPickup),
                borderRadius: BorderRadius.circular(12),
                child: Stack(
                  alignment: AlignmentDirectional.topStart,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Container(
                        //height: double.infinity,
                        //width: double.infinity,

                        alignment: Alignment.centerLeft,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: address?.name == null
                              ? MainAxisAlignment.center
                              : MainAxisAlignment.start,
                          children: address?.name != null
                              ? [
                                  Container(
                                    child: Text(
                                      address.name,
                                      style: TextStyles.title.copyWith(
                                          color: Theme.of(context)
                                              .primaryColorDark),
                                    ),
                                    alignment: AlignmentDirectional.topStart,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: Text(
                                        address.street ?? '',
                                        style: TextStyles.bodySm,
                                        overflow: TextOverflow.clip,
                                      ),
                                      alignment: AlignmentDirectional.topStart,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Text(_countryCity(address)),
                                      ]
                                  )
                                ]
                              : [
                                  Center(
                                    child: Icon(
                                      Icons.add,
                                      size: 60,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .secondary,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    tr.add_address,
                                    style: TextStyles.title,
                                  ),
                                ],
                        ),
                      ),
                    ),
                    if (address?.name != null && address.isPickup)
                      PositionedDirectional(
                        bottom: 10,
                        end: 10,
                        child: FittedBox(
                          child: Container(
                            child: Text("Default", style: TextStyle(fontSize: 12, color: Colors.white, fontWeight:FontWeight.bold ),),
                            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 2),

                            decoration: const BoxDecoration(
                                color: const Color(0xff579a06),
                              borderRadius: const BorderRadius.all(const Radius.circular(3)),
                              boxShadow: [
                                BoxShadow(color: Colors.grey, spreadRadius: 0, blurRadius: 3, offset: Offset(0.0, 3))
                              ],
                            ),
                          ),
                        ),
                      )
                  ],
                )),
          ),
        ));
  }

  String _countryCity(Address address) {
    String str = "";
    if (address?.city?.name != null) {
      str += address.city.name + ", ";
    }
    str += address?.country?.name ?? '';
    return str;
  }
}
