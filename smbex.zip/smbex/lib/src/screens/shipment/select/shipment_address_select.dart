

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/models/address.dart';

import '../../../../i18n/i18n.dart';
import '../../../controllers/address_controller.dart';
import '../../../controllers/shipment_controller.dart';
import '../../../models/shipment.dart';
import '../../../widgets/SlidingUpPanel.dart';
import '../../address/address_edit.dart';
import '../../address/addresses.dart';
import 'address_select_controller.dart';
import 'branch_list.dart';

export 'address_select_controller.dart';

class ShipmentAddressSelect extends StatefulWidget {
  final ShipmentController shipmentController;
  final AddressSelectController controller;
  final Widget child;
  const ShipmentAddressSelect({
    Key key,
    this.shipmentController,
    this.controller,
    this.child
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _ShipmentAddressSelectState();

}

class _ShipmentAddressSelectState extends State<ShipmentAddressSelect>
    with SingleTickerProviderStateMixin{
  TabController tabController;
  AddressController _pickupAddressController;
  AddressController _deliveryAddressController;
  PanelController _panelController;
  ScrollController _scrollController;

  GlobalKey _appBarWidgetKey = GlobalKey(debugLabel: "slidTabBarKey");
  Size _appBarSize ;
  double _radius = 12;
  Address _source;
  Address _dest;
  Shipment _ship;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    _pickupAddressController = AddressController();
    _deliveryAddressController = AddressController();
    _panelController = PanelController();
    widget.controller.addListener(_openPanel);
    _scrollController = ScrollController();
    _ship = widget.shipmentController.shipment;
    _source = _copyAddress(_ship?.from??Address.From(true));
    _dest = _copyAddress(_ship?.to??Address.From(false));
  }


  @override
  void didUpdateWidget(ShipmentAddressSelect oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller){
      oldWidget.controller?.removeListener(_openPanel);
      widget.controller?.addListener(_openPanel);
    }
    if (_ship != widget.shipmentController.shipment){
      _source = _copyAddress(_ship?.from??Address.From(true));
      _dest = _copyAddress(_ship?.to??Address.From(false));
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async{
        if((_panelController.isPanelShown || _panelController.isPanelOpen )){
          if (_panelController.isPanelAnimating){
            return false;
          }
          widget.controller.isPickup = null;
          _panelController.hide();
        }
        return true;
      },
      child: LayoutBuilder(builder: (BuildContext context, BoxConstraints cons){
        //WidgetsBinding.instance?.addPostFrameCallback(_getWidgetInfo);
        return _buildSlidingUpPanel(context, cons);
      }),
    );
  }


  Widget _buildSlidingUpPanel(BuildContext context, BoxConstraints cons) {
    final attached = _panelController.isAttached ;
    final mq = MediaQuery.of(context);
    final _panelHeightOpen = mq.size.height - mq.padding.top;
    final _initFabHeight = 0;

    final _panelHeightClosed = widget.controller.isPickup == null ? 0.0 :  _panelHeightOpen * .75 + mq.viewInsets.bottom ;
    final pageIndex = widget.shipmentController.pageIndex;
    if (pageIndex != 0 && attached && !_panelController.isPanelAnimating
        && (_panelController.isPanelShown || _panelController.isPanelOpen )){
      _panelController.animatePanelToPosition(0.0);

    }

    double cPos = 0;
    final currentTab = tabController.index;
    final tabBar = TabBar(
      controller: tabController,
      //key: _appBarWidgetKey,
      tabs: [
        Tab(
            text: tr.addresses,
            icon: Icon(Icons.person)
        ),
        Tab(
            text: tr.new_address,
            icon: Icon(Icons.add)
        ),

      ],
    );
    //print("TabBar::size: ${tabBar.preferredSize?.height}");
    return SlidingUpPanel(
      controller: _panelController,
      maxHeight: _panelHeightOpen,
      minHeight: _panelHeightClosed,
      parallaxEnabled: false,
      //parallaxOffset: .6,
      //backdropEnabled: true,
      backdropTapClosesPanel: true,
      margin: EdgeInsets.zero,
      padding: EdgeInsets.zero,
        //renderPanelSheet: false,
      snapPoint: .5,
      onPanelClosed: (){
        //widget.controller.isPickup = null;
        print("ShipmentAddressSelect::onPanelClosed");
      },
      onPanelOpened: (){
        print("ShipmentAddressSelect::onPanelOpened");
      },
      onPanelSlide: (double pos) => setState(() {
        final newPos = pos * _panelHeightOpen;
        if (_panelHeightOpen - newPos < 48){
          _radius = max(min(-12 * newPos / 48 + 12.0, 12), 0).toDouble() ;
          setState((){});
        } else if (_radius != 12){
          _radius = 12.0;
          setState((){});
        }
        if (pos == 0.0){
          //if (_panelController.isPanelShown || _panelController.isPanelOpen)
           //   widget.controller.isPickup = null;

        }
      }),
      header: Material(
        color: Theme.of(context).backgroundColor,
        child: IntrinsicHeight(
          child: Row(
            children: [

              Container(
                constraints: BoxConstraints.expand(height: tabBar.preferredSize?.height, width: cons.maxWidth - 60),
                //width: double.infinity,
                child: tabBar,
              ),
              IconButton(
                  onPressed: (){
                    //widget.controller.isPickup = null;
                    //_panelController.hide();
                    widget.controller.open(null);
                  },
                  icon: Icon(Icons.close)
              )
            ],
          ),
        )
      ),
      borderRadius: BorderRadius.only(
          topLeft: Radius.circular(_radius),
          topRight: Radius.circular(_radius)
      ),
      boxShadow: <BoxShadow>[
        BoxShadow(
          blurRadius: (_radius??0) / 3 * 2,
          color: Color.fromRGBO(0, 0, 0, 0.25),
        )
      ],
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            color: Theme.of(context).colorScheme.onPrimary,
          ),
          Positioned(
            height: 130,
            left: 0,
            right: 0,
            child: Container(
              constraints: BoxConstraints(maxHeight: 60),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary,
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(12), bottomRight: Radius.circular(12))
              ),
            ),
          ),
          GestureDetector(
            child: widget.child,
            onTap: () {
              if (widget.controller.isPickup != null)
                widget.controller.open(null);
            }
          )
        ],
      ),
      panel: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: widget.shipmentController.shipment != null && widget.controller.isPickup != null
                 ? Container(
                    padding: EdgeInsets.only(top: (tabBar.preferredSize?.height??0)),
                    height: attached ? _panelController.panelPosition * _panelHeightOpen + _panelHeightClosed - (tabBar.preferredSize?.height??0) : null,
                    //color: Colors.redAccent,
                    child: TabBarView(
                      controller: tabController,
                      physics: const NeverScrollableScrollPhysics() ,
                      children: [
                        if (widget.controller.isPickup != false) ...[
                          AddressesScreen(
                            key: Key('pickupAddresses'),
                            isPickup: true,
                            onSelect: _onAddressSelect,
                            //scrollController: currentTab == 1 ? sc : null,
                            showAppBar: false,
                            forceBranch: shipmentMetaLoadState.
                              value?.forceFromBranch == true ,
                          ),
                          AddressWidget(
                            controller: _pickupAddressController,
                            address: _source,
                            //scrollController: currentTab == 0 ? sc : null,
                            showAppBar: false,
                            showCity: true,
                            isPickup: true,
                            forceBranch: shipmentMetaLoadState.
                              value?.forceFromBranch == true,
                            callback: (address) => _onAddress(address, true)
                          ),

                        ],
                        if (widget.controller.isPickup == false) ...[
                          AddressesScreen(
                            key: Key('deliveryAddresses'),
                            isPickup: widget.controller.isPickup,
                            onSelect: _onAddressSelect,
                            //scrollController: currentTab == 1 ? sc : null,
                            showAppBar: false,
                            forceBranch: shipmentMetaLoadState.
                              value?.forceToBranch == true,
                          ),
                          AddressWidget(
                            controller: _deliveryAddressController,
                            address: _dest,
                            //scrollController: currentTab == 0 ? sc : null,
                            showAppBar: false,
                            showCity: true,
                            isPickup: false,
                            forceBranch: shipmentMetaLoadState.
                                value?.forceToBranch == true,
                            callback: (address) => _onAddress(address, false)
                          ),

                        ],
                      ],
                    ),
                  )
                  : SizedBox(),
          )
    );

  }

  void _onAddressSelect(Address address){
    _onAddress(address, widget.controller.isPickup);
  }

  void _onAddress(Address address, bool isPickup){
      if (isPickup) {
        widget.shipmentController.setFromAddress(address);
        _source.copy(address);
      } else {
        widget.shipmentController.shipment.to = address;
        _dest.copy(address);
      }
      widget.shipmentController.validate(0, context);

      widget.controller.isPickup = null;
      widget.shipmentController.setState((){
        _panelController.close();
      });
  }

  void _getWidgetInfo(_) {
    final RenderBox renderBox = _appBarWidgetKey.currentContext?.findRenderObject() as RenderBox;
    //_appBarWidgetKey.currentContext?.size;
    final newSize = renderBox?.size;
    if (newSize != _appBarSize && newSize != null) {
      _appBarSize = renderBox.size;
      print('Size: ${_appBarSize.width}, ${_appBarSize.height}');
      setState(() {});
    }
  }

  void _openPanel(){
    if(!mounted)
      return;
    print("ShipmentAddressSelect: close:${widget.controller.isPickup == null}");
    if(widget.controller.isPickup == null
        && _panelController.isAttached
    ){
      _panelController.animatePanelToPosition(.0).then(
              (value) => setState((){}));
      return;
    }

    _panelController.open();
    //_panelController.animatePanelToPosition(.7);

    WidgetsBinding.instance?.addPostFrameCallback((_){
      //_panelController.animatePanelToPosition(.7);
    });
  }

  Address _copyAddress(Address source) {
    Address copy = Address.From(source.isPickup);
    copy.copy(source);
    return copy;
  }

}