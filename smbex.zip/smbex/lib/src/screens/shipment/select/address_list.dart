

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/models/branch.dart';

import '../../../widgets/SmbWidget.dart';
import '../../../widgets/picker/search/select_panel.dart';
import '../../branch/branch_provider.dart';

class AddressSelectList extends StatelessWidget {
  final GlobalKey<SelectPanelState> _globalKey = GlobalKey<SelectPanelState>();
  final TextEditingController _searchTextController = TextEditingController();

  StateSetter _setState;

  @override
  Widget build(BuildContext context) {
    InputBorder border = OutlineInputBorder(
        borderRadius: const BorderRadius.all(Radius.circular(16.0)),
        borderSide: BorderSide(color: Theme.of(context).hintColor)
    );
    BranchProvider provider = Provider.of<BranchProvider>(context);
    return SelectPanel<Branch>(
        key: _globalKey,
        isPage: true,
        showSearchBox: false,
        isFilteredOnline: true,
        onFind: (String search) {
          return provider.searchBranch(search);
        },
        builder: (BuildContext context, Widget child,
            ValueChanged<String> valueChanged) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter state) {
              _setState = state;
              return Column(
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: TextField(
                      //autofocus: true,
                      controller: _searchTextController,
                      decoration: InputDecoration(
                          border: border,
                          focusedBorder: border,
                          enabledBorder: border,
                          prefix: Align(
                            child: IconButton(
                              icon: Icon(Icons.clear),
                              onPressed: (){
                                _searchTextController.text = '';
                                valueChanged('');
                              },
                            ),
                          ),
                          suffix: Icon(Icons.search)
                      ),
                    ),
                  ),
                  child
                ],
              );
            },
          );
        }
    );
  }
}