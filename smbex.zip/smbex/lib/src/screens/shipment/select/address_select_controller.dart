
import 'package:flutter/material.dart';

class AddressSelectController extends ChangeNotifier{
  bool isPickup;
  void open(bool pickup){
    isPickup = pickup;
    notifyListeners();
  }

}