
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';

import '../../../helpers/Debouncer.dart';
import '../../../models/address.dart';
import '../../../theme/text_styles.dart';
import '../../../widgets/picker/search/select_panel.dart';
import '../../branch/branch_provider.dart';


class BranchSelectList extends StatefulWidget  {
  final ScrollController controller;
  BranchSelectList({Key key, this.controller}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _BranchSelectList();

}

class _BranchSelectList extends State<BranchSelectList>  {
  final GlobalKey<SelectPanelState> _globalKey = GlobalKey<SelectPanelState>();
  final TextEditingController _searchTextController = TextEditingController();
  final _debouncer = Debouncer();

  void initState(){
    super.initState();
    BranchProvider provider = Provider.of<BranchProvider>(context, listen: false);
    _searchTextController.text = provider.filter;
    provider.searchBranch(null);
  }

  @override
  Widget build(BuildContext context) {
    final dividerColor = Theme.of(context).dividerColor;
    InputBorder border = OutlineInputBorder(
        borderRadius: const BorderRadius.all(Radius.circular(30.0)),
        borderSide: BorderSide(color: dividerColor),
    );
    BranchProvider provider = Provider.of<BranchProvider>(context);

    if(true){
      return Stack(
        fit: StackFit.expand,
        children: [
          LoadingWidget(
              isLoading: provider.isLoading,
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: TextField(
                      autofocus: false,
                      controller: _searchTextController,
                      onChanged: (v) => _debouncer(()=> provider.searchBranch(v)),
                      decoration: InputDecoration(
                          border: border,
                          focusedBorder: border,
                          enabledBorder: border,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
                          suffixIcon:  _searchTextController.text.isNotEmpty
                              ? Padding(
                              padding: EdgeInsetsDirectional.only(end: 4, top: 2, bottom: 2),
                              child: Material(
                                  color: LightColor.background,
                                  //shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                  borderRadius: BorderRadius.circular(26),
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(30),
                                    child: Icon(Icons.clear),
                                    onTap: (){
                                      _searchTextController.text = '';
                                      provider.searchBranch('');
                                    },
                                  )
                              ),
                          )
                              : null ,
                          prefixIcon: Icon(Icons.search)
                      ),
                    )
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      child: ListView.separated(
                          controller: widget.controller,
                          separatorBuilder: (_, __) => const SizedBox(height: 16,),
                          itemBuilder: (_, index)=>  Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: dividerColor),
                              borderRadius: BorderRadius.circular(8),

                            ),
                            child: ListTile(
                              onTap: (){

                              },
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              title: Text(provider.searchedBranchList[index].name),
                              subtitle: Column(
                                children: [
                                  SizedBox(height: 10,),
                                  Row(
                                    children: [
                                      Expanded(child: Text(provider.searchedBranchList[index].address, overflow: TextOverflow.clip, maxLines: 2,)),
                                    ],
                                  ),
                                  SizedBox(height: 10,),
                                  Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Text(provider.searchedBranchList[index].cityCountry),
                                        Text(provider.searchedBranchList[index].distanceFormat, style: TextStyles.title,)
                                      ]
                                  )
                                ],
                              ),

                            ),
                          ),

                          itemCount: provider.searchedBranchList?.length??0
                      ),
                    ),
                  )
                ],
              )
          )

        ],
      );
    }
  }
  Future _requestBranchService(BranchProvider provider) async{
    provider.setCurrentLocation();
    return provider.branches();
  }

}