import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/controllers/shipment_controller.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/theme/theme.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';
import 'package:smbex_app/src/widgets/connection_status_widget.dart';

import '../../../i18n/i18n.dart';
import '../../models/route_argument.dart';
import '../../repository/account_repository.dart';
import '../../widgets/PermissionDeniedWidget.dart';
import 'ShipmentListWidget.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
import 'create_shipment_screen.dart';

const double _fabDimension = 56.0;


class ShipmentsWidget extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;
  final int currentTab = 0;
  final int limit;
  final RouteArgument args;
  ShipmentsWidget({Key key, this.parentScaffoldKey, this.limit=10, this.args}) : super(key: key);
  @override
  _ShipmentsWidgetState createState() => _ShipmentsWidgetState();



}

class _ShipmentsWidgetState extends StateMVC<ShipmentsWidget>
    with SingleTickerProviderStateMixin{
  ShipmentController _con;
  LoadMore<TinyShipment> _outLoadMore;
  LoadMore<TinyShipment> _inLoadMore;
  TabController tabController;
  ScrollController scrollViewController;
  ValueNotifier<int> tabIndexNotify;
  bool _isConnected = true;
  _ShipmentsWidgetState() : super(ShipmentController()) {
    _con = controller;
  }

  LoadMore<TinyShipment> _getOutLoadMore(LoadMoreNotify<TinyShipment> onLoadMore){
    if (_outLoadMore == null)
      _outLoadMore = ShipmentController.getShipmentLoadMore({"limit": widget.limit}, onLoadMore);
    else
      _outLoadMore.setOnLoadMore(onLoadMore);
    return _outLoadMore;
  }

  LoadMore<TinyShipment> _getInLoadMore(LoadMoreNotify<TinyShipment> onLoadMore){
    if (_inLoadMore == null)
      _inLoadMore = ShipmentController.getInShipmentLoadMore({ "limit": widget.limit}, onLoadMore);
    else
      _inLoadMore.setOnLoadMore(onLoadMore);

    return _inLoadMore;
  }

  @override
  void initState() {
    super.initState();
    if (!currentAccount.value.valid) {
      Future.delayed(Duration(milliseconds: 100),(){
        //Navigator.of(context).pushReplacementNamed('/Home', arguments: 2);
      });
    }
    var currentTab = widget.currentTab;
    if (widget.args != null)
      currentTab = int.tryParse(widget.args.id) ?? currentTab;


    tabController = TabController(vsync: this, length: 2, initialIndex: currentTab);
    scrollViewController = ScrollController();
    tabIndexNotify = ValueNotifier<int>(tabController.index);
    tabController.addListener(() {
      tabIndexNotify.value = tabController.index;
    });

  }

  @override
  void dispose() {
    super.dispose();
    tabController.dispose();
    scrollViewController.dispose();
    tabIndexNotify.dispose();
  }

  void onPopBack() {
    setState(() { });
  }

  Widget tab(BuildContext context, String text){

    return Tab(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        /*
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(50),
            border: Border.all(color: Theme.of(context).accentColor, width: 1)),
            
         */
        child: Align(
          alignment: Alignment.center,
          child: Text(text),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    int limit = 15;
    final th = Theme.of(context);
    if (!currentAccount.value.valid)
        return Scaffold(
            key: _con.scaffoldKey,
            body: PermissionDeniedWidget(),
            appBar: appBar(context, titleText: tr.shipments),
        );

    final tabBar = TabBar(
        controller: tabController,
        //indicatorColor: Colors.white,
        //unselectedLabelColor: Colors.white70,
        //labelColor: Colors.white,
        tabs: [
          tab(context, tr.outgoing),
          tab(context, tr.incoming),
        ]
    );

    return Scaffold(
        key: _con.scaffoldKey,
        //backgroundColor: Theme.of(context).backgroundColor,
        appBar: appBar(
          context,
          centerTitle: false,
          bottom: PreferredSize(
            child: Material(
              color: th.scaffoldBackgroundColor,
              child: tabBar,
            ),
            preferredSize: tabBar.preferredSize,
          ),

          titleText: tr.shipments,
          ),

        body: ConnectionChangeWidget(
          builder: (context, connect) =>
              TabBarView(
                  controller: tabController,
                  physics: NeverScrollableScrollPhysics(),
                  children:[
                    ShipmentListWidget(loadMoreFactory: _getOutLoadMore, controller: scrollViewController, isConnected: connect,),
                    ShipmentListWidget(loadMoreFactory: _getInLoadMore, controller: scrollViewController, isDelivey: true, isConnected: connect,),
                  ]
              ),
        ),
        floatingActionButton: ValueListenableBuilder(
          valueListenable: tabIndexNotify,
          builder: (context, value, child) =>
              value == 0
              ? OpenContainer(
                openBuilder: (BuildContext context, VoidCallback _) {
                  return CreateShipmentScreen();
                },
                closedElevation: 6.0,
                closedShape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(_fabDimension / 2),
                  ),
                ),
                closedColor: th.colorScheme.secondary,
                closedBuilder: (BuildContext context, VoidCallback openContainer) {
                  return SizedBox(
                    height: _fabDimension,
                    width: _fabDimension,
                    child: Center(
                      child: Icon(
                        Icons.add,
                        color: th.colorScheme.onSecondary,
                      ),
                    ),
                  );
                },
              )
              : const SizedBox.shrink()
        )
    );
  }
}
