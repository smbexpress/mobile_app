import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:lifecycle/lifecycle.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/controllers/shipment_controller.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/screens/shipment/shipment_actions.dart';
import 'package:smbex_app/src/screens/signin.dart';
import 'package:smbex_app/src/theme/theme.dart';
import 'package:smbex_app/src/widgets/CommonWidget.dart';
import 'package:smbex_app/src/widgets/connection_status_widget.dart';
import 'package:smbex_app/src/widgets/loading_widget.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';
import 'package:smbex_app/src/widgets/stack_body.dart';

import '../../../i18n/i18n.dart';
import '../../helpers/helper.dart';
import '../../models/payment_method.dart';
import '../../models/tody_tip.dart';
import '../../notification_provider.dart';
import '../../repository/account_repository.dart';
import '../../repository/settings_repository.dart';
import '../../theme/text_styles.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/checkout_widget.dart';
import '../../widgets/icon_text.dart';
import '../../widgets/payment_list_tile.dart';
import '../../widgets/system_ui_overlay_mixin.dart';
import '../../widgets/tip_widget.dart';
import '../checkout/checkout_provider.dart';


class ShipmentDetailScreen extends StatefulWidget {
  RouteArgument args;
  int shipmentId;
  Shipment shipment;
  ShipmentDetailScreen({
    Key key,
    this.shipmentId = 0,
    args,
  }) {
      if (args is RouteArgument) {
        this.args = args;
        shipmentId = int.tryParse(args.id);
        if (shipmentId == 0){
          shipment = this.args.param as Shipment;
        }
      }
  }

  @override
  _ShipmentDetailScreenState createState() => _ShipmentDetailScreenState();
}

class _ShipmentDetailScreenState extends StateMVC<ShipmentDetailScreen>
    with SystemUiOverlayMixin {
  ShipmentController _con;
  Shipment shipment;
  NotificationProvider _provider;
  bool _hasCheckout = false;
  _ShipmentDetailScreenState() : super(ShipmentController()) {
    _con = controller;
  }

  @override
  void initState() {
    super.initState();
    if (widget.shipmentId != 0)
        _con.getShipment(widget.shipmentId);
    else if(widget.shipment != null){
      _con.setShipment(widget.shipment);
    }

    dynamic meta = widget.shipment?.meta;
    final isNew = meta != null && meta['isNew'] == true;
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (isNew){
        showNotifyDialog(
          context,
          title: tr.done,
          message: tr.shipmentCreatedSuccess,
          contentType: ContentType.SUCCESS,
          duration:  const Duration(seconds: 4)
        );
      }
    });
    _provider = context.read<NotificationProvider>();
    _provider
        .addLiveCommand(
          LiveCommand(
              key: 'currentShipment',
              model: 'shipments',
              method: 'changed',
              listener: _liveTrigger,
              last: DateTime.now(),
              args: {
                'id': widget.shipmentId != 0
                    ? widget.shipmentId
                    :  widget.shipment.id
              }
          ),
    );

    _provider.addMessageListener(_onRemoteMessage);
    context.read<CheckoutProvider>().reset();

  }
  @override
  void dispose() {
    _provider.removeMessageListener(_onRemoteMessage);
    _provider?.removeLiveCommand('currentShipment');
    super.dispose();
  }

  void _liveTrigger(dynamic item){
    _reload();
  }

  void _onRemoteMessage(RemoteMessage message){
    if (message.data['model'] == 'shipments'
        && message.data['res_id'] == _con.shipment?.id)
      _reload();
  }

  void _reload() async{
    if (mounted)
      _con.getShipment(widget.shipment?.id ?? widget.shipmentId);
  }

  void _notifyAndReload() async{
    _provider.dispatch(RemoteMessage(
      data: {
        'model': 'shipments',
        'res_id': widget.shipment?.id,
      }
    ));
  }

  @override
  Widget build(BuildContext context) {
    if ( _con.errorResult ==null && _con.shipment != null) {
      shipment = _con.shipment;
    }
    CheckoutProvider checkoutProvider =
        Provider.of<CheckoutProvider>(context);

    return Scaffold(
        appBar: appBar(
          context,
          key: _con.scaffoldKey,
          isSecondary: true,
          rounded: true,
          titleText: S.of(context).shipmentDetail,
          actions: <Widget>[
            if(shipment != null && shipmentHasActions(shipment))
              IconButton(
                icon: Icon(Icons.more_vert),
                onPressed: (){
                  //Navigator.of(context).popAndPushNamed(routeName)
                  showShipmentBottomSheet(context, shipment, _notifyAndReload);
                },
              ),
          ],

        ),
        body: ConnectionChangeWidget(
            builder: (context, isConnected) {
              return !currentAccount.value.valid
                  ? SignInWidget()
                  : StackBodyWidget(
                footer: createFooter(context, shipment),
                body: RefreshIndicator(
                    onRefresh: () async{
                      if (shipment.valid)
                        return _con.getShipment(shipment.id);

                      return true;
                    },
                    child : LifecycleWrapper(
                        onLifecycleEvent: (event) {
                          if (event == LifecycleEvent.active &&
                              shipment != null &&
                              !editShipmentState.isLoading &&
                              !editShipmentState.validate()) {
                              WidgetsBinding.instance
                                  .endOfFrame.then((_) => _reload());
                          }
                        },
                        child: LoadingWidget(
                            isLoading: shipment == null && _con.errorResult == null,
                            child: shipment != null
                                ? createBody(context, shipment, checkoutProvider)
                                : _con.errorResult != null
                                ? MessagePlaceholder.error(
                                error: _con.errorResult,
                                onRetry: _reload
                            )
                                : const SizedBox.shrink()
                        )
                    )

                ),
              );
            }
        )
    );
  }

  Widget createBody(BuildContext context,
      Shipment shipment,
      CheckoutProvider checkoutProvider) {

    ThemeData theme = Theme.of(context);

    final tips = shipment.meta != null
        ? _createTipWidget(shipment.meta['tips']) : null;

    final child = SingleChildScrollView(
      padding: EdgeInsets.symmetric(vertical: 7),
      child:Column(
        children: <Widget>[
          if (tips != null)
            tips,

          cartWidget(context,
            child: renderShipmentAddressAll(context, shipment.order_date,
                shipment.status, shipment.from, shipment.to,
                withHeader: true, trackingCode: shipment.name,
                onSelect: (address) {
                  Navigator.of(context).pushNamed('/AddressShow',
                      arguments: RouteArgument(
                          id: address.id.toString(),
                          param: {'shipment_id': shipment.id}));
                }

            ),
            horizontal: 0.0,
            borderRadius: 0.0,
          ),

          createPaymentMethod(context, shipment),
          if (shipment.payment != null)
            createPaymentWidget(context, shipment),

          SizedBox(height: 16,),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(
                    Icons.card_giftcard,
                    size: 22,
                    color: theme.colorScheme.secondary
                ),
                const SizedBox(width: 5,),
                Text(
                  tr.packageInfo,
                )
              ],
            ),
          ),
          cartWidget(context,
            horizontal: 0.0,
            borderRadius: 0.0,
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: <Widget>[

                //const Divider(thickness: .5,),
                ListTile(
                  onTap: () {},
                  dense: false,
                  title: Text(
                    tr.packageType,
                    style: theme.textTheme.bodyText2,
                  ),
                  trailing: Text(
                    shipment.package.name??'',
                    style: theme.textTheme.subtitle2,
                  ),
                ),
                ListTile(
                  onTap: () {},
                  dense: true,
                  title: Text(
                    tr.service,
                    style: theme.textTheme.bodyText2,
                  ),
                  trailing: Text(
                    shipment.service.name??'',
                    style: theme.textTheme.subtitle2,
                  ),
                ),
                ListTile(
                  onTap: () {},
                  dense: true,
                  title: Text(
                    tr.weight,
                    style: theme.textTheme.bodyText2,
                  ),
                  trailing: Text(
                    (shipment.weight?.toString()?? "")+ " KG",
                    style: theme.textTheme.subtitle2,
                  ),
                ),
                if (shipment.cod != null && shipment.cod > 0)
                  ListTile(
                    dense: true,
                    title: Text(
                      tr.cash_on_delivery,
                      style: theme.textTheme.bodyText2,
                    ),
                    trailing: Helper.getPrice(shipment.cod, context, currency: shipment.codCurrency, style: theme.textTheme.subtitle2),
                  ),
              ],
            ),
          ),
          SizedBox(height: 10,),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(
                    Icons.info_outline,
                    size: 22,
                    color: theme.colorScheme.secondary
                ),
                const SizedBox(width: 5,),
                Text(
                  tr.booking_notes,
                )
              ],
            ),
          ),

          cartWidget(context,
            horizontal: 0.0,
            borderRadius: 0.0,
            child: ListView(
              shrinkWrap: true,
              primary: false,
              children: <Widget>[

                ListTile(
                  onTap: () {},
                  dense: true,
                  title: Row(
                    children: <Widget>[
                      Icon(
                        Icons.date_range,
                        size: 22,
                      ),
                      SizedBox(width: 10),
                      Text(
                        t.pickup_date,
                        //style: theme.textTheme.bodyText2,
                      ),
                    ],
                  ),
                  trailing: Text(
                    Helper.shiftDateTime(shipment.pickupDate)??"",
                    style: theme.textTheme.subtitle2,
                  ),
                ),
                ListTile(
                  onTap: () {},
                  dense: true,
                  title: Row(
                    children: <Widget>[
                      Icon(
                        Icons.alarm,
                        size: 22,
                      ),
                      SizedBox(width: 10),
                      Text(
                        t.pickup_time,
                        style: theme.textTheme.bodyText2,
                      ),
                    ],
                  ),
                  trailing: Text(
                    shipment.pickupTime.valid
                        ? "${shipment.pickupTime.startToString()} - ${shipment.pickupTime.endToString()}"
                        : "",
                    style: theme.textTheme.subtitle2,
                    overflow: TextOverflow.ellipsis,
                  ),

                ),
                Divider(height: 1),
                ListTile(
                  dense: true,
                  isThreeLine: true,
                  trailing: SizedBox(),
                  subtitle: Text(
                    shipment.content??"",
                    maxLines: 4,
                    style: theme.textTheme.bodyText2,
                  ),
                  title: Row(
                    children: <Widget>[
                      SizedBox(width: 10),
                      Text(
                        tr.content,
                        style: theme.textTheme.caption,
                      ),
                      SizedBox(height: 50),
                    ],
                  ),
                ),
                SizedBox(height: 50),
              ],
            ),

          ),
          if (shipment.amountToDue != null && shipment.amountToDue >= 1)
            SizedBox(height: 100)
        ],
      ),
    );

    final validateWidget = createValidateAddressWidget(shipment);

    if (validateWidget != null) {
      return Column(
        children: [
          Material(
            color: theme.cardColor,
            child: Container(
              //height: 96,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                  //color: theme.cardColor,
                  border: Border(bottom: BorderSide(color: theme.dividerColor))
              ),
              child: validateWidget,
            ),
          ),
          Expanded(child: child)
        ],
      );
    }

    return child;
  }

  Widget createPaymentMethod(BuildContext context, Shipment shipment){
    ThemeData theme = Theme.of(context);
    if (shipment == null)
      return const SizedBox();
    if (shipment.amountToDue != null && shipment.amountToDue >= .5){
      if (!_hasCheckout){
        _hasCheckout = true;
        context.read<CheckoutProvider>().paymentStatus.addListener(_reload);
      }
      return Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            child: Row(
              children: [
                Icon(Icons.credit_card, size: 22, color: theme.colorScheme.secondary,),
                const SizedBox(width: 5,),
                Text(
                  S.of(context).payment_mode,
                )
              ],
            ),
          ),

          CheckoutWidget(type: 'shipments', id: shipment.id)
        ],
      );
    }
    return const SizedBox();
  }

  Widget createPaymentWidget(BuildContext context, Shipment shipment){
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Row(
            children: [
              Icon(Icons.credit_card, size: 22,
                color: Theme.of(context)
                    .colorScheme.secondary,),
              const SizedBox(width: 5,),
              Text(
                S.of(context).payment_mode,
              )
            ],
          ),
        ),
        cartWidget(
          context,
          child : PaymentListTile(payment: shipment.payment,),
          horizontal: 0.0,
          borderRadius: 0.0,
        ),

      ],
    );
  }

  Widget createFooter(BuildContext context, Shipment shipment){

    if (!isWaitingPayment(shipment)){
      return SizedBox();
    }
    final checkoutProvider = context.read<CheckoutProvider>();
    ThemeData theme = Theme.of(context);
    return Container(
      //height: 96,
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
          color: theme.cardColor,
          border: Border(top: BorderSide(color: theme.dividerColor))
      ),
      child: SizedBox(
        width: MediaQuery.of(context).size.width - 40,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    t.total,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
                Helper.getPrice(
                    shipment.amountToDue,
                    context,
                    style: theme.textTheme.titleSmall,
                    currency: shipment.amountToDueCurrency
                )
              ],
            ),
            const SizedBox(height: 5),
            SizedBox(
                width: MediaQuery.of(context).size.width - 40,
                child: ValueListenableBuilder(
                  valueListenable: checkoutProvider.paymentMethodListenable,
                  builder: (context, value, child) =>
                      ElevatedButton(
                        onPressed: checkoutProvider.paymentMethod!= null
                            ? () => checkoutProvider.onCheckout(context)
                            : null,
                        child: Text(
                          t.checkout,
                        ),
                      ),
                )
            ),
          ],
        ),
      ),
    );
  }

  Widget createValidateAddressWidget(Shipment shipment){
    if (_canValidate(shipment)) {
      return Container(
        width: double.infinity,
        child: TextButton(
          onPressed: () =>
              Navigator.of(context).pushNamed(
                  "/PickupValidation",
                  arguments: RouteArgument(id: shipment.id.toString())
              ),
          child: IconText(
            icon: Icon(Icons.location_on_outlined, color: Colors.green,),
            text: tr.deliveryConfirm,
          ),
          style: TextButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: Theme.of(context).dividerColor)
              )
          ),
          //contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        ),
      );
    }
    return null;
  }

  bool _canValidate(Shipment shipment) {
    final flags = shipment.flags ?? 0;

    return flags < W_DELIVERED &&
        (flags & INVALID_PICKUP_ADDRESS) != 0 &&
        (flags & W_PICKED) == 0;
  }

  Widget _createTipWidget(dynamic data) {
    TipWidget widget = _createTipWidget0(data) ;
    if (widget != null) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        child: widget,
      );
    }
    return const SizedBox.shrink();
  }

  TipWidget _createTipWidget0(dynamic data) {
    if (data is String) {
      return TipWidget(
        assignTips: [
          TodayTip(
            id: '0',
            content: data,
            type: TodayTipType.tip,
            created: DateTime.now(),
          )],
        tipType: TodayTipType.tip,
      );
    }
    if (data is Map) {
      final tip = TodayTip.fromMap(data);
      return TipWidget(
        assignTips: [tip],
        tipType: tip.type,
      );
    }
    if (data is List) {
      return TipWidget(
        assignTips: data.map((data) => TodayTip.fromMap(data))
            .toList().cast<TodayTip>(),
        tipType: TodayTipType.tip,
      );
    }

    return null;
  }

}
