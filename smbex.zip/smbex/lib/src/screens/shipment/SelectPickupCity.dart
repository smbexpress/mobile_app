part of 'create_shipment_screen.dart';

class SelectPickupCity extends StatefulWidget {
  final ShipmentController shipCtr;
  SelectPickupCity(this.shipCtr);
  @override
  SelectPickupCityState createState() => SelectPickupCityState();
}


class SelectPickupCityState extends State<SelectPickupCity> {
  Shipment shipment;
  bool disposed = false;
  bool showCountry = true;
  @override
  void initState() {
    shipment = widget.shipCtr.shipment;
    Address from = shipment.from;
    Address to = shipment.to;
    List<Country> countries = Api().company.countries;
    if (countries.length == 1){

      if (!(from.country.valid ?? false)) {
        from.country = countries[0];
        from.city = City();
      }
      if (!(to.country.valid ?? false)) {
        to.country = countries[0];
        to.city = City();
      }
      //to.city = from.city = City();
      showCountry = false;
    }

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    disposed = true;

  }


  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);
    List<Country> countries = Api().company.countries;
    Address from = shipment.from;
    Address to = shipment.to;

    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
      children: [

        SizedBox(height: 20,),
        if (showCountry)
          //Text("From Country", style: TextStyles.title),
          createSearchDropdown<Country>(context, tr.from_country, (c) => c.name ?? '',
              key: ValueKey(from.country),
              selected:  from.country.valid ? from.country : null,
              items: countries,
              popupTitle: tr.select_country,
              onChanged: (Country c) async{

                if(from.country != c)
                  _onMounted(() {
                    from.country = c;
                    from.city = City.EMPTY;
                    _validate();
                  });
              }
          ),
        if (showCountry)
          SizedBox(height: 30,),

        //if(from.country.valid)*/Text("From City", style: TextStyles.title,),
        /*if(from.country.valid)*/
        createSearchDropdown<City>(context, tr.from_city, (c) => c.name ?? '',
            key: ValueKey(from.city),
            selected:  from.city.valid ? from.city : null,
            online: true,
            enabled: from.country.valid,
            endpoint: 'cities/search',
            args: {'country': from.country.code},
            popupTitle: tr.select_city,
            convert: (c)  {
              print("SelectPickupCity::convert: $c");
              return City.fromJson(c);
            },
            onChanged: (City c) async{
              print("SelectPickupCity:: to city: ${c.id}:${c.name}");
              if(from.city != c)
                _onMounted(() {
                  from.city = c;
                  _validate();
                });
            }
        ),
        SizedBox(height: 20,),
        Divider(),
        SizedBox(height: 20,),
        if (showCountry)
          createSearchDropdown<Country>(context, tr.to_country, (c) => c.name ?? '',
              key: ValueKey(to.country),
              selected:  to.country.valid ? to.country : null,
              items: countries,
              popupTitle: tr.select_country,
              onChanged: (Country c) {

                if(to.country != c)
                  _onMounted(() {
                    to.country = c;
                    to.city = City.EMPTY;
                    _validate();
                  });


              }
          ),
        if (showCountry)
          SizedBox(height: 30,),
        //if(to.country.valid)Text("To City", style: TextStyles.title),
        if(to.country.valid)
          createSearchDropdown<City>(context, tr.to_city, (c) => c.name ?? '',
              key: ValueKey(to.city),
              selected:  to.city.valid ? to.city : null,
              online: true,
              enabled: to.country.valid,
              endpoint: 'cities/search',
              placeholder: 'Search city',
              args: {'country_id': to.country.id.toString()},
              convert: (c) => City.fromJson(c),
              popupTitle: tr.select_city,
              onChanged: (City c) {
                if(to.city != c)
                  _onMounted((){
                    to.city = c;
                    _validate();
                  });

              }
          ),
        if(widget.shipCtr.errorWidget != null && !widget.shipCtr.loading)
          widget.shipCtr.errorWidget

      ],
    );

  }

  void _validate(){
    widget.shipCtr.validate(0, context);
    setState(() {});
  }

  void _onMounted(Function callback){
    if (mounted){
      callback.call();
    }
  }




}