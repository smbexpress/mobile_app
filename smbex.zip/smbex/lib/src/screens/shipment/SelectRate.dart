part of 'create_shipment_screen.dart';

class SelectRate extends StatelessWidget {
  final ShipmentController shipCtr;
  const SelectRate(this.shipCtr);
  @override
  Widget build(BuildContext context) {
    if (shipCtr.loading)
      return const SizedBox();

    Shipment shipment = shipCtr.shipment;
    List<Rate> rates = shipCtr.rates.items;
    if (rates.isEmpty)
      return Container(
        child: Center(
          child: AnimatedOpacity(
            opacity: 0.0,
            duration: Duration(seconds: 2),
            child: MessagePlaceholder.empty(message: tr.noRateAvailable,),
          ),
        ),
      );
    Rate firstRate = rates.first;
    ThemeData theme = Theme.of(context);

    return MediaQuery.removePadding(
        context: context,
        child: Material(
            //color: Theme.of(context).primaryColor.withOpacity(.5),
            child: Stack(
                alignment: Alignment.topCenter,

                children: <Widget>[
                  ListView.separated(
                    primary: false,
                    separatorBuilder: (context, index) => const SizedBox(height: 20,),
                    itemCount: rates.length + (shipCtr.edit ? 1 : 0),
                    shrinkWrap: true,
                    padding: EdgeInsets.only(top: 20, left: 14, right: 14, bottom: 20),
                    itemBuilder: (context, index) {

                      if (index == 0 && shipCtr.edit){
                        return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(tr.selectRate, style: TextStyles.title,),
                                const SizedBox(height: 10,),
                                if (firstRate.taxNote != null)
                                  Text(firstRate.taxNote, style: TextStyles.bodySm,),
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: tr.confirmShipmentTermLink,
                                        style: TextStyles.bodySm.copyWith(color: LightColor.iconColor),
                                      ),
                                      TextSpan(
                                        text: tr.termAndConditions,
                                        style:TextStyles.bodySm.copyWith(fontWeight: FontWeight.w500, color: Colors.blue) ,
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = ()=> Helper.launchWebsite('term-and-conditions'),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                        );
                      }
                      if (shipCtr.edit){
                        index--;
                      }
                      Rate rate = rates[index];
                      bool selected = rate == shipment.rate;
                      Widget tile = ListTile(
                        key: ValueKey(rate),
                        title: Text(rate.name),
                        subtitle: Text(rate.description??"      "),
                        leading: Icon(
                          shipment.package.type=="d" ? Icons.mail : Icons.all_inbox_rounded,
                          size: 48,
                          color: selected ? theme.colorScheme.secondary : Colors.grey,
                        ),
                        trailing: shipCtr.edit ? Icon(
                          selected? Icons.radio_button_checked : Icons.radio_button_off,
                          size: 28,
                          color: selected ? theme.colorScheme.secondary : Colors.grey,
                        ): null,

                        isThreeLine: false,
                        onTap: () {
                          if (shipment.rate  != rate) {
                            shipment.rate = rate;
                            shipCtr.validate(2, context);
                            shipCtr.setState(() => {});
                          }
                        },
                      );
                      List<Rate> addons = rate.addons;
                      List<Widget> addonW = [];
                      if (addons != null && addons.isNotEmpty){
                        addonW.add(ListTile(
                          title: Text(tr.itemRate, style: TextStyles.body.subTitleColor),
                          //subtitle: Text(arate.description??"", style: TextStyles.bodySm),
                          trailing: Helper.getPrice(rate.rate, context,
                              currency: shipment.currency, style: TextStyles.body.subTitleColor),
                        ));
                        for(int i=0; i < addons.length;i++ ){
                          Rate aRate = addons[i];
                          addonW.add(ListTile(
                            key: ValueKey(aRate),
                            title: Text(aRate.name??"", style: TextStyles.body.subTitleColor),
                            trailing: Helper.getPrice(aRate.total??aRate.rate, context,
                                currency: shipment.currency, style: TextStyles.body.subTitleColor),
                          ));
                          if (i != 0 && i < addons.length -1)
                            addonW.add(Divider(),);
                        }
                      }
                      return Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                              side: BorderSide(color: theme.dividerColor)
                          ),
                          child:Column(children: [
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 10),
                              child: tile,
                            ),
                            Divider(),
                            //ExpanedableWidget(title: null)
                            ExpanedableWidget(
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(tr.total, style: TextStyles.title),
                                  Helper.getPrice(rate.total??rate.rate, context,
                                      style: TextStyles.title.bold.subTitleColor,
                                      currency: shipment.currency),
                                ],
                              ),
                              children: addonW,
                              tilePadding: EdgeInsets.symmetric(horizontal: 16, vertical: 0),

                            )
                          ],)
                      );

                    },
                  )
                ]
            )
        )
    );


  }

}
