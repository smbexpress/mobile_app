import 'dart:math';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart' hide Step;
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lifecycle/lifecycle.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:showcaseview/showcaseview.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/i18n/i18n.dart';
import 'package:smbex_app/src/app_state.dart';
import 'package:smbex_app/src/controllers/shipment_controller.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/screens/shipment/select/shipment_address_select.dart';
import 'package:smbex_app/src/screens/shipment/select_date.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/icon_text.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../api.dart';
import '../../models/address.dart';
import '../../theme/dash_painter.dart';
import '../../theme/extention.dart';
import '../../theme/theme.dart';
import '../../widgets/CommonWidget.dart';
import '../../widgets/ExpanedableWidget.dart';
import '../../widgets/SlidingUpPanelWidget.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/SttepperWidget.dart';
import '../../widgets/connection_status_widget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/stack_body.dart';
import '../../widgets/system_ui_overlay_mixin.dart';

part 'SelectPickup.dart';
part 'SelectPickupCity.dart';
part 'SelectRate.dart';
part 'ShipmentContent.dart';

class CreateShipmentScreen extends StatefulWidget {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  RouteArgument routeArgument;
  bool controllerInited = false;
  bool edit = true;
  CreateShipmentScreen({Key key, this.routeArgument, this.edit = true})
      : super(key: key);
  @override
  _CreateShipmentScreenState createState() => _CreateShipmentScreenState(edit);
}

class _CreateShipmentScreenState extends StateMVC<CreateShipmentScreen> {
  // MUST BE MAINTAINED, SEPARATELY.
  PageController _pageController;
  Color activeColor = Colors.green;
  Color selectedColor = Colors.lightBlue;
  Color iconColor = Color(0xAA9da9bb);
  Color activeIconColor = LightColor.white;
  Color stepColor = Color(0xAAd8e2ef);
  Shipment shipment;
  ShipmentController _con;
  Widget mainLoader;

  ScrollController _scrollViewController;
  ErrorResult errorResult;
  ValueNotifier<int> stepController;
  AddressSelectController _addressSelectController;
  DateTime created;
  _CreateShipmentScreenState(bool edit) : super(ShipmentController(edit)) {
    _con = controller;
  }

  @override
  void initState() {
    _pageController = PageController(keepPage: true);
    stepController = ValueNotifier(0);
    _scrollViewController = new ScrollController();
    _scrollViewController.addListener(onScroll);
    _addressSelectController = widget.edit ? AddressSelectController() : null;
    _con.newShipment();
    created = DateTime.now();
    super.initState();
  }

  @override
  void dispose() {
    _scrollViewController.removeListener(onScroll);
    _pageController?.dispose();
    _scrollViewController?.dispose();
    _addressSelectController?.dispose();
    super.dispose();
  }

  void onScroll() {
    setState(() {});
  }

  _afterLayout() {
    _navigate(_con.pageIndex, false);
  }

  //@override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    Widget child = Stack(
      fit: StackFit.expand,
      children: [
        Container(
          color: Theme.of(context).colorScheme.onPrimary,
        ),
        Positioned(
            height: 130,
            left: 0,
            right: 0,
            child: AnnotatedRegion<SystemUiOverlayStyle>(
              value: AppTheme.blueOverlayStyle,
              child: Container(
                constraints: BoxConstraints(maxHeight: 60),
                decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondary,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(12),
                        bottomRight: Radius.circular(12))),
              ),
            )),


        build0(context)
      ],
    );
    child = ConnectionStatusWidget(
      onConnect: () {
        if (shipment == null) {
          _con.newShipment();
        } else if (_con.errorResult != null) {
          if (_con.retryFunc != null) {
            _con.retryFunc.call();
          }
        }
      },
      child: LifecycleWrapper(
          onLifecycleEvent: (event) {
            if (event == LifecycleEvent.active) {
              if (shipment != null && !editShipmentState.isLoading && !editShipmentState.validate()) {
                WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
                  shipment = null;
                  _navigate(0);
                  _con.newShipment();
                });
              }
            }
          },
          child: GestureDetector(
              child: widget.edit
                  ? ShipmentAddressSelect(
                    shipmentController: _con,
                    controller: _addressSelectController,
                    child: child,
                  )
                  : child,
              onTap: (){
                FocusScope.of(context).unfocus();
              }
          ),

      ),
    );

    final finalChild = ShowCaseWidget(
        builder: Builder(
          builder: (context) => child,
        )
    );
    if (!widget.edit) return finalChild;
    return WillPopScope(
      onWillPop: () async {
        if (_addressSelectController.isPickup != null) {
          _addressSelectController.open(null);
          return false;
        }
        if (stepController.value > 0) {
          _navigate(stepController.value -1);
          return false;
        }
        return true;
      },
      child: finalChild,
    );
  }

  Widget build0(BuildContext context) {
    shipment = _con.shipment;
    if (!widget.controllerInited) {
      //WidgetsBinding.instance.addPostFrameCallback(_afterLayout);
      if (shipment != null) {
        widget.controllerInited = true;
        Future.delayed(Duration(milliseconds: 500), _afterLayout);
      }
    }
    if (shipment == null && !_con.loading && _con.errorResult == null) {
      _con.loading = true;
    }

    return new Scaffold(
        key: _con.scaffoldKey,
        backgroundColor: Colors.transparent,
        body: new NestedScrollView(
            controller: _scrollViewController,
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverPadding(
                  padding: EdgeInsets.only(
                      top: max(24, MediaQuery.of(context).padding.top)),
                ),
                new SliverAppBar(
                  //automaticallyImplyLeading: false,
                  primary: false,
                  //centerTitle:true,
                  //backgroundColor: Theme.of(context).backgroundColor,
                  backgroundColor: Colors.transparent,
                  //elevation: 0,
                  shadowColor: Colors.transparent,
                  title: Text(
                    !_con.edit
                        ? tr.rateShipment
                        : shipment?.valid == true
                            ? tr.editShipment
                            : tr.newShipment,
                    style: Theme.of(context).textTheme.subtitle1.merge(
                        TextStyle(
                            letterSpacing: 1.3,
                            color: Theme.of(context).backgroundColor)),
                  ),

                  leading: new IconButton(
                    icon: new Icon(Icons.arrow_back,
                        color: Theme.of(context).backgroundColor),
                    onPressed: () {
                      if (stepController.value > 0) {
                        _navigate(stepController.value - 1);
                      } else {
                        Navigator.of(context).pop();
                      }
                    },
                    padding: EdgeInsets.all(2),
                  ),
                  pinned: true,
                  floating: true,
                  //flexibleSpace: Placeholder(),
                  snap: innerBoxIsScrolled,
                  expandedHeight: 180,
                  //toolbarHeight: 180,
                  forceElevated: false,
                  bottom: createStepper(context, false),
                  stretch: true,
                ),
                //SliverPadding(padding: EdgeInsets.only(top: 100),),
              ];
            },
            body: LoadingWidget(
              isLoading: _con.loading ||
                  (shipment == null && _con.errorResult == null),
              child: Container(
                child: shipment == null
                    ? _con.errorResult != null
                    ? Center(
                  child:
                  MessagePlaceholder.error(error: _con.errorResult),
                )
                    : SizedBox()
                    : StackBodyWidget(
                  body: createPageView(context),
                  footer: createFooter(),
                ),
                color: Theme.of(context).colorScheme.onPrimary,
              ),
            )
        )
    );
  }

  Widget createStepper(BuildContext context, [bool withContainer = true]) {
    var offset =
        _scrollViewController.hasClients ? _scrollViewController.offset : 0.0;

    final pad = max(min(-16 * offset / 180 + 16.0, 16), 0).toDouble();
    final rad = max(min(-12 * offset / 180 + 12.0, 12), 0).toDouble();
    //print("scroll: $pad");
    final container = Container(
        alignment: Alignment.center,
        height: 110,
        padding: EdgeInsets.symmetric(
          horizontal: pad,
        ),
        child: Container(
          padding: EdgeInsets.only(top: 20),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            //color: Colors.red,
            boxShadow: [
              BoxShadow(
                  color: Colors.grey,
                  spreadRadius: 0,
                  blurRadius: pad,
                  offset: Offset(0.0, pad / 2))
            ],
            borderRadius: BorderRadius.circular(rad),
            // borderRadius: BorderRadius.circular(5.0),
          ),
          child: StepperWidget(
            selectedIndex: stepController.value,
            iconSize: 24.0 * 1.2,
            items: [
              StepItem(tr.setup, Icons.add_location),
              StepItem(tr.content, Icons.article_rounded),
              StepItem(tr.review, Icons.verified_user)
            ],
            onIndexChange: (index) {
              _navigate(index);
              return true;
            },
          ),
        ));
    if (!withContainer) {
      return PreferredSize(
        child: container,
        preferredSize: Size(MediaQuery.of(context).size.width, 110),
      );
    }
    return container;
  }

  Widget createPageView(BuildContext context) {
    if (!_con.loading && (_con.errorWidget == null || errorResult != _con.errorResult) &&
        (_con.errorResult != null || _con.retryFunc != null)) {
      _con.errorWidget = MessagePlaceholder.error(
        error: _con.errorResult,
        onRetry: _con.retryFunc,
      );
    }
    print(
        "-------------createPageView: ${_pageController.initialPage}--------------");
    return Form(
      key: widget.formKey,
      child: PageView(
        controller: _pageController,
        physics: NeverScrollableScrollPhysics(),
        children: <Widget>[
          _con.edit
              ? SelectPickup(_con, null, _addressSelectController)
              : SelectPickupCity(_con),
          ShipmentContent(_con, null),
          SelectRate(_con),
        ],
      ),
    );
  }

  Widget createFooter() {
    //if (stepController.value == 2 && !_con.edit)
    //  return null;
    //ThemeData theme = Theme.of(context);
    return Container(
        padding: EdgeInsets.fromLTRB(
            20, 5, 20, MediaQuery.of(context).padding.bottom + 3),
        decoration: BoxDecoration(
          border: Border(
            top: Divider.createBorderSide(context, width: 1.0),
          ),
          //color: theme.primaryColor,
          //borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20)),
          //boxShadow: [BoxShadow(color: theme.focusColor.withOpacity(0.15), offset: Offset(0, -2), blurRadius: 5.0)]
        ),
        child: ElevatedButton(
          onPressed: _con.valid
              ? () {
                  if (widget.formKey.currentState.validate()) {
                    widget.formKey.currentState.save();
                    if (stepController.value < 2) {
                      _navigate(stepController.value + 1);
                    } else if (_con.edit) {
                      _con.save(shipment, context).then((result) {
                        if (!result.hasError) {
                          Shipment ship = result.item;
                          if (ship.meta == null) {
                            ship.meta = {};
                          }
                          ship.meta['isNew'] = true;
                          Navigator.of(context).pushReplacementNamed(
                              '/ShipmentDetail',
                              arguments:
                                  new RouteArgument(id: '0', param: ship));
                        }
                      });
                    } else {

                      Navigator.of(context)
                          .pushNamedAndRemoveUntil('/Home',
                              (Route<dynamic> route) => false
                      );
                    }
                  }
                }
              : null,
          style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 4),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8))),
          //disabledColor: theme.focusColor.withOpacity(0.5),
          //padding: EdgeInsets.symmetric(vertical: 8),
          //color: theme.accentColor,
          //shape: StadiumBorder(),
          child: Text(
            stepController.value < 2
                ? t.buttons.next
                : _con.edit
                    ? tr.buttons.confirm
                    : tr.buttons.finish,
            textAlign: TextAlign.start,
            //style: TextStyle(color: theme.primaryColor),
          ),
        ));
  }

  _navigate(int index, [bool animate = true]) {
    if (index > stepController.value && !_con.valid) return;
    if (stepController.value != index &&
        _addressSelectController?.isPickup != null) {
      _addressSelectController.open(null);
    }
    print("-------------------------_navigate[$index]----------------------");
    setState(() {
      stepController.value = index;
      if (_pageController.hasClients) {
        if (animate) {
          _pageController.animateToPage(index,
              duration: Duration(milliseconds: 500), curve: Curves.decelerate);
        } else {
          _pageController.jumpToPage(index);
        }
      }
      _scrollToTop();
      _con.validate(index, context);
    });
  }

  _scrollToTop() {
    _scrollViewController.animateTo(
      0.0,
      duration: const Duration(microseconds: 1),
      curve: new ElasticInCurve(0.01),
    );
  }
}
