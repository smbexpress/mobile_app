import 'package:flutter/material.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/helpers/upgrader.dart';
import 'package:smbex_app/src/models/model.dart';

import '../../../i18n/i18n.dart';
import '../../api.dart';
import '../../config.dart';
import '../../helpers/navigation.dart';
import '../../models/route_argument.dart';
import '../../models/shipment.dart';
import '../../widgets/SmbWidget.dart';
import '../../widgets/loading_widget.dart';
import '../../widgets/page_transition.dart';
import '../../widgets/stylish_dialog.dart';
import '../pdf_viewer.dart';

void _makeRequest(BuildContext context, String confirmMessage, String endpoint, VoidCallback callback) async{
  Navigator.of(context).pop();
  final confirm = await alert(
      context,
      title: Text(tr.buttons.confirm),
      content: Text(confirmMessage)
  );
  if (confirm == true){
    final loader = Helper.overlayLoader(context);
    Overlay.of(context).insert(loader);
    var result = null;
    try {
      result = await ResultItem.of(Api().post(endpoint), null);
      if(result.hasError) {
        result = result.error;
      }
    } catch(e){
      result = ErrorResult.tryError(e);
    }
    Helper.hideLoader(loader);
    if (result is ErrorResult){
      showSnackBar(context, error: result);
    } else {
      showNotifyDialog(context,
        title: tr.done,
        showMessage: false,
        contentType: ContentType.SUCCESS,
        duration: Duration(seconds: 3)
      );
      callback();
    }
  }
}

bool shipmentHasActions(Shipment shipment){
  int childCount = 0;
  if (!isWaitingPayment(shipment) && shipment.status == 'p') childCount++;
  //if(shipment.canEdit) childCount++;
  if (['p', 'm'].contains(shipment?.status?.code)) childCount++;
  if (!['p', 'c', 'd'].contains(shipment?.status?.code)) childCount += 3;
  return childCount > 0;
}

void showShipmentBottomSheet(BuildContext context, Shipment shipment, VoidCallback callback) async {

  int childCount = 0;
  if (!isWaitingPayment(shipment) && shipment.status == 'p') childCount++;
  //if(shipment.canEdit) childCount++;
  if (['p', 'm'].contains(shipment?.status?.code)) childCount++;
  if (!['p', 'c', 'd'].contains(shipment?.status?.code)) childCount += 3;

  if (childCount == 0)
    return;

  final parentContext = context;
  final itemHeight = 60.0;
  final height = childCount * itemHeight + 48.0;

  print("showShipmentBottomSheet: height: $height");
  final mq = MediaQuery.of(context);
  showModalBottomSheet(
    context: context,
    isDismissible: true,
    constraints: BoxConstraints(
        maxWidth: mq.size.width - 32,
    ),
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    shape: const RoundedRectangleBorder(
      borderRadius: const BorderRadius.all(const Radius.circular(12.0)),
    ),
    builder: (context) {
      StateSetter stateSetter;
      bool isLoading = false;
      return SafeArea(
          minimum: EdgeInsets.only(
              top: mq.padding.top,
              bottom: mq.viewInsets.bottom + 16
          ),
        child: Padding(
            padding: EdgeInsets.only(bottom: 12, top: 5),
            //color: Colors.red,
            child: IntrinsicHeight(
              child: Material(
                color: Theme.of(context).cardColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 10,
                      child: Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Theme.of(context).dividerColor.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                    ),
                    if(!isWaitingPayment(shipment) && shipment.status == 'p')
                      ListTile(
                        leading: Icon(Icons.send),
                        title: Text(tr.buttons.confirm),
                        onTap: () async {
                          Navigator.pop(context);
                          generateWaybill(parentContext, callback, shipment.id);
                        },
                      ),
                    /*
                    if(shipment.canEdit)
                      ListTile(
                        leading: Icon(Icons.cancel),
                        title: Text(tr.editShipment),
                        onTap: () async {
                          Navigator.of(context).pushReplacementNamed('/ShipmentEdit',
                              arguments: new RouteArgument(id: shipment.id?.toString(), param: shipment));
                        },
                      ),

                     */
                    if (['p', 'm'].contains(shipment?.status?.code))
                      ListTile(
                        leading: Icon(Icons.cancel),
                        title: Text(tr.cancelShipment),
                        onTap: () async {
                          //Navigator.of(context).pop();
                          cancelShipment(parentContext, callback, shipment.id);
                        },
                      ),
                    if (!['p', 'c', 'r'].contains(shipment?.status?.code))
                      ...[
                      ListTile(
                        leading: Icon(Icons.reply),
                        title: Text(tr.createReturnShipment),
                        onTap: () async {
                          returnShipment(parentContext, callback, shipment.id);

                        },
                      ),

                      ListTile(
                        leading: Icon(Icons.picture_as_pdf, ),
                        title: Text(tr.showPdfLabel),
                        onTap: () async {
                          Navigator.of(context).pop();
                          showPdfLabel(parentContext, shipment.id);

                        },
                      ),
                      ListTile(
                        leading: Icon(Icons.money, ),
                        title: Text(tr.showWaybillInvoice),
                        onTap: () async {
                          Navigator.of(context).pop();
                          showWaybillInvoice(parentContext, shipment.id);

                        },
                      ),
                    ],
                    SizedBox(height: 6,)

                  ],
                ),
              ),
            )
        )
      );
    },

  );
}

void showPdfLabel(BuildContext context, int id){
  final loader = Helper.overlayLoader(context);
  Overlay.of(context).insert(loader);
  ResultItem.get('shipments/${id}/pdfurl')
      .then((response){
    if (response.hasError){
      showNotifyDialog(context,
          error: response.error,
          duration: const Duration(seconds: 8)
      );

    } else {
      Navigation.navigateTo(context: context,
          screen: PdfViewer(title: tr.pdfLabel, url: response.item['url']));

    }
  }).whenComplete(() => Helper.hideLoader(loader));
}

void showWaybillInvoice(BuildContext context, int id){
  final loader = Helper.overlayLoader(context);
  Overlay.of(context).insert(loader);
  ResultItem.get('shipments/${id}/waybillInvoice')
      .then((response){
    if (response.hasError){
      showNotifyDialog(context, error: response.error)  ;

    } else {
      final url = '${Config().url}${response.item['url']}';
      Navigation.navigateTo(context: context,
          screen: PdfViewer(title: tr.waybillInvoice, url: url));

    }
  }).whenComplete(() => Helper.hideLoader(loader));
}

void generateWaybill(BuildContext context, VoidCallback callback, int id) async{

  final dialog = showNotifyDialog(context,
      showMessage: false,
      showTitle: false,
      contentType: ContentType.PROGRESS,
      duration: null,
      show: false,
      dismissOnTouchOutside: false
  );
  dialog.show();
  ResultItem result = await ResultItem.of(Api().post('shipments/${id}/confirm'), (data) => data) ;
  dialog.dismiss();
  if (result.hasError){
    showNotifyDialog(context, error: result.error, duration: null);
  } else {
    showSuccessDialog(context);
    callback?.call();
  }
}

void cancelShipment(BuildContext context, VoidCallback callback, int id) async{
  _makeRequest(
      context,
      "Are you sure you want to cancel this shipment?",
      "shipments/$id/cancel",
      callback
  );
}

void returnShipment(BuildContext context, VoidCallback callback, int id) async{
  _makeRequest(
      context,
      "Are you sure you want to return for this shipment?",
      "shipments/$id/cancel",
      callback
  );
}

bool isWaitingPayment(Shipment shipment){
  return shipment != null && (shipment.status.code == 'w' ||
      (shipment.amountToDue != null && shipment.amountToDue >= .5));
}