part of 'create_shipment_screen.dart';

class ShipmentContent extends StatefulWidget {
  final ShipmentController shipCtr;
  final ScrollController scrollController;
  ShipmentContent(this.shipCtr, this.scrollController);
  @override
  State<StatefulWidget> createState() => ShipmentContentState();
}

class ShipmentContentState extends State<ShipmentContent> {
  final GlobalKey _codHelpKey = GlobalKey();
  final ValueNotifier<bool> packageExpandedTrigger = new ValueNotifier(false);
  SlidingUpPanelController slidePanelController;
  Shipment shipment;
  @override
  void initState() {
    shipment = widget.shipCtr.shipment;
    slidePanelController =
        new SlidingUpPanelController(value: SlidingUpPanelStatus.hidden);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery.removePadding(
        context: context,
        child: Stack(
            alignment: Alignment.topCenter,
            children: <Widget>[_body(context), createSlidePanel(context)]));
  }

  Widget _body(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Flexible(
            child: Container(
          margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
          child: ListView(
            children: [
              createPackageCard(context),
              if (shipment.package != null && shipment.package.valid)
                Padding(
                  padding:
                      EdgeInsets.only(left: 10, top: 10, right: 10, bottom: 50),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: createContent(),
                  ),
                )
            ],
            shrinkWrap: true,
            primary: true,
            padding: EdgeInsets.zero,
          ),
        ))
      ],
    );
  }

  Widget createPackageCard(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(10, 24, 10, 10),
          child: Text(
            tr.tapToSelectPackageType,
            style: TextStyles.title,
          ),
        ),

        Container(
            margin: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Theme.of(context).dividerColor)),
            //margin: EdgeInsets.only(top: 10),
            child: ListTile(
              contentPadding:
                  EdgeInsets.symmetric(vertical: 15, horizontal: 10),
              title: Text(
                shipment.package.name ?? tr.packageType,
                style: TextStyles.titleM.accent,
              ),
              subtitle: Text(
                shipment.package.description ?? tr.tapToSelectPackageType,
                style: TextStyles.bodySm,
              ),
              leading: Icon(
                  shipment.package.type == "d"
                      ? Icons.mail
                      : Icons.all_inbox_rounded,
                  size: 48),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 1.0,
                    color: Theme.of(context).dividerColor,
                    margin: const EdgeInsets.symmetric(horizontal: 5),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 2),
                    child: Icon(Icons.keyboard_arrow_down_outlined, size: 28),
                  )
                ],
              ),
              onTap: () =>
                  {slidePanelController.value = SlidingUpPanelStatus.expanded},
            )),

        //if (shipment.package != null)
      ],
    );
  }

  List<Widget> createContent() {
    final p = shipment.package;

    List<Widget> children = [];

    if (widget.shipCtr.edit) {
      children.add(SizedBox(
        height: 5,
      ));
      children.add(textField(
        context,
        labelText: tr.content,
        keyboardType: TextInputType.multiline,
        maxLines: 2,
        initialValue: shipment.content,
        onSaved: (input) {
          shipment.content = input;
        },
        onChanged: (input) {
          setState(() {
            shipment.content = input;
            _validate();
            //print("Content changed");
          });
        },
        validator: (input) => widget.shipCtr.validateInput('content', input),
      ));
      children.add(SizedBox(
        height: 5,
      ));
      children.add(Text(
        tr.form.minLengthErrorText(10),
        style: TextStyle(fontSize: 11),
      ));
    }

    if (p.isWeight) {
      children.add(SizedBox(
        height: 20,
      ));
      //children.add(Text("Weight", style: TextStyles.title,));
      //children.add(SizedBox(height: 10,));
      children.add(textField(context,
          labelText: tr.weight,
          initialValue: shipment.hasWeight ? shipment.weight.toString() : null,
          keyboardType: TextInputType.number,
          onSaved: (input) {
            shipment.weight = double.tryParse(input);
          },
          onChanged: (input) {
            setState(() {
              shipment.weight = double.tryParse(input);
              _validate();
            });
          },
          validator: (input) => widget.shipCtr.validateInput('weight', input),
          suffixIcon: Container(
            width: 60,
            alignment: Alignment.center,
            child: Text(
              "KG",
              style: TextStyles.title,
            ),
            //color: Theme.of(context).backgroundColor,
            //constraints: BoxConstraints(maxHeight: 60),
            //padding: EdgeInsets.symmetric(horizontal: 4),
            //alignment: Alignment.center,
          ),
          helperText: shipment.package.hasMaxWeight
              ? tr.form.maxErrorText(shipment.package.weight)
              : null));
    }

    if (p.hasItems){
      if (shipment.parcelCount == null || shipment.parcelCount == 0)
        shipment.parcelCount = 1;

      children.add(Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 0),
        child: InputDecorator(
          decoration: InputDecoration(
              prefixIcon: TextButton(
                  onPressed: shipment.parcelCount > 1
                      ? () {
                    shipment.parcelCount--;
                    setState(() {});
                    _validate();
                  }
                      : null,
                  child: Icon(Icons.remove)
              ),
              suffixIcon: TextButton(
                  onPressed: shipment.parcelCount < p.maxItems
                      ? () {

                    shipment.parcelCount++;
                    _validate();
                    setState(() {});
                  }
                      : null,
                  child: Icon(Icons.add)
              ),
              labelText: tr.parcelQuantity
          ),
          child: Text(
            shipment.parcelCount.toString(),
            style: Theme.of(context).textTheme.titleMedium,
            textAlign: TextAlign.center,
          ),
        ),
      ));
    }

    if (p.hasCod) {
      Iterable<String> currencies = shipmentMetaLoadState.value.currencies.keys;
      print("Available COD currencies: $currencies");
      //_codHelpKey
      children.add(
        Padding(
            padding: const EdgeInsets.fromLTRB(15, 26, 15, 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  tr.cash_on_delivery,
                  style: TextStyles.title,
                ),
                Showcase(
                    key: _codHelpKey,
                    child: TextButton(
                      child: Icon(Icons.info_outline),
                      onPressed: () {
                        ShowCaseWidget.of(context).startShowCase([_codHelpKey]);
                      },
                    ),
                    description: tr.cash_on_delivery_amount
                )
              ],
            )
        )
      );
      /*
      children.add(Tooltip(
        message: tr.cash_on_delivery_amount,
        textStyle: TextStyles.titleM.white,
        //showDuration: Duration(milliseconds: 500),
        waitDuration: Duration(seconds: 10),
        padding: const EdgeInsets.fromLTRB(15, 26, 15, 10),
        //triggerMode: TooltipTriggerMode.manual,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              tr.cash_on_delivery,
              style: TextStyles.title,
            ),
            TextButton(
              child: Icon(Icons.info_outline),
              onPressed: () {},
            )
          ],
        ),
      ));

       */

      children.add(textField(context,
          hintText: tr.cash_on_delivery_amount,
          labelText: tr.cash_on_delivery,
          keyboardType: TextInputType.number,
          initialValue: shipment.hasCod ? shipment.cod.toString() : null,
          onSaved: (input) {
            shipment.cod = double.tryParse(input);
          },
          onChanged: (input) {
            shipment.cod = double.tryParse(input);
            _validate();
          },
          validator: (input) => widget.shipCtr.validateInput('cod', input),
          suffixIcon: Padding(
            //width: 123,
            //alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 1,
                    height: 30,
                    color: Theme.of(context).dividerColor,
                  ),
                  const SizedBox(width: 6,),
                  DropdownButton(
                      value: shipment.codCurrency,
                      style: TextStyles.title,
                      underline: SizedBox(),
                      //onTap: ()=> FocusTraversalGroup(child: child),
                      onChanged: (value) {
                        setState(() {
                          shipment.codCurrency = value;
                          _validate();
                        });
                      },
                      items: currencies
                          .map((cur) => DropdownMenuItem(
                          value: cur,
                          child: Text(cur, textAlign: TextAlign.center)))
                          .toList()
                  ),
                  //const SizedBox(width: 4,),
                ],
              ))));
    }

    return children;
  }

  Widget createPackageItem(BuildContext context, Package p) {
    final selected = p.id == shipment.package.id;
    return ListTile(
      key: ValueKey(p),
      title: Text(
        p.name,
        style: TextStyles.titleM.accent,
      ),
      subtitle: Text(
        p.description ?? "",
        style: TextStyles.bodySm,
      ),
      leading: Icon(
        p.type == "d" ? Icons.mail : Icons.all_inbox_rounded,
        size: 48,
        color: selected ? Theme.of(context).colorScheme.secondary : null,
      ),
      trailing: Icon(
        selected ? Icons.check_box : Icons.check_box_outline_blank,
        color: selected ? Theme.of(context).colorScheme.secondary : null,
        size: 28,
      ),
      onTap: () {
        setState(() {
          packageExpandedTrigger.value = false;
          slidePanelController.hide();
          if (shipment.package != p) {
            shipment.package = p;
            _validate();
          }
        });
      },
    );
  }

  void _validate() {
    widget.shipCtr.validate(1, context);
  }

  @override
  void dispose() {
    slidePanelController?.dispose();
    super.dispose();
  }

  Widget createSlidePanel(BuildContext context) {
    final childs = <Widget>[];
    int len = widget.shipCtr.packages.length;
    widget.shipCtr.packages.items.forEach((e) => {
          childs.add(createPackageItem(context, e)),
          childs.add(Divider()),
          len--,
          if (len == 0)
            {
              childs.add(SizedBox(
                height: 20,
              ))
            }
        });
    print("Has ${widget.shipCtr.packages.length} package's!");

    TextStyle titleStyle = TextStyles.title.copyWith(fontSize: 20).bold;
    if (AppTheme.fullWidth(context) < 393) {
      titleStyle = TextStyles.title.copyWith(fontSize: 18).bold;
    }

    return SlidingUpPanelWidget(
      controlHeight: 50,
      panelController: slidePanelController,
      panelStatus: SlidingUpPanelStatus.hidden,
      anchor: 0,
      child: Container(
        //margin: EdgeInsets.symmetric(horizontal: 15.0),
        decoration: ShapeDecoration(
          color: Theme.of(context).cardColor,
          shadows: [
            BoxShadow(
                blurRadius: 6.0,
                spreadRadius: 1.0,
                color: const Color(0x51000000))
          ],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15.0),
              topRight: Radius.circular(15.0),
            ),
          ),
        ),
        child: Column(
          children: <Widget>[
            Container(
              alignment: Alignment.center,
              child: Text(
                "Package Types",
                style: titleStyle,
              ),
              padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
            ).ripple(() => slidePanelController.hide()),
            Divider(
              height: 0.5,
              color: Colors.grey[300],
            ),
            Flexible(
              child: Container(
                child: Material(
                  //color: Theme.of(context).primaryColor,
                  child: ListView(
                    children: childs,
                    shrinkWrap: true,
                    //primary: true,
                  ),
                ),
              ),
            ),
          ],
          mainAxisSize: MainAxisSize.min,
        ),
      ),
      onTap: () {
        ///Customize the processing logic
        if (SlidingUpPanelStatus.anchored == slidePanelController.status ||
            SlidingUpPanelStatus.collapsed == slidePanelController.status ||
            SlidingUpPanelStatus.dragging == slidePanelController.status) {
          slidePanelController.hide();
        } else {
          slidePanelController.expand();
        }
      },
      enableOnTap: true,
    );
  }
}
