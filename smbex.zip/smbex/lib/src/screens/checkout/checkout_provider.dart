import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/oppwa/oppwa.dart';

import '../../../i18n/i18n.dart';
import '../../config.dart';
import '../../models/cart.dart';
import '../../models/model.dart';
import '../../models/payment_method.dart';
import '../../theme/text_styles.dart';
import '../../widgets/CreditCardCVVSheetWidget.dart';
import '../../widgets/SmbWidget.dart';

class CheckoutProvider extends ChangeNotifier {
  ValueNotifier<Cart> _cart = ValueNotifier<Cart>(null);
  ValueNotifier<PaymentMethodItem> _paymentMethod =
      ValueNotifier<PaymentMethodItem>(null);
  ValueNotifier<String> paymentStatus = ValueNotifier(null);
  Transaction _currentTx;
  bool loading = false;
  ErrorResult error;
  ScaffoldState scaffoldState;
  String message;
  OverlayEntry loader;

  void reset() {
    loading = false;
    error = null;
    message = null;
    _currentTx = null;
    paymentStatus.value = null;
    _paymentMethod.value = null;
    _cart.value = null;
  }

  void initCart(BuildContext context, Cart cart, int id) {
    scaffoldState = context.findAncestorStateOfType<ScaffoldState>();
    if (loader != null) {
      Helper.hideLoader(loader);
    }

    if (this.scaffoldState != null)
      loader = Helper.overlayLoader(this.scaffoldState);

    loading = false;
    error = null;
    message = null;
    _currentTx = null;
    paymentStatus.value = null;
    _paymentMethod.value = null;
    _cart.value = null;
    _requestCart(cart.type, id);
  }

  void dispose() {
    super.dispose();
    paymentStatus.dispose();
    _paymentMethod.dispose();
    _cart.dispose();

    if (loader != null) {
      Helper.hideLoader(loader);
    }
    loader = null;
  }

  Future<void> _requestCart(String type, int id) async {
    if (loading) return Future<void>.value();
    loading = true;
    WidgetsBinding.instance
        .addPostFrameCallback((timeStamp) => notifyListeners());
    return _updateCart(ResultItem.post<Cart>("${type}/cart",
        data: {'id': id}, func: (res) => Cart.fromJSON(res)));
  }

  void setPaymentMethod(PaymentMethodItem item, [bool checkout = true]) {
    PaymentCard card = item.ref is PaymentCard ? item.ref as PaymentCard : null;
    PaymentMethod method =
        card != null ? card.method : item.ref as PaymentMethod;
    method.defaultCart = card;
    _paymentMethod.value = item;
    loading = false;
    error = null;
    message = null;
    _currentTx = null;
    paymentStatus.value = null;
    if (item.method?.provider == 'hyperpay' && checkout) {
      goCheckout(scaffoldState.context);
    } else if (card != null) {
      cart.paymentMethod = item;
    }

    notifyListeners();
  }

  Future<void> _updateCart(Future<ResultItem<Cart>> cartResult) {
    error = null;
    return cartResult.then((ResultItem<Cart> result) {
      loading = false;
      if (!result.hasError) {
        PaymentMethodItem paymentMethod = result.item.paymentMethod;
        _cart.value = result.item;
        if (paymentMethod != null) {
          setPaymentMethod(paymentMethod, false);
        } else {
          notifyListeners();
        }
      } else {
        error = result.error;
        Config.debug("_updateCart error: $error", runtimeType);
        notifyListeners();
      }
    }).catchError((error, stack) {
      error = ErrorResult.tryError(error, stack);
      loading = false;

      Config.error("_updateCart exception: $error", stack, runtimeType);
      notifyListeners();
    });
  }

  void onCheckout(BuildContext context) {
    if (cartPaymentMethod.ref is PaymentCard) {
      showPaymentCardCVVSheetWidget(context);
    } else if (cartPaymentMethod.method?.provider == 'hyperpay') {
      goCheckout(context);
    }
  }

  void goCheckout(BuildContext context) {
    PaymentCard card = paymentMethod.ref is PaymentCard
        ? paymentMethod.ref as PaymentCard
        : null;
    PaymentMethod method =
        card != null ? card.method : paymentMethod.ref as PaymentMethod;
    error = null;
    message = null;
    notifyListeners();

    Map<String, dynamic> data = {
      'acquirer_id': int.parse(method.id),
      'ids': _cart.value.items.map((e) => e.id).toList(),
      'with_tokens': false,
      'with_pm': false
    };

    if (card != null) {
      data['payment_token_id'] = int.parse(paymentMethod.id);
    }
    data['route'] = _cart.value.route;

    _showLoading();

    ResultItem.of<dynamic>(
            Api().post("${_cart.value.type}/checkout", data: data), null)
        .then((ResultItem<dynamic> result) {
      if (!result.hasError) {
        Config.debug("notification_url: ${result.item['notification_url']}",
            runtimeType);
        Transaction tx = result.item['tx'] != null
            ? Transaction.fromJSON(result.item['tx'])
            : null;
        Cart txCart = result.item['cart'] != null
            ? Cart.fromJSON(result.item['cart'])
            : null;
        txCart.paymentMethod = paymentMethod;
        loading = false;
        message = tx == null ? "Warning: Cart was updated" : null;
        notifyListeners();
        //currentCart.value = txCart;
        _setTransaction(tx, txCart);
      } else {
        Config.debug(
            "Receive error post checkout with data: ${data}", runtimeType);
        loading = false;
        error = result.error;
        notifyListeners();

        _currentTx = null;
      }
    }).whenComplete(_hideLoading);
  }

  void _setTransaction(Transaction tx, Cart txCart) {
    _currentTx = tx;
    if (tx != null) {
      String status = tx.status;
      paymentStatus.value = status;
      if (status != 'error' && tx.provider == 'hyperpay') {
        Map<String, dynamic> data = {
          'checkoutId': tx.checkoutId,
          'brand': tx.brands,
          'amount':
              tx.mode == 'test' ? tx.amount?.toInt()?.toDouble() : tx.amount,
          'currency': tx.currency,
          'mode': tx.mode == 'test' ? 'TEST' : 'LIVE',
          'type': 'ReadyUI',
          'country': tx.country
        };
        if (paymentMethod.ref is PaymentCard) {
          PaymentCard card = paymentMethod.ref as PaymentCard;
          data.addAll({'type': 'token', 'tokenId': card.ref, 'cvv': card.cvv});
        }
        Config.log("Send Oppwa checkout: $data");
        Oppwa.checkout(data).then((value) async {
          Config.debug("Oppwa checkout result: ${value}", runtimeType);
          if (value is Map) {
            String status = value['status'];

            message = value['message'] ?? null;
            //notifyListeners();

            if (status == 'sync' || status == 'success') {
              await _checkPaymentStatus(tx, status);
            } else if (status == 'redirect') {
              tx.redirectUrl = message;
              _transactionRedirect(tx, message);
              message = null;
            } else {
              message ??= status;
              tx.message = message;
              _transactionFailed(tx, status);
            }
            paymentStatus.value = status;
            notifyListeners();
          }
        }, onError: (error, stackTrace) {
          Config.error('native return error: $error', stackTrace, runtimeType);
          message = '$error';
          paymentStatus.value = 'error';
          tx.message = '$error';

          _transactionFailed(tx, 'error');
        }).whenComplete(() {
          Config.debug("native payment call completetd!!", runtimeType);
        });
      } else {
        paymentStatus.value = tx.status;
        message = tx.message;
        notifyListeners();
        if (status == 'done' || status == 'pending') {
          _transactionSuccess(tx, status);
        } else {
          _transactionFailed(tx, status);
        }
      }
    }
  }

  void _checkPaymentStatus(Transaction tx, String status) async {
    String resourcePath = message;
    loading = true;
    error = null;
    message = null;
    //notifyListeners();

    if (resourcePath != null) {
      try {
        await Api().get("payment/hp/result",
            data: {"txId": tx.id.toString(), "resourcePath": resourcePath});
      } finally {
        _getPaymentStatus(tx, status);
      }
    } else {
      _getPaymentStatus(tx, status);
    }
  }

  void _getPaymentStatus(Transaction tx, String status) async {
    loading = true;
    _showLoading();
    try {
      await _getPaymentStatus0(tx, status, 1);
    } finally {
      loading = false;
      _hideLoading();
      notifyListeners();
    }
  }

  void _getPaymentStatus0(Transaction tx, String status, int retry) async {
    ResultItem<dynamic> result =
        await ResultItem.get<dynamic>("payments/status/poll?id=${tx.id}");

    if (!result.hasError) {
      dynamic item = result.item;
      bool success = item['success'] ?? false;
      String error = item['error'];
      if (success) {
        List<dynamic> transactions = item['transactions'] ?? [];
        transactions.forEach((element) {
          if (element['id'] == tx.id) {
            String state = element['state'];
            tx.update(element);
            if (state == 'done') {
              _transactionSuccess(tx, state);
            } else if (state == 'cancel' || state == 'error') {
              _transactionFailed(tx, state, false);
            } else {}
          }
        });
      } else if (error != null) {
        if (error == 'tx_process_retry') {
          if (retry < 5) {
            Future.delayed(Duration(seconds: 3),
                () => _getPaymentStatus0(tx, status, retry + 1));
            return;
          } else {
            result.error =
                ErrorResult.tryError("Unable to get payment status!");
          }
        } else if (error == 'no_tx_found') {
          //loadCart();
          error = "No transaction for this cart";
          result.error =
              ErrorResult.tryError("No transaction for current cart!");
        } else {
          result.error = ErrorResult.tryError(error);
        }
      }
    }
    _showSnackBar(result.error);
    loading = false;
    notifyListeners();
  }

  void _transactionSuccess(Transaction tx, String status) {
    showSuccessSnackBar(scaffoldState.context, tr.paymentDoneSuccess);
  }

  void _transactionFailed(Transaction tx, String status, [bool fromUi = true]) {
    if (status == 'failed' || status == 'error') {
      _showSnackBar(tx.message);
    }
    if (status == 'cancel') {
      _showSnackBar(tx.message);
    }
  }

  void _transactionRedirect(Transaction tx, String redirect) async {
    /*
    Object result = await Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => HyperpayPaymentWidget(url: redirect, cart: cart, tx: tx)));
    */
    print("_transaction Redirect: ${redirect}");
  }

  void _showLoading() {
    if (loader != null && scaffoldState != null) {
      Overlay.of(scaffoldState.context).insert(loader);
    }
  }

  void _hideLoading() {
    if (loader != null) {
      Helper.hideLoader(loader);
    }
  }

  void _showSnackBar(dynamic message) {
    Config.log("_showSnackBar: $message", runtimeType);
    if (message != null && scaffoldState != null)
      showSnackBar(
        scaffoldState.context,
        error: message,
        showTitle: false,
        duration: Duration(seconds: 10),
      );
  }

  void showPaymentCardCVVSheetWidget(BuildContext context) async {
    final navigator = context.findAncestorStateOfType<NavigatorState>();
    final parentContext = context;

    final scaffoldState = context.findAncestorStateOfType<ScaffoldState>();

    //AnimationController animationController = BottomSheet.createAnimationController(navigator);
    double oldAnimValue = 0;
    GlobalKey<FormState> formKey = new GlobalKey<FormState>();
    GlobalKey<State> stateKey = new GlobalKey<State>();
    ValueNotifier csvValueNotifier = ValueNotifier("");
    await showModalBottomSheet(
      context: parentContext,
      isDismissible: false,
      isScrollControlled: true,
      useRootNavigator: false,
      //transitionAnimationController: animationController,
      enableDrag: false,
      builder: (context) {
        return LayoutBuilder(
            key: stateKey,
            builder: (context, box) {
              final mq = MediaQuery.of(context);

              return SafeArea(
                  //maintainBottomViewPadding: true,
                  minimum: EdgeInsets.only(bottom: mq.viewInsets.bottom),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              tr.payment_options,
                              style: TextStyles.title,
                            ),
                            const Spacer(),
                            InkWell(
                              child: Icon(Icons.close),
                              onTap: () {
                                csvValueNotifier.dispose();
                                //animationController.dispose();
                                Navigator.of(context).pop();
                                //FocusScope.of(context).unfocus();
                              },
                            ),
                            const SizedBox(
                              width: 10,
                            )
                          ],
                        ),
                      ),
                      Divider(
                        height: .5,
                      ),
                      CreditCardCVVSheetWidget(
                        onChange: () {
                          csvValueNotifier.value =
                              (cartPaymentMethod.ref as PaymentCard).cvv;
                          print("csvValueNotifier: ${csvValueNotifier.value}");
                        },
                        formKey: formKey,
                        paymentCard: cartPaymentMethod.ref as PaymentCard,
                        cardNumberDecoration: InputDecoration(
                            labelText: tr.card_number,
                            hintText: 'XXXX XXXX XXXX XXXX',
                            isDense: true,
                            contentPadding: const EdgeInsets.all(10),
                            prefix: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: CachedNetworkImage(
                                imageUrl: cartPaymentMethod.icon,
                                placeholder: (context, url) =>
                                    CircularProgressIndicator(),
                                errorWidget: (context, url, error) =>
                                    Icon(Icons.credit_card),
                                width: 24,
                                height: 24,
                              ),
                            )),
                      ),
                      ValueListenableBuilder(
                        valueListenable: csvValueNotifier,
                        builder: (context, value, child) => Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                  child: Text(
                                    tr.payNow,
                                    //style: TextStyles.title.copyWith(color:LightColor.white),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder()),
                                  onPressed: value?.length == 3
                                      ? () {
                                          if (formKey.currentState.validate()) {
                                            csvValueNotifier.dispose();
                                            //animationController.dispose();
                                            Navigator.of(context).pop();
                                            goCheckout(parentContext);
                                          }
                                        }
                                      : null),
                            )
                          ],
                        ),
                      )
                    ],
                  ));
            });
      },
    );
    //csvValueNotifier.dispose();
    //animationController.dispose();
  }

  Cart get cart => _cart.value;
  bool get hasCart => _cart.value != null && _cart.value.items.isNotEmpty;
  ValueListenable<Cart> get cartListenable => _cart;

  PaymentMethodItem get cartPaymentMethod => cart?.paymentMethod;
  PaymentMethodItem get paymentMethod => _paymentMethod.value;

  ValueListenable<PaymentMethodItem> get paymentMethodListenable =>
      _paymentMethod;
}
