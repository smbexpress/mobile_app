import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/controllers/account_controller.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/repository/account_repository.dart' as accountRepo;
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../../i18n/i18n.dart';
import '../theme/extention.dart';
import '../theme/text_styles.dart';

class OtpVerificationWidget extends StatefulWidget {
  static String TAG = '/MobileOtpVerification';

  OtpVerificationWidget({Key key});

  @override
  OtpVerificationWidgetState createState() =>
      OtpVerificationWidgetState();
}

class OtpVerificationWidgetState
    extends StateMVC<OtpVerificationWidget> {
  Timer _timer;
  int _start = 60;
  AccountController _con;
  int otp;
  int insetOtp;
  bool validOtp = false;
  bool isDone = false;
  TextEditingController _otpController = TextEditingController();

  OtpVerificationWidgetState() : super(AccountController()) {
    _con = controller;
    otp = _con.account.otp;
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
      (Timer timer) => setState(
        () {
          if (_start < 1) {
            timer.cancel();
          } else {
            _start = _start - 1;
          }
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(milliseconds: 1000), () {
      startTimer();
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //changeStatusColor(Theme.of(context).primaryColor);
    var width = MediaQuery.of(context).size.width;
    ThemeData th = Theme.of(context);

    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: _con.scaffoldKey,
          //appBar: appBar(context, automaticallyImplyLeading: false, showBack: false, titleText: S.of(context).verify),
          body: SafeArea(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                      children: <Widget>[
                        SizedBox(height: 60),
                        Text(
                          S.of(context).verify_your_account,
                          style: Theme.of(context).textTheme.headline3.w600,
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 10),
                        Opacity(
                          opacity: 0.7,
                          child: Icon(
                            Icons.verified_user,
                            size: 120.0,
                            color: Colors.orangeAccent,
                          ),
                        ),

                        SizedBox(
                          height: 16,
                        ),
                        Opacity(
                          opacity: 0.7,
                          child: Text(
                            S.of(context).otpSentTo(_con.account.mobile),
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headline3.merge(TextStyle(fontWeight: FontWeight.w300)),
                          ),
                        ),
                        SizedBox(
                          height: 16,
                        ),
                        Form(
                          key: _con.loginFormKey,
                          child: Directionality(
                              textDirection: TextDirection.ltr,

                              child: pinCodeTextField(
                                context,
                                controller: _otpController,
                                onTextChanged: (text) {},
                                onDone: (String code) {
                                  isDone = true;
                                  insetOtp = int.tryParse(code);
                                  setState(() {
                                    //validOtp = insetOtp == otp;
                                    _con.account.otp = insetOtp;
                                    accountRepo.sendToken = code;
                                     _con.verify();
                                  });
                                },
                                hasError: _con.error != null,
                              )),
                        ),
                        SizedBox(
                          height: 50,
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 16, right: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[

                              Row(
                                children: _start == 0
                                    ? <Widget>[
                                        Container(
                                          padding: EdgeInsets.all(8.0),
                                          decoration: BoxDecoration(
                                            color: th.primaryColor,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Icon(
                                            Icons.arrow_back,
                                            color: th.cardColor,
                                          ),
                                        ).ripple((){
                                          Navigator.of(context).pop();
                                        }),
                                        SizedBox(
                                          width: 8,
                                        ),
                                        Text(S.of(context).buttons.back, style:TextStyles.body.bold,),
                                      ]
                                    : [Container()],
                              ),
                              _start == 0
                                   ? Text(S.of(context).resend, style:TextStyles.body.bold.copyWith(color:LightColor.blue))
                                      .p(8).ripple((){
                                      _con.updateAction(Account.ACT_NORMAL);
                                      Navigator.of(context).pushReplacementNamed('/Login', arguments: 3);
                                    })
                                    : Text("$_start Seconds",
                                        style: TextStyle(
                                            color: th.primaryColor, fontSize: 16)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
