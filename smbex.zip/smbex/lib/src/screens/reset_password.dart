import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/models/account.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/widgets/CommonWidget.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';
import 'package:smbex_app/src/widgets/picker/country/country_code.dart';
import '../repository/account_repository.dart' as repository;

import '../../i18n/i18n.dart';
import '../api.dart';
import '../controllers/account_controller.dart';
import '../helpers/helper.dart';
import '../theme/theme.dart';
import '../widgets/picker/country/country_code_picker.dart';

class ResetPasswordWidget extends StatefulWidget {
  bool register;
  ResetPasswordWidget({
    Key key,
  }) : super(key: key);

  @override
  _ResetPasswordWidgetState createState() => _ResetPasswordWidgetState();
}

class _ResetPasswordWidgetState extends State<ResetPasswordWidget> {
  TextEditingController password1;
  TextEditingController password2;
  bool hidePassword ;
  GlobalKey<FormState> formKey;
  _ResetPasswordWidgetState();

  @override
  void initState() {
    password1 = TextEditingController();
    password2 = TextEditingController();
    hidePassword = true;
    formKey  = GlobalKey<FormState>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        //backgroundColor: Color(0xff0451A1),
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: AppTheme.whiteOverlayStyle,
          child: LayoutBuilder(
            builder: (context, box) {

              return SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20 + MediaQuery.of(context).padding.top,
                    ),
                    SizedBox(
                      height: max(0, 180  ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(20),
                      child: Form(
                        key: formKey,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        child: Column(
                          children: <Widget>[
                            SizedBox(height: 20),

                            Text(
                                "Reset / New Password",
                                style: Theme.of(context)
                                    .textTheme
                                    .displaySmall
                                    .merge(TextStyle(
                                  fontSize: 20,
                                ))),
                            SizedBox(height: 20),
                            ...createPasswordWidgets(context),
                            SizedBox(height: 20,),
                            ...createRepeatPasswordWidgets(context),
                            SizedBox(height: 30),
                            ElevatedButton(
                              //padding: EdgeInsets.symmetric(vertical: 12, horizontal: 60),
                              onPressed: () {
                                update();
                              },
                              child: Text(
                                  "Reset Password"
                              ),
                              //color: Theme.of(context).accentColor,
                              //shape: StadiumBorder(),
                            ),
                            SizedBox(height: MediaQuery.of(context).viewInsets.bottom),

                          ],
                        ),
                      ),
                    )


                  ],
                ),
              );
            }
            ,
          )
        ),
      ),
    );
  }


  List<Widget> createPasswordWidgets(BuildContext context) {
    return [
      textField(
        context,
        controller: password1,
        validator: (input) => input.length < 3
            ? tr.form.minLengthErrorText(6)
            : null,
        obscureText: hidePassword,

        icon: Icons.lock,
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              hidePassword = !hidePassword;
            });
          },
          color: Theme.of(context).primaryColorDark.withOpacity(0.4),
          icon:
          Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
        ),
        labelText: "New Password",
        hintText: "New Password",
      ),
    ];
  }

  List<Widget> createRepeatPasswordWidgets(BuildContext context) {
    return [
      textField(
        context,
        controller: password2,
        validator: (input) => input.length < 3
            ? tr.form.minLengthErrorText(6)
            : password1.text != input
            ? "Passwords do not match"
            : null,
        obscureText: hidePassword,
        icon: Icons.lock,
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              hidePassword = !hidePassword;
            });
          },
          color: Theme.of(context).primaryColorDark.withOpacity(0.4),
          icon:
          Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
        ),
        labelText: "Repeat Password",
        hintText: "Repeat Password",
      ),
    ];
  }

  void update() {
    final loader = Helper.overlayLoader(context);
    FocusScope.of(context).unfocus();
    if (formKey.currentState?.validate() == true) {
      formKey.currentState.save();
      Overlay.of(context).insert(loader);
      repository.updateWithData({'password': password1.text}).then((value)  {
        if (value.hasError){
          showSnackBar(context, error: value.error);
        } else {
          showSnackBar(context,
              title: tr.done,
              message: tr.profile_settings_updated_successfully,
              contentType: ContentType.SUCCESS
          );
          Navigator.of(context).pushNamedAndRemoveUntil(
              '/Home', (Route<dynamic> route) => false);


        }
      }).whenComplete(() => {
        Helper.hideLoader(loader),
      });
    }
  }


}
