import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:io' as file;

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' show Client, Response;
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';
//import 'package:path_provider/path_provider.dart';

import 'models/address.dart';
import 'models/app.dart';
import 'models/model.dart';
import 'repository/account_repository.dart';

Directory _appDocsDir;

class Api {
  static final Api _api = new Api._internal();

  var filter = new Map<String, String>();
  String tzOffset;
  Client client = Client();
  Map<String, String> headers = {
    HttpHeaders.contentTypeHeader: "application/json",
    'X-FMSAPI-APP': 'mobile'
  };
  Map<String, dynamic> cookies = {};
  List<Cookie> cookieList = [];
  Config config = Config();
  String lang;
  String sysLang;
  Company _company = Company.fromJSON({});
  String sid;

  factory Api() {
    return _api;
  }

  Future init() async {
    initContext();
    //_appDocsDir = await getApplicationDocumentsDirectory();
  }

  void initContext() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final oldLang = lang;
    lang = prefs.getString('language') != null
        ? prefs.getString('language')
        : 'en';

    if (lang == 'ar') {
      sysLang = 'ar_AA';
    } else {
      sysLang = 'en_US';
    }
    Duration tz = DateTime.now().timeZoneOffset;
    var hours = tz.inHours.abs();
    var minutes = tz.inMinutes.abs();

    tzOffset = (hours * 60 + minutes).toString();

    headers.clear();
    headers['X-FMSAPI-LANG'] = sysLang;

    if (currentAccount.value.valid) {
      headers["apiKey"] = currentAccount.value.apiToken;
    }

    if (_company.countries.isEmpty || oldLang != lang) {
      initCompany();
    }
  }

  Api._internal();

  void initCompany() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    lang = prefs.getString('language') != null
        ? prefs.getString('language')
        : 'en';

    final lastUpdate = prefs.getInt('last_company_update') ?? 0;
    final lastLang = prefs.getString('last_company_lang');

    if (lastUpdate != null && lastLang == lang) {
      Duration diff = DateTime.now()
          .difference(DateTime.fromMillisecondsSinceEpoch(lastUpdate));
      if (diff.inDays < 2) {
        final companyData = prefs.getString('company_data');
        if (companyData != null) {
          _company = Company.fromJSON(jsonDecode(companyData));

          return;
        }
      }
    }

    print("***Api::initCompany****");

    ResultItem<Company> companyResult = await ResultItem.of(
        get('app/company'), (data) => Company.fromJSON(data),
        printResult: true);
    if (companyResult.hasError) {
      Future.delayed(Duration(seconds: 20), initCompany);
      print("Fetching company error!\n ${companyResult.error}");
    } else {
      _company = companyResult.item;
      prefs.setString('company_data', jsonEncode(companyResult.data));
      prefs.setString('last_company_lang', lang);
      prefs.setInt(
          'last_company_update', DateTime.now().millisecondsSinceEpoch);
      print("Fetching company success!");
    }
  }

  Future<Response> getJson(String endPoint,
      {Map<String, dynamic> data,
      Map<String, dynamic> kwargs,
      withCookies: true,
      withAuth: false}) async {
    return send(endPoint, data: data, kwargs: kwargs, withAuth: withAuth);
  }

  Future<Response> get(String endPoint,
      {Map<String, dynamic> data,
      int timeout,
      int delay,
      withAuth: false}) async {
    if (withAuth && !currentAccount.value.valid) {
      print("Api::get: error auth !!!");
      return Future.value(_errorResponse);
    }

    if (withAuth && !kIsWeb) {
      headers["apiKey"] = currentAccount.value.apiToken;
    }

    var url = config.url;
    String queryString = "";
    if (data != null) {
      queryString = data.entries
          .map((MapEntry en) =>
              "${en.key}=${Uri.encodeComponent('${en.value}')}")
          .toList()
          .join('&');
      if (queryString.isNotEmpty) {
        queryString += "&";
      }
    }

    queryString += 'lang=$lang';

    if (endPoint.lastIndexOf("?") == -1)
      url += "$endPoint?$queryString";
    else {
      url += "$endPoint&$queryString";
    }
    Map<String, String> wheaders = kIsWeb ? {} : this.headers;
    print(url);

    try {
      return http.get(
        Uri.parse(url),
        headers: wheaders,
      );
    } catch (e, stack) {
      Config.error('get $e', stack, runtimeType);
      return Response(e, 1000, reasonPhrase: stack.toString());
    }
  }

  Future<Response> post(String endPoint,
      {dynamic data, dynamic kwargs, withCookies: true, withAuth: true}) async {
    return send(endPoint, data: data, kwargs: kwargs, withAuth: withAuth);
  }

  Future<Response> put(String endPoint,
      {dynamic data, withCookies: true, withAuth: true}) async {
    return send(endPoint, data: data, withAuth: withAuth, method: "PUT");
  }

  Future<Response> delete(String endPoint,
      {withCookies: true, withAuth: true}) async {
    return send(endPoint,
        withAuth: withAuth, method: "DELETE", keepAlive: false);
  }

  Future<Response> send(String endPoint,
      {dynamic data,
      dynamic kwargs,
      withAuth: true,
      method = "POST",
      bool keepAlive = true}) async {
    //print("Access when account is valid!");
    if (withAuth && !currentAccount.value.valid) {
      print("Access when account is not valid!");
      return Future.value(_errorResponse);
    }

    headers[HttpHeaders.contentTypeHeader] = 'application/json';
    if (endPoint.lastIndexOf("?") != -1)
      endPoint += "&";
    else
      endPoint += "?";

    endPoint += 'lang=$lang';

    print(config.url + endPoint);

    if (withAuth || currentAccount.value.valid) {
      headers["apiKey"] = currentAccount.value.apiToken;
      //print("Send Token *********: ${currentAccount.value.apiToken}");
    }

    Map<String, String> wheaders = kIsWeb ? {} : this.headers;

    Future<Response> response;
    try {
      switch (method) {
        case "PUT":
          response = http.put(
            Uri.parse(config.url + endPoint),
            headers: wheaders,
            body: json.encode(getPayLoad(data, kwargs: kwargs)),
          );
          break;
        case "DELETE":
          response =
              http.delete(Uri.parse(config.url + endPoint), headers: wheaders);
          break;
        case "POST":
        default:
          response = http.post(
            Uri.parse(config.url + endPoint),
            headers: wheaders,
            body: json.encode(getPayLoad(data, kwargs: kwargs)),
          );
      }
    } catch (e, stack) {
      Config.error('get $e', stack, runtimeType);
      response =
          Future.value(Response(e, 1000, reasonPhrase: stack.toString()));
    }
    //response.then((Response res) => _updateCookie(res));
    return response;
    //return response.then(_checkResponse);
  }

  Response _checkResponse(Response response) {
    String contentType = response.headers[HttpHeaders.contentTypeHeader];
    if (contentType != 'application/json') {
      Config.log("Error get json content!", runtimeType);
      response = Response('{"result":{"error": "Error get json content!"}}',
          response.statusCode == 200 ? 503 : response.statusCode,
          headers: response.headers);
    }

    return response;
  }

  dynamic getPayLoad(dynamic data, {dynamic kwargs}) {
    var payload = {
      "context": {"lang": sysLang, if (tzOffset != null) "tz_offset": tzOffset},
      if (data != null) ...data,
      if (kwargs != null) ...kwargs,
    };

    return payload;
  }

  Response get _errorResponse => Response(
      json.encode({
        "success": false,
        "error": {"code": 100, "message": "Auth Required"}
      }),
      401);

  void _updateCookie(http.Response response) async {
    //print("Response : ${response.body}");
    String allSetCookie = response.headers[HttpHeaders.setCookieHeader];
    if (allSetCookie != null) {
      var setCookies = allSetCookie.split(',');
      for (var setCookie in setCookies) {
        var cookies = setCookie.split(';');
        for (var cookie in cookies) {
          _setCookie(cookie);
        }
      }
      headers[HttpHeaders.cookieHeader] = generateCookieHeader();
    }
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('cookies', json.encode(cookies));
  }

  void _setCookie(String rawCookie) {
    if (rawCookie.length > 0) {
      var keyValue = rawCookie.split('=');
      if (keyValue.length == 2) {
        var key = keyValue[0].trim();
        var value = keyValue[1];
        if (key == 'path') return;
        cookies[key] = value;
      }
    }
  }

  String generateCookieHeader() {
    String cookie = "";
    for (var key in cookies.keys) {
      if (cookie.length > 0) cookie += "; ";
      cookie += key + "=" + cookies[key];
    }
    return cookie;
  }

  List<Cookie> generateCookies() {
    for (var key in cookies.keys) {
      Cookie ck = new Cookie(key, cookies[key]);
      cookieList.add(ck);
    }
    return cookieList;
  }

  void clearCookies() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('cookies');
  }

  Future<dynamic> getPaymentUrl(String endPoint) async {
    headers['cookie'] = generateCookieHeader();
    headers['content-type'] =
        'application/x-www-form-urlencoded; charset=utf-8';
    final response = await http.post(
      Uri.parse(endPoint),
      headers: headers,
    );
    _updateCookie(response);
    return response;
  }

  Future<dynamic> postAjax(String url, Map data) async {
    headers['cookie'] = generateCookieHeader();
    headers['content-type'] =
        'application/x-www-form-urlencoded; charset=utf-8';
    print(data);
    final response =
        await http.post(Uri.parse(url), headers: headers, body: data);
    _updateCookie(response);
    return response;
  }

  Company get company => _company;

  Country getCountry(String code, [bool exact = false]) {
    return _company.countries.firstWhere((cr) => cr.code == code,
        orElse: () => _company.allCountries.firstWhere((cr) => cr.code == code,
            orElse: () => exact ? null : Country(code: code)));
  }

  processCredimaxPayment(redirect) async {
    headers['content-type'] =
        'application/x-www-form-urlencoded; charset=UTF-8';
    headers['Accept'] = 'application/json, text/javascript, */*; q=0.01';
    final response = await http.post(
      Uri.parse(
          'https://credimax.gateway.mastercard.com/api/page/version/49/pay'),
      headers: headers,
      body: redirect,
    );
    _updateCookie(response);
    return response;
  }

  downloadSplashSave(List<String> splashScreens) async {
    final StreamController<ImageChunkEvent> chunkEvents =
        StreamController<ImageChunkEvent>();

    var i = 0;

    splashScreens.forEach((image) async {
      File file = fileFromDocsDir("splash" + i.toString() + ".jpg");

      if (image.isNotEmpty) {
        final Uri resolved = Uri.base.resolve(image);
        final HttpClientRequest request = await HttpClient().getUrl(resolved);
        headers?.forEach((String name, String value) {
          request.headers.add(name, value);
        });
        final HttpClientResponse response = await request.close();
        if (response.statusCode != HttpStatus.ok)
          throw NetworkImageLoadException(
              statusCode: response.statusCode, uri: resolved);

        final Uint8List bytes = await consolidateHttpClientResponseBytes(
          response,
          onBytesReceived: (int cumulative, int total) {
            chunkEvents.add(ImageChunkEvent(
              cumulativeBytesLoaded: cumulative,
              expectedTotalBytes: total,
            ));
          },
        );

        if (bytes.lengthInBytes == 0) {
          throw Exception('NetworkImage is an empty file: $resolved');
        }

        i++;

        file.writeAsBytes(bytes, flush: true);
      }

      if (i == splashScreens.length) {
        //chunkEvents.close();
      }
    });
  }

  File fileFromDocsDir(String filename) {
    String pathName = p.join(_appDocsDir.path, filename);
    return File(pathName);
  }

  Future<Map<String, String>> getPlatformInfo() async {
    Map<String, String> deviceData;
    final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
    try {
      if (defaultTargetPlatform == TargetPlatform.android) {
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
      }
    } on PlatformException {
      deviceData = <String, String>{
        'Error:': 'Failed to get platform version.'
      };
    }
    return deviceData;
  }

  Map<String, String> _readAndroidBuildData(AndroidDeviceInfo build) {
    return <String, String>{
      'release': build.version.release,
      'device': build.device,
      'manufacturer': build.manufacturer,
      'model': build.model,
      'type': build.type,
      'isPhysical': build.isPhysicalDevice.toString(),
      'device_uuid': build.id,
      'platform': 'Android'
    };
  }

  Map<String, String> _readIosDeviceInfo(IosDeviceInfo data) {
    return <String, String>{
      'name': data.name,
      'systemName': data.systemName,
      'systemVersion': data.systemVersion,
      'model': data.model,
      'isPhysical': data.isPhysicalDevice.toString(),
      'device_uuid': data.identifierForVendor,
      'platform': 'IOS'
    };
  }

  String get deviceInfo {}

  Future<Response> getResponse(String url,
      {Map<String, String> headers, bool withAuth = false}) async {
    Config.debug("getResponse $url", runtimeType);
    if (url.startsWith("http:") || url.startsWith("https:")) {
      if (withAuth && !currentAccount.value.valid) {
        Config.debug("You have no auth to request $url", runtimeType);
        return Future.value(_errorResponse);
      }
      if (withAuth) {
        this.headers["apiKey"] = currentAccount.value.apiToken;
        Map<String, String> temHeader = Map.of(this.headers);
        if (headers != null) {
          temHeader.addAll(headers);
        }
        headers = temHeader;
      }
      Config.debug("getResponse $url", runtimeType);

      return http.get(
        Uri.parse(url),
        headers: headers,
      );
    }

    return get(url, withAuth: withAuth);
  }

  void savePdf(Response response, String fileName,
      [bool document = false]) async {
    final directory = await (document
        ? getApplicationDocumentsDirectory()
        : getDownloadsDirectory());

    String filePath =
        '${directory.path}${file.Platform.pathSeparator}$fileName';

    final pdfData = file.File(filePath);
    await pdfData.writeAsBytes(response.bodyBytes);

    await Share.shareFiles([filePath]);
  }
}
