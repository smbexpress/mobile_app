

class Slider {
  final double width;
  final double height;
  final double radius;
  final int interval;
  final List<Slide> slides;
  Slider({
    this.width,
    this.height,
    this.radius,
    this.interval,
    this.slides,
  });

  static Slider fromJSON(dynamic json) =>
      Slider(
        width: json['width']?.toDouble(),
        height: json['height']?.toDouble(),
        radius: json['radius']?.toDouble(),
        interval: json['interval']?.toInt(),
        slides: json['slides']?.map((data) => Slide.fromJSON(data))?.toList()?.cast<Slide>()??[],
      );


}

class Slide {
  final String id;
  final String imageUrl;
  final String description;
  final String linkUrl;

  Slide({
    this.id,
    this.imageUrl,
    this.description,
    this.linkUrl
  });

  static Slide fromJSON(dynamic jsonMap) =>
      Slide(
        id: jsonMap['id'],
        imageUrl: jsonMap['image_url'],
        description: jsonMap['description'],
        linkUrl: jsonMap['link_url'],
      );

}

