
import '../helpers/helper.dart';
import 'address.dart';
import 'shipment.dart';
import 'slider.dart';

class CarBrand{
  int id;
  String name;

  CarBrand({
    this.id,
    this.name
  });

  factory CarBrand.fromJSON(dynamic json) => CarBrand(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == 0 ? 0 : id,
    "name": name == null ? null : name,
  };
  String toStringM(){
    return "CarBrand("+toJson().toString()+")";
  }
  String toString(){
    return name;
  }
}

class CarModel{
  int id;
  String name;

  CarModel({
    this.id,
    this.name
  });

  factory CarModel.fromJSON(dynamic json) => CarModel(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? 0 : id,
    "name": name == null ? null : name,
  };

  String toStringM(){
    return "CarModel("+toJson().toString()+")";
  }

  String toString(){
    return name;
  }
}

class Company{
  String name;
  String street;
  String zip;
  String mobile;
  String phone;
  String email;
  String website;
  Currency currency;
  String logo;
  String vat;
  List<Country> countries;
  List<Country> allCountries;
  List<Currency> currencies;
  List<Currency> allCurrencies;
  Map<String, Currency> currencyMap;
  Slider slider;

  Company(
      this.name,
      this.street,
      this.zip,
      this.mobile,
      this.phone,
      this.email,
      this.website,
      this.logo,
      this.vat,
      this.currency,
      this.countries,
      this.allCountries,
      this.currencies,
      this.allCurrencies,
      this.currencyMap,
      this.slider);

  Currency getCurrency(dynamic data){
    if (data == null || (data is String && data == currency.name))
      return currency;

    if (data is Map)
        return Currency.fromJSON(data);

    return currency;
  }

  static fromJSON(dynamic json){
    print("** parse compmany ${json}");
    List<Country> countries = Helper.map(json['countries'] ?? [], (el) => Country.fromJson(el));
    List<Country> allCountries = Helper.map(json['all_countries'] ?? [], (el) => Country.fromJson(el));

    List<Currency> currencies = Helper.map(json['currencies'] ?? [], (el) => Currency.fromJSON(el));
    List<Currency> allCurrencies = Helper.map(json['all_currencies'] ?? [], (el) => Currency.fromJSON(el));

    Map<String, Currency> currencyMap = Map();
    allCurrencies.forEach((cur) => currencyMap[cur.name] = cur );

    Currency currency = json['currency'] != null? currencyMap[json['currency']]??Currency.fromJSON({}) : Currency.fromJSON({});
    Slider slider = json['slider'] != null ? Slider.fromJSON(json['slider']) : null;

    return Company(
        json['name']??"",
      json['street']??"",
      json['zip']??"",
      json['mobile']??"",
      json['phone']??"",
      json['email']??"",
      json['website']??"",
      json['logo'],
      json['vat']??"",
      currency,
      countries,
      allCountries,
      currencies,
      allCurrencies,
      currencyMap,
      slider
    );

  }

}