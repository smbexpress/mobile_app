import '../api.dart';
import '../helpers/helper.dart';
import '../models/address.dart';
import 'model.dart';

class Account {
  static const int ACT_NORMAL = 0;
  static const int ACT_REGISTER = 1;
  static const int ACT_UPDATE = 2;
  static const int ACT_FORGET = 3;
  static const int ACT_REG_PASSWORD = 4;
  static const int ACT_UPDATE_PASSWORD = 5;
  static const int ACT_LOGIN_PASSWORD = 6;
  static const int ACT_UPDATE_NAME = 7;
  static const int ACT_UPDATE_EMAIL = 8;
  static const int ACT_UPDATE_MOBILE = 9;
  static const int ACT_VERIFY = 10;
  static const int ACT_FORGET_PASSWORD = 11;
  static const int ACT_UPDATE_FORGET_PASSWORD = 12;

  int id;
  String name;
  String email;
  String password;
  String apiToken;
  String mobile;
  String phone;
  Address billing;
  Address defaultAddress = Address.Pickup();
  City city;
  Country country;
  String street;
  bool verified=false;
  int otp;
  String otpAt;
  bool exists = false;
  int action = ACT_NORMAL;
  String lang;
  // used for indicate if client logged in or not
  bool auth;
  double lat;
  double lng;
  String currency;
  bool forceFromBranch;
  bool forceToBranch;
//  String role;

  Account();

  Account.fromJSON(dynamic json) {
      //try {
        id = json['id'];
        name = json['name']??'';
        email = json['email'];
        apiToken = json['auth_token'];
        mobile = json['mobile'] ?? '';
        phone = json['phone'] ?? '';
        defaultAddress = json['default_address'] != null ? Address.fromJSON(
            json['default_address']) : Address.Pickup();
        verified = json['verified'] ?? false;
        country = Api().getCountry(json['country']);
        city = json['city'] != null ? City.fromJson(json['city']) : new City();


        exists = json['exists'] != null ?  json['exists'] : id != null && id != 0;
        lang = json['lang'];
        currency  = json['currency'];
        if (defaultAddress.valid){
          lat = json['lat']?.toDouble()??defaultAddress.lat;
          lng = json['lng']?.toDouble()??defaultAddress.lng;
        }
        forceFromBranch = json['force_from_branch'] ?? false;
        forceToBranch = json['force_to_branch'] ?? false;

      //} catch(e){}
  }



  Map toMap([bool all=true]) {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["email"] = email;
    map["name"] = name;
    map["password"] = password;
    map["auth_token"] = apiToken;
    map["mobile"] = mobile;
    map["phone"] = phone;
    map["currency"] = currency;
    if (all) {
      map["defaultAddress"] = defaultAddress.toMap();
      if (city != null) {
        map["city"] = city.valid? city.toJson() : city.name;
        map["country"] = country.code;
      } else{
        map["city"] = defaultAddress.city.valid? defaultAddress.city.toJson() : defaultAddress.city.name;
        map["country"] = defaultAddress.country.code;
      }
    }
    map["street"] = defaultAddress.street;
    map["city_id"] = city != null ? city.id : defaultAddress.city.id;
    map["action"] = action;
    map["lang"] = lang;
    map["lat"] = lat??defaultAddress.lat;
    map["lng"] = lng??defaultAddress.lng;
    return map;
  }

  Map toUpdate() {
    Map map = toMap();
    map.remove("auth_token");
    return map;
  }

  Map get toLogin => {
    if (id != null && id != 0)
    'id': id,
    'password': password,
    'mobile': mobile,
    if (apiToken != 0)
    'auth_token': apiToken,
  };

  Map get toVerify => {
    'id': id,
    'otp': otp,
    'auth_token': apiToken,
    'otp_at': otpAt,
    'mobile': mobile,
    'otp_test': true
  };

  Map get toTest => {
    'id': id,
    'auth_token': apiToken,
    'mobile': mobile,
  };

  Map get toLogout => {
    'id': id,
    'auth_token': apiToken,
  };

  @override
  String toString() {
    var map = this.toMap(false);
    map["auth"] = this.auth;
    return map.toString();
  }

  bool profileCompleted() {
    return defaultAddress.id != null && verified && defaultAddress.mobile != null && defaultAddress.mobile != '';
  }

  bool get valid {
    return  id != null && id != 0 && apiToken != null;
  }

  void update(Account other){
    if (other.id != null)  id = other.id;
    if (other.name != '')  name = other.name;
    if (other.email != '')  email = other.email;
    if (other.apiToken != null)  apiToken = other.apiToken;
    if (other.mobile != '')  mobile = other.mobile;
    if (other.phone != '')  phone = other.phone;
    if (other.defaultAddress.valid)  defaultAddress = other.defaultAddress;
    if (other.verified)  verified = other.verified;
    if (other.country != null && other.country.valid)  country = other.country;
    if (other.city != null && other.city.valid)  city = other.city;
    if (other.password != null)  password = other.password;
    if (other.otp != null)  otp = other.otp;
    if (other.lang != null)  lang = other.lang;
    if (other.exists)  exists = other.exists;
    if (other.currency != null)  currency = other.currency;
  }

  void logout(){
    id = 0;
    name = null;
    email = null;
    apiToken = null;
    mobile = null;
    phone = null;
    exists=false;
    otp=null;
    password = null;
    verified = false;
    action = ACT_NORMAL;
  }

}

class AuthRequest {

  final int action; //LOGIN|REGISTER|UPDATE|FORGET|CHECK|VERIFY
  final String phone;
  final String email;
  final String otpToken; //required on VERIFY
  final String otp; //required on VERIFY
  final String password; //required LOGIN
  final Map<String, dynamic> data;

  AuthRequest({
      this.action,
      this.phone,
      this.email,
      this.otpToken,
      this.otp,
      this.password,
      this.data
  }); //registration data

  Map<String, dynamic> toMap() =>
    Helper.removeNulls({
      'mobile': phone,
      'email': email,
      'otp_token': otpToken,
      'otp': otp,
      'password': password,
      ...data,
      'action': action,
    });

}

class OtpInfo{
  final String otpToken;
  final DateTime sentTime;
  final int count;
  final bool string;

  OtpInfo({
    this.otpToken,
    this.sentTime,
    this.count,
    this.string
  });

}

class AuthResponse {
  final OtpInfo otpInfo;
  final Map todo;
  final bool success;
  AuthResponse({
    this.otpInfo,
    this.todo,
    this.success
  });

}

class AuthResponseInfo {
  final AuthRequest request;
  final AuthResponse response;
  final ErrorResult error;
  AuthResponseInfo({this.request, this.response, this.error});


}
