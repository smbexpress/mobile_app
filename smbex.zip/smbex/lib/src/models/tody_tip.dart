
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/helpers/helper.dart';

Color _parseColor(String hex) {
  if (hex == null)
      return null;
  if (hex.startsWith("#"))
    hex = hex.substring(1);
  if (hex.length != 6 && hex.length != 8) {
    Config.log("Error parse color  of $hex");
    return null;
  }
  if (hex.length == 6)
    hex = 'FF$hex';
  final value = int.tryParse(hex, radix:16);
  Config.log("Parse color $hex to $value");

  return value != null ? Color(value) : null;
}

enum TodayTipType {
  popup,
  status,
  fixedStatus,
  tip,
  fixedTip
}

final Map<String, TodayTipType> _tipTypeMap = {
  for(TodayTipType type in TodayTipType.values)
    type.name : type,
};

class TodayTip{
  final String id;
  final TodayTipType type; //Popup, Status, FixedStatus, Tip, FixedTip,
  final DateTime created;
  final DateTime expire;
  final String content;
  final String route;
  final Map<String, dynamic> args;
  final String linkUrl;
  final String imageUrl;
  final String readMore;
  final Color color;
  final double heightFactor;
  TodayTip({
    @required this.id,
    this.type,
    @required this.created,
    this.expire,
    this.content,
    this.route,
    this.args,
    this.linkUrl,
    this.imageUrl,
    this.readMore,
    this.color,
    this.heightFactor
  });

  static TodayTip fromMap(dynamic map) =>
      TodayTip(
        id: map['id']?.toString(),
        type: _tipTypeMap[map['type']],
        content: map['content'],
        route: map['route'],
        args: map['args']?.cast<String, dynamic>(),
        linkUrl: map['link_url'],
        imageUrl: map['image_url'],
        readMore: map['read_more'],
        created: Helper.parseServerDate(map['created']) ?? DateTime.now(),
        expire: Helper.parseServerDate(map['expire']),
        color: _parseColor(map['color']),
        heightFactor: map['height_factor']?.toDouble()
      );
  
  bool get valid {
    if (expire != null)
        return DateTime.now().isAfter(expire);
    if (type == TodayTipType.fixedStatus
        || type == TodayTipType.fixedTip)
      return true;
    
    return DateTime.now().add(Duration(hours: 24)).isAfter(created);
  }
  
  Map<String, dynamic> toMap() =>
     Helper.removeNulls(
      <String, dynamic>{
        'id': id,
        'type': type?.name,
        'content': content,
        'route': route,
        'args': args,
        'link_url': linkUrl,
        'image_url': imageUrl,
        'read_more': readMore,
        'created': Helper.formatDatetime(created),
        'expire': Helper.formatDatetime(expire),
        'color': color?.value?.toRadixString(16)?.padLeft(8, '0'),
        'height_factor': heightFactor
      });
  
  static Future<List<TodayTip>> getTips(List<dynamic> rawTipList, String prefKey) async{
    SharedPreferences pref = prefKey != null 
        ? (await SharedPreferences.getInstance()) 
        : null;
    bool fromPref = false;
    if (rawTipList == null && pref != null && pref.getString(prefKey) != null){
      rawTipList = jsonDecode(pref.getString(prefKey));
      fromPref = true;
    }
    else if (rawTipList != null && pref != null){
      pref.setString(prefKey, jsonEncode(rawTipList));
    }
    
    if (rawTipList != null ){
      final toIgnoreStore = pref.getString('${prefKey}_ignore');
      final ignoreTipIds = toIgnoreStore != null
            ? Set.of(jsonDecode(pref.getString('${prefKey}_ignore'))?.toSet() ?? <String>{})
            : <String>{};
      final tips = List<TodayTip>.of(
          rawTipList.map((map) => TodayTip.fromMap(map))
          .toList().cast<TodayTip>())
          ..removeWhere((tip) => !tip.valid)
          ..sort((t1, t2) => t1.created.compareTo(t2.created));

      if (!fromPref && ignoreTipIds.isNotEmpty){
        int ignoreTipLength = ignoreTipIds.length;
        final existsIds = tips.map((e) => e.id).toSet();
        ignoreTipIds.removeWhere((id) => !existsIds.contains(id)) ;
        if (ignoreTipLength != ignoreTipIds.length) {
          pref.setString('${prefKey}_ignore', jsonEncode(ignoreTipIds.toList()));
        }

        tips.removeWhere((tip) => ignoreTipIds.contains(tip.id));
        //
      }


      if (tips.length != rawTipList.length)
        pref.setString(prefKey, jsonEncode(tips.map((e) => e.toMap()).toList()));

      return tips;
    }

    return Future.value([]);
    
  }


  static Future closeTip(TodayTip tip, List<TodayTip> tips, String prefKey) async{
    tips.remove(tip);
    if (prefKey != null){
      SharedPreferences pref = await SharedPreferences.getInstance();
      final ignoreTipIds = Set.of(jsonDecode(pref.getString('${prefKey}_ignore')??'[]')?.toSet() ?? <String>{});
      if (ignoreTipIds.isNotEmpty){
        int ignoreTipLength = ignoreTipIds.length;
        if (tip.valid){
          ignoreTipIds.add(tip.id);
        } else {
          ignoreTipIds.remove(tip.id);
        }
        if (ignoreTipLength != ignoreTipIds.length) {
          pref.setString('${prefKey}_ignore', jsonEncode(ignoreTipIds.toList()));
        }
      }
      pref.setString(prefKey, jsonEncode(tips.map((e) => e.toMap()).toList()));
    }
    return Future.value();
  }

  static void checkTipsExpiry(List<TodayTip> tips, String prefKey) async{
    final toRemoveTips = tips.where((tip) => !tip.valid);
    toRemoveTips.forEach((tip)=> closeTip(tip, tips, prefKey));
  }



}