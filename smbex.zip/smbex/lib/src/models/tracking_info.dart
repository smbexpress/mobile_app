
import 'package:intl/intl.dart';
import '../helpers/helper.dart';
import 'address.dart';


final DateFormat _shortFormat = DateFormat('d, MMM, yyyy', 'en_US');
final DateFormat _timeFormat = DateFormat('hh:mm a', 'en_US');

const _steps = [
  'shipped',
  'in_trainsit',
  'arrived',
  'delivered',
];


class TrackingInfo{

  final dynamic id;
  final String trackingCode;
  final String eta;
  final double weight;
  final String weightUnit;
  final String status;
  final int step;
  final String statusCode;
  final String statusTitle;
  final List<TrackingItem> items = [];
  final DriverInfo driverInfo;
  final Address from;
  final Address to;
  final double cod;
  final String codCurrency;
  final String service;
  final String packageType;
  TrackingInfo({
    this.id,
    this.trackingCode,
    this.eta,
    this.weight,
    this.status,
    this.driverInfo,
    this.statusCode,
    this.statusTitle,
    this.step,
    this.weightUnit,
    this.from,
    this.to,
    this.cod,
    this.codCurrency,
    this.service,
    this.packageType
  });

  void addItem(TrackingItem item){
    items.add(item);
  }
}

TrackingInfo _toTrackingInfo(dynamic data){
  final driverInfoMap = data['driver_info'];
  final driverInfo =driverInfoMap != null
      ? DriverInfo(name: driverInfoMap['name'], phone: driverInfoMap['phone'] ?? '+9965654454')
      :  null;
  return TrackingInfo(
    id: data['id'],
    trackingCode: data['tracking_code'],
    weight: data['weight']?.toDouble(),
    status: data['status'],
    statusTitle: data['status_title'],
    statusCode: data['status_code'],
    step: data['step'],
    eta: data['eta'],
    weightUnit: data['weight_unit'],
    driverInfo: driverInfo,
    from: Address.fromJSON(data['from_address']),
    to: Address.fromJSON(data['to_address']),
    cod: data['cod']?.toDouble(),
    codCurrency: data['cod_currency'],
    service: data['service'],
    packageType: data['package_type'],
  );
}


class TrackingItem{

  TrackingItem({
    this.date,
    this.message,
    this.time,
    this.status,
    this.statusCode,
    this.groups,
    this.locationDetail,
    this.driverInfo
  });

  final String message;
  final String date;
  final String time;
  final String status;
  final String statusCode;
  final DriverInfo driverInfo;
  List<TrackingItem> groups;

  final LocationDetail locationDetail;

  void addItem(TrackingItem item){
    groups??=[];
    groups.add(item);
  }

  static TrackingItem fromMap(dynamic data){
    var d = Helper.parseServerDate(data['datetime']);
    return TrackingItem(
        date: _shortFormat.format(d),
        time: _timeFormat.format(d),
        statusCode: data['status_code'],
        status: data['status_title'],
        message: data['message'],
        locationDetail: data['location_details'] != null ?
        _toLocDetail(data['location_details']) : null
    );
  }

}

TrackingItem _toTrackingItem(dynamic data){
  return TrackingItem(
      date: data['date'],
      time: data['time'],
      statusCode: data['status_code'],
      status: data['status_title'],
      message: data['message'],
      locationDetail: data['location_details'] != null ?
      _toLocDetail(data['location_details']) : null

  );
}

class LocationDetail{
  final String countryCode;
  final String country;
  final String city;
  final String locationName;
  final String locationCode;
  final double lat;
  final double lng;
  final String location;
  LocationDetail({
    this.countryCode,
    this.country,
    this.city,
    this.locationName,
    this.locationCode,
    this.lat,
    this.lng,
    this.location
  });

}
class DriverInfo {
  DriverInfo({
    this.name,
    this.phone,
    this.thumbnailUrl,
  });

  final String name;
  final String phone;
  final String thumbnailUrl;
  bool _onTime = false;

  bool get onTime => _onTime;
}

LocationDetail _toLocDetail(dynamic data){
  return LocationDetail(
    countryCode: data['country_code'],
    country: data['country_name'],
    city: data['city'],
    locationName: data['location_name'],
    locationCode: data['location_code'],
    lat: data['lat']?.toDouble(),
    lng: data['lng']?.toDouble(),
    location: data['location'],
  );
}

TrackingInfo parseTrackingInfo(dynamic tracking) {
  if (tracking != null){

    var status = tracking['status']?? '';
    var trackingItems = tracking['tracking_items']?? [];
    final offset = DateTime.now().timeZoneOffset.inSeconds;
    print("_parseTrackingInfo:: status: $status");
    tracking['step'] = _steps.indexOf(status);

    var eta = Helper.parseServerDate(tracking['estimate_delivery_date']);
    var lastDateTime = null;
    tracking['eta'] = eta != null ? _shortFormat.format(eta) : '';

    TrackingInfo trackingInfo = _toTrackingInfo(tracking);

    final itemGroups = <String,TrackingItem>{};
    final items = [];
    trackingItems.forEach((item) {
      var d = Helper.parseServerDate(item['datetime']);
      if (d != null){
        lastDateTime = d;
        //d = d.subtract(Duration(seconds: offset));
        item['datetime'] = Helper.formatDatetime(d);
        item['date'] = _shortFormat.format(d);
        item['time'] = _timeFormat.format(d);
      } else {
        item['datetime'] = '';
        item['date'] = '';
        item['time'] = '';
      }

      var locationDetails = item['location_details'];
      final ld = "${item['date']}-${locationDetails != null ? locationDetails['location_name'] : ""}";
      final tItem = _toTrackingItem(item);
      final parent = itemGroups[ld];
      if (parent == null){
        itemGroups[ld] = tItem;
        trackingInfo.addItem(tItem);
      } else{
        parent.addItem(tItem);
      }
    });
    if (tracking['step'] == 4 &&
        trackingInfo.driverInfo != null ) {
      final lastDs = Helper.parseDate(lastDateTime);
      final firstDs = Helper.parseDate(tracking['eta']);

      if (lastDs != null && firstDs != null &&
          (lastDs == firstDs || lastDs.isBefore(firstDs))) {
        trackingInfo.driverInfo._onTime = true;
      }

    }
    //trackingInfo.driverInfo._onTime = true;
    //debugPrint("trackingItems: $trackingItems");
    //debugPrint("items: $items");

    return trackingInfo;
  }

  //debugPrint('tracking.step: ${tracking['step']}');
  return tracking;
}

class TrackingHistory {
  final String code;
  final String from;
  final String to;
  final String orderDate;
  final int lastUsed;

  TrackingHistory(
      {
        this.code,
        this.from,
        this.to,
        this.orderDate,
        this.lastUsed
      });

  static TrackingHistory fromMap(dynamic map) =>
      TrackingHistory(
          code: map['code'],
        from: map['from'],
        to: map['to'],
        orderDate: map['orderDate'],
        lastUsed: map['lastUsed'],
      );

  Map<String, dynamic> toMap() => {
    'code': code,
    'from': from,
    'to': to,
    'orderDate': orderDate,
    'lastUsed': lastUsed,
  };

  TrackingHistory update(int lastUsed) =>
      TrackingHistory(
          code: code,
          from: from,
          to: to,
          orderDate: orderDate,
          lastUsed: lastUsed
      );

  @override
  bool operator ==(Object other) {
    if (identical(this, other))
      return true;
    if (other is TrackingHistory) {
      return other.code == code;
    }
    return false;
  }

  @override
  int get hashCode => code.hashCode;

}