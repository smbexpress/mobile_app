import 'package:smbex_app/src/models/payment_method.dart';

import '../../i18n/i18n.dart';

class Payment {
  String id;
  String name;
  String method;
  String type;
  String provider;
  String icon;

  Payment.init();

  Payment(this.method);

  Payment.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      name = jsonMap['name'] ?? '';
      method = jsonMap['method'] ?? '';
      type = jsonMap['type'] ?? '';
      provider  = jsonMap['provider'] ?? '';
      icon = getPaymentIcon(this);
      if (method == 'cash') {
        name = tr.cash;
      }
      if (name == 'credit_card') {
        name = tr.creditCard;
      }

    } catch (e) {
      id = '';
      name = '';
      method = '';
      provider  = '';
      print(e);
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'status': name,
      'method': method,
    };
  }
}
