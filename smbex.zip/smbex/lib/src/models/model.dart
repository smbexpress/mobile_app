import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart';
import 'package:smbex_app/src/helpers/network_exception.dart';

import '../api.dart';
import '../config.dart';
import '../helpers/custom_trace.dart';

abstract class Model {}

enum LoadStatus {
  start,
  normal,
  error,
  loading,
  completed,
}

class LoadArgs {
  Map<String, dynamic> args;
  LoadArgs({this.args});
}

class ResultItem<T> {
  T item;
  ErrorResult error;
  dynamic data;
  ResultItem({this.item, this.error, this.data});

  factory ResultItem.fromJson(Response response, T Function(dynamic data) func,
      {bool useUtf}) {
    Map<String, dynamic> data = json.decode(response.body);
    return ResultItem<T>(
        item: func(data['result'] ?? {}),
        error: ErrorResult.tryError(data['error'] ?? null),
        data: data);
  }

  ResultItems<K> toItems<K>(K Function(dynamic data) func) {
    if (hasError) {
      return new ResultItems<K>(items: <K>[], error: error);
    }
    return ResultItems<K>.fromJson(data ?? [], func);
  }

  static Future<ResultItem<T>> fromResponse<T>(
      Response response, T Function(dynamic data) func,
      {bool useUtf}) async {
    try {
      if (response.statusCode != 200) {
        return ResultItem<T>(
            error: ErrorResult(
                code: response.statusCode,
                message: getNetworkException(response),
                network: response.statusCode == 1000));
      }
      dynamic data = useUtf == true
          ? json.decode(utf8.decode(response.bodyBytes))
          : json.decode(response.body);
      var error = ErrorResult.tryError(data['error'] ?? null);
      var result = data['result'] ?? data['data'] ?? Map<String, dynamic>();

      return ResultItem<T>(
          item: func != null ? func(result) : result,
          error: error,
          data: result);
    } catch (e, stack) {
      Config.error(
          "Error result: ${response.body}", stack, ResultItem<T>().runtimeType);
      rethrow;
    }
  }

  static Future<ResultItem<T>> of<T>(
      Future<Response> response, T Function(dynamic data) func,
      {bool printResult = false, bool useUtf = false, int timeout}) async {
    //Response res = await response;
    Response _response;
    bool ignoreTimeoute = false;
    var resp = response.then((Response response) {
      _response = response;
      ignoreTimeoute = true;
      if (printResult || true) {
        if (response.statusCode == 200) {
          Config.result("${response.body}", T);
        } else {
          Config.result(
              "ResultItem::error statusCode:${response.statusCode},"
              "reasonPhrase: ${response.reasonPhrase} $response",
              T);
        }
      }
      return ResultItem.fromResponse(response, func, useUtf: useUtf);
    }, onError: (error, stack) async {
      ignoreTimeoute = true;
      Config.error(error, stack, ResultItem<T>().runtimeType);

      return ResultItem<T>(error: ErrorResult.tryError(error));
    });
    if (timeout != null) {
      resp = resp.timeout(Duration(seconds: timeout), onTimeout: () {
        if (!ignoreTimeoute)
          return ResultItem<T>(
              error: ErrorResult(
                  code: 0,
                  message: TimeoutException(null).toString(),
                  network: true));
        return null;
      });
    }
    return resp;
  }

  static Future<ResultItem<T>> get<T>(String endpoint,
      {Map<String, dynamic> data,
      T Function(dynamic data) func,
      bool printResult = false,
      withAuth: true,
      bool useUtf = false}) async {
    try {
      return ResultItem.of<T>(
          Api().get(endpoint, data: data, withAuth: withAuth), func,
          printResult: printResult, useUtf: useUtf);
    } catch (e, stack) {
      return ResultItem<T>(error: ErrorResult.tryError(e));
    }
  }

  static Future<ResultItem<T>> post<T>(String endpoint,
      {Map<String, dynamic> data,
      T Function(dynamic data) func,
      bool printResult = false,
      withAuth: true,
      bool useUtf = false}) async {
    try {
      return ResultItem.of<T>(
          Api().post(endpoint, data: data, withAuth: withAuth), func,
          printResult: printResult, useUtf: useUtf);
    } catch (e, stack) {
      return ResultItem<T>(error: ErrorResult.tryError(e));
    }
  }

  bool get hasError => error != null;

  String toString() {
    String result = "ResultItem(items: $item";
    if (hasError) result += ", $error";
    result += ")";
    return result;
  }
}

class ResultItems<T> {
  int length = 0;
  List<T> items = <T>[];
  LoadStatus status = LoadStatus.normal;
  ErrorResult error;
  ResultItems(
      {this.status: LoadStatus.normal,
      this.length: 0,
      this.items: const [],
      this.error}) {
    if (length < items.length) length = items.length;
    if (error != null) status = LoadStatus.error;
  }

  factory ResultItems.fromJson(dynamic data, T Function(dynamic data) func) {
    //print("ResultItems::fromJson: $data");
    List<T> items = [];
    int length;
    var records;
    var error;
    if (data is List) {
      records = data;
      length = records.length;
    } else {
      length = data['length'] ?? 0;
      records = data['items'] ?? [];
      error = ErrorResult.tryError(data['error'] ?? null);
    }

    records.forEach((val) => items.add(func(val)));
    return ResultItems<T>(length: length, items: items, error: error);
  }

  static Future<ResultItems<T>> fromResponse<T>(
      Response response, T Function(dynamic data) func) async {
    if (response.statusCode > 300) {
      return ResultItems<T>(
          error: ErrorResult(
              code: response.statusCode,
              message: getNetworkException(response),
              network: response.statusCode == 1000));
    }
    try {
      Map<String, dynamic> data = json.decode(response.body);
      dynamic result = data['result'] ?? {};
      List<dynamic> records;
      int length;
      if (result is List) {
        records = result;
        length = records.length;
      } else {
        records = result['items'] ?? [];
        length = (result['length']?.toInt()) ?? records.length;
      }

      //print("Parcels::records: ${records}");
      List<T> items = [];
      Config.result("T in list: $T -> length: $length", T);
      if (func != null) {
        records.forEach((val) => items.add(func(val)));
      } else {
        items = records;
      }
      return ResultItems<T>(
          length: length,
          items: items,
          error: ErrorResult.tryError(data['error'] ?? null));
    } catch (e, stack) {
      //print("Caught: $m");
      Config.error("Stack: $e\nResult: ${response.body}", stack,
          ResultItems<T>().runtimeType);
      throw e;
    }
  }

  static Future<ResultItems<T>> of<T>(
      Future<Response> response, T Function(dynamic data) func,
      {int timeout}) async {
    bool ignoreTimeoute = false;
    var resp = response.then((Response response) {
      ignoreTimeoute = true;
      return ResultItems.fromResponse(response, func);
    }).catchError((error, stack) {
      ignoreTimeoute = true;
      //print(StackTrace.current);
      Config.error("$error\n$stack", stack, ResultItems<T>().runtimeType);
      return ResultItems<T>(error: ErrorResult.tryError(error));
    });
    if (timeout != null) {
      resp = resp.timeout(Duration(seconds: timeout), onTimeout: () {
        if (!ignoreTimeoute)
          return ResultItems<T>(
              error: ErrorResult(
                  code: 0,
                  message: TimeoutException(null).toString(),
                  network: true));
        return null;
      });
    }
    return resp;
  }

  static Future<ResultItems<T>> get<T>(String endpoint,
      {Map<String, dynamic> data,
      T Function(dynamic data) func,
      withAuth = true}) async {
    return ResultItems.of<T>(
        Api().get(endpoint, data: data, withAuth: withAuth), func);
  }

  bool get hasError => error != null;
  bool get isEmpty => items.length == 0;

  void clear() {
    status = LoadStatus.normal;
    items = <T>[];
    error = null;
    length = 0;
  }

  void setLoading([bool clearResult = true]) {
    if (clearResult) clear();
    error = null;
    status = LoadStatus.loading;
  }

  void update(ResultItems<T> other) {
    status = LoadStatus.normal;
    items = other.items;
    length = other.length;
    error = other.error;
  }

  void expand(ResultItems<T> other) {
    status = other.status;
    items.addAll(other.items ?? []);
    length = other.length;
    error = other.error;
  }

  bool get loading => status == LoadStatus.loading;

  void add(List<T> newList) {
    this.items.addAll(newList);
  }

  String toString() {
    String type = this.runtimeType.toString();
    String result = "$type(length: $length, items: $items";
    if (hasError) result += ", $error";
    result += ")";
    return result;
  }
}

class ErrorResult {
  var code;
  var message;
  var trace;
  var fields;
  var error;
  bool network;
  ErrorResult(
      {this.code,
      this.message,
      this.trace,
      this.fields,
      this.error,
      this.network = false});

  static ErrorResult tryError(dynamic error, [dynamic trace]) {
    if (error == null && trace == null) return null;

    if (error is String) {
      return ErrorResult(code: -1, message: error, trace: trace);
    }
    if (error is Map) {
      return ErrorResult(
          code: error['code'] ?? -1,
          message: error['message'],
          fields: error['errors'] ?? error['data'],
          error: error['error'],
          trace: trace);
    }
    if (error is IOException) {
      return ErrorResult(
          code: 0, message: error.toString(), network: true, trace: trace);
    }

    if (error is TimeoutException) {
      return ErrorResult(
          code: 0, message: 'Network timeout', network: true, trace: trace);
    }

    if (error is Exception) {
      return ErrorResult(code: -1, message: error.toString(), trace: trace);
    }

    if (error is Response) {
      final response = error;
      try {
        Map<String, dynamic> data = json.decode(response.body);
        final errors = data['errors'] ?? data['error'];
        return ErrorResult(error: errors, code: response.statusCode);
      } catch (e) {}

      return ErrorResult(
          error: response.body,
          code: response.statusCode,
          network: response.statusCode < 400,
          trace: trace);
    }

    return ErrorResult(code: -1, message: error?.toString(), trace: trace);
    ;
  }

  bool get isNetwork => network || code == 0 || code == 408;

  String toString() {
    return "ErrorResult(\n\tcode: $code, \n\tmessage: $message, \n\tfields: $fields, \n\terror: $error, \n\ttrace: $trace)";
  }

  bool get hasFields => fields is Map || fields is List;
}

class ResultItemsConverter<T>
    extends Converter<Response, Future<ResultItems<T>>> {
  final T Function(dynamic data) func;
  const ResultItemsConverter(this.func);
  @override
  Future<ResultItems<T>> convert(Response input) async {
    return ResultItems.fromResponse(input, func);
  }
}

typedef LoadMoreProvider = Future Function(LoadArgs args, int offset);
typedef LoadMoreNotify<T> = void Function(ResultItems<T> result);
typedef LoadMoreFactory<T> = LoadMore<T> Function(LoadMoreNotify<T> notify);

class LoadMore<T> {
  int page = 0;
  int perPage = 5;
  int maxRetries;
  int retryIntervals;
  int _currentRetry = 0;
  ResultItems<T> resultItems =
      ResultItems<T>(items: <T>[], status: LoadStatus.start);
  LoadMoreProvider loadMoreProvider;
  LoadMoreNotify<T> onLoadMore;
  LoadArgs args;
  Timer _timer;
  LoadMore(this.args,
      {this.perPage = 5, @required this.loadMoreProvider, this.onLoadMore});

  void _runTimer() {
    if (_timer != null) {
      _timer.cancel();
    }

    _timer = Timer(Duration(seconds: retryIntervals), () {
      Timer tm = _timer;
      _timer = null;
      loadMore();
      tm.cancel();
    });
  }

  Future<void> loadMore() async {
    Config.log("loadMore Request loadMore ....${T}", runtimeType);
    if (resultItems.status == LoadStatus.loading) {
      //await notifyLoadMore();
      Config.log("loadMore Still loading....", runtimeType);
      return;
    }
    if (_timer != null && _timer.isActive) {
      return;
    }

    if (resultItems.status == LoadStatus.completed) {
      //await notifyLoadMore();
      Config.log("loadMore when loading complete....", runtimeType);
      await notifyLoadMore();
      return;
    }

    if (resultItems.status != LoadStatus.start &&
        resultItems.status != LoadStatus.error) {
      int totalPages = (resultItems.length / perPage).ceil();

      if (page >= totalPages) {
        if (resultItems.status != LoadStatus.completed) {
          resultItems.status = LoadStatus.completed;
          return await notifyLoadMore();
        }
        return;
      }
    }
    //print("loadMore Before delay");
    int offset = (page * perPage) as int;
    resultItems.status = LoadStatus.loading;
    await notifyLoadMore();
    ResultItems<T> result = await loadMoreProvider(args, offset);
    if (!result.isEmpty) print("First ${T}: ${result.items[0]}");
    resultItems.expand(result);

    if (result.status == LoadStatus.normal ||
        result.status == LoadStatus.completed) {
      page += 1;
      int totalPages = (result.length / perPage).ceil();
      if (page >= totalPages) {
        page = totalPages - 1;
        resultItems.status = LoadStatus.completed;
      }
    }
    if (result.hasError && retryIntervals != null) {
      if (maxRetries == null && _currentRetry < maxRetries) {
        _runTimer();
        _currentRetry++;
      }
    } else {
      _currentRetry = 0;
    }

    return await notifyLoadMore();
  }

  Future<void> refresh() async {
    int offset = (page * perPage) as int;
    resultItems.status = LoadStatus.loading;
    await notifyLoadMore();
    await Future.delayed(Duration(seconds: 2));
  }

  Future<void> reset() async {
    if (resultItems.status == LoadStatus.loading) return false;

    resultItems.length = page = 0;
    resultItems.items = <T>[];
    resultItems.status = LoadStatus.start;
    return await loadMore();
  }

  Future<void> notifyLoadMore({ResultItems<T> result}) async {
    if (onLoadMore != null) {
      if (result == null) result = resultItems;
      onLoadMore(result);
    }
  }

  setOnLoadMore(LoadMoreNotify<T> notify) {
    this.onLoadMore = notify;
  }
}

class Models<T> {
  int length;
  List<T> models;
  dynamic error;
  Models({this.length, this.models, this.error});

  factory Models.fromJson(String source, T Function(dynamic data) func) {
    Map<String, dynamic> data = json.decode(source);
    return Models<T>(
        length: data['length'] == null ? 0 : data['length'],
        models: data['records'].map((x) => func(x)));
  }
}

Models<T> toModels<T>(String source, T Function(dynamic data) func) {
  Map<String, dynamic> data = json.decode(source);
  List<T> list = data['recordes'].map((x) => func(x));
}

class LoadState<T> extends ValueNotifier<T> {
  LoadStatus _status;
  DateTime _lastUpdate;
  final Duration _until;
  bool _stale = true;
  dynamic _error;

  LoadState(T value,
      {LoadStatus status = LoadStatus.normal,
      Duration until = const Duration(hours: 1)})
      : _status = status,
        _until = until,
        super(value);

  bool get isLoading => _status == LoadStatus.loading;
  void reload([T newValue]) {
    _status = LoadStatus.loading;
    _error = null;
    _lastUpdate = null;
    _stale = true;
    value = newValue;
  }

  LoadStatus get status => _status;

  set status(LoadStatus status) {
    if (_status != status) {
      _status = status;

      notifyListeners();
    }
  }

  void update(T newValue, [Object error, DateTime time]) {
    _lastUpdate = time ?? DateTime.now();
    _stale = time != null ? isStale() : false;
    _status = error == null ? LoadStatus.completed : LoadStatus.error;
    _error = error;
    if (value == newValue) notifyListeners();

    value = error == null ? newValue : null;
  }

  bool get stale => _stale;

  bool validate() {
    if (value == null ||
        _lastUpdate == null ||
        DateTime.now().isAfter(_lastUpdate.add(_until))) {
      _error = null;
      _lastUpdate = null;
      _stale = true;
      _status = LoadStatus.normal;
    }
    return !_stale;
  }

  bool isStale() {
    if (_lastUpdate == null ||
        DateTime.now().isAfter(_lastUpdate.add(_until))) {
      _stale = true;
    }
    return _stale;
  }

  dynamic get error => _error;

  set error(Object newError) {
    _error = newError;
    _status = newError == null ? LoadStatus.completed : LoadStatus.error;
  }

  void reset([T newValue]) {
    _error = null;
    _status = LoadStatus.normal;
    _lastUpdate = null;
    value = newValue;
  }

  DateTime get lastUpdate => _lastUpdate;
}

typedef ModelSerializer<T> = T Function(dynamic data);

class ApiRequest<T> {
  final String path;
  final String method;
  final Map<String, String> headers;
  final Map<String, dynamic> data;
  final int timeout;
  final ModelSerializer<T> serializer;
  final bool withAuth;
  ApiRequest(this.path, this.method,
      {this.data, this.headers, this.timeout, this.serializer, this.withAuth});

  factory ApiRequest.of(String path,
          {Map<String, dynamic> data,
          Map<String, String> headers,
          int timeout,
          ModelSerializer<T> serializer,
          bool withAuth}) =>
      ApiRequest(path, "GET",
          data: data,
          headers: headers,
          timeout: timeout,
          serializer: serializer,
          withAuth: withAuth);

  factory ApiRequest.post(String path,
          {Map<String, dynamic> data,
          Map<String, String> headers,
          int timeout,
          ModelSerializer<T> serializer,
          bool withAuth}) =>
      ApiRequest(path, "POST",
          data: data,
          headers: headers,
          timeout: timeout,
          serializer: serializer,
          withAuth: withAuth);

  Future<ResultItem<T>> once() async {
    Response response;
    bool trigger = true;
    try {
      Future<Response> future = _request();

      if (timeout != null) {
        future.timeout(Duration(seconds: timeout), onTimeout: () {
          trigger = false;
          return null;
        });
      }

      response = await future;
    } catch (error, trace) {
      return Future.value(
          ResultItem<T>(error: ErrorResult.tryError(error, trace)));
    }

    if (!trigger) {
      return ResultItem<T>(
          error: ErrorResult(
              code: 0,
              message: TimeoutException(null).toString(),
              network: true));
    }

    return ResultItem.fromResponse<T>(response, serializer);
  }

  Future<ResultItems<T>> list() async {
    Response response;
    bool trigger = true;
    try {
      Future<Response> future = _request();

      if (timeout != null) {
        future.timeout(Duration(seconds: timeout), onTimeout: () {
          trigger = false;
          return null;
        });
      }

      response = await future;
    } catch (error, trace) {
      return Future.value(
          ResultItems<T>(error: ErrorResult.tryError(error, trace)));
    }

    if (!trigger) {
      return ResultItems<T>(
          error: ErrorResult(
              code: 0,
              message: TimeoutException(null).toString(),
              network: true));
    }

    return ResultItems.fromResponse<T>(response, serializer);
  }

  Future<Response> _request() {
    Future<Response> future;
    if (method == 'POST')
      future = Api().post(path, data: data);
    else if (method == 'PUT')
      future = Api().put(path, data: data);
    else if (method == 'DEL')
      future = Api().put(path, data: data);
    else {
      future = Api().get(path, data: data);
    }
    return future;
  }
}
