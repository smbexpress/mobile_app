

import 'package:smbex_app/src/api.dart';

class OpeningHours{

  int day;
  String dayName;
  double start;
  String startString;
  double end;
  String endString;

  OpeningHours({this.day, this.dayName, this.start, this.startString, this.end, this.endString});

  OpeningHours.fromJSON(dynamic jsonMap) {
    day = jsonMap['day'].toInt();
    dayName = jsonMap['day_name'];
    start = jsonMap['start'].toDouble();
    startString = jsonMap['start_string'];
    end = jsonMap['end'].toDouble();
    endString = jsonMap['end_string'];
  }
}

class Branch {
  int id;
  String name;
  String description;
  String phone;
  String contactName;
  String address;
  String country;
  double lat;
  double lng;
  bool closed;
  bool availableForDelivery;
  bool availableForPickup;
  double distance;
  String hub;
  String city;
  List<OpeningHours> opening = [];

  Branch();

  Branch.fromJSON(dynamic jsonMap) {
    try {
      id = jsonMap['id'] != null ? jsonMap['id'].toInt() : 0;
      name = jsonMap['name'];
      dynamic addr = jsonMap['address']??{};
      address = addr['street']??'';
      description = addr['comment'];
      phone = addr['phone'];
      lat = addr['lat'];
      lng = addr['lng'];
      city = addr['city'];
      country = addr['country'];
      contactName = jsonMap['contact_name'];
      closed = jsonMap['closed'] ?? false;
      distance = jsonMap['distance']?.toDouble();
      hub = jsonMap['hub'];
      opening = jsonMap['working_time'] != null
          ? List.from(jsonMap['working_time']).map((element) => OpeningHours.fromJSON(element)).toList()
          : [];
    } catch (e) {
      print(e);
    }
  }

  Branch.fromJsonFast(dynamic jsonMap) {
    id = jsonMap['id']?.toInt() ?? 0;
    name = jsonMap['name'];
    city = jsonMap['city'];
    country = jsonMap['country'];
  }

  String get distanceFormat {
    if ( distance == null  || distance < 10)
      return "~";

    if (distance < 900)
      return distance.toStringAsFixed(0) + " M";

    if (distance <= 1100)
      return " 1 KM";

    return (distance / 1000.0 ).toStringAsFixed(1) + " KM";
  }

  String get cityCountry {
    if ( city == null)
      return country??'';

    if ( country == null)
      return city;

    return '$city, ${Api().getCountry(country).name ?? country}';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'country': country,
    'city': city
  };

  bool isUnknown() {
    return lat == null || lng == null;
  }

}
