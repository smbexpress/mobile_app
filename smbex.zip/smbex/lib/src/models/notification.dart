// @dart=2.12

class Notification {
  String? id;
  late String type;
  String? title;
  String? summary;
  String? body;
  Map<String, dynamic>? data;
  late bool isRead;
  late DateTime date;
  String? route;
  Notification();

  Notification.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      type = jsonMap['type']??'';
      data = jsonMap['data']??{};
      isRead = jsonMap['is_read']??false;
      title = jsonMap['title']??'';
      body = jsonMap['body']??'';
      summary = jsonMap['summary']??'';
      route = jsonMap['route']??'';
      date = DateTime.parse(jsonMap['date']);
    } catch (e) {
      id = '';
      type = '';
      data = {};
      isRead = false;
      date = new DateTime(0);
      title = '';
      summary = '';
      body = '';
      route = null;
      print(e);
    }
  }
}
