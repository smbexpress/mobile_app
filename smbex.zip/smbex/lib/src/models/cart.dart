import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/payment_method.dart';

class Cart {
  String route;
  String type;
  double subtotal;
  double tax;
  double total;
  String currency;
  String footer;
  List<CartItem> items=[];
  PaymentMethodItem paymentMethod;
  Cart();

  Cart.fromJSON(dynamic map) {
    items = map['items'] != null ? Helper.map(map['items'], (el) => CartItem.fromJSON(el)) : <CartItem>[];
    currency = map['currency'];
    subtotal = map['subtotal']?.toDouble();
    tax = map['tax']?.toDouble();
    total = map['total']?.toDouble();
    type = map['type'];
    route = map['route'];
    footer = map['footer'];
    PaymentMethod pm = map['payment_method'] != null ? PaymentMethod.fromJSON(map['payment_method']) : null;
    if (pm != null){
       if (pm.defaultCart != null) {
         paymentMethod = pm.defaultCart.toItem();
       } else {
         paymentMethod = pm.toItem();
       }
    }
  }

}

String _cartName(Object id, String name){
  return name == null || name == '-' ? '$id' : name;
}

class CartItem {

  int id;
  String name;
  String title;
  double subtotal;
  double tax;
  double total;
  CartItem.fromJSON(dynamic map) {
    id = map['id']?.toInt();
    name = _cartName(map['id'], map['name']);
    title = map['title']??'';
    subtotal = map['subtotal']?.toDouble();
    tax = map['tax']?.toDouble();
    total = map['total']?.toDouble();
  }

}

class Transaction {

  int id;
  String checkoutId;
  String brands;
  String domain;
  String baseUrl;
  int acquirerId;
  String provider;
  double amount;
  String currency;
  String mode;
  String status;
  String message;
  String country;
  String redirectUrl;
  Transaction.fromJSON(dynamic map) {
    id = map['id']?.toInt();
    checkoutId = map['checkoutId'];
    brands = map['brands']??"";
    domain = map['domain'];
    baseUrl = map['base_url'];
    acquirerId = map['acquirer_id'];
    amount = map['amount']?.toDouble();
    currency = map['currency'];
    provider = map['provider'];
    mode = map['mode'];
    status = map['state'];
    message = map['message'];
    country = map['country'];
  }

  void update(dynamic map){
    status = map['state']??status;
    message = map['message_to_display']??message;
    amount = map['amount']?.toDouble()??amount;
    currency = map['currency']??currency;
  }
}

