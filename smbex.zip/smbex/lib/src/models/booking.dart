import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/shipment.dart';

import '../custom_color_scheme.dart';
import '../models/address.dart';
import '../models/app.dart';
import '../models/payment.dart';

Map<String,Color> statusColor;

class BookingStatus{
  String code;
  String name;
  BookingStatus();
  BookingStatus.fromJSON(dynamic jsonMap) {
    this.code = jsonMap['code'] != null ? jsonMap['code'] : "";
    this.name = jsonMap['name'] != null ? jsonMap['name'] : "";
  }

  Color getColor(BuildContext context){
    if (statusColor == null){
      ThemeData them = Theme.of(context);
      statusColor = {
        'n' : them.hintColor, //in review
        'v' : them.colorScheme.warning, //in review
        'm' : them.accentColor.withGreen(10),//Confirmed
        'a' : them.colorScheme.success,//Approved
        'r' : them.errorColor,//Rejected
        'o' : them.colorScheme.info,//In Origin
        't' : them.colorScheme.info,//In Route
        'i' : them.accentColor,//In Destination
        'd' : them.colorScheme.success,//Delivered
        'c' : them.errorColor,//Cancelled
      };
    }
    return statusColor[code]??Theme.of(context).accentColor;
  }
  String toString(){
    return "BookingStatus("+{'code':code, 'name': name}.toString()+")";
  }
}


class Booking {
  int id;
  String name;
  BookingStatus status;
  Address pickupAddress;
  Address dropoffAddress;
  String bookingDate;
  String comment;
  double tax;
  double subtotal;
  double total;
  Payment payment;
  CarBrand brand;
  CarModel model;
  TimeWindow pickupTime;
  DateTime pickupDate;
  int rate;
  String bookingUuid;
  String plateNumber;
  String modelYear;
  bool editing = false;
  Booking _originModel;

  Booking(){

  }

  Booking fromMap(dynamic jsonMap){
    //try {

      id = jsonMap['id'] != null ? jsonMap['id'] : 0;
      name = jsonMap['name']??null;
      tax = jsonMap['tax'] != null ? jsonMap['tax'] : 0.0;
      subtotal = jsonMap['subtotal'] != null ? jsonMap['subtotal'] : 0.0;
      total = jsonMap['total'] != null ? jsonMap['total'] : 0.0;
      comment = jsonMap['customer_note']??null;
      status = jsonMap['status'] != null ? BookingStatus.fromJSON(jsonMap['status']) : new BookingStatus();
      pickupAddress =
      jsonMap['pickup_address'] != null ? Address.fromJSON(jsonMap['pickup_address']) : new Address();
      dropoffAddress =
      jsonMap['dropoff_address'] != null ? Address.fromJSON(jsonMap['dropoff_address']) : new Address();
      payment = jsonMap['payment'] != null ? Payment.fromJSON(jsonMap['payment']) : new Payment.init();
      bookingDate = jsonMap['booking_date'];
      pickupDate = Helper.parseDate(jsonMap['pickup_date']);
      pickupTime =
      jsonMap['pickup_time'] != null ? TimeWindow.fromJSON(jsonMap['pickup_time']) : new TimeWindow();
      brand =
      jsonMap['brand'] != null ? CarBrand.fromJSON(jsonMap['brand']) : new CarBrand();
      model =
      jsonMap['model'] != null ? CarModel.fromJSON(jsonMap['model']) : new CarModel();
      rate = jsonMap['rate'];
      bookingUuid = jsonMap['booking_uuid'];
      plateNumber = jsonMap['plate_number'];
      modelYear = jsonMap['model_year'];
    /*
    } catch (e) {
      print("Error at Booking fromMap: $e");
      print(CustomTrace(StackTrace.current, message: e).toString());
      id = 0;
      tax = 0.0;
      subtotal = 0.0;
      total = 0.0;
      name = '';
      comment = '';
      status = BookingStatus();
      pickupDate = null;
      bookingDate = null;
      pickupAddress = Address.fromJSON({'isPickup':true});
      dropoffAddress = new Address();
      payment =  new Payment.init();
      pickupTime = new PickupTime();
      brand = new CarBrand();
      model = new CarModel();
      rate = 0;
      print(e);
    }

     */
    return this;
  }

  static Booking fromJSON(Map<String, dynamic> jsonMap) {
    return Booking().fromMap(jsonMap);
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["comment"] = comment;
    map["pickup_address"] = pickupAddress.id;
    map["dropoff_address"] = dropoffAddress.id;
    map["pickup_time"] = tax;
    map["payment"] = payment?.toMap();
    return map;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'customer_note': comment,
    'pickup_address_id': pickupAddress.id,
    'dropoff_address_id': dropoffAddress.id,
    'brand_id': brand.id,
    'model_id': model.id,
    'pickup_date': Helper.formatDate(pickupDate),
    'pickup_time_id': pickupTime.id,
    'booking_uuid': bookingUuid,
    'plate_number': plateNumber,
    'model_year': modelYear,
    'rate': rate,
  };

  @override
  int get hashCode => id?.hashCode ^ name?.hashCode;

  bool get canEdit => ['n', 'v', 'm', 'a'].indexOf(status?.code) >= 0;

  bool get canCancel => ['n', 'v', 'm', 'a'].indexOf(status?.code) >= 0;

  bool get valid => id != null && id != 0;
  Booking copy(){
    return copyTo(Booking());
  }

  Booking copyTo(Booking m){
    m.id = id;
    m.name = name;
    m.status = status;
    m.pickupAddress = pickupAddress;
    m.dropoffAddress = dropoffAddress;
    m.bookingDate = bookingDate;
    m.comment = comment;
    m.tax = tax;
    m.subtotal = subtotal;
    m.total = total;
    m.payment = payment;
    m.brand = brand;
    m.model = model;
    m.pickupTime = pickupTime;
    m.pickupDate = pickupDate;
    m.rate = rate;
    m.bookingUuid = bookingUuid;
    m.plateNumber = plateNumber;
    m.modelYear = modelYear;
    return m;
  }

  Booking backup() {
    if (_originModel == null){
      _originModel = copy();
    }
    return _originModel;
  }

  String toString(){
    return toJson().toString();
  }

}
