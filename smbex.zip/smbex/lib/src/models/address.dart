
import 'package:flutter/foundation.dart';
import 'package:location/location.dart';
import 'package:smbex_app/src/helpers/helper.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import 'branch.dart';

class Address {
  int id;
  bool isDefault;
  String name;
  String street;
  String street2;
  String zip;
  City city = City();
  String mobile;
  String mobile2;
  String phone;
  String email;
  String comment;
  double lat;
  double lng;
  Country country = Country();
  String province;
  String district;
  bool isPickup = false;
  bool temporary = false;
  Map<String, dynamic> meta;
  Branch facility;
  int facilityId;

  Address copyTo(Address other){
    return other?.copy(this)?? Address.Pickup().copy(this);
  }

  Address copy(Address other){
    id = other.id;
    isDefault = other.isDefault;
    name = other.name;
    street = other.street;
    street2 = other.street2;
    zip = other.zip;
    city = other.city;
    mobile = other.mobile;
    mobile2 = other.mobile2;
    phone = other.phone;
    email = other.email;
    comment = other.comment;
    lat = other.lat;
    lng = other.lng;
    country = other.country;
    city = other.city;
    province = other.province;
    isPickup = other.isPickup;
    district = other.district;
    temporary = other.temporary;
    meta = other.meta != null ? Map.from(other.meta) : null;
    facility = other.facility;
    facilityId = facility?.id ?? other.facilityId;
    return this;
  }

  Address();

  factory Address.Pickup(){
    Address address = Address();
    address.isPickup = true;
    return address;
  }
  factory Address.From(bool pickup){
    Address address = Address();
    address.isPickup = pickup;
    return address;
  }

  Address.fromJSON(dynamic jsonMap) {
    try {
      id = jsonMap['id'];
      name = jsonMap['name'];
      isDefault = jsonMap['is_default'];
      comment = jsonMap['comment'];
      street = jsonMap['street'];
      street2 = jsonMap['street2'] ;
      zip = jsonMap['zip'] ;
      mobile = jsonMap['mobile'] ;
      mobile2 = jsonMap['mobile2'];
      phone = jsonMap['phone'] ;
      email = jsonMap['email'];
      lat = jsonMap['lat'];
      lng = jsonMap['lng'];
      province = jsonMap['province'];
      district = jsonMap['district'];
      isPickup = jsonMap['type'] == 'p' || jsonMap['type'] != 'd';
      country = Api().getCountry(jsonMap['country']);
      city = jsonMap['city'] != null ? City.fromJson(Helper.valueToMap(jsonMap['city'])) : new City();
      facilityId = jsonMap['location_id']?.toInt();
      meta = jsonMap['meta']?.cast<String, dynamic>();
      temporary = jsonMap['temporary'];
      debugPrint("country: $country");

    } catch (e, stack) {
      debugPrintStack(stackTrace: stack, label: e.toString());
      id = 0;
      name = null;
      isDefault = false;
      comment = null;
      street = null;
      street2 = null;
      zip = null;
      mobile =null;
      mobile2 = null;
      phone = null;
      email = null;
      lat = null;
      lng = null;
      province = null;
      isPickup = true;
      country = new Country();
      city = new City();
      print(e);
    }
  }

  Address.fromJsonShort(dynamic map, [bool isPickup = false]){
    try {
      id = map['id'];
      name = map['name'];
      street = map['street'];
      zip = map['zip'];
      phone = map['phone'];
      mobile = map['mobile'] ?? phone;
      email = map['email'];
      district = map['district'];
      country = Api().getCountry(map['country']);
      city = map['city'] != null
          ? City.fromJson(Helper.valueToMap(map['city']))
          : new City();
      facility = map['location'] != null ? Branch.fromJSON(map['facility']) : null;
      facilityId = map['location_id']?.toInt() ?? facility?.id;
      this.isPickup = isPickup;
    }  catch (e, stack) {
      debugPrintStack(stackTrace: stack, label: e.toString());
    }
  }

  bool isUnknown() {
    return lat == null || lng == null;
  }

  Map toMap([bool toSave=false]) {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["name"] = name;
    map["comment"] = comment;
    map["street"] = street;
    map["street2"] = street2;
    map["is_default"] = isDefault;
    map["type"] = isPickup ? 'p' : 'd';
    map["zip"] = zip;
    map["mobile"] = mobile;
    map["mobile2"] = mobile2;
    map["phone"] = phone;
    map["email"] = email;
    map["lat"] = lat;
    map["lng"] = lng;
    map["province"] = province;
    map["district"] = district;
    map["meta"] = meta;
    map["temporary"] = temporary;
    map["location_id"] = facility?.id ?? facilityId;
    map["country"] = country.code;
    if(toSave) {
      map["city"] = city.toJson();
      map["location"] = facility?.toJson();
    } else{
      map["city"] = city.valid ? city.id : null;
    }

    Helper.removeNulls(map);

    return map;
  }

  LocationData toLocationData() {
    return LocationData.fromMap({
      "latitude": lat,
      "longitude": lng,
    });
  }

  String get formattedAddress{
    StringBuffer bu = StringBuffer();
    if (name != null)
      bu.write(name);
    bu.write("\n");
    if (street != null){
      bu.writeln(street);
    }
    if (country.name != null ||  city.name != null || zip != null){
      bu.write("\n");
    }
    if (city.name != null){
      bu.write(city.name);
    }

    if (zip != null){
      if (city.name != null)
        bu.write(", ");
      bu.write(zip);
    }
    
    if (country.name != null){
      if (city.name != null || zip != null)
        bu.write(", ");
      bu.write(country.name);
    }

    return bu.toString();
  }

  String get formattedName{
    StringBuffer bu = StringBuffer();
    if (name != null)
      bu.write(name);
    bu.write("\n");
    if (street != null){
      bu.writeln(street);
    }
    return bu.toString().trim();
  }

  String get formattedRegion{

    if (facility != null) {
      return '${tr.branch}: ${facility.name}, ${facility.cityCountry}';
    }

    StringBuffer bu = StringBuffer();

    if (city.name != null){
      bu.write(city.name);
    }

    if (zip != null){
      if (city.name != null)
        bu.write(", ");
      bu.write(zip);
    }

    if (country.name != null){
      if (city.name != null || zip != null)
        bu.write(", ");
      bu.write(country.name);
    }
    return bu.toString();
  }

  String toString(){
    return "Address("+toMap().toString()+")";
  }

  bool get valid => (id != null && id != 0) || city.valid;

  bool get validId => (id != null && id != 0);

}

class Country {
  int id;
  String name;
  String code;
  String dial;
  List<Region> regions;
  static final Country EMPTY = Country();
  Country({
    this.id=0,
    this.name,
    this.code,
    this.dial,
    this.regions,
  });

  factory Country.fromJson(dynamic json) => Country(
    id: json["id"],
    name: json["name"],
    code: json["code"],
    dial: json["phone_code"]?.toString(),
    regions: json["regions"] == null ? null : List<Region>.from(json["regions"].map((x) => Region.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "code": code == null ? null : code,
    "phone_code": dial == null ? null : dial,
    "regions": regions == null ? null : List<dynamic>.from(regions.map((x) => x.toJson())),
  };


  String toString(){
    return "Country("+toJson().toString()+")";
  }

  bool get valid => id != null && id != 0 || code != null;

  @override
  bool operator ==(Object other) {
    if (identical(this, other))
      return true;
    if (other is Country)
        return other.id == id || code == other.code;

    return false ;
  }

  static Country of(String code, [bool exact=true]) =>
      Api().getCountry(code, exact);

}

class City{
  int id = 0;
  String name;
  double lat;
  double lng;
  String country;
  static final EMPTY =  City();
  City({
    this.id=0,
    this.name,
    this.lat,
    this.lng,
    this.country
  });

  factory City.fromJson(dynamic json) => City(
    id: json["id"] == null ? 0 : json["id"],
    name: json["name"],
    lat: json["lat"]?.toDouble(),
    lng: json["lng"]?.toDouble(),
    country: json["country"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == 0 ? 0 : id,
    "name": name,
    "lat": lat,
    "lng": lng,
    "country": country,
  };

  String toString(){
    return "City("+toJson().toString()+")";
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other))
      return true;
    if (other is City) {
      if (id != 0 && other.id != 0)
        return other.id == id;

      if (other.country == country && name?.toLowerCase() == other.name?.toLowerCase())
        return true;
    }


    return false ;
  }

  bool get valid => id != null && id != 0;

  bool isUnknown() {
    return lat == null || lng == null;
  }
}


class Region {
  int id;
  String name;

  Region({
    this.id,
    this.name,
  });

  factory Region.fromJson(dynamic json) => Region(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
  };
}

