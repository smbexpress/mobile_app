

import 'package:smbex_app/src/models/shipment.dart';

class Setting {
  String appName = '';
  double defaultTax;
  String defaultCurrency;
  String distanceUnit;
  bool currencyRight = false;
  int currencyDecimalDigits = 2;
  String googleMapsKey;
  String appVersion;
  bool enableVersion = true;
  bool enablePayment;
  bool enableWallet;
  Set<DeliveryMode> deliveryModes;
  bool forceFromBranch;
  bool forceToBranch;
  String shareUrl;
  Setting();

  Setting.fromJSON(Map<String, dynamic> jsonMap) {

    for (var key in _default.keys){
      if (!jsonMap.containsKey(key)){
        jsonMap[key] = _default[key];
      }
    }
      googleMapsKey = jsonMap['google_maps_key'] ?? null;
      //mobileLanguage.value = Locale(jsonMap['mobile_language'] ?? "en", '');
      appVersion = jsonMap['app_version'] ?? '';
      distanceUnit = jsonMap['distance_unit'] ?? 'km';
      enableVersion = jsonMap['enable_version'] == null || jsonMap['enable_version'] == '0' ? false : true;
      enablePayment = jsonMap['enable_payment'] ?? false;
      enableWallet = jsonMap['enable_wallet'] ?? false;
      defaultTax = double.tryParse(jsonMap['default_tax']) ?? 0.0; //double.parse(jsonMap['default_tax'].toString());
      defaultCurrency = jsonMap['default_currency'] ?? '';
      currencyRight = jsonMap['currency_right'] == null || jsonMap['currency_right'] == '0' ? false : true;
      deliveryModes = jsonMap['delivery_modes']
              ?.split(",")?.map((mode) => kDeliveryMode[mode])
              ?.toSet()?.cast<DeliveryMode>()?? kDeliveryMode.values.toSet();

      forceFromBranch = jsonMap['force_from_branch'] ?? false;
      forceToBranch = jsonMap['force_to_branch'] ?? false;
      shareUrl = jsonMap['share_url'] ;
    //}
  }

//  ValueNotifier<Locale> initMobileLanguage(String defaultLanguage) {
//    SharedPreferences.getInstance().then((prefs) {
//      return new ValueNotifier(Locale(prefs.get('language') ?? defaultLanguage, ''));
//    });
//    return new ValueNotifier(Locale(defaultLanguage ?? "en", ''));
//  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["app_name"] = appName;
    map["default_tax"] = defaultTax;
    map["default_currency"] = defaultCurrency;
    map["enable_payment"] = enablePayment;
    map["enable_wallet"] = enableWallet;
    map["google_maps_key"] = googleMapsKey;

    List modes = (deliveryModes ?? kDeliveryMode.values)
        .map((e) => kDeliveryModeStr[e]).toList();
    map["delivery_modes"] = modes.join(",");
    map["force_from_branch"] = forceFromBranch ?? false;
    map["force_to_branch"] = forceToBranch ?? false;
    map["share_url"] = shareUrl;
    return map;
  }

  Map<String, dynamic> get defaults => _default;

  Map<String, dynamic> _default = {
      "app_name": "SmbAuto",
      "enable_stripe": "1",
      "default_tax": "10",
      "default_currency": "SR",
      "google_maps_key": "AIzaSyAFN-W8CtWMKALwgJc6ch2q7XFjzotxq78",
      "mobile_language": "en",
      "app_version": "1.0.0",
      "enable_version": "1"
  };


}
