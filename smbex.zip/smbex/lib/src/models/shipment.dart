import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/tracking_info.dart';

import '../custom_color_scheme.dart';
import '../models/address.dart';
import '../models/payment.dart';
import '../helpers/helper.dart';
import '../repository/settings_repository.dart';
import 'branch.dart';

Map<String, Color> statusColor;

class Place {
  int id;
  String name;
  Address address;
  String workingTime;
  Place({this.id, this.name, this.address, this.workingTime});
  factory Place.fromJSON(dynamic map) => Place(
        id: map['id'],
        name: map['name'],
        address: Address.fromJSON(map['address'] ?? {}),
        workingTime: map['working_time'],
      );
}

class Status {
  int id;
  String code;
  String name;

  Status({this.id, this.name, this.code});
  factory Status.fromJSON(dynamic map) =>
      Status(id: map['id'], name: map['name'] ?? '', code: map['code'] ?? '');
  factory Status.fromList(dynamic list) => Status(code: list[0], name: list[1]);

  static Status tryStatus(dynamic data) {
    if (data is String) {
      return Status(name: data, code: data);
    }
    if (data is List && data.length == 2) {
      return Status.fromList(data);
    }
    if (data is Map) {
      return Status.fromJSON(data);
    }
    return Status.fromJSON({});
  }

  Color getColor(BuildContext context) {
    if (statusColor == null) {
      ThemeData them = Theme.of(context);
      statusColor = {
        'p': Colors.black54, //in Pending
        'm': Colors.lime, // Confirmed
        's': Colors.deepPurpleAccent, //SFP
        'i': them.colorScheme.primary, //In Facility
        't': them.colorScheme.primary, //Transit
        'a': them.colorScheme.success, //Arrived
        'f': them.colorScheme.success, //OFD
        'd': them.colorScheme.success, //Delivered
        'l': them.colorScheme.error, //Failed
        'e': them.colorScheme.error, //Exception
        'c': them.hintColor, //Cancelled
        'r': Colors.orange, //For Return
        'w': Colors.orange, //A waiting payment
      };
    }
    return statusColor[code] ?? Theme.of(context).accentColor;
  }

  @override
  String toString() => name;
}

class Activity {
  int id;
  String notes;
  Place place;
  Status status;
  String date;
  Activity({this.id, this.notes, this.place, this.status, this.date});
  factory Activity.fromJSON(dynamic map) => Activity(
        id: map['id'],
        notes: map['name'],
        place: Place.fromJSON(map['place'] ?? {}),
        status: Status.fromJSON(map['status'] ?? {}),
        date: map['date'],
      );
  String toString() {
    return "Activity(" +
        {'id': id, 'status': status, 'place': status, 'date': date}.toString() +
        ")";
  }
}

class TimeWindow {
  int id;
  String name;
  double start;
  double end;
  TimeWindow({this.id, this.name, this.start, this.end});

  factory TimeWindow.of(double start, double end, [String name]) => TimeWindow(
      name: name ??
          '${Helper.formatDuration(start)} - ${Helper.formatDuration(end)}',
      start: start,
      end: end);

  factory TimeWindow.fromJSON(dynamic map) => TimeWindow(
      id: map['id']?.toInt(),
      name: map['name'] ??
          '${Helper.formatDuration(map['start']?.toDouble())} - ${Helper.formatDuration(map['end']?.toDouble())}',
      start: map['start']?.toDouble(),
      end: map['end']?.toDouble());

  Map<String, dynamic> toMap() => {'start': start, 'end': end};

  String toString() {
    return name;
  }

  bool get valid => id != null && id != 0;
  bool get isEmpty => start == end && start == 0;
  bool validForStart(double validStart) {
    return start != null && start >= validStart;
  }

  bool validForEnd(double validEnd) {
    return end != null && end <= validEnd;
  }

  bool validForAll(double validStart, double validEnd) {
    return validForStart(validStart) && validForEnd(validEnd) && start <= end;
  }

  String startToString() {
    return Helper.formatDuration(start);
  }

  String endToString() {
    return Helper.formatDuration(end);
  }

  TimeWindow copy(TimeWindow other) {
    start = other?.start;
    end = other?.end;
    id = other?.id;
    name = other?.name;
    return this;
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is TimeWindow && other.start == start && other.end == end) {
      return true;
    }
    return false;
  }

  @override
  int get hashCode => Object.hash(start, end);
}

class Currency {
  int id;
  String name;
  String symbol;
  String position;
  Currency({this.id, this.name, this.symbol, this.position});
  factory Currency.fromJSON(dynamic map) => Currency(
      id: map['id'],
      name: map['name'],
      symbol: map['symbol'],
      position: map['position']);

  static Currency fromResult(dynamic result) {
    return Api().company.getCurrency(result);
  }

  bool get valid => id != null && id != 0;

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is Currency && other.id == id;
  }

  @override
  int get hashCode => id ?? 0;
}

class Package {
  int id;
  String name;
  String code;
  String description;
  String type;
  int maxItems;
  double weight;
  String measureType;
  double maxCod;
  int qty;
  Package(
      {this.id,
      this.name,
      this.code,
      this.type,
      this.weight,
      this.maxItems,
      this.measureType,
      this.description,
      this.maxCod,
      this.qty});
  factory Package.fromJSON(dynamic map) => Package(
        id: map['id'],
        name: map['name'],
        code: map['code'],
        type: map['type'],
        weight: map['weight']?.toDouble(),
        measureType: map['mesure_type'],
        maxItems: map['max_items']?.toInt(),
        description: map['description'],
        maxCod: map['max_cod']?.toDouble(),
        qty: map['qty']?.toInt(),
      );
  static tryParse(dynamic map) {
    if (map is String) return Package(name: map);

    return Package.fromJSON(map ?? {});
  }

  bool get valid => id != null && id != 0;

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is Package && other.id == id;
  }

  @override
  int get hashCode => (id?.hashCode) ?? 0 ^ (name?.hashCode) ?? 0;

  bool get hasCod => !isDoc && maxCod != null && maxCod > 0;
  bool get isDoc => type == 'd';
  bool get isWeight => measureType == 'w' || measureType == 'wv';
  bool get hasMaxWeight => weight != null && weight > 0;
  bool get hasItems => maxItems != null && maxItems > 1;
}

class Service {
  int id;
  String name;
  String code;
  String description;

  Service({this.id, this.code, this.name, this.description});
  factory Service.fromJSON(dynamic map) => Service(
      id: map['id'],
      name: map['name'],
      code: map['code'],
      description: map['description']);
  bool get valid => id != null && id != 0;

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other != null && other is Service && other.id == id;
  }

  static tryParse(dynamic map) {
    if (map is String) return Service(name: map);

    return Service.fromJSON(map ?? {});
  }
}

class Rate {
  int id;
  String name;
  String code;
  double rate;
  double total;
  String description;
  List<Rate> addons;
  String icon;
  String badge;
  String taxNote;
  String termLink;
  static final Rate EMPTY = Rate();

  Rate(
      {this.id,
      this.name,
      this.code,
      this.rate,
      this.total,
      this.description,
      this.icon,
      this.badge,
      this.taxNote,
      this.termLink,
      this.addons});
  factory Rate.fromJSON(dynamic map) => Rate(
      id: map['id'],
      name: map['name'],
      code: map['code'],
      rate: map['rate']?.toDouble(),
      total: map['total']?.toDouble() ?? map['rate']?.toDouble(),
      description: map['description'],
      taxNote: map['tax_note'],
      termLink: map['term_link'],
      icon: map['icon'],
      badge: map['badge'],
      addons: map['addons'] != null
          ? Helper.map(map['addons'], (el) => Rate.fromJSON(el))
          : null);
  bool get valid => id != null && id > 0;

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other != null && other is Rate && other.id == id;
  }

  @override
  int get hashCode => (id?.hashCode) ?? 0 ^ (name?.hashCode) ?? 0;

  String toString() {
    return "Rate(" + {'name': name, 'rate': rate}.toString() + ")";
  }
}

class Parcel {
  int id;
  String name;
  int qty;
  double width;
  double height;
  double length;
  double weight;
  double actWeight;

  Parcel(
      {this.id,
      this.name,
      this.qty,
      this.width,
      this.height,
      this.length,
      this.weight,
      this.actWeight});

  factory Parcel.fromJSON(dynamic map) => Parcel(
        id: map['id'],
        name: map['name'],
        qty: map['qty']?.toInt(),
        width: map['width']?.toDouble(),
        height: map['height']?.toDouble(),
        length: map['length']?.toDouble(),
        weight: map['weight']?.toDouble(),
        actWeight: map['total_weight']?.toDouble(),
      );

  Map<String, dynamic> toMap() => Helper.removeNulls({
        'id': id,
        'qty': qty,
        'width': width,
        'height': height,
        'length': length,
        'weight': weight,
      });

  Parcel copy(Parcel other) {
    id = other.id;
    name = other.name;
    weight = other.weight;
    width = other.width;
    height = other.height;
    length = other.length;
    qty = other.qty;
    actWeight = other.actWeight;
    return this;
  }

  bool get valid => id != null && id != 0;

  @override
  int get hashCode => (id?.hashCode) ?? 0;

  static List<Map> ofMap(
      Map defaultMap, List<Parcel> parcels, int parcelCount) {
    if (parcelCount == null || parcelCount <= 1)
      return parcels != null && parcels.isNotEmpty
          ? parcels.map((parcel) => parcel.toMap()).toList()
          : [defaultMap];

    if (parcels == null || parcels.isEmpty) {
      return List.generate(parcelCount, (index) => defaultMap);
    }

    if (parcels.length < parcelCount)
      return List.generate(parcelCount, (index) => parcels[0].toMap());

    parcels.map((parcel) => parcel.toMap()).toList();
  }
}

class ShipmentChild {
  int id;
  String name;
  ShipmentChild({this.id, this.name});
  factory ShipmentChild.fromJSON(dynamic map) =>
      ShipmentChild(id: map['id'], name: map['name']);
}

class Shipment {
  int id;
  String name;
  Activity activity;
  Address from;
  Address to;
  String order_date;
  String content;
  double tax;
  double subtotal;
  double total;
  Payment payment;
  TimeWindow pickupTime;
  String pickupDate;
  int rating;
  String bookingUuid;
  Package package;
  Service service;
  List<Parcel> parcels;
  String currency;
  double cod;
  String codCurrency;
  bool editing = false;
  Shipment _originModel;
  int qty;
  double weight;
  Rate rate = Rate.EMPTY;
  Status status;
  bool isDelivery = false;
  double amountToDue;
  String amountToDueCurrency;
  String deliveryMode;
  int parcelCount;
  String headNote;
  TrackingItem currentTracking;
  Branch fromBranch;
  Branch toBranch;
  String eta;
  int flags;
  dynamic meta;

  Shipment();

  factory Shipment.fromJSON(dynamic map) {
    return Shipment._fromJSON(map);
  }

  factory Shipment.ofDelivery(dynamic map) {
    return Shipment._fromJSON(map, true);
  }

  Shipment._fromJSON(dynamic map, [bool delivery = false]) {
    //try {
    debugPrint("Shipment Json: ${map['pickup_time']}");
    id = map['id'];
    name = map['tracking_code'];
    from = Address.fromJSON(map['from_address'] ?? {});
    to = Address.fromJSON(map['to_address'] ?? {});
    order_date =
        Helper.formatDatetime(Helper.parseServerDate(map['order_date']));
    content = map['content'];
    isDelivery = delivery;
    deliveryMode = map['delivery_mode'];
    eta = Helper.formatDate(Helper.parseServerDate(map['eta']));
    var fromBranch = map['from_location'];
    var toBranch = map['to_location'];
    if ((deliveryMode == 'rd' || deliveryMode == 'rr') && fromBranch != null) {
      fromBranch = Branch.fromJsonFast(fromBranch);
    } else {
      fromBranch = null;
    }

    if ((deliveryMode == 'dr' || deliveryMode == 'rr') && toBranch != null) {
      toBranch = Branch.fromJsonFast(toBranch);
    } else {
      toBranch = null;
    }
    this.fromBranch = fromBranch;
    this.toBranch = toBranch;
    flags = map['flags']?.toInt();
    if (!delivery) {
      tax = map['tax']?.toDouble();
      subtotal = map['subtotal']?.toDouble();
      total = map['total']?.toDouble();
      currency = map['currency'];
      pickupTime = TimeWindow.fromJSON(map['pickup_time'] ?? {});
      pickupDate = map['pickup_date'];
    } else {
      currentTracking = map['current_activity'] != null
          ? TrackingItem.fromMap(map['current_activity'])
          : null;
    }
    if (map['payment'] != null) payment = Payment.fromJSON(map['payment']);
    headNote = map['head_note'];

    package = Package.tryParse(map['package_type'] ?? {});
    service = Service.tryParse(map['service'] ?? {});
    parcels =
        Helper.map(map['parcels'] ?? [], (el) => Parcel.fromJSON(el)) ?? [];
    weight = map['total_weight']?.toDouble();
    cod = map['cod']?.toDouble();
    codCurrency = map['cod_currency'];
    meta = map['meta'];
    status = Status.tryStatus(map['status']);
    parcelCount = map['parcel_count']?.toInt();

    if (!delivery) {
      dynamic amountDue = map['amount_due'];
      if (amountDue != null && amountDue['amount'] != null) {
        amountToDue = amountDue['amount']?.toDouble() ?? 0.0;
        amountToDueCurrency = amountDue['currency'];
      } else if (status?.code == 'p' && total != null && total > 0) {
        amountToDue = total;
        amountToDueCurrency = currency;
      }
    } else {
      dynamic amountDue = map['cod_amount_due'];
      if (amountDue != null && amountDue['amount'] != null) {
        amountToDue = amountDue['amount']?.toDouble() ?? 0.0;
        amountToDueCurrency = amountDue['currency'];
      }
    }

    print("Shipment amountDue: $amountToDue");
    print("Shipment parsed success!!");
    /*
    } catch(e, stack){
      debugPrintStack(stackTrace: stack, label: e.toString());
      //print(CustomTrace(StackTrace.current, message: e.toString()).toString());
    }*/
  }

  Map toMap() => {
        'id': id,
        'name': name,
        'from_address': from.validId ? from.id : from.toMap(true),
        'to_address': to.validId ? to.id : to.toMap(true),
        'content': content,
        'pickup_time': pickupTime?.toMap(),
        'pickup_date': pickupDate,
        'package_type': package.code,
        'service': service?.code ?? rate?.code,
        'parcels':
            Parcel.ofMap({'qty': qty, 'weight': weight}, parcels, parcelCount),
        'parcel_count': parcelCount ?? (parcels.isEmpty ? 1 : parcels.length),
        'cod': cod,
        'cod_currency': codCurrency,
        'rate': rate?.id,
        'delivery_mode': deliveryMode,
        if (fromBranch != null) 'from_branch': fromBranch.id,
        if (toBranch != null) 'to_branch': toBranch.id,
      };

  @override
  int get hashCode => (id?.hashCode) ?? 0 ^ (name?.hashCode) ?? 0;

  bool get canEdit => status == null || status?.code == 'p';

  bool get canCancel =>
      ['n', 'v', 'm', 'a'].indexOf(activity?.status?.code) >= 0;

  bool get valid => id != null && id != 0;

  Shipment copyTo(Shipment m, [bool withMeta = false]) {
    m.id = id;
    m.name = name;
    m.activity = activity;
    m.from.copy(from);
    m.to.copy(to);
    m.order_date = order_date;
    m.content = content;
    m.tax = tax;
    m.subtotal = subtotal;
    m.total = total;
    m.payment = payment;
    m.package = package;
    m.pickupTime?.copy(pickupTime);
    m.pickupDate = pickupDate;
    m.rating = rating;
    m.parcels = m.parcels.map((e) => e.copy(new Parcel())).toList();
    m.cod = cod;
    m.codCurrency = codCurrency;
    m.currency = currency;
    m.weight = weight;
    m.qty = qty;
    m.meta = withMeta
        ? meta is Map
            ? Map.of(meta)
            : meta
        : m.meta;
    m.deliveryMode = deliveryMode;
    m.parcelCount = parcelCount;
    m.currentTracking = currentTracking;
    m.fromBranch = fromBranch;
    m.toBranch = toBranch;

    return m;
  }

  Shipment copy([Shipment m]) {
    return copyTo(m ?? Shipment.fromJSON({}));
  }

  String toString() {
    Map map = toMap();
    map.addAll({"from": from.formattedAddress});
    map.addAll({"to": to.formattedAddress});
    map.addAll({"package": package.name});

    return toMap().toString();
  }

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is Shipment && other.id == id;
  }

  bool get hasCod => package.hasCod && cod != null && cod > 0;
  bool get isDoc => package.isDoc;
  bool get hasWeight => package.isWeight && weight != null && weight > 0;
  bool get isWeightValid =>
      !package.isWeight ||
      (hasWeight && (!package.hasMaxWeight || weight <= package.weight));
  bool get isValidCod => hasCod && cod <= package.maxCod;

  bool get isAwaitingPayment => meta is Map && meta['awaiting_payment'] == true;
}

enum DeliveryMode {
  RETAIL_TO_RETAIL,
  RETAIL_TO_DOOR,
  DOOR_TO_DOOR,
  DOOR_TO_RETAIL,
}

const kDeliveryMode = <String, DeliveryMode>{
  'rr': DeliveryMode.RETAIL_TO_RETAIL,
  'rd': DeliveryMode.RETAIL_TO_DOOR,
  'dd': DeliveryMode.DOOR_TO_DOOR,
  'dr': DeliveryMode.DOOR_TO_RETAIL,
};

const kDeliveryModeStr = <DeliveryMode, String>{
  DeliveryMode.RETAIL_TO_RETAIL: 'rr',
  DeliveryMode.RETAIL_TO_DOOR: 'rd',
  DeliveryMode.DOOR_TO_DOOR: 'dd',
  DeliveryMode.DOOR_TO_RETAIL: 'dr',
};

class TinyShipment {
  int id;
  String name;
  Address from;
  Address to;
  Branch fromBranch;
  Branch toBranch;
  String reference;
  String date;
  String orderDate;
  Status status;
  String deliveryMode;
  bool isDelivery;
  TinyShipment(
      {this.id,
      this.name,
      this.from,
      this.to,
      this.fromBranch,
      this.toBranch,
      this.reference,
      this.date,
      this.orderDate,
      this.status,
      this.deliveryMode,
      this.isDelivery});

  factory TinyShipment.fromJSON(dynamic map, [bool isDelivery = false]) {
    //print("TinyShipment:: fromJSON -> map: ${map}");
    final orderDate = Helper.parseServerDate(map['order_date']);
    final orderDateString = Helper.formatDatetime(orderDate);
    final dateString = Helper.formatDate(orderDate);
    final from = Address.fromJsonShort(map['from_address']);
    final to = Address.fromJsonShort(map['to_address']);
    final deliveryMode = map['delivery_mode'];
    var fromBranch = map['from_location'];
    var toBranch = map['to_location'];
    if ((deliveryMode == 'rd' || deliveryMode == 'rr') && fromBranch != null) {
      fromBranch = Branch.fromJsonFast(fromBranch);
    } else {
      fromBranch = null;
    }

    if ((deliveryMode == 'dr' || deliveryMode == 'rr') && toBranch != null) {
      toBranch = Branch.fromJsonFast(toBranch);
    } else {
      toBranch = null;
    }

    return TinyShipment(
        id: map['id']?.toInt(),
        name: map['tracking_code'],
        from: from,
        to: to,
        fromBranch: fromBranch,
        toBranch: toBranch,
        reference: map['reference'],
        date: dateString,
        orderDate: orderDateString,
        status: Status.fromList(map['status'] ?? ['p', 'Pending']),
        deliveryMode: deliveryMode,
        isDelivery: isDelivery);
  }
  bool get valid => id != null && id != 0;

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is TinyShipment && other.id == id;
  }

  @override
  int get hashCode => (id?.hashCode) ?? 0 ^ (name?.hashCode) ?? 0;
}

class WorkingTime {
  final DateTime date;
  //final List<TimeWindow> windows;
  final List<double> timeSpans;
  WorkingTime({this.date, this.timeSpans});

  factory WorkingTime.fromJSON(dynamic jsonMap) {
    final dateString = jsonMap['date'];
    List<double> timeSpans = jsonMap['time_spans']?.cast<double>() ?? [];
    List<TimeWindow> windows = [];
    for (int i = 0; i < timeSpans.length - 1; i++) {
      //windows.add(TimeWindow.of(timeSpans[i], timeSpans[i+1]));
    }

    if (dateString != null) {
      final DateTime date = Helper.parseDate(dateString) ?? DateTime.now();
      return WorkingTime(date: date, timeSpans: timeSpans);
    }
    return WorkingTime(
        date: Helper.parseDate(dateString) ?? DateTime.now(),
        timeSpans: timeSpans);
  }
}

class WorkingTimes {
  final List<WorkingTime> items;
  final int cityId;
  WorkingTimes({this.items, this.cityId});

  factory WorkingTimes.fromJSON(dynamic json) {
    return WorkingTimes(
        items: json['items']
            ?.map((time) => WorkingTime.fromJSON(time))
            ?.toList()
            ?.cast<WorkingTime>(),
        cityId: json['city_id']?.toInt());
  }
}

class Offer {
  int id;
  String title;
  double percent;
  double flat;
}

class ShipmentMeta {
  final Set<DeliveryMode> modes;
  final String codCurrency;
  final Address fromAddress;
  final Map<String, double> currencies;
  final bool forceFromBranch;
  final bool forceToBranch;
  ShipmentMeta(
      {this.modes,
      this.codCurrency,
      this.fromAddress,
      this.currencies,
      this.forceFromBranch,
      this.forceToBranch});

  factory ShipmentMeta.fromJSON(dynamic json) {
    final forceFromBranch =
        json['force_from_branch'] ?? kSettings.forceFromBranch ?? false;

    Address fromAddress = Address.fromJSON(json['from_address']);
    if (forceFromBranch && fromAddress.facilityId == null) fromAddress = null;
    dynamic meta = json['meta'] ?? const <String, dynamic>{};
    final currencies = meta['currencies'] ?? json['currencies'] ?? const [];
    return ShipmentMeta(
        fromAddress: fromAddress,
        modes: json['delivery_modes']
                ?.split(",")
                ?.map((mode) => kDeliveryMode[mode])
                ?.toSet()
                ?.cast<DeliveryMode>() ??
            kSettings.deliveryModes,
        currencies: Map.fromEntries(currencies
            .map((cur) =>
                MapEntry<String, double>(cur['name'], cur['rate'].toDouble()))
            .toList()
            .cast<MapEntry<String, double>>()),
        codCurrency: json['cod_currency'],
        forceFromBranch:
            json['force_from_branch'] ?? kSettings.forceFromBranch ?? false,
        forceToBranch:
            json['force_to_branch'] ?? kSettings.forceToBranch ?? false);
  }
}
