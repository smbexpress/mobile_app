import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/payment.dart';

import '../../i18n/i18n.dart';


bool _isExpired(String cardExpiry) {
  List expire = cardExpiry.split('/');
  final ds = DateTime.now();
  return ds.year > int.parse(expire[1])
         || (ds.year == int.parse(expire[1])  && ds.month >= int.parse(expire[0]) );
}

String _formatExpire(String cardExpiry) {
  List expire = cardExpiry.split('/');
  return '${expire[0]}/${expire[1].length > 2 ? expire[1].substring(2) : expire[1]}';
}

const List<String> _assetsPaymentBrands = [
  'cash',
  'creditcard',
  'mastercard',
  'visa',
  'mada',
  'apple',
  'google',
  'stc'
];

String _getPaymentMethodIcon(PaymentMethod method){
  if (method.provider == 'hyperpay'){
    if (method.brands?.isNotEmpty == true) {
      return method.brands.length > 1
          ? 'assets/img/creditcard.png'
          : _assetsPaymentBrands.contains(method.brands[0].toLowerCase())
            ? 'assets/img/${method.brands[0].toLowerCase()}.png'
            : Config().url + "web/media/image/payment.acquirer/${method.id}";
    }
  }
  return _assetsPaymentBrands.contains(method.provider.toLowerCase())
         ? 'assets/img/${method.provider.toLowerCase()}.png'
         : Config().url + "web/media/image/payment.acquirer/${method.id}";
}

String _getCardIcon(String brand){
  return _assetsPaymentBrands.contains(brand.toLowerCase())
      ? 'assets/img/${brand.toLowerCase()}.png'
      : Config().url + "web/media/payment/icon/${brand}";
}

String getPaymentIcon(Payment payment) {
  final method = payment.method?.toLowerCase();
  if (_assetsPaymentBrands.contains(method)) {
    return 'assets/img/${method}.png';
  }

  if (_assetsPaymentBrands.contains(payment.provider)) {
    return 'assets/img/${payment.provider}.png';
  }
  if (payment.id != null && payment.id.isNotEmpty)
    return Config().url +
        "web/media/image/payment.acquirer/${payment.id}";

  return 'assets/img/cash.png';

}

class PaymentCard{
  int id;
  String name;
  String ref;
  String expire;
  String brand;
  String holder;
  bool expired;
  bool isDefault;
  bool verified;
  PaymentMethod method;
  bool isCvvFocused = false;
  String cvv;

  PaymentCard.fromJSON(dynamic map) {
    id = map['id']?.toInt();
    name = map['name'];
    ref = map['ref'];
    expired = _isExpired(map['expire']);
    expire = _formatExpire(map['expire']);
    brand = map['brand'];
    holder = map['holder'];
    isDefault = map['is_default']??false;
    verified = map['verified']??false;
  }

  PaymentMethodItem toItem(){
    return PaymentMethodItem.ofCard(this);
  }

  String get icon => _getCardIcon(this.brand);

}

class PaymentMethod {
  String id;
  String name;
  String title;
  String description;
  String logo;
  String provider='custom';
  double fees;
  double balance;
  String currency;
  String mode;
  String route;
  bool isCustom=true;
  List<String> brands = [];
  List<PaymentCard> cards = [];
  bool isDefault = false;
  PaymentCard defaultCart;

  PaymentMethod(this.id, this.name, this.description, this.route, this.logo);

  PaymentMethod.fromJSON(dynamic map) {
    id = map['id']?.toString();
    name = map['name'];
    title = map['title'];
    description = Helper.skipHtml(map['description']) ;
    provider = map['provider'];
    currency = map['currency'];
    mode = map['mode'];
    fees = map['fees']?.toDouble();
    balance = map['balance']?.toDouble();
    brands = map['brands']?.cast<String>()??[];
    cards = Helper.map(map['cards'], (el) => PaymentCard.fromJSON(el));
    isCustom = false;
    cards.forEach((card) {
      card.method = this;
      if (card.isDefault)
        defaultCart = card;
    });

    if (provider == 'cod'){
      route = "/CashOnDelivery";
    } else if (provider == 'transfer'){
      route = "/PayOnPickup";
    } else {
      route = "/Checkout";
    }
  }

  PaymentMethodItem toItem(){
    return PaymentMethodItem.ofMethod(this);
  }

  String  get icon => _getPaymentMethodIcon(this);

  @override
  String toString() {
    return "${runtimeType}(name: $name, title: $title, description: $description)";
  }
}



class PaymentMethodItem {
  String id;
  String name;
  String description;
  String icon;
  String route;
  bool isCard;
  Object ref;
  PaymentMethodItem(this.id, this.name, this.description, this.route, this.icon, this.isCard, this.ref);


  PaymentMethod get method => ref is PaymentMethod ? ref as PaymentMethod : null;
  PaymentCard get card  => ref is PaymentCard ? ref as PaymentCard : null;

  static PaymentMethodItem ofMethod(PaymentMethod ob){
    return PaymentMethodItem(ob.id, ob.title ?? ob.name, ob.description??'', ob.route, ob.icon, false, ob);
  }

  static PaymentMethodItem ofCard(PaymentCard ob){
    return PaymentMethodItem(ob.id.toString(), '**** **** **** ${ob.name}', ob.expire, ob.method.route, ob.icon, true, ob);
  }
}

class PaymentMethodList {
  List<PaymentMethod> _paymentsList;
  List<PaymentMethod> _cashList;
  List<PaymentMethod> _pickupList;
  PaymentMethod defaultMethod;
  PaymentMethodList() {
    this._paymentsList = [
      new PaymentMethod("credit", S.tr.visa_card, S.tr.click_to_credit_card_payment, "/Checkout", "assets/img/credit.png"),
    ];
    this._cashList = [
      new PaymentMethod("cod", S.tr.cash_on_delivery, S.tr.click_to_pay_cash_on_delivery, "/CashOnDelivery", "assets/img/cash.png"),
    ];
    this._pickupList = [
      new PaymentMethod("pop", S.tr.pay_on_pickup, S.tr.click_to_pay_on_pickup, "/PayOnPickup", "assets/img/pay_pickup.png"),
    ];
  }
  PaymentMethodList.of(List<PaymentMethod> pms) {
    this._paymentsList = [];
    this._cashList = [];
    this._pickupList = [];
    for (PaymentMethod pm in pms){
      if (pm.provider == 'cod'){
        _cashList.add(pm);
      } else if (pm.provider == 'transfer'){
        _pickupList.add(pm);
      } else {
        _paymentsList.add(pm);
      }
    }
    pms.forEach((pm) {
      if(defaultMethod != null){
        pm.isDefault = false;
        pm.defaultCart = null;
      } else if (pm.isDefault){
        defaultMethod = pm;
      }
    });
  }



  static Future<PaymentMethodList> get(endpoint, Map<String,dynamic> data) async {
    return ResultItems.get<PaymentMethod>(endpoint, data: data, func: (data) => PaymentMethod.fromJSON(data))
        .then((value) => PaymentMethodList.of(value.items));
  }

  List<PaymentMethod> get paymentsList => _paymentsList;
  List<PaymentMethod> get cashList => _cashList;
  List<PaymentMethod> get pickupList => _pickupList;
}
