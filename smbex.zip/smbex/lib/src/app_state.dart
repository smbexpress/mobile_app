import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart' hide Action, Route;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/repository/account_repository.dart';

import 'api.dart';
import 'helpers/connection_status_singleton.dart';
import 'helpers/notification_service.dart';
import 'helpers/upgrader.dart';
import 'models/account.dart';
import 'models/setting.dart';
import 'notification_provider.dart';
import 'repository/settings_repository.dart' as settingsRepo;

/// A state model class that follows provider pattern for internal package state management, read this guide
/// for more details: https://flutter.dev/docs/development/data-and-backend/state-mgmt/simple
class AppState extends ChangeNotifier{

  static AppState _instance ;

  static AppState get instance => _instance;

  final navigatorKey = GlobalKey<NavigatorState>();

  bool _hasLogin = false;
  AppState([this.firebaseMessaging]){
    _instance = this;
    _setupAsync();
    currentAccount.addListener(_onAppStateChanged);
    settingsRepo.settingNotifier.addListener(_onAppStateChanged);
    loginNotifier.addListener(_loginChanged);
  }

  void _setupAsync() async {
    Config.setCurrentVersion();
    ConnectionStatusSingleton.getInstance().initialize();
    getCurrentAccount();
    Future.delayed(Duration(seconds: 1), (){
      settingsRepo.initSettings();
      Api().init();
    });


  }
  
  void _onAppStateChanged(){
    notifyListeners();
    debugPrint("AppState:: _onAppStateChanged");
  }

  @override
  void dispose() {
    super.dispose();
    currentAccount.removeListener(_onAppStateChanged);
    settingsRepo.settingNotifier.removeListener(_onAppStateChanged);
    loginNotifier.removeListener(_onAppStateChanged);
    ConnectionStatusSingleton.getInstance().dispose();
    tokenSubscription?.cancel();
  }

  void _loginChanged(){
    debugPrint("AppState:: _loginChanged: ${account.valid}");
    if (!account.valid) {
      _hasLogin = false;
      if (tokenSubscription != null)
        tokenSubscription.cancel();
      tokenSubscription = null;
      if (navigatorKey.currentContext != null) {
        final notificationProvider = Provider.of<NotificationProvider>(
            navigatorKey.currentContext, listen: false);
        notificationProvider.dropFcm();
      }
    } else {
      _hasLogin = true;
      firebaseMessaging.getToken().then(updateToken);
      tokenSubscription = firebaseMessaging.onTokenRefresh.listen(updateToken);
      createNavigatorObserver();
      _popRouteNotify._checkFcmSetup();
    }
  }

  void checkVersion() async{
    final upgrader = Upgrader();
    await upgrader.initialize();
    await upgrader.checkVersion(context: navigatorKey.currentState.context);
  }

  NavigatorObserver createNavigatorObserver(){
    _popRouteNotify ??= PopRouteNotify(navigatorKey, _hasLogin);
    return _popRouteNotify;
  }

  PopRouteNotify get popRouteNotify => _popRouteNotify;

  PopRouteNotify _popRouteNotify;
  StreamSubscription tokenSubscription;
  FirebaseMessaging firebaseMessaging;

  Setting get setting => settingsRepo.settingNotifier.value;
  Account get account => currentAccount.value;
}

// ignore: missing_return
Future<dynamic> onBackgroundMessageHandler(RemoteMessage message)async{
    print("AppState::onBackgroundMessageHandler data: ${message.data}");
    final data = message.data;
    final notification = message.notification;
    if (notification != null) {
      //await NotificationService().init();
      // Handle notification message
      //await NotificationService().showNotifications(message);
    }
}

mixin PopRouteObserver {

  bool onPop(String routeName) => false;

}

typedef OnPopObserver = bool Function(String routeName) ;

class PopRouteAdapter with PopRouteObserver{
  final OnPopObserver _onPop;
  PopRouteAdapter(this._onPop);
  @override
  bool onPop(String routeName) => _onPop(routeName);

}

class PopRouteNotify extends NavigatorObserver{

  final List<PopRouteObserver> _list = [];
  final GlobalKey<NavigatorState> navigatorKey;
  final List<String> _stack = [];
  bool _listenMain = false;
  PopRouteNotify(this.navigatorKey, this._listenMain);


  void addObserver(PopRouteObserver observer){
    _list.remove(observer);
    _list.add(observer);
  }

  void removeObserver(PopRouteObserver observer){
    _list.remove(observer);
  }

  String get currentRoute => _stack.isNotEmpty ? _stack.last : null;

  void _add(String routeName){
    print("PopRouteNotify::add: $routeName");
    if (routeName != null)
      _stack.add(routeName);
    if (_listenMain && (routeName == '/Home')){
      _setupFcm();
    }
  }

  void _remove(String routeName, [bool notify=false]){

    if (_stack.isNotEmpty){
      if (_stack.last == routeName){
        try {
          if (notify) {
            _notify();
          }
        } finally {
          _stack.removeLast();
        }
      }
    }
    print("PopRouteNotify::remove: $routeName, notify:$notify, history: $_stack");
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic> previousRoute) {
    String newRouteName = route?.settings?.name;
    if (route is PageRoute )
      _add(newRouteName??'');
  }

  @override
  void didReplace({ Route<dynamic> newRoute, Route<dynamic> oldRoute }) {

    String oldRouteName = oldRoute?.settings?.name;
    String newRouteName = newRoute?.settings?.name;
    if (oldRoute is PageRoute )
      _remove(oldRouteName??'');
    if (newRoute is PageRoute )
      _add(newRouteName??'');
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic> previousRoute) {
    String newRouteName = route?.settings?.name;
    if (route is PageRoute )
      _remove(newRouteName??'', true);

  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic> previousRoute) {
    print("PopRouteNotify::didRemove ${route?.settings?.name} => ${previousRoute?.settings?.name}");
  }

  void _notify(){
    String currentRouteName = _stack.isNotEmpty ? _stack.last : null;
    if (currentRouteName != null) {
      for (PopRouteObserver observer in _list) {
        if (observer.onPop(currentRouteName) == true)
          break;
      }
    }
  }

  void addHome(){

  }

  void _checkFcmSetup(){
    if (_list.contains('/Home')){
      _setupFcm();
    } else {
      _listenMain = true;
    }
  }
  void _setupFcm(){
    _listenMain = false;
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      final notificationProvider = Provider.of<NotificationProvider>(navigatorKey.currentContext, listen: false);
      notificationProvider.setupFcm();
    });

  }

}

abstract class RefreshStateOnPopMixin<T extends StatefulWidget> extends State<T>
    implements PopRouteObserver{

  int _currentLength;
  PopRouteNotify _popRouteNotify;
  @override
  void initState(){
    super.initState();
    _popRouteNotify = context.read<AppState>().popRouteNotify;
    _currentLength = _popRouteNotify._stack.length;
    _popRouteNotify.addObserver(this);
  }

  @override
  void dispose(){
    _popRouteNotify?.removeObserver(this);
    super.dispose();
  }

  bool onPop(String routeName){
    final result = _popRouteNotify._stack.length == _currentLength ;
    if (result)
      WidgetsBinding.instance.addPostFrameCallback((timeStamp){
        if(mounted)
          onPopDone();
      });
    return result;
  }

  void onPopDone(){
    setState((){});
  }

}