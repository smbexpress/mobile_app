import 'package:flutter/material.dart';
import 'package:timelines/timelines.dart';

const kTileHeight = 50.0;

const completeColor = Color(0xff5e6172);
const inProgressColor = Color(0xff5ec792);
const todoColor = Color(0xffd1d2d7);

class StepItem {
  String title;
  IconData icon;
  StepItem(this.title, this.icon);
}

class StepperWidget extends StatelessWidget{
  int selectedIndex;
  bool Function(int index) onIndexChange;
  List<StepItem> items;
  Color selectedColor;
  Color activeColor;
  Color inActiveColor;
  Color activeIconColor;
  Color activeTextColor;
  double iconSize;
  BorderSide _sideBorder;
  StepperWidget({
    this.selectedIndex,
    this.onIndexChange,
    this.activeColor,
    this.activeIconColor,
    this.activeTextColor,
    this.inActiveColor,
    this.iconSize,
    this.selectedColor,
    this.items=const[]
  });

  Color getColor(int index, BuildContext context) {
    if (index == selectedIndex) {
      return selectedColor??Colors.blue;
    } else if (index>= 0 && index < selectedIndex) {
      return activeColor??Colors.green;
    } else {
      return inActiveColor??=Theme.of(context).dividerColor;
    }
  }


  @override
  Widget build(BuildContext context) {
    getColor(-1, context);
    _sideBorder ??= BorderSide(color: Theme.of(context).dividerColor, width: 5);
    activeIconColor ??=Theme.of(context).backgroundColor;
    activeTextColor ??=Theme.of(context).colorScheme.inverseSurface??Color(0xff5e6172);
    return LayoutBuilder(
        builder: (context, box){
          return Timeline.builder(
            theme: TimelineThemeData(
              direction: Axis.horizontal,
              connectorTheme: ConnectorThemeData(
                space: iconSize - 8,
                thickness: 2,
              ),
            ),
            itemBuilder: (context, index) => buildTimelineTile(context, index, box.maxWidth / items.length),
            itemCount: items.length,
          );
        }
    );
  }

  Widget buildTimelineTile(BuildContext context, int index, double itemExtent){
    var color = getColor(index, context);
    return TimelineTile(
      mainAxisExtent: itemExtent,
      nodeAlign: TimelineNodeAlign.start,

      node: TimelineNode(
        indicator: Container(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: InkWell(
              onTap: (){
                print("onPressed: $index");
                if(onIndexChange != null)
                  onIndexChange(index);
              },
              //customBorder: StadiumBorder(),
              child: Container(
                width: iconSize + iconSize/2,
                height: iconSize + iconSize/2,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(iconSize),
                    color: index > selectedIndex ? null : color,
                    //shape: BoxShape.circle,
                    border: index > selectedIndex ? Border(
                        left: _sideBorder,
                        right: _sideBorder,
                        top: _sideBorder,
                        bottom: _sideBorder
                    ): null
                ),
                child: Icon(
                  items[index].icon,
                  color: index > selectedIndex ? inActiveColor : activeIconColor,
                  size: iconSize,
                ),
              )
          ),
        ),
        startConnector: index == 0 ? null :
          buildConnector(context, index, ConnectorType.start),
        endConnector: index == items.length - 1 ? null :
          buildConnector(context, index + 1, ConnectorType.end),

      ),
      contents: Container(
        //padding: const EdgeInsets.only(top: 10.0),
        child: Text(
          items[index].title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: index > selectedIndex ? inActiveColor : activeTextColor,
          ),
        ),
      ),
      oppositeContents: null,
    );
  }

  Widget buildConnector(BuildContext context, int index, type) {
    if (index > 0) {
      final color = index == selectedIndex ?
      getColor(index - 1, context) :  getColor(index, context);
      return DashedLineConnector(
        dash: 3,
        gap: 3,
        color: color,
      );
    } else {
      return null;
    }
  }


}
