// Flutter imports:
import 'package:flutter/material.dart';

import 'copy_to_clipboard.dart';

class IconText extends StatelessWidget {
  const IconText({
    this.text,
    this.value,
    this.icon,
    this.iconData = Icons.copy_rounded,
    this.style,
    this.alignment,
    this.copyToClipboard = false,
  });

  final String text;
  final String value;
  final Widget icon;
  final IconData iconData;
  final TextStyle style;
  final MainAxisAlignment alignment;
  final bool copyToClipboard;

  @override
  Widget build(BuildContext context) {
    final textChild = Text(
      text ?? '',
      style: style,
      overflow: TextOverflow.ellipsis,
    );

    Widget child = Row(
      mainAxisAlignment: alignment ?? MainAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        if (icon != null)
          icon,
        if (iconData != null && icon == null)
          Icon(iconData, color: style?.color),
        SizedBox(width: 10),
        Flexible(
          child: textChild,
        ),
      ],
    );
    if (copyToClipboard)
      child = CopyToClipboard(
          value: value ?? text,
          child: child
      );
    return child;

  }
}
