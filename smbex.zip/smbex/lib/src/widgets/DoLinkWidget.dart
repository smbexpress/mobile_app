import 'dart:math';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/theme/light_color.dart';

Widget flipWidgetIfNeed(Widget child, bool rtl){
  if(!rtl)
    return child;
  return Transform(
      alignment: FractionalOffset.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.001) //These are magic numbers, just use them :)
        ..rotateY(180 * pi / 180),
      child: child);
}

class DoLinkWidget extends StatelessWidget {
  final AnimationController animationController;
  final Animation animation;
  const DoLinkWidget({Key key, this.animationController, this.animation})
      : super(key: key);

  Widget _createChild(BuildContext context){
    bool rtl = Directionality.of(context) == TextDirection.rtl;
    return Padding(
      padding: const EdgeInsets.only(
          left: 24, right: 24, top: 16, bottom: 18),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            LightColor.accent,
            LightColor.accent.withOpacity(.6)
          ], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius:  BorderRadius.only(
              topLeft: rtl ? Radius.circular(68.0): Radius.circular(8.0),
              bottomLeft: Radius.circular(8.0),
              bottomRight: Radius.circular(8.0),
              topRight: !rtl? Radius.circular(68.0):Radius.circular(8.0)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: LightColor.grey.withOpacity(0.6),
                offset: Offset(1.1, 1.1),
                blurRadius: 10.0),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Next workout',
                textAlign: TextAlign.justify,
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 14,
                  letterSpacing: 0.0,
                  color: LightColor.white,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  'Legs Toning and\nGlutes Workout at Home',
                  textAlign: TextAlign.justify,
                  style: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: 20,
                    letterSpacing: 0.0,
                    color: LightColor.white,
                  ),
                ),
              ),
              SizedBox(
                height: 32,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Icon(
                        Icons.timer,
                        color: LightColor.white,
                        size: 16,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 4.0),
                      child: Text(
                        '68 min',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          letterSpacing: 0.0,
                          color: LightColor.white,
                        ),
                      ),
                    ),
                    Expanded(
                      child: SizedBox(),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: LightColor.white,
                        shape: BoxShape.circle,
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                              color: LightColor.black
                                  .withOpacity(0.4),
                              offset: Offset(8.0, 8.0),
                              blurRadius: 8.0),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Icon(
                          Icons.arrow_right,
                          color: Color(0xFF6F56E8),
                          size: 44,
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget child = _createChild(context);
    return AnimatedBuilder(
      animation: animationController,
      child: child,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: animation,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 30 * (1.0 - animation.value), 0.0),
            child: child
          ),
        );
      },
    );
  }
}

double _constraint(double val){
  return val < 0 ? 0 : val > 1 ? 1 : val;
}

class RunningViewWidget extends StatelessWidget {
  final AnimationController animationController;
  final Animation animation;

  const RunningViewWidget({Key key, this.animationController, this.animation})
      : super(key: key);


  Widget _createChild(BuildContext context){
    TextDirection dir = Directionality.of(context);
    bool rtl = dir == TextDirection.rtl;
    return
        Padding(
          padding: const EdgeInsets.only(
              left: 24, right: 24, top: 0, bottom: 0),
          child: Stack(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 16, bottom: 16),
                child: Container(
                  margin: EdgeInsets.only(top: 30),
                  decoration: BoxDecoration(
                    color: LightColor.white,
                    borderRadius: BorderRadius.all(Radius.circular(8.0)),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                          color: LightColor.grey.withOpacity(0.4),
                          offset: Offset(1.1, 1.1),
                          blurRadius: 10.0),
                    ],
                  ),
                  child: Stack(
                    alignment: rtl ? Alignment.topRight : Alignment.topLeft,
                    children: <Widget>[
                      ClipRRect(
                        borderRadius:
                        BorderRadius.all(Radius.circular(8.0)),
                        child: SizedBox(
                          height: 74,
                          child: AspectRatio(
                            aspectRatio: 1.714,
                            child: flipWidgetIfNeed(Image.asset(
                                "assets/img/hom_run_bg.png"), rtl),
                          ),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsetsDirectional.only(
                                  start: 100,
                                  end: 16,
                                  top: 16,
                                ),
                                child: Text(
                                  "You're doing great!",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    letterSpacing: 0.0,
                                    color:
                                    LightColor.accent,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsetsDirectional.only(
                              start: 100,
                              bottom: 12,
                              top: 4,
                              end: 16,
                            ),
                            child: Text(
                              "Keep it up\nand stick to your plan!",
                              textAlign: TextAlign.justify,
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 10,
                                  letterSpacing: 0.0,
                                  color: LightColor.grey
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              Positioned.directional(
                top: -0,
                start: 0,
                textDirection: dir,
                child: SizedBox(
                  width: 110,
                  height: 110,
                  child: flipWidgetIfNeed(Image.asset("assets/img/shipment2.png"), rtl),
                ),
              )
            ],
          ),
        );

  }

  @override
  Widget build(BuildContext context) {
    Widget child = _createChild(context);
    return AnimatedBuilder(
      animation: animationController,
      child: child,
      builder: (BuildContext context, Widget child) {
        var value = animationController.status == AnimationStatus.forward ? 0.0 : 1.0;
        try{
          value = animation.value;
        } catch(e){
          print("RunningViewWidget::exception: $e");
          if(animationController.status != AnimationStatus.completed &&
              animationController.status != AnimationStatus.dismissed)
          return SizedBox();
        }
        return FadeTransition(
          opacity: animation,
          child: new Transform.translate(
            offset: Offset(0, 30 * (1.0 - value)),
            child: child
          ),
        );
      },
    );
  }


}


class GeneralAnimatedWidget extends StatelessWidget {
  final AnimationController animationController;
  final Animation animation;
  final WidgetBuilder builder;
  const GeneralAnimatedWidget({Key key, this.animationController, this.animation, this.builder})
      : super(key: key);
  @override
  Widget build(BuildContext context) {

    Widget child = builder(context);
    return AnimatedBuilder(
      animation: animationController,
      child: child,
      builder: (BuildContext context, Widget child) {
        var value = animationController.status == AnimationStatus.forward ? 0.0 : 1.0;
        try{
          value = animation.value;
        } catch(e){
          print("GeneralAnimatedWidget::exception: $e");
          if(animationController.status != AnimationStatus.completed &&
              animationController.status != AnimationStatus.dismissed)
            return SizedBox();
        }
        return FadeTransition(
          opacity: animation,
          alwaysIncludeSemantics: false,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 30 * (1.0 - value), 0.0),
            child: child,

          ),
        );
      },
    );
  }
}
