import 'package:flutter/material.dart';
import 'package:smbex_app/i18n/i18n.dart';

import '../../../helpers/helper.dart';
import 'country_code.dart';

/// selection dialog used for selection of the country code
class SelectionDialog extends StatefulWidget {
  final List<CountryDetails> elements;
  final bool showCountryOnly;
  final InputDecoration searchDecoration;
  final TextStyle searchStyle;
  final WidgetBuilder emptySearchBuilder;
  final bool showFlag;

  /// elements passed as favorite
  final List<CountryDetails> favoriteElements;

  SelectionDialog(this.elements, this.favoriteElements,
      {Key key,
        this.showCountryOnly,
        this.emptySearchBuilder,
        InputDecoration searchDecoration = const InputDecoration(),
        this.searchStyle,
        this.showFlag})
      : assert(searchDecoration != null, 'searchDecoration must not be null!'),
        this.searchDecoration =
        searchDecoration.copyWith(prefixIcon: Icon(Icons.search)),
        super(key: key);

  @override
  State<StatefulWidget> createState() => _SelectionDialogState();
}

class _SelectionDialogState extends State<SelectionDialog> {
  /// this is useful for filtering purpose
  List<CountryDetails> filteredElements;
  TextStyle itemStyle;
  TextStyle iconStyle;
  @override
  Widget build(BuildContext context){
      Color textColor = Theme.of(context).textTheme.bodyText1.color;
      itemStyle = Theme.of(context).textTheme.subtitle2;
      iconStyle = itemStyle.copyWith(fontSize: 24);
      return SimpleDialog(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              style: widget.searchStyle,
              decoration: InputDecoration(
                hintText: S.of(context).search,
              ),
              onChanged: _filterElements,
            )
          ],
        ),
        children: [
          Container(
              margin: EdgeInsets.only(top: 16),
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              height: MediaQuery
                  .of(context)
                  .size
                  .height,
              child: ListView(
                  children: [
                    widget.favoriteElements.isEmpty
                        ? const DecoratedBox(decoration: BoxDecoration())
                        : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[]
                          ..addAll(widget.favoriteElements
                              .map( _buildOption).toList())
                          ..add(const Divider())),
                  ]
                    ..addAll(filteredElements.isEmpty
                        ? [_buildEmptySearchWidget(context)]
                        : filteredElements.map(_buildOption)))),
        ],
      );
  }

  Widget _buildOption(CountryDetails e) {
    return ListTile(
      onTap: () => _selectItem(e),
      key: Key(e.toLongString()),
        horizontalTitleGap: 4,
      leading: widget.showFlag ? Text(
          Helper.countryCodeToEmoji(e.code),
          style: iconStyle,
      ) : null,
      title: Text(
        e.toLongString(),
        textAlign: TextAlign.justify,
        maxLines: 1,
        style: itemStyle,
      ),
     trailing: Text(
       e.dialCode??'',
       textAlign: TextAlign.justify,
       maxLines: 1,
       style: itemStyle,
     ),
    );

  }

  Widget _buildEmptySearchWidget(BuildContext context) {
    if (widget.emptySearchBuilder != null) {
      return widget.emptySearchBuilder(context);
    }

    return Center(child: Text('No Country Found'));
  }

  @override
  void initState() {
    filteredElements = widget.elements;
    super.initState();
  }

  void _filterElements(String s) {
    s = s.toUpperCase();
    setState(() {
      filteredElements = widget.elements
          .where((e) =>
      e.code.contains(s) ||
          e.dialCode.contains(s) ||
          e.name.toUpperCase().contains(s))
          .toList();
    });
  }

  void _selectItem(CountryDetails e) {
    Navigator.pop(context, e);
  }
}
