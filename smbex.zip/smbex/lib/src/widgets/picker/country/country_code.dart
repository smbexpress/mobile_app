import 'package:country_codes/country_codes.dart';
export 'package:country_codes/country_codes.dart';

extension CountryDetailsFactory on CountryDetails{

  static CountryDetails create({
    String dialCode,
    String code,
    String alpha3Code,
    String name,
    String localizedName
  }) {
    CountryDetails country = CountryDetails.fromMap({
      'name': name,
      'alpha2Code': code,
      'alpha3Code': alpha3Code,
      'dialCode': dialCode,
    }, localizedName);
    return country;
  }

  String get code => alpha2Code;

  String get rawDialCode => dialCode?.substring(1);

  String toLongString() => "$name ($code)";

  String toCountryCodeString() => "$code $dialCode";

  String toCountryStringOnly() => '$name';

}

/// Country element. This is the element that contains all the information
class CountryCode {
  /// the name of the country
  String name;

  /// the flag of the country
  String flagUri;

  /// the country code (IT,AF..)
  String code;

  /// the dial code (+39,+93..)
  String dialCode;

  CountryCode({this.name, this.flagUri, this.code, this.dialCode});

  @override
  String toString() => "$dialCode";

  String toLongString() => "$name ($code)";

  String toCountryCodeString() => "$code $dialCode";

  String toCountryStringOnly() => '$name';
}
