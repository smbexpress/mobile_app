import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:implicitly_animated_reorderable_list_2/implicitly_animated_reorderable_list_2.dart';
import 'package:implicitly_animated_reorderable_list_2/transitions.dart';
import 'package:location/location.dart';
import 'package:material_floating_search_bar/material_floating_search_bar.dart';
import 'package:smbex_app/src/widgets/gps_location_builder.dart';

import '../../../../../i18n/i18n.dart';
import '../../../../config.dart';
import '../../../../helpers/maps_util.dart';
import '../../../../theme/theme.dart';
import '../../../loading_widget.dart';
import '../../../system_ui_overlay_mixin.dart';
import '../place_picker.dart';
import '../uuid.dart';


typedef AcceptLocation<T> = Future<T> Function(LocationResult location);
/// Place picker widget made with map widget from
/// [google_maps_flutter](https://github.com/flutter/plugins/tree/master/packages/google_maps_flutter)
/// and other API calls to [Google Places API](https://developers.google.com/places/web-service/intro)
///
/// API key provided should have `Maps SDK for Android`, `Maps SDK for iOS`
/// and `Places API`  enabled for it
class PlacePicker<T> extends StatefulWidget {
  /// API key generated from Google Cloud Console. You can get an API key
  /// [here](https://cloud.google.com/maps-platform/)
  final String apiKey;

  final AcceptLocation<T> acceptLocation;
  final Future<bool> Function() onWillPop;
  /// Location to be displayed when screen is showed. If this is set or not null, the
  /// map does not pan to the user's current location.
  final LatLng displayLocation;



  PlacePicker(this.apiKey, {this.displayLocation, this.acceptLocation, this.onWillPop});

  @override
  State<StatefulWidget> createState() => PlacePickerState();


  static BuildContext _context;
  static BuildContext get context => _context;

}

/// Place picker state
class PlacePickerState<T> extends State<PlacePicker<T>> with SystemUiOverlayMixin{
  Completer<GoogleMapController> mapController = Completer();

  /// Result returned after user completes selection
  LocationResult locationResult;

  /// Overlay to display autocomplete suggestions
  OverlayEntry overlayEntry;

  List<NearbyPlace> nearbyPlaces = List();

  /// Session token required for autocomplete API call
  String sessionToken = Uuid().generateV4();

  GlobalKey appBarKey = GlobalKey();

  bool hasSearchTerm = false;

  String previousSearchTerm = '';

  LatLng lasLatLng;
  bool moveToDisplayLocation = false;

  FloatingSearchBarController _floatingSearchBarController;

  ValueNotifier<List<RichSuggestion>> _suggestions =
      ValueNotifier<List<RichSuggestion>>([]);

  // constructor
  PlacePickerState();

  void onMapCreated(GoogleMapController controller) {
    if (this.mapController.isCompleted) {
      mapController = Completer();
    }

    this.mapController.complete(controller);
    //if (widget.displayLocation != null)
    //  moveToLocation(widget.displayLocation);
    //}
  }

  @override
  void setState(fn) {
    if (this.mounted) {
      super.setState(fn);
    }


  }

  @override
  void initState() {
    super.initState();
    _floatingSearchBarController = FloatingSearchBarController();
    //SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    if (widget.displayLocation != null) {
      lasLatLng = widget.displayLocation;
    }
    moveToDisplayLocation =
        widget.displayLocation != null;

    initSystemUiOverlay(AppTheme.transOverlayStyle, true);
  }

  @override
  void dispose() {
    _floatingSearchBarController?.dispose();
    //SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
    leave();
    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    PlacePicker._context = context;
    Size size = mq.size;
    print("Screen size: ${mq.size}");
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    return WillPopScope(
        onWillPop: () async{
          if (_floatingSearchBarController.isOpen){
            _floatingSearchBarController.close();
            return false;
          }
          if (widget.onWillPop != null) {
              return widget.onWillPop();
          }

          return true;
        },
        child: Scaffold(
          //backgroundColor: Colors.transparent,
          body: GpsLocationBuilder(
            //initial: lasLatLng,
            builder: (context, latLang, updateLocation) {
                if (lasLatLng == null && latLang != null) {
                  //moveToLocation(latLang);
                }
                if (latLang == null) {
                  return AnimatedOpacity(
                      opacity: 1.0,
                      duration: Duration(milliseconds: 400),
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                  );
                }
                //this.lasLatLng = latLang;
                return Stack(
                    children: [
                      Positioned(
                          top: 0,
                          height: mq.padding.top,
                          left: 0,
                          right: 0,
                          child: AnnotatedRegion<SystemUiOverlayStyle>(
                            value:AppTheme.transOverlayStyle,
                            child: Container(),
                          )
                      ),
                      Positioned(
                          top: 0,
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: FloatingSearchBar(
                            controller: _floatingSearchBarController,
                            hint: tr.search,
                            builder: (context, _) {
                              return ValueListenableBuilder<List<RichSuggestion>>(
                                  valueListenable: _suggestions,
                                  builder: (context, branches, _) => buildExpandableBody()
                              );
                            },
                            backgroundColor: theme.cardColor,
                            transitionDuration: const Duration(milliseconds: 400),
                            transitionCurve: Curves.easeInOutCubic,
                            debounceDelay: const Duration(milliseconds: 400),
                            physics: const BouncingScrollPhysics(),
                            axisAlignment: -1.0,
                            openAxisAlignment: 0.0,
                            scrollPadding: EdgeInsets.zero,
                            transition: SlideFadeFloatingSearchBarTransition(spacing: 16),
                            automaticallyImplyBackButton: true,
                            onQueryChanged: searchPlace,
                            closeOnBackdropTap: true,
                            clearQueryOnClose: true,
                            overlayStyle: AppTheme.whiteOverlayStyle,
                            actions: [
                              FloatingSearchBarAction.searchToClear(showIfClosed: true,),
                              FloatingSearchBarAction.icon(
                                  icon: Icons.my_location,
                                  onTap: () async{

                                    final latLng = await updateLocation();
                                    if (latLng != null) {
                                      moveToLocation(latLng);
                                    }
                                  }
                              )
                            ],
                            body: Stack(
                              fit: StackFit.expand,
                              children: [
                                Positioned(
                                  top: -mq.padding.top,
                                  bottom: 0,
                                  left: 0,
                                  right: 0,
                                  child: GoogleMap(
                                    initialCameraPosition: CameraPosition(
                                        target: widget.displayLocation ?? latLang??LatLng(0.0, 0.0),
                                        zoom: 15),
                                    myLocationButtonEnabled: false,
                                    myLocationEnabled: false,
                                    zoomControlsEnabled: false,
                                    onMapCreated: onMapCreated,
                                    onTap: (latLng) {
                                      //clearOverlay();
                                      //moveToLocation(latLng);
                                    },
                                    onCameraMove: (pos){
                                      this.locationResult = null;
                                      lasLatLng = pos.target;
                                      //reverseGeocodeLatLng(pos.target);
                                    },
                                    onCameraIdle: (){
                                      if (lasLatLng != null) {
                                        reverseGeocodeLatLng(lasLatLng);
                                      }
                                    },
                                    circles: latLang != null &&
                                        this.mapController.isCompleted
                                        ? {
                                          Circle(
                                              circleId: CircleId("userLocation"),
                                              center: latLang,
                                              fillColor: theme.colorScheme.primary,
                                              radius: 50,
                                              zIndex: 1,
                                              strokeColor: theme.colorScheme.
                                                  primary.withOpacity(.4)
                                          )
                                        }
                                        : const <Circle>{},
                                  ),
                                ),
                                if(lasLatLng != null)
                                pin(),
                                if (this.locationResult != null)
                                  Positioned(
                                      bottom: 0,
                                      left: 0,
                                      right: 0,
                                      child: SelectPlaceAction(getLocationName(), () async {
                                        if (widget.acceptLocation!=null) {
                                          final result = await widget.acceptLocation(this.locationResult);
                                          if (result != null)
                                            return Navigator.of(context).pop(result);
                                        } else {
                                          return Navigator.of(context).pop(this.locationResult);
                                        }
                                      }
                                      )
                                  ),

                              ],
                            ),
                            //isScrollControlled: true,

                          )
                      ),

                    ]
                );
            }
          )

        )
    );
  }



  Widget pin() {
    return IgnorePointer(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.place, size: 56),
            Container(
              decoration: ShapeDecoration(
                shadows: [
                  BoxShadow(
                    blurRadius: 4,
                    color: Colors.black38,
                  ),
                ],
                shape: CircleBorder(
                  side: BorderSide(
                    width: 4,
                    color: Colors.transparent,
                  ),
                ),
              ),
            ),
            SizedBox(height: 56),
          ],
        ),
      ),
    );
  }

  /// Begins the search process by displaying a "wait" overlay then
  /// proceeds to fetch the autocomplete list. The bottom "dialog"
  /// is hidden so as to give more room and better experience for the
  /// autocomplete list overlay.
  void searchPlace(String place) {
    // on keyboard dismissal, the search was being triggered again
    // this is to cap that.
    if (place == this.previousSearchTerm) {
      return;
    }

    previousSearchTerm = place;

    setState(() {
      hasSearchTerm = place.length > 0;
    });

    if (place.length < 1) {
      return;
    }

    autoCompleteSearch(place);
  }

  /// Fetches the place autocomplete list with the query [place].
  void autoCompleteSearch(String place) async {
    try {
      final items = await MapsUtil.searchPlace(place);
      final suggestions = <RichSuggestion>[];
      if (items.isEmpty) {
        AutoCompleteItem aci = AutoCompleteItem();
        aci.text = "No result found";
        aci.offset = 0;
        aci.length = 0;
        suggestions.add(RichSuggestion(aci));
      } else {
        for (dynamic aci in items) {
          suggestions.add(RichSuggestion(aci));
        }
      }

      displayAutoCompleteSuggestions(suggestions);
    } catch (e) {
      print(e);
    }
  }

  /// To navigate to the selected place from the autocomplete list to the map,
  /// the lat,lng is required. This method fetches the lat,lng of the place and
  /// proceeds to moving the map to that location.
  void decodeAndSelectPlace(dynamic placeId) async {
    try {
      MapsUtil.decodePlace(placeId, widget.apiKey);
      moveToLocation(await MapsUtil.decodePlace(placeId, widget.apiKey));
    } catch (e) {
      print(e);
    }
  }

  /// Display autocomplete suggestions with the overlay.
  void displayAutoCompleteSuggestions(List<RichSuggestion> suggestions) {
    _suggestions.value = suggestions;
    //setState(() { });
  }

  /// Utility function to get clean readable name of a location. First checks
  /// for a human-readable name from the nearby list. This helps in the cases
  /// that the user selects from the nearby list (and expects to see that as a
  /// result, instead of road name). If no name is found from the nearby list,
  /// then the road name returned is used instead.
  String getLocationName() {
    if (this.locationResult == null) {
      return "Unnamed location";
    }

    for (NearbyPlace np in this.nearbyPlaces) {
      if (np.latLng == this.locationResult.latLng && np.name != this.locationResult.locality) {
        this.locationResult.name = np.name;
        return "${np.name}, ${this.locationResult.locality}";
      }
    }
    if (locationResult.name == null ||
        locationResult.name.isEmpty
    ){
      return locationResult.locality ?? locationResult.district ?? 'Unnamed location';
    }

    if (locationResult.locality == null ||
        locationResult.locality == locationResult.name)
      return locationResult.name;

    return "${locationResult.name}, ${locationResult.locality}";
  }

  /// Fetches and updates the nearby places to the provided lat,lng
  void getNearbyPlaces(LatLng latLng) async {
    try {
      final response = await http.get(Uri.parse("https://maps.googleapis.com/maps/api/place/nearbysearch/json?" +
          "key=${widget.apiKey}&" +
          "location=${latLng.latitude},${latLng.longitude}&radius=150"));

      if (response.statusCode != 200) {
        throw Error();
      }

      final responseJson = jsonDecode(response.body);

      if (responseJson['results'] == null) {
        throw Error();
      }

      this.nearbyPlaces.clear();

      for (Map<String, dynamic> item in responseJson['results']) {
        final nearbyPlace = NearbyPlace()
          ..name = item['name']
          ..icon = item['icon']
          ..latLng = LatLng(item['geometry']['location']['lat'], item['geometry']['location']['lng']);

        this.nearbyPlaces.add(nearbyPlace);
      }

      // to update the nearby places
      setState(() {
        // this is to require the result to show
        this.hasSearchTerm = false;
      });
    } catch (e) {
      //
    }
  }

  /// This method gets the human readable name of the location. Mostly appears
  /// to be the road name and the locality.
  void reverseGeocodeLatLng(LatLng latLng) async {
    try {
        this.locationResult = await MapsUtil.reverseGeocode(latLng, widget.apiKey);
        //lasLatLng = null;
        setState(() {});
    } catch (e, stack) {
      debugPrintStack(stackTrace: stack, label: "$e");
    }
  }

  /// Moves the camera to the provided location and updates other UI features to
  /// match the location.
  void moveToLocation(LatLng latLng) async{
    //Config.debug("moveToLocation latLng: $latLng", widget.runtimeType);
    try {
      GoogleMapController _mapController = await mapController.future;
      _mapController.animateCamera(CameraUpdate.newLatLngZoom(latLng, 15.0));
    } catch(error, tract) {
      Config.error(error, tract, widget.runtimeType);
    }

    reverseGeocodeLatLng(latLng);

    //getNearbyPlaces(latLng);
  }

  void moveToCurrentUserLocation() {
    if (widget.displayLocation != null || lasLatLng != null) {
      moveToLocation(widget.displayLocation ?? lasLatLng);
      return;
    }
    /*
    Location().getLocation().then((locationData) {
      LatLng target = LatLng(locationData.latitude, locationData.longitude);
      moveToLocation(target);
    }).catchError((error) {
      // TODO: Handle the exception here
      print(error);
    });

     */
  }

  Widget buildExpandableBody() {

    final items = _suggestions.value;

    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        clipBehavior: Clip.antiAlias,
        child: ImplicitlyAnimatedList<RichSuggestion>(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          items: items,
          insertDuration: const Duration(milliseconds: 700),
          itemBuilder: (context, animation, item, i) {
            return SizeFadeTransition(
              animation: animation,
              child: buildItem(context, items, item, textTheme),
            );
          },
          updateItemBuilder: (context, animation, item) {
            return FadeTransition(
              opacity: animation,
              child: buildItem(context, items, item, textTheme),
            );
          },
          areItemsTheSame: (a, b) => a == b,
        ),
      ),
    );
  }

  Widget buildItem(BuildContext context,
      List<RichSuggestion> items, RichSuggestion place, TextTheme textTheme) {

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        InkWell(
          onTap: place.autoCompleteItem.id != null
              ? () {
                  FloatingSearchBar.of(context)?.close();
                  Future.delayed(
                      const Duration(milliseconds: 500),
                          (){
                         decodeAndSelectPlace(place.autoCompleteItem.place ?? place.autoCompleteItem.id);
                      }
                  );
          } : null,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                SizedBox(
                  width: 36,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 500),
                    child: const Icon(Icons.place, key: Key('place')),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: place
                ),
              ],
            ),
          ),
        ),
        if (items.isNotEmpty && place != items.last)
          const Divider(height: .5),
      ],
    );
  }

}
