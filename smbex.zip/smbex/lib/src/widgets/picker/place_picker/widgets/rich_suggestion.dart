import 'package:flutter/material.dart';

import '../place_picker.dart';

class RichSuggestion extends StatelessWidget {
  final AutoCompleteItem autoCompleteItem;
  RichSuggestion(this.autoCompleteItem);

  @override
  Widget build(BuildContext context) {
    return RichText(text: TextSpan(children: getStyledTexts(context)));
  }

  List<TextSpan> getStyledTexts(BuildContext context) {
    final List<TextSpan> result = [];
    final style = TextStyle(color: Colors.grey, fontSize: 15);

    if (autoCompleteItem.offset <= 0 || autoCompleteItem.length == 0) {
      result.add(TextSpan(text: autoCompleteItem.text, style: style));
      return result;
    }


    final startText = autoCompleteItem.text.substring(0, autoCompleteItem.offset);
    if (startText.isNotEmpty) {
      result.add(TextSpan(text: startText, style: style));
    }

    final boldText =
        autoCompleteItem.text.substring(autoCompleteItem.offset, autoCompleteItem.offset + autoCompleteItem.length);
    result.add(
      TextSpan(text: boldText, style: style.copyWith(color: Theme.of(context).textTheme.bodyText1.color)),
    );

    final remainingText = autoCompleteItem.text.substring(autoCompleteItem.offset + autoCompleteItem.length);
    result.add(TextSpan(text: remainingText, style: style));

    return result;
  }
}
