

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/helpers/maps_util.dart';
import 'package:smbex_app/src/helpers/upgrader.dart';

import '../../i18n/i18n.dart';
import '../helpers/connection_status_singleton.dart';

typedef UpdateLocation = Future<LatLng> Function();


typedef LocationWidgetBuilder = Widget Function(
    BuildContext contex,
    LatLng latLng,
    UpdateLocation updateLocation);


class GpsLocationBuilder extends StatefulWidget{

  final LocationWidgetBuilder builder;
  final LatLng initial;
  GpsLocationBuilder({
    Key key,
    this.builder,
    this.initial
  }): super(key: key);

  @override
  _GpsLocationBuilder createState() => _GpsLocationBuilder();

}


class _GpsLocationBuilder extends State<GpsLocationBuilder> with SingleTickerProviderStateMixin{

  AnimationController controller;
  Animation<Offset> offset;
  LatLng latLng;
  bool isRed = true;
  Future<LatLng> pendingRequest;
  @override
  void initState() {
    controller = AnimationController(vsync: this, value: 0.0, duration: Duration(milliseconds: 500));
    offset = Tween<Offset>(begin: const Offset(0.0, -1.0), end: const Offset(0.0, 0.0)).animate(controller);
    latLng = widget.initial;
    if (latLng == null) {
      WidgetsBinding.instance.endOfFrame.then((timeStamp) async {
        //_connectionChanged(await MapsUtil.getLastLocation());
        //latLng =  LatLng(24.688331, 46.684109);
        //_getLocation(true);
      });
    }

    super.initState();
  }
  Future<LatLng> _getLocation([bool updateState=false]) async{
    if (pendingRequest != null){
      return pendingRequest;
    }
    pendingRequest = _getFnLocation(updateState)
    ..whenComplete((){
      pendingRequest = null;
    }) ;
    return pendingRequest;
  }

  Future<LatLng> _getFnLocation([bool updateState=false]) async{
    
    final location = Location();
    
    if (!(await location.serviceEnabled())) {
      try{
        print("GpsLocationBuilder:: service disabled!");
        _locationChanged(null, updateState);
        final result = await location.requestService();
        if (!result) {
          _locationChanged(null, updateState);
          return null;
        }
      } catch (error, stack){
        _locationChanged(null, updateState);
        Config.error(error, stack, widget.runtimeType);
        return null;
      }
    }

    PermissionStatus status = await location.hasPermission();

    if (status == PermissionStatus.DENIED_FOREVER) {
      _locationChanged(null, updateState);
      return null;
    }

    if (status == PermissionStatus.DENIED) {

      status = await location.requestPermission();
      if (
      status == PermissionStatus.DENIED_FOREVER ||
          status == PermissionStatus.DENIED
      ) {
        _locationChanged(null, updateState);
        return null;
      }
    }

    final loc = await location.getLocation();
    final latLLng = LatLng(loc.latitude, loc.longitude);
    _locationChanged(latLLng, updateState);
    return latLLng;
  }


  void _locationChanged(LatLng lastLocation, [bool updateState=false]) {
    if (latLng == lastLocation) return;
    latLng = lastLocation;
    latLng == null ? controller.forward() : controller.reverse();
    isRed = !isRed;
    Config.debug("_locationChanged latLng: $latLng", widget.runtimeType);
    if (updateState)
      setState((){});
    if (latLng != null){
      MapsUtil.setLastLocation(latLng);
    }
    _checkLocation();
  }

  void _checkLocation(){
    if (latLng == null){
      Future.delayed(Duration(seconds: 2), (){
        isRed = !isRed;
        if (mounted) {
          setState(() {});
          _checkLocation();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    final childWidget = Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      top: 0,
      child: FutureBuilder<LatLng>(
        future: latLng != null ? Future.value(latLng) : _getLocation(),
        builder: (context, snapshot ){
          //LatLng latLng = snapshot.data ?? LatLng(24.688331, 46.684109);
          LatLng latLng = snapshot.data;
          /*
          if (latLng == null) {
            return FutureBuilder<LatLng>(
              future: MapsUtil.getLastLocation(),
              builder: (context, snapshot ) =>
                  widget.builder(context, snapshot.data, _getLocation)
            );
          }

           */
          Config.debug("latLng: $latLng", widget.runtimeType);
          return widget.builder(context, snapshot.data , _getLocation);
        }
      ),
    );

    final statusWidget =
            Positioned(
              child: buildStatus(context),
              left: 0,
              right: 0,
              bottom: 0,
              top: 0,
            );



    return Stack(
      fit: StackFit.expand,
      children:[childWidget, statusWidget],
    );
  }

  @override
  void dispose() {
    controller?.dispose();

    super.dispose();
  }

  Widget buildStatus(BuildContext context){
    return SlideTransition(
      position: offset,
      //height: _hasLocation ? 0 : MediaQuery.of(context).size.height,
      //duration: Duration(milliseconds: 500),
      //curve: Curves.easeInOutCubic,
      child: Material(
        color: Colors.transparent,
        child: Container(
          color: Colors.black.withOpacity(.5),
          //height: MediaQuery.of(context).size.height,
          //constraints: BoxConstraints.expand(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(
                Icons.satellite_alt,
                color: isRed 
                    ? Colors.deepOrangeAccent 
                    : Colors.blueAccent,
                size: 100,
              ),
              SizedBox(height: 20,),
              //Text("Internet connection is not available!!", style: TextStyle(fontSize: 14, color: Colors.deepOrange),),
              Text(S.of(context).enableLocation, style: TextStyle(fontSize: 16, color: Colors.white),),
              SizedBox(height: 20,),
              ElevatedButton(
                  onPressed: () async{
                    final loc = _getLocation();
                    if (loc != null){
                      setState(() {
                      });
                    }
                  },
                  child: Text("Check")
              )
            ],
          ),
        ),
      ),
    );
  }

  void didUpdateWidget(GpsLocationBuilder oldWidget) {
    super.didUpdateWidget(oldWidget);
    latLng = widget.initial;
  }

}