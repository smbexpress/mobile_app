import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../i18n/i18n.dart';

class CopyToClipboard extends StatelessWidget {
  const CopyToClipboard({
    Key key,
    @required this.value,
    this.child,
    this.showBorder = false,
    this.onLongPress,
    this.prefix,
  }) : super(key: key);

  final Widget child;
  final String value;
  final bool showBorder;
  final Function onLongPress;
  final String prefix;

  @override
  Widget build(BuildContext context) {
    if ((value ?? '').isEmpty) {
      return SizedBox();
    }

    final widget = child == null
        ? Text(
            prefix != null ? '$prefix: $value' : value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          )
        : child;
    final onTap = () {
      Clipboard.setData(ClipboardData(text: value));

      Fluttertoast.showToast(
        toastLength: Toast.LENGTH_LONG,
        msg: tr.copiedToClipboard.replaceFirst(
          ':value',
          value.replaceAll('\n', ' '),
        ),
      );
    };

    if (showBorder) {
      return ConstrainedBox(
        child: OutlinedButton(
          onPressed: onTap,
          child: widget,
          onLongPress: onLongPress,
        ),
        constraints: BoxConstraints(maxWidth: 180),
      );
    } else {
      return InkWell(
        child: widget,
        onTap: onTap,
        onLongPress: onLongPress,
      );
    }
  }
}
