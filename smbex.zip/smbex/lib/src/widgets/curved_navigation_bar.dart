import 'package:flutter/material.dart';
import 'package:smbex_app/src/theme/light_color.dart';


typedef _LetIndexPage = bool Function(int value);
class NavbarItem{
  final IconData icon;
  final String label;
  final Key key;
  NavbarItem(this.icon, this.label, {this.key});


}

class CurvedNavigationBar extends StatefulWidget {
  final List<NavbarItem> items;
  final int index;
  final Color color;
  final Color buttonBackgroundColor;
  final Color backgroundColor;
  final ValueChanged<int> onTap;
  final _LetIndexPage letIndexChange;
  final Curve animationCurve;
  final Duration animationDuration;
  final double height;
  final int notchIndex;
  final Color unselectedItemColor;
  final Color selectedItemColor;
  final double extent;
  CurvedNavigationBar({
    Key key,
    @required this.items,
    this.index = 0,
    this.color = Colors.white,
    this.buttonBackgroundColor,
    this.backgroundColor = Colors.blueAccent,
    this.onTap,
    _LetIndexPage letIndexChange,
    this.animationCurve = Curves.easeOut,
    this.animationDuration = const Duration(milliseconds: 600),
    this.height = 75.0,
    this.notchIndex,
    this.unselectedItemColor,
    this.selectedItemColor,
    this.extent = 20.0
  })  : letIndexChange = letIndexChange ?? ((_) => true),
        assert(items != null),
        assert(items.length >= 1),
        assert(0 <= index && index < items.length),
        assert(0 <= height && height <= 75.0),
        super(key: key);

  @override
  CurvedNavigationBarState createState() => CurvedNavigationBarState();
}

class CurvedNavigationBarState extends State<CurvedNavigationBar>
    with SingleTickerProviderStateMixin {
  double _startingPos;
  int _endingIndex = 0;
  double _pos;
  double _buttonHide = 0;
  NavbarItem _icon;
  AnimationController _animationController;
  int _length;

  @override
  void initState() {
    super.initState();
    final index = widget.notchIndex??widget.index;
    _icon = widget.items[index];
    _length = widget.items.length;
    _pos = index / _length;
    _startingPos = index / _length;
    if (widget.notchIndex == null) {
      _animationController = AnimationController(vsync: this, value: _pos);
      _animationController.addListener(() {
        setState(() {
          _pos = _animationController.value;
          final endingPos = _endingIndex / widget.items.length;
          final middle = (endingPos + _startingPos) / 2;
          if ((endingPos - _pos).abs() < (_startingPos - _pos).abs()) {
            _icon = widget.items[_endingIndex];
          }
          _buttonHide =
              (1 - ((middle - _pos) / (_startingPos - middle)).abs()).abs();
        });
      });
    }
  }

  @override
  void didUpdateWidget(CurvedNavigationBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index != widget.index) {

      final newPosition = widget.index / _length;
      _startingPos = _pos;
      _endingIndex = widget.index;
      _animationController?.animateTo(newPosition,
          duration: widget.animationDuration, curve: widget.animationCurve);

      if (widget.notchIndex != null) {
        _icon = widget.items[widget.notchIndex];
      }
    }
  }

  @override
  void dispose() {
    _animationController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final notchSelected = widget.notchIndex == widget.index ||
        (widget.notchIndex == null && _endingIndex == widget.index);

    if (widget.notchIndex != null) {
      //_icon = widget.items[widget.notchIndex];
    }

    return Container(
      height: widget.height,
      decoration: BoxDecoration(
        color: widget.backgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 7), // changes position of shadow
          ),
        ],
      ),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: <Widget>[
          Positioned(
            bottom: -40 - (75.0 - widget.height),
            left: Directionality.of(context) == TextDirection.rtl
                ? null
                : _pos * size.width,
            right: Directionality.of(context) == TextDirection.rtl
                ? _pos * size.width
                : null,
            width: size.width / _length,
            child: Center(
              child: Transform.translate(
                  offset: Offset(
                    0,
                    -(1 - _buttonHide) * 80,
                  ),
                  child: InkWell(
                    onTap: widget.notchIndex != null
                        ? () => _buttonTap(widget.notchIndex)
                        : null,
                    child: Material(
                      color: notchSelected ? widget.selectedItemColor : widget.buttonBackgroundColor ?? widget.color,
                      shadowColor: LightColor.shadow,
                      type: MaterialType.circle,
                      elevation: 16,
                      key: _icon.key,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                            _icon.icon,
                            size: 40,
                            color: notchSelected
                                ? widget.backgroundColor ?? Colors.white
                                : widget.unselectedItemColor
                        ),
                      ),
                    ),
                  )
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0 - (75.0 - widget.height),
            child: CustomPaint(
              painter: NavCustomPainter(
                  _pos, _length, widget.color, Directionality.of(context)),
              child: Container(
                height: 75.0,
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0 - (75.0 - widget.height),
            child: SizedBox(
                height: 100.0,
                child: Row(
                    children: widget.items.map((item) {
                      final index = widget.items.indexOf(item);
                      return NavButton(
                          onTap: _buttonTap,
                          position: _pos,
                          length: _length,
                          index: index,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(item.icon, size: 26, color: index == widget.index ? widget.selectedItemColor : widget.unselectedItemColor),
                              Text(item.label??'',
                                style: TextStyle(color: index == widget.index ? widget.selectedItemColor : widget.unselectedItemColor),
                              )
                            ],
                          ),
                      );
                    }).toList())),
          ),
        ],
      ),
    );
  }

  void setPage(int index) {
    _buttonTap(index);
  }

  void _buttonTap(int index) {
    if (!widget.letIndexChange(index)) {
      return;
    }
    if (widget.onTap != null) {
      widget.onTap?.call(index);
    }
    final newPosition = index / _length;
    setState(() {
      _startingPos = _pos;
      _endingIndex = index;
      _animationController?.animateTo(newPosition,
          duration: widget.animationDuration, curve: widget.animationCurve);
    });
  }
}

class NavButton extends StatelessWidget {
  final double position;
  final int length;
  final int index;
  final ValueChanged<int> onTap;
  final Widget child;

  NavButton({
    @required this.onTap,
    @required this.position,
    @required this.length,
    @required this.index,
    @required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final desiredPosition = 1.0 / length * index;
    final difference = (position - desiredPosition).abs();
    final verticalAlignment = 1 - length * difference;
    final opacity = length * difference;

    return Expanded(
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Container(
              height: 75.0,
              child: Transform.translate(
                offset: Offset(
                    0, difference < 1.0 / length ? verticalAlignment * 40 : 0),
                child: Opacity(
                    opacity: difference < 1.0 / length * 0.99 ? opacity : 1.0,
                    child: child),
              )
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: TextButton(
                style: TextButton.styleFrom(
                    shape: CircleBorder()
                ),
                onPressed: () => onTap(index),
                child: Container()
            ),
          )
        ],
      ),
    );
  }
}

class NavCustomPainter extends CustomPainter {
   double loc;
   double s;
   Color color;
   TextDirection textDirection;

  NavCustomPainter(
      double startingLoc, int itemsLength, this.color, this.textDirection) {
    final span = 1.0 / itemsLength;
    s = 0.2;
    double l = startingLoc + (span - s) / 2;
    loc = textDirection == TextDirection.rtl ? 0.8 - l : l;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo((loc - 0.1) * size.width, 0)
      ..cubicTo(
        (loc + s * 0.20) * size.width,
        size.height * 0.05,
        loc * size.width,
        size.height * 0.60,
        (loc + s * 0.50) * size.width,
        size.height * 0.60,
      )
      ..cubicTo(
        (loc + s) * size.width,
        size.height * 0.60,
        (loc + s - s * 0.20) * size.width,
        size.height * 0.05,
        (loc + s + 0.1) * size.width,
        0,
      )
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return this != oldDelegate;
  }
}