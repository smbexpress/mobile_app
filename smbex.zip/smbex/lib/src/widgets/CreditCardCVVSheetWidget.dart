import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:smbex_app/src/models/payment_method.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/theme/text_styles.dart';

import '../../i18n/i18n.dart';
import 'SmbWidget.dart';
// ignore: must_be_immutable
class CreditCardCVVSheetWidget extends StatefulWidget {
  final PaymentCard paymentCard;
  final VoidCallback onChange;
  final GlobalKey<FormState> formKey;
  final InputDecoration cardNumberDecoration;
  final InputDecoration cardHolderDecoration;
  final InputDecoration expiryDateDecoration;
  final InputDecoration cvvCodeDecoration;
  final String cvvValidationMessage;
  final double height;
  CreditCardCVVSheetWidget({
    Key key,
    this.paymentCard,
    this.onChange,
    this.formKey,
    this.height,
    this.cardHolderDecoration = const InputDecoration(
      labelText: 'Card holder',
      isDense: true,
      contentPadding: const EdgeInsets.all(10),
    ),
    this.cardNumberDecoration = const InputDecoration(
      labelText: 'Card number',
      hintText: 'XXXX XXXX XXXX XXXX',
      labelStyle: const TextStyle(color: LightColor.titleTextColor),
      isDense: true,
      contentPadding: const EdgeInsets.all(10),
    ),
    this.expiryDateDecoration = const InputDecoration(
      labelText: 'Expired Date',
      hintText: 'MM/YY',
      labelStyle: const TextStyle(color: LightColor.titleTextColor),
      isDense: true,
      contentPadding: const EdgeInsets.all(10),
    ),
    this.cvvCodeDecoration = const InputDecoration(
      labelText: 'CVV',
      hintText: 'XXX',
      labelStyle: const TextStyle(color: LightColor.titleTextColor),
      isDense: true,
      contentPadding: const EdgeInsets.all(10),
    ),
    this.cvvValidationMessage = 'Please input a valid CVV'
  }) : super(key: key);

  @override
  _CreditCardCVVSheetWidgetState createState() => _CreditCardCVVSheetWidgetState();
}

class _CreditCardCVVSheetWidgetState extends State<CreditCardCVVSheetWidget> with SingleTickerProviderStateMixin{
  FocusNode cvvFocusNode = FocusNode();
  final TextEditingController _cardNumberController = TextEditingController();
  final TextEditingController _expiryDateController = TextEditingController();
  final TextEditingController _cardHolderNameController = TextEditingController();
  final TextEditingController _cvvCodeController = TextEditingController();

  void textFieldFocusDidChange() {
    print("csvValueNotifier: ${_cvvCodeController.text}") ;
    widget.paymentCard.cvv = _cvvCodeController.text;
    widget.onChange?.call();
  }

  @override
  void initState() {
    super.initState();
    _cardNumberController.text = '**** **** **** ' + widget.paymentCard.name??'';
    _expiryDateController.text = widget.paymentCard.expire??'';
    _cardHolderNameController.text = widget.paymentCard.holder??'';
    //_cvvCodeController.text = widget.paymentCard.cvv??'';
    _cvvCodeController.addListener(textFieldFocusDidChange);
    //cvvFocusNode.addListener(textFieldFocusDidChange);
    cvvFocusNode.requestFocus();
  }

  @override
  void dispose() {
    cvvFocusNode.dispose();
    _cardNumberController.dispose();
    _expiryDateController.dispose();
    _cardHolderNameController.dispose();
    _cvvCodeController.dispose();

    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {

    final body = Container(
      padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
      child: Form(
        key: widget.formKey,
        child: Wrap(
          children: <Widget>[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              margin: const EdgeInsets.only(left: 16, top: 16, right: 16),
              child: TextFormField(
                  enabled: false,
                  decoration: widget.cardNumberDecoration,
                  controller: _cardNumberController
              ),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    margin: const EdgeInsets.only(left: 16, top: 8, right: 16),
                    child: TextFormField(
                      enabled: false,
                      decoration: widget.expiryDateDecoration,
                      controller: _expiryDateController,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    margin: const EdgeInsets.only(left: 16, top: 8, right: 16),
                    child: TextFormField(
                      focusNode: cvvFocusNode,
                      controller: _cvvCodeController,
                      decoration: widget.cvvCodeDecoration,
                      keyboardType: TextInputType.number,
                      onChanged: (String text) {
                        setState(() {
                          widget.paymentCard.cvv = text;
                        });
                      },
                      validator: (String value) {
                        if (value == null || value.isEmpty || value.length < 3) {
                          return widget.cvvValidationMessage;
                        }
                        return null;
                      },
                      inputFormatters: [
                        //FilteringTextInputFormatter.allow(RegExp(r'\[0-9]{3,4}')),
                        FilteringTextInputFormatter.digitsOnly,
                        TextInputFormatter.withFunction((oldValue, newValue){
                          if (newValue.text != null && newValue.text.length > 4){
                            return oldValue;
                          }
                          return newValue;
                        })
                      ],
                    ),
                  ),
                ),
              ],
            ),
            //const SizedBox(height: 16,),

          ],
        ),
      ),
    );

    if (true)
      return body;


    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: appBar(
        context,
        isSecondary: false,
        automaticallyImplyLeading: false,
        showBack: false,
        //leading: SizedBox(width: 0,),
        centerTitle: false,
        titleText: S.of(context).payment_options,
        actions: [
          InkWell(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Icon(Icons.close),
            ),
            onTap: () {
              Navigator.of(context).pop();
            },
          ),
          SizedBox(width: 10,)
        ],
      ),
      body: body,
      bottomSheet: Container(
        height: 50,
        color: LightColor.accent,
        child: Row(
          children: [
            Expanded(
              child: TextButton(
                child: Text(
                  "Pay Now",
                  style: TextStyles.title.copyWith(color:LightColor.white),
                ),
                onPressed: widget.onChange
              ),
            )
          ],
        ),
      ),
    );
  }


}
