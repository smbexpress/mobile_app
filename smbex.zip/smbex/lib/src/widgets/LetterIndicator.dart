import 'package:flutter/material.dart';

//refer to https://github.com/gonuit/flutter-letter-refresh-indicator

class LetterIndicator extends StatelessWidget {
  final AnimationController data;
  final Color accent;

  static const _circleSize = 70.0;

  static const _defaultShadow = [
    BoxShadow(blurRadius: 10, color: Colors.black26)
  ];

  LetterIndicator({
    @required this.data,
    this.accent,
  }) : assert(data != null);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final widgetWidth = constraints.maxWidth;
      final widgetHeight = constraints.maxHeight;
      final letterTopWidth = (widgetWidth / 2) + 50;

      final leftValue = (widgetWidth - (letterTopWidth * data.value / 1))
          .clamp(letterTopWidth - 100, double.infinity);

      final rightValue = (widgetWidth - (widgetWidth * data.value / 1))
          .clamp(0.0, double.infinity);

      final opacity = (data.value - 1).clamp(0, 0.5) / 0.5;

      return Stack(
        children: <Widget>[
          Positioned(
            right: rightValue,
            child: Container(
              height: widgetHeight,
              width: widgetWidth,
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: _defaultShadow,
              ),
            ),
          ),
          Positioned(
            left: leftValue,
            child: CustomPaint(
              painter: TrianglePainter(
                strokeColor: Colors.white,
                paintingStyle: PaintingStyle.fill,
              ),
              child: Container(
                height: widgetHeight,
                width: letterTopWidth,
              ),
            ),
          ),
          if (data.value >= 1)
            Container(
              padding: const EdgeInsets.only(right: 100),
              child: Transform.scale(
                scale: data.value,
                child: Opacity(
                  opacity: data.isAnimating ? 1 : opacity,
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: _circleSize,
                      height: _circleSize,
                      decoration: BoxDecoration(
                        boxShadow: _defaultShadow,
                        color: accent ?? Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: <Widget>[
                          Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(Colors.black),
                              value: data.isAnimating ? null : 0,
                            ),
                          ),
                          Icon(
                            Icons.mail_outline,
                            color: Colors.white,
                            size: 35,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
        ],
      );
    });
  }
}

class TrianglePainter extends CustomPainter {
  final Color strokeColor;
  final PaintingStyle paintingStyle;
  final double strokeWidth;

  static double convertRadiusToSigma(double radius) {
    return radius * 0.57735 + 0.5;
  }

  TrianglePainter(
      {this.strokeColor = Colors.black,
        this.strokeWidth = 3,
        this.paintingStyle = PaintingStyle.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = strokeColor
      ..strokeWidth = strokeWidth
      ..style = paintingStyle;
    final path = getTrianglePath(size.width, size.height);
    final shadowPaint = Paint()
      ..color = Colors.black.withAlpha(50)
      ..maskFilter =
      MaskFilter.blur(BlurStyle.normal, convertRadiusToSigma(10));
    canvas.drawPath(path, shadowPaint);

    canvas.drawPath(path, paint);
  }

  Path getTrianglePath(double x, double y) {
    return Path()
      ..moveTo(0, y / 2)
      ..lineTo(x, 0)
      ..lineTo(x, y)
      ..lineTo(0, y / 2);
  }

  @override
  bool shouldRepaint(TrianglePainter oldDelegate) {
    return oldDelegate.strokeColor != strokeColor ||
        oldDelegate.paintingStyle != paintingStyle ||
        oldDelegate.strokeWidth != strokeWidth;
  }
}