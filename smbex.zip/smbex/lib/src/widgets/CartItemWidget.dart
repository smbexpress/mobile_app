import 'package:flutter/material.dart';

import '../helpers/helper.dart';
import '../models/cart.dart';
import '../models/route_argument.dart';

// ignore: must_be_immutable
class CartItemWidget extends StatefulWidget {
  String route;
  CartItem cart;
  VoidCallback onDismissed;
  String currency;
  double taxAmount;
  CartItemWidget({Key key, this.cart, this.currency,this.taxAmount, this.route, this.onDismissed}) : super(key: key);

  @override
  _CartItemWidgetState createState() => _CartItemWidgetState();
}

class _CartItemWidgetState extends State<CartItemWidget> with SingleTickerProviderStateMixin{

  @override
  Widget build(BuildContext context) {
    return InkWell(
      key: Key(widget.cart.id.toString()),

      onTap: () {
        if (widget.route != null)
          Navigator.of(context).pushNamed(widget.route, arguments: new RouteArgument(id: "${widget.cart.id}"));
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 7),
        decoration: BoxDecoration(
          //color: Theme.of(context).primaryColor.withOpacity(0.9),
          boxShadow: [
            //BoxShadow(color: Theme.of(context).focusColor.withOpacity(0.1), blurRadius: 5, offset: Offset(0, 2)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Flexible(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text( "#${widget.cart.name}", style: Theme.of(context).textTheme.subtitle2),
                            InkWell(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                child: Icon(
                                  Icons.close_sharp,
                                  color: Colors.red,
                                ),
                              ),
                              onTap: widget.onDismissed,
                            )
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                                child: Text(
                                  widget.cart.title??'',
                                  style: Theme.of(context).textTheme.caption,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                            ),
                            Helper.getPrice(widget.cart.subtotal, context, currency: widget.currency, style: Theme.of(context).textTheme.headline5),

                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
