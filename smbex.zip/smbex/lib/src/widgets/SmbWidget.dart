import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_text_field/pin_code_text_field.dart';
import 'package:provider/provider.dart';

import 'package:smbex_app/src/app_state.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/theme/theme.dart';
import 'package:smbex_app/src/widgets/page_transition.dart';
import 'package:smbex_app/src/widgets/picker/search/dropdown_search.dart';
import 'package:smbex_app/src/widgets/stylish_dialog.dart';
import 'package:time_range_picker/time_range_picker.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../helpers/helper.dart';
import '../helpers/size_config.dart';
import '../models/model.dart';
import '../notification_provider.dart';
import '../repository/account_repository.dart';
import "../theme/extention.dart";
import 'ShoppingCartButtonWidget.dart';
import 'animation_icon.dart';

export 'package:material_floating_search_bar/material_floating_search_bar.dart';

/*fonts*/
const fontRegular = 'Regular';
const fontMedium = 'Medium';
const fontSemibold = 'Semibold';
const fontBold = 'Bold';
/* font sizes*/
const textSizeSmall = 12.0;
const textSizeSMedium = 14.0;
const textSizeMedium = 16.0;
const textSizeLargeMedium = 18.0;
const textSizeNormal = 20.0;
const textSizeLarge = 24.0;
const textSizeXLarge = 34.0;

/* margin */

const spacing_control_half = 2.0;
const spacing_control = 4.0;
const spacing_standard = 8.0;
const spacing_middle = 10.0;
const spacing_standard_new = 16.0;
const spacing_large = 24.0;
const spacing_xlarge = 32.0;
const spacing_xxLarge = 40.0;

Widget appBar(BuildContext context,
    {Key key,
    bool automaticallyImplyLeading: false,
    Widget leading,
    Color backgroundColor,
    double elevation: 0,
    Widget title,
    String titleText,
    List<Widget> actions,
    bool showBack: true,
    Widget bottom,
    bool centerTitle: true,
    bool showCart,
    bool isSecondary = true,
    bool rounded}) {
  if (titleText != null) {
    title = Text(titleText);
  }

  if (showCart != null && showCart && currentAccount.value.valid) {
    actions = actions ?? [];
    actions.add(new ShoppingCartButtonWidget(
        labelColor: Theme.of(context).primaryColor));
  }
  final appBar = AppBar(
      key: key,
      automaticallyImplyLeading: showBack || automaticallyImplyLeading,
      leading: leading,
      backgroundColor: backgroundColor,
      elevation: elevation,
      title: title,
      centerTitle: centerTitle,
      actions: actions,
      bottom: bottom,
      shape: rounded == true
          ? const RoundedRectangleBorder(
              borderRadius: const BorderRadius.only(
                  bottomLeft: const Radius.circular(8),
                  bottomRight: const Radius.circular(8)))
          : null);

  if (isSecondary == false) {
    final theme = Theme.of(context);
    return AppWrapperWidget(
        child: appBar,
        theme: theme.copyWith(
            appBarTheme: AppBarTheme(
                iconTheme: IconThemeData(color: theme.colorScheme.onSurface),
                titleTextStyle:
                    TextStyle(color: theme.colorScheme.onSurface, fontSize: 18),
                backgroundColor: theme.cardColor,
                systemOverlayStyle: AppTheme.whiteOverlayStyle,
                shape: rounded == true
                    ? const RoundedRectangleBorder(
                        borderRadius: const BorderRadius.only(
                            bottomLeft: const Radius.circular(8),
                            bottomRight: const Radius.circular(8)))
                    : null)));
  }
  return appBar;
}

class AppWrapperWidget extends StatelessWidget with PreferredSizeWidget {
  final PreferredSizeWidget child;
  final Widget wrap;
  final ThemeData theme;
  const AppWrapperWidget({Key key, this.theme, this.child, this.wrap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return theme != null
        ? Theme(data: theme, child: wrap ?? child)
        : wrap ?? child;
  }

  @override
  Size get preferredSize => child.preferredSize;
}

Widget text(String text, BuildContext context,
    {var fontSize,
    var textColor,
    var isCentered = false,
    var maxLine = 1,
    var latterSpacing,
    var textAllCaps = false,
    var isLongText = false}) {
  ThemeData th = Theme.of(context);

  if (fontSize == null) fontSize = th.textTheme.bodyText1.fontSize;
  if (textColor == null) textColor = th.accentColor;
  return Text(textAllCaps ? text.toUpperCase() : text,
      textAlign: isCentered ? TextAlign.center : TextAlign.start,
      maxLines: isLongText ? null : maxLine,
      style: TextStyle(
          fontSize: fontSize, color: textColor, letterSpacing: latterSpacing));
}

BoxDecoration boxDecoration(BuildContext context,
    {double radius = spacing_middle,
    Color color = Colors.transparent,
    Color bgColor,
    var showShadow = false}) {
  bgColor = bgColor != null ? bgColor : Theme.of(context).primaryColor;

  return BoxDecoration(
      color: bgColor,
      boxShadow: showShadow
          ? [
              BoxShadow(
                  color: Theme.of(context).hintColor.withOpacity(0.15),
                  blurRadius: 10,
                  spreadRadius: 2)
            ]
          : [BoxShadow(color: Colors.transparent)],
      border: Border.all(color: color),
      borderRadius: BorderRadius.all(Radius.circular(radius)));
}

Padding editTextStyle(BuildContext context, var hintText, {var line = 1}) {
  return Padding(
      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
      child: TextFormField(
        maxLines: line,
        style: TextStyle(
          fontSize: 16,
        ),
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(4, 16, 4, 16),
          hintText: hintText,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: BorderSide(
                color: Theme.of(context).accentColor.withOpacity(0.2),
                width: 0.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: BorderSide(
                color: Theme.of(context).accentColor.withOpacity(0.2),
                width: 0.0),
          ),
        ),
      ));
}

Container homeEditTextStyle(var hintText, {var line = 1}) {
  return Container(
    child: TextField(
      style: TextStyle(fontSize: 16),
      decoration: InputDecoration(
        contentPadding: EdgeInsets.fromLTRB(16, 8, 16, 8),
        isDense: true,
        hintText: hintText,
        border: InputBorder.none,
      ),
    ),
  );
}

Widget title(var title, BuildContext context) {
  return Stack(
    children: <Widget>[
      Container(color: Theme.of(context).primaryColor, height: 70),
      Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.width * 0.15,
            alignment: Alignment.topLeft,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    IconButton(
                      icon: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).backgroundColor,
                      ),
                      onPressed: () {
                        //finish(context);
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(spacing_standard, 0, 0, 0),
                      child: Text(title,
                          style: Theme.of(context).textTheme.headline4),
                    ),
                  ],
                )
              ],
            ),
          ),
          Container(
            padding:
                EdgeInsets.only(top: MediaQuery.of(context).size.width * 0.05),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20))),
          ),
        ],
      )
    ],
  );
}

Widget decorateStack1(BuildContext context,
    {double top: 65.0, double vertical: 30.0}) {
  return Container(
    width: double.infinity,
    padding: EdgeInsets.symmetric(vertical: vertical, horizontal: 20),
    margin: EdgeInsets.fromLTRB(40, top, 40, 20),
    //margin: EdgeInsets.symmetric(vertical: 65, horizontal: 40),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: Theme.of(context).primaryColor.withOpacity(0.6),
    ),
  );
}

Widget decorateStack2(BuildContext context, Widget child,
    {double top: 85.0, double vertical: 30.0}) {
  return Container(
    width: double.infinity,
    padding: EdgeInsets.symmetric(vertical: vertical, horizontal: 20),
    //margin: EdgeInsets.symmetric(vertical: 85, horizontal: 20),
    margin: EdgeInsets.fromLTRB(20, top, 20, 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: Theme.of(context).cardColor,
      boxShadow: [
        BoxShadow(
            color: Theme.of(context).hintColor.withOpacity(0.2),
            offset: Offset(0, 10),
            blurRadius: 20)
      ],
    ),
    child: child,
  );
}

Widget pinCodeTextField(BuildContext context,
    {controller,
    pinLength: 4,
    hasError: false,
    onDone,
    onTextChanged,
    highlightColor,
    defaultBorderColor,
    hasTextBorderColor,
    pinTextStyle}) {
  ThemeData theme = Theme.of(context);
  return PinCodeTextField(
    autofocus: true,
    controller: controller,
    //isCupertino: true,
    hideCharacter: false,
    highlight: true,

    highlightColor: highlightColor ?? theme.accentColor,
    defaultBorderColor: defaultBorderColor ?? theme.accentColor,
    hasTextBorderColor: hasTextBorderColor ?? theme.primaryColor,
    maxLength: pinLength,
    hasError: hasError,
    maskCharacter: "*",
    onTextChanged: onTextChanged,
    onDone: onDone ?? (_) => {},
    wrapAlignment: WrapAlignment.start,
    pinBoxDecoration: ProvidedPinBoxDecoration.defaultPinBoxDecoration,
    pinTextStyle: pinTextStyle ??
        new TextStyle(
          color: theme.accentColor,
          fontSize: 35.0,
          fontWeight: FontWeight.bold,
        ),
    textDirection: TextDirection.ltr,
    pinTextAnimatedSwitcherTransition:
        ProvidedPinBoxTextAnimation.scalingTransition,
    pinTextAnimatedSwitcherDuration: Duration(milliseconds: 300),
  );
}

Widget buildVerticalAnimatedFade(Widget content,
    {int index: 0, int selected = 0, int length: 1}) {
  return Stack(
    children: <Widget>[
      PositionedDirectional(
        start: 24.0,
        top: 0.0,
        bottom: 0.0,
        child: SizedBox(
          width: 24.0,
          child: Center(
            child: SizedBox(
              width: index == length - 1 ? 0.0 : 1.0,
              child: Container(
                color: Colors.grey.shade400,
              ),
            ),
          ),
        ),
      ),
      AnimatedCrossFade(
        firstChild: Container(height: 0.0),
        secondChild: Container(
          margin: const EdgeInsetsDirectional.only(
            start: 60.0,
            end: 24.0,
            bottom: 24.0,
          ),
          child: content,
        ),
        firstCurve: const Interval(0.0, 0.6, curve: Curves.fastOutSlowIn),
        secondCurve: const Interval(0.4, 1.0, curve: Curves.fastOutSlowIn),
        sizeCurve: Curves.fastOutSlowIn,
        crossFadeState: selected == index
            ? CrossFadeState.showSecond
            : CrossFadeState.showFirst,
        duration: kThemeAnimationDuration,
      ),
    ],
  );
}

Widget listItem0(BuildContext context, String text, Widget icon,
    {onTap, double padding: 10.0}) {
  ThemeData theme = Theme.of(context);
  return InkWell(
    onTap: onTap,
    child: Container(
        padding: EdgeInsets.all(padding),
        decoration: BoxDecoration(
            color: theme.primaryColor.withOpacity(1),
            borderRadius: BorderRadius.all(Radius.circular(10)),
            boxShadow: [
              BoxShadow(
                color: Color(0x88999999),
                offset: Offset(0, 5),
                blurRadius: 5.0,
              ),
            ]),
        child: Row(
          children: <Widget>[
            if (icon != null) icon,
            Expanded(
              flex: 5,
              child: Container(
                  padding: EdgeInsetsDirectional.only(start: 10),
                  child: Text(
                    text ?? "",
                    style: theme.textTheme.headline5,
                  )),
            ),
            Expanded(
              flex: 1,
              child: Icon(
                Icons.arrow_forward_ios,
                color: theme.textTheme.caption.color,
              ),
            ),
          ],
        )),
  );
}

Widget listItem(BuildContext context, String text, String subtitle, Widget icon,
    {onTap, double padding: 10.0, borderIcon: true, Widget trailing}) {
  var style = TextStyles.title.bold;
  if (text != null && text.length > 22) {
    style = TextStyles.bodySm;
    if (text.length > 30) {
      text = text.substring(0, 25) + ' ...';
    }
  }

  return Container(
    margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.all(Radius.circular(20)),
      boxShadow: <BoxShadow>[
        BoxShadow(
          offset: Offset(4, 4),
          blurRadius: 10,
          color: LightColor.grey.withOpacity(.2),
        ),
        BoxShadow(
          offset: Offset(-3, 0),
          blurRadius: 15,
          color: LightColor.grey.withOpacity(.1),
        )
      ],
    ),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: borderIcon
            ? ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(13)),
                child: Container(
                  height: 55,
                  width: 55,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: LightColor.accent,
                  ),
                  child: icon,
                ),
              )
            : icon,
        title: Text(
          text != null ? text : "",
          style: style,
          maxLines: 1,
          overflow: TextOverflow.clip,
        ),
        subtitle: Text(
          subtitle,
          style: TextStyles.bodySm.subTitleColor.bold,
        ),
        trailing: trailing ??
            Icon(
              Icons.chevron_right,
              size: 30,
              color: Theme.of(context).colorScheme.secondary,
            ),
      ),
    ).ripple(() {
      if (onTap != null) onTap();
    }, borderRadius: BorderRadius.all(Radius.circular(20))),
  );
}

Widget buildPageHeader(BuildContext context,
    {double height = 350, Widget title}) {
  return ClipPath(
    clipper: ThemPageHeaderClipper(),
    child: Container(
      padding: EdgeInsets.all(40),
      //height: height,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondary,
        /*
        image: DecorationImage(
          image: AssetImage("assets/images/virus.png"),
        ),*/
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[SizedBox(height: 20), if (title != null) title],
      ),
    ),
  );
}

typedef FutureFactory = Future Function();

Future<TimeRange> timeRange(
    BuildContext context, double start, double end) async {
  start = start ?? 8;
  end = end ?? start + 1;

  int shour = (start).floor();
  int smin = (start * 60.0 % 60.0).round();
  int ehour = (end % 24).floor();
  int emin = (end * 60.0 % 60.0).round();
  if (smin == 60) {
    smin = 0;
    shour += 1;
  }
  shour = shour % 24;

  if (emin == 60) {
    emin = 0;
    ehour += 1;
  }
  ehour = ehour % 24;
  TimeRange result = await showTimeRangePicker(
    context: context,
    start: TimeOfDay(hour: shour, minute: smin),
    end: TimeOfDay(hour: ehour, minute: emin),
    onStartChange: (start) {
      print("start time " + start.toString());
    },
    onEndChange: (end) {
      print("end time " + end.toString());
    },
    interval: Duration(minutes: 30),
    use24HourFormat: true,
    padding: 30,
    strokeWidth: 20,
    handlerRadius: 14,
    strokeColor: Colors.orange,
    handlerColor: Colors.orange[700],
    selectedColor: Colors.amber,
    backgroundColor: Colors.green,
    ticks: 12,
    ticksColor: Colors.white,
    snap: true,
    labels: ["12 pm", "3 am", "6 am", "9 am", "12 am", "3 pm", "6 pm", "9 pm"]
        .asMap()
        .entries
        .map((e) {
      return ClockLabel.fromIndex(idx: e.key, length: 8, text: e.value);
    }).toList(),
    labelOffset: -30,
    labelStyle: TextStyle(
        fontSize: 22, color: Colors.grey, fontWeight: FontWeight.bold),
    timeTextStyle: TextStyle(
        color: Colors.orange[700],
        fontSize: 32,
        fontStyle: FontStyle.italic,
        fontWeight: FontWeight.bold),
    activeTimeTextStyle: TextStyle(
        color: Colors.orange,
        fontSize: 32,
        fontStyle: FontStyle.italic,
        fontWeight: FontWeight.bold),
    disabledTime: TimeRange(
        startTime: TimeOfDay(hour: 18, minute: 0),
        endTime: TimeOfDay(hour: 7, minute: 0)),
    disabledColor: Colors.grey,
  );

  return result;
}

Future<DateTime> showDatePickDate(BuildContext context, DateTime value,
    [DateTime firstDate, DateTime lastDate]) async {
  lastDate = lastDate ?? DateTime.now().add(Duration(days: 7));
  final date = await showDatePicker(
      context: context,
      firstDate: firstDate ?? value ?? DateTime.now(),
      initialDate: value ?? DateTime.now(),
      lastDate: lastDate);

  return date;
}

Widget createOptions(BuildContext context, List options, dynamic selected,
    ValueChanged onChange) {
  Color cardColor = Theme.of(context).cardColor;
  Color textSelectionColor = Theme.of(context).primaryColor;
  Color accentColor = Theme.of(context).accentColor;
  return ListView.builder(
    shrinkWrap: true,
    scrollDirection: Axis.horizontal,
    itemCount: options.length,
    itemBuilder: (BuildContext context, int index) {
      bool isSelected = selected == options[index];
      return Padding(
          padding: const EdgeInsets.all(3.0),
          child: ChoiceChip(
              key: ValueKey<String>(options[index]['id'].toString()),
              elevation: 1.0,
              padding: EdgeInsets.all(10),
              backgroundColor: isSelected ? accentColor : cardColor,
              selectedColor: accentColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),
              ),
              selected: isSelected,
              label: Text(
                options[index].toString(),
                style: TextStyle(
                    color: isSelected ? textSelectionColor : accentColor),
              ),
              onSelected: (bool check) {
                //widget?.onTap();
                if (onChange != null) onChange(options[index]);
              }));
    },
  );
}

Widget createLogo(BuildContext context) {
  return Stack(
    alignment: Alignment.center,
    children: <Widget>[
      Container(
        width: 200,
        height: 200,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(image: AssetImage("assets/img/logo1.png")),
            gradient: LinearGradient(
                begin: Alignment.bottomLeft,
                end: Alignment.topRight,
                colors: [
                  Colors.grey.withOpacity(0.5),
                  Colors.grey.withOpacity(0.01),
                ])),
      ),
      Positioned(
        right: -30,
        bottom: -50,
        child: Container(
          width: 160,
          height: 160,
          decoration: BoxDecoration(
            color: Theme.of(context).backgroundColor.withOpacity(.6),
            borderRadius: BorderRadius.circular(150),
          ),
        ),
      ),
      Positioned(
        left: -60,
        top: -50,
        child: Container(
          width: 180,
          height: 180,
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.5),
            borderRadius: BorderRadius.circular(150),
          ),
        ),
      )
    ],
  );
}

InputDecoration createUnderLineDecoration(
  BuildContext context, {
  Widget icon,
  Color iconColor,
  Widget label,
  String labelText,
  String helperText,
  int helperMaxLines,
  String hintText,
  int hintMaxLines,
  String errorText,
  TextStyle errorStyle,
  int errorMaxLines,
  bool isCollapsed = false,
  bool isDense,
  EdgeInsetsGeometry contentPadding,
  Widget prefixIcon,
  Widget prefix,
  String prefixText,
  Widget suffixIcon,
  Widget suffix,
  Widget counter,
  String counterText,
  bool filled,
  Color fillColor,
  Color focusColor,
  Color hoverColor,
}) {
  final decorationTheme = Theme.of(context).inputDecorationTheme;
  return InputDecoration(
    icon: icon,
    iconColor: iconColor,
    label: label,
    labelText: labelText,
    helperText: helperText,
    helperMaxLines: helperMaxLines,
    hintText: hintText,
    hintMaxLines: hintMaxLines,
    errorText: errorText,
    isDense: isDense,
    contentPadding: contentPadding,
    prefixIcon: prefixIcon,
    prefix: prefix,
    suffixIcon: suffixIcon,
    suffix: suffix,
    counter: counter,
    counterText: counterText,
    filled: filled,
    fillColor: decorationTheme.fillColor,
    focusColor: decorationTheme.focusColor,
    hoverColor: decorationTheme.hoverColor,
    hintStyle: decorationTheme.hintStyle,
    labelStyle: decorationTheme.labelStyle,
    border: UnderlineInputBorder(borderSide: decorationTheme.border.borderSide),
    enabledBorder: UnderlineInputBorder(
        borderSide: decorationTheme.enabledBorder.borderSide),
    focusedBorder: UnderlineInputBorder(
        borderSide: decorationTheme.focusedBorder.borderSide),
    disabledBorder: UnderlineInputBorder(
        borderSide: decorationTheme.disabledBorder.borderSide),
    errorBorder: UnderlineInputBorder(
        borderSide: decorationTheme.errorBorder.borderSide),
  );
}

Future<bool> alert(BuildContext context,
    {Widget content,
    Widget title,
    String confirmText,
    String cancelText,
    TextStyle confirmStyle,
    TextStyle cancelStyle,
    bool showConfirm = true,
    bool showCancel = true}) {
  return showDialog(
      context: context,
      //barrierColor: Colors.transparent,
      builder: (BuildContext context) {
        return defaultTargetPlatform == TargetPlatform.iOS
            ? CupertinoAlertDialog(
                content: content,
                title: title,
                actions: [
                  if (showCancel)
                    CupertinoDialogAction(
                        child: Text(cancelText ?? tr.buttons.discard, style: cancelStyle,),
                        onPressed: () => Navigator.of(context).pop(false)),
                  if (showConfirm)
                    CupertinoDialogAction(
                        child: Text(confirmText ?? tr.buttons.yes, style: confirmStyle,),
                        onPressed: () => Navigator.of(context).pop(true)),
                ],
              )
            : AlertDialog(
                content: content,
                title: title,
                actions: [
                  if (showCancel)
                    TextButton(
                        child: Text(cancelText ?? tr.buttons.discard, style: cancelStyle,),
                        onPressed: () => Navigator.of(context).pop(false)),
                  if (showConfirm)
                    TextButton(
                        child: Text(confirmText ?? tr.buttons.yes, style: confirmStyle,),
                        onPressed: () => Navigator.of(context).pop(true)),
                ],
              );
      });
}

class ContentType {
  ContentType._();
  static const int NORMAL = 0,
      PROGRESS = 1,
      SUCCESS = 2,
      INFO = 3,
      WARNING = 4,
      ERROR = 5,
      CUSTOM = 6;
}

void showSnackBar(BuildContext context,
    {String title,
    String message,
    dynamic error,
    Duration duration,
    int contentType,
    BorderRadiusGeometry borderRadius = const BorderRadius.only(
        topRight: const Radius.circular(12.0),
        topLeft: const Radius.circular(12.0)),
    EdgeInsetsGeometry margin,
    SnackBarBehavior behavior = SnackBarBehavior.fixed,
    bool showTitle = true,
    bool showMessage = true,
    bool useRootContext = true}) {
  final useContext = useRootContext && context != null
      ? context.read<AppState>().navigatorKey.currentContext
      : context ?? AppState.instance.navigatorKey.currentContext ;

  contentType ??= ContentType.ERROR;

  final snackBar = SnackBar(
    //backgroundColor: Colors.white,
    elevation: 8.0,
    behavior: behavior,
    margin: margin,
    shape: RoundedRectangleBorder(borderRadius: borderRadius),
    content: Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimationIcon(
            iconType: AnimationIconType.values[contentType],
            scale: 1.3,
            duration: Duration(milliseconds: 1000),
          ),
          if (showTitle)
            SizedBox(
              height: 20,
            ),
          if (showTitle)
            Text(
              title ?? (contentType == ContentType.ERROR ? tr.oops : tr.done),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          if (showMessage)
            SizedBox(
              height: 10,
            ),
          if (showMessage)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                message ??
                    Helper.getError(error,
                        fallback: tr.errorMessages.somethingWrong),
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.start,
                maxLines: 3,
              ),
            ),
          SizedBox(
            height: 20,
          ),
        ],
      ),
    ),
  );

  ScaffoldMessenger.of(useContext).showSnackBar(snackBar);
}

void showSuccessSnackBar(BuildContext context, [String title]) =>
    showSnackBar(context,
        title: title ?? tr.done,
        showMessage: false,
        contentType: ContentType.SUCCESS
    );



StylishDialog showNotifyDialog(BuildContext context,
    {String title,
    String message,
    dynamic error,
    Duration duration = const Duration(seconds: 6),
    int contentType,
    AppState appState,
    bool showTitle = true,
    bool showMessage = true,
    bool show = true,
    bool fullWidth ,
    bool dismissOnTouchOutside = true,
    TransitionType  transitionType
    }) {
  final state = appState ?? Provider.of<AppState>(context, listen: false);
  final provider = context.read<NotificationProvider>();
  contentType ??= ContentType.ERROR;
  bool visible = false;
  final controller = DialogController(
      listener: (status) => visible = (status != DialogStatus.Dismissed));

  final dialog = StylishDialog(
      controller: controller,
      context: state.navigatorKey.currentState.context,
      alertType: StylishDialogType.NORMAL,
      transitionType: transitionType ?? contentType == ContentType.ERROR
          ? TransitionType.BOTTOM
          :TransitionType.SCALE_OPACITY,
      dismissOnTouchOutside: dismissOnTouchOutside,
      iconScale: 1.8,
      addView: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimationIcon(
              iconType: AnimationIconType.values[contentType],
              scale: 1.8,
              duration: Duration(milliseconds: 1000),
            ),
            if (showTitle)
              SizedBox(
                height: 20,
              ),
            if (showTitle &&
                (contentType == ContentType.ERROR ||
                    contentType == ContentType.SUCCESS))
              Text((contentType == ContentType.ERROR ? tr.oops : tr.done),
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
              ),
            if (showMessage)
              SizedBox(
                height: 10,
              ),
            if (showMessage)
              Text(
                message ??
                    Helper.getError(error,
                        fallback: tr.errorMessages.somethingWrong),
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
      margin: fullWidth != true ? EdgeInsets.symmetric(
          horizontal: getProportionateScreenWidth(34)
      ) : null
  );

  if (duration != null)
    Future.delayed(duration, () {
      print("showNotifyDialog::$visible");
      if (visible) {
        dialog.dismiss();
      }
    });
  if (show) dialog.show();

  return dialog;
}

StylishDialog showSuccessDialog(BuildContext context) =>
    showNotifyDialog(context,
        title: tr.done,
        showMessage: false,
        contentType: ContentType.SUCCESS,
        duration: const Duration(seconds: 6)
    );

StylishDialog showErrorDialog(BuildContext context, {
    String message,
    dynamic error,
    Duration duration = const Duration(seconds: 16),
    bool warning,
    bool fullWidth
  }) =>
    showNotifyDialog(context,
        title: warning == true ? tr.warning : tr.oops,
        message: message,
        error: error,
        contentType: warning == true
            ? ContentType.WARNING
            : ContentType.ERROR,
        fullWidth: fullWidth,
        duration: const Duration(seconds: 6)
    );

DropdownSearch<T> createSearchDropdown<T>(
    BuildContext context, String label, String toString(T),
    {Key key,
    T selected,
    String endpoint,
    Map<String, dynamic> args,
    bool online = false,
    List<T> items,
    T convert(dynamic),
    void onChanged(T data),
    String placeholder,
    bool enabled = true,
    String popupTitle,
    bool outline = true,
    List<T> Function(List<T> items) sort,
    FormFieldValidator<T> validator}) {
  ThemeData theme = Theme.of(context);

  return DropdownSearch<T>(
      key: key,

      selectedItem: selected,
      //filterFn: (user, filter) => user.userFilterByCreationDate(filter),
      itemAsString: toString,
      onChanged: onChanged,
      //dropdownSearchDecoration: Theme.of(context).inputDecorationTheme.,
      enabled: enabled,
      validator: validator,
      dropdownSearchDecoration: outline
          ? InputDecoration(
              label: Text(label ?? ''),
              border: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: theme.dividerColor.withOpacity(.2)),
                  borderRadius: const BorderRadius.all(Radius.circular(10))),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      width: 1, color: theme.dividerColor.withOpacity(.7)),
                  borderRadius: const BorderRadius.all(Radius.circular(10))),
              focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(width: 2, color: theme.primaryColorDark),
                  borderRadius: const BorderRadius.all(Radius.circular(8))),
              focusColor: theme.focusColor,
              fillColor: theme.cardColor,
              filled: true,
              contentPadding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            )
          : createUnderLineDecoration(context),
      dropDownButton: Icon(
        Icons.expand_more,
        color: theme.colorScheme.secondary,
        size: 26,
      ),
      mode: Mode.PAGE,
      items: items,
      showSearchBox: true,
      isFilteredOnline: online,
      hint: placeholder ?? tr.search,
      searchBoxDecoration: InputDecoration(
        hintText: placeholder ?? tr.search,
      ),
      onFind: online
          ? (text) {
              if (text != null && text.isNotEmpty) {
                if (args != null) {
                  args['q'] = text;
                } else {
                  args = {'q': text};
                }
              }
              return ResultItems.of(Api().get(endpoint, data: args), convert)
                  .then((result) =>
                      sort != null ? sort(result.items) : result.items);
            }
          : null,
      popupTitle: Container(
        padding: EdgeInsets.only(bottom: 2),
        //color: theme.cardColor,
        child: appBar(context, titleText: popupTitle ?? '', isSecondary: true),
      ));
}
