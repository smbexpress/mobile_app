import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/models/route_argument.dart';
import 'package:smbex_app/src/widgets/refreshaple.dart';
import 'package:smbex_app/src/widgets/stylish_dialog.dart';
import '../helpers/helper.dart';
import '../models/tody_tip.dart';
import 'flutter_html_text.dart';

class TipWidget extends StatefulWidget {
  final List<TodayTip> assignTips;
  final TodayTipType tipType;
  final void Function(TodayTip tip) onClose;
  const TipWidget({
    Key key,
    this.assignTips,
    this.tipType,
    this.onClose
  }) : super(key: key);

  @override
  State<TipWidget> createState() => TipWidgetState();

  static Future<Map<TodayTipType, TipWidget>>
    fromStore(String prefKey, [List<dynamic> allTips]) async{
    final tipList = await TodayTip.getTips(allTips, prefKey);
    return createTips(prefKey, tipList);
  }

  static Map<TodayTipType, TipWidget>
      createTips(String prefKey, [List<TodayTip> allTips]){
    Map<TodayTipType, List<TodayTip>> tipMapGroup = {};
    //TodayTip.getTips(rawTipList, prefKey)
    allTips?.forEach((tip) {
      List<TodayTip> group = tipMapGroup[tip.type?? TodayTipType.tip];
      if (group == null){
        tipMapGroup[tip.type?? TodayTipType.tip] = group = <TodayTip>[];
      }
      group.add(tip);
    });
    Map<TodayTipType,TipWidget> tipWidgetGroup = {};

    void onTipClose(TodayTip tip) async{
      if(tipWidgetGroup[tip.type].assignTips.isEmpty){
        tipWidgetGroup.remove(tip.type);
      }
      await TodayTip.closeTip(tip, allTips, prefKey);
    }

    for(MapEntry<TodayTipType, List<TodayTip>> tipEntry in tipMapGroup.entries){
      tipWidgetGroup[tipEntry.key] = TipWidget(
          assignTips: tipEntry.value,
          tipType: tipEntry.key,
          onClose: onTipClose,
      );
    }
    return tipWidgetGroup;
  }

}

class TipWidgetState extends State<TipWidget> {
  StylishDialog _popup;
  ImageProvider _imageProvider;
  Map<TodayTip, ImageProvider> _mapImageProvider = {};
  void _onClose(TodayTip tip) async{
    widget.assignTips.remove(tip);
    await widget.onClose?.call(tip);
    final popup = _popup;
    _popup = null;
    if (tip.type == TodayTipType.popup) {
      try{
        popup?.dismiss();
      } catch(e){
        Navigator.of(context, rootNavigator: true).pop();
      }
    }
    _refreshAncestor();
    setState(() {});

  }
  void _onPressed(TodayTip tip) async{

      if (tip.linkUrl != null){
        Helper.launchWebsite(tip.linkUrl);
      }
      if (tip.route != null){
        if(tip.type == TodayTipType.popup){
          _popup?.dismiss();
          _popup = null;
          widget.assignTips.remove(tip);
          await widget.onClose?.call(tip);
        }
        final arguments = tip.args != null
            ? RouteArgument(id: tip.args['id']?.toString(), param: tip.args)
            : null;

        await Navigator.pushNamed(
            this.context, tip.route, arguments: arguments);

        if(tip.type == TodayTipType.popup) {
          _refreshAncestor();
          setState(() {});
        }
      }

  }

  Widget _createTipChild(TodayTip tip){
    final type = tip.type;
    bool canClose = type == TodayTipType.tip || type == TodayTipType.popup || type == TodayTipType.status;
    Widget child = tip.content != null
                  ? HtmlText(data: tip.content)
                  : const SizedBox();

    child = Row(
      children: [
        Expanded(child: child)
      ],
    );
    ImageProvider _imageProvider = _mapImageProvider[tip];
    if (tip.imageUrl != null && _imageProvider == null){
      _imageProvider = _getImageProvider(tip.imageUrl, tip.type != TodayTipType.popup);
      if (_imageProvider != null){
        _mapImageProvider[tip] = _imageProvider;
      }
    }

    _imageProvider ??= _getImageProvider(tip.imageUrl, tip.type != TodayTipType.popup);

    if (tip.heightFactor != null){
      final mq = MediaQuery.of(context);
      child = SizedBox(
        height: mq.size.height * min(tip.heightFactor, .8) - mq.padding.top - mq.padding.bottom,
        child: child,
      );
    }

    child = tip.readMore != null || canClose
       ? Column(
          children: [
            if (canClose)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                      onTap: ()=> _onClose(tip),
                      child: Icon(
                          Icons.close
                      )
                  )
                ],
              ),
            child,
            if (tip.readMore != null)
              const SizedBox(height: 16,),
            if (tip.readMore != null)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                      onPressed: ()=> _onPressed(tip),
                      child: Text(
                          tip.readMore
                      )
                  )
                ],
              )

          ],
      )
      : child;


    child = tip.route != null ||  tip.linkUrl != null
        ? InkWell(
            child: child,
            onTap: ()=> _onPressed(tip),
         )
        : child;

    child = _imageProvider != null
        ? Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: _imageProvider,
                  fit: BoxFit.fill
              )
            ),
            child: child,

         )
        : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: child,
        ) ;


    child = Material(
      color: tip.color,
      child: child,
      clipBehavior: Clip.hardEdge,
    );
    if (type != TodayTipType.popup)
      child = AnimatedSlide(
        offset: Offset(0, 0.0),
        child: child,
        duration: Duration(milliseconds: 300),
      );

    return child;
  }

  void _showPopup(TodayTip tip) async{
    _popup = StylishDialog(
        context: context,
        addView: _createTipChild(tip),
        alertType: StylishDialogType.NORMAL,
        transitionDuration: Duration(milliseconds: 400),
        dismissOnTouchOutside: false
    );
    await _popup.show();
    if (_popup != null) {
      widget.assignTips.remove(tip);
      await widget.onClose?.call(tip);
      _refreshAncestor();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
      if (widget.assignTips.isEmpty)
        return const SizedBox.shrink();

      if (widget.tipType == TodayTipType.popup)  {
        if (_popup == null)
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
            if (mounted)
              _showPopup(widget.assignTips.first);
          });

        return const SizedBox.shrink();
      }

      if (widget.assignTips.length == 1)
        return _createTipChild(widget.assignTips.first);

      return Column(
          children: [
            _createTipChild(widget.assignTips.first),
            const SizedBox(height: 16,),
            _createTipChild(widget.assignTips[1])
          ]
      );

  }

  void _refreshAncestor(){
    final parent = context.findAncestorStateOfType<Refreshaple>();
    if (parent != null){
      parent.refresh();
    } else {
      setState(() {

      });
    }
  }

  static ImageProvider _getImageProvider(String url, bool cache){
    if (url == null)
      return null;

    final base64Pos = url.indexOf('base64,');
    if (base64Pos > 0) {
      return Image.memory(base64Decode(url.substring(base64Pos + 'base64,'.length))).image;
    }
    if (url.startsWith("http:") || url.startsWith("https:"))
      return cache
          ? CachedNetworkImageProvider(url)
          : Image.network(url).image;

    if (url.startsWith("file:"))
      return Image.file(File(url)).image;

    if (url.startsWith("assets/"))
      return Image.asset(url).image;

    return null;
  }

}

