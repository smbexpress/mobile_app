import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../api.dart';
import '../config.dart';
import '../models/account.dart';

class ProfileAvatarWidget extends StatelessWidget {
  final Account account;
  ProfileAvatarWidget({
    Key key,
    this.account,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondary,
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(12), bottomRight: Radius.circular(12)),
      ),
      child: Column(
        children: <Widget>[
          Container(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[

                ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(300)),
                  child: /*account.image?.url == null ? Container(
                    height: 200,
                    width: 200,
                    decoration: BoxDecoration(
                      image: DecorationImage (image: AssetImage("assets/img/logo1.png")),
                      color: Colors.white
                    ),
                  ) :*/ CachedNetworkImage(
                        height: 80,
                        width: 80,
                        fit: BoxFit.cover,
                        imageUrl: '${Config().url}mobile/web/media/account/avatar',
                        httpHeaders: Api().headers,
                        placeholder: (context, url) => Image.asset(
                          'assets/img/loading.gif',
                          fit: BoxFit.cover,
                          height: 80,
                          width: 80,
                        ),
                        errorWidget: (context, url, error) => Image(
                            image: AssetImage("assets/img/logo1.png")
                        ),
                      ),
                ),
//              SizedBox(
//                width: 50,
//                height: 50,
//                child: FlatButton(
//                  padding: EdgeInsets.all(0),
//                  onPressed: () {},
//                  child: Icon(Icons.chat, color: Theme.of(context).primaryColor),
//                  color: Theme.of(context).accentColor,
//                  shape: StadiumBorder(),
//                ),
//              ),
              ],
            ),
          ),
          SizedBox(height: 10,),
          Text(
            account.name,
            style: Theme.of(context).textTheme.headline6?.merge(TextStyle(color: Theme.of(context).cardColor)),
          ),

        ],
      ),
    );
  }
}
