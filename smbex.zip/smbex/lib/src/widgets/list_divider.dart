// Flutter imports:
import 'package:flutter/material.dart';

class ListDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
   Color color = Theme.of(context).dividerColor;
    // https://github.com/flutter/flutter/issues/46339#issuecomment-562859241
    return Container(
      color: color,
      child: Divider(
        color: color,
        thickness: 1.5,
        height: 1.5,
      ),
    );
  }
}
