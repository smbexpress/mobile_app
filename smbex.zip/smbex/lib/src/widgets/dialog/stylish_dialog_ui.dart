// @dart=2.12
import 'package:flutter/material.dart';
import '../stylish_dialog.dart';

const _sizeK = 48.0;

// ignore: must_be_immutable
class StylishDialogUI extends StatefulWidget {
  StylishDialogUI({
    Key? key,
    required this.context,
    required this.alertType,
    this.animationLoop,
    this.titleText,
    this.contentText,
    this.confirmText,
    this.cancelText,
    this.confirmPressEvent,
    this.cancelPressEvent,
    this.addView,
    this.confirmButton,
    this.cancelButton,
    this.color,
    this.titleStyle,
    this.contentStyle,
    this.style,
    this.backgroundColor,
    this.borderRadius: const BorderRadius.all(const Radius.circular(14)),
    this.iconScale = 1.0
  }) : super(key: key);

  final BuildContext context;
  final StylishDialogType? alertType;
  final bool? animationLoop;
  String? titleText;
  String? contentText;
  String? confirmText;
  String? cancelText;
  VoidCallback? confirmPressEvent;
  VoidCallback? cancelPressEvent;
  Widget? addView;

  Widget? confirmButton;
  Widget? cancelButton;
  Color? color;
  TextStyle? titleStyle;
  TextStyle? contentStyle;
  Style? style;
  Color? backgroundColor;
  final BorderRadius borderRadius;
  final double iconScale;
  @override
  State<StylishDialogUI> createState() => _StylishDialogState();
}

class _StylishDialogState extends State<StylishDialogUI>
    with TickerProviderStateMixin {
  final GlobalKey _key = GlobalKey<NavigatorState>();

  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _initializeAnimation();
  }

  @override
  void didUpdateWidget(covariant StylishDialogUI oldWidget) {
    super.didUpdateWidget(oldWidget);

    ///dispose the current active controller and
    /// create a new one for changeAlertType
    _controller.dispose();
    _initializeAnimation();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  _initializeAnimation() {
    _controller = AnimationController(
      duration: widget.alertType == StylishDialogType.SUCCESS
          ? const Duration(milliseconds: 600)
          : const Duration(milliseconds: 600),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.fastOutSlowIn,
    );
  }

  @override
  Widget build(BuildContext context) {
    //Default values of Confirm Button Text
    widget.confirmText ??= 'Confirm';
    //Default values of Cancel Button Text
    widget.cancelText ??= 'Cancel';

    return Dialog(
      key: (widget.key ?? _key),
      shape: RoundedRectangleBorder(
        borderRadius: widget.borderRadius,
      ),
      //elevation: 0,
      backgroundColor: widget.style == Style.Default
          ? (widget.backgroundColor ?? Colors.white)
          : Colors.black,
      child: widget.style == Style.Default
          ? _stylishContentBox()
          : _stylishContentBoxStyle1(),
    );
  }

  _stylishContentBox() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _stylishDialogChange(),
        if (widget.titleText != null) _titleTextWidget(widget.titleText),
        if (widget.contentText != null) _contentTextWidget(widget.contentText),
        if (widget.addView != null)
          Container(
              padding:
                  const EdgeInsets.only(left: 10, top: 8, bottom: 4, right: 10),
              child: widget.addView),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            ///Cancel
            if (widget.cancelButton != null)
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: widget.cancelButton!,
              )
            else if (widget.cancelPressEvent != null)
              _pressButtonWidget(
                  widget.cancelPressEvent, Colors.red, widget.cancelText),

            ///Confirm
            if (widget.confirmButton != null)
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: widget.confirmButton!,
              )
            else if (widget.confirmPressEvent != null)
              _pressButtonWidget(
                  widget.confirmPressEvent, Colors.teal, widget.confirmText),
          ],
        ),
      ],
    );
  }

  //Text widget for title text
  _titleTextWidget(text) {
    return Padding(
      padding: const EdgeInsets.only(top: 12.0, left: 8, right: 8, bottom: 8),
      child: Text(
        '$text',
        textAlign: TextAlign.center,
        style: widget.titleStyle,
      ),
    );
  }

  //Text widget for content text
  _contentTextWidget(text) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, right: 8, bottom: 10),
      child: Text(
        '$text',
        textAlign: TextAlign.center,
        style: widget.contentStyle,
      ),
    );
  }

  //Button widget for confirm and cancel buttons
  _pressButtonWidget(pressEvent, color, text) {
    return Flexible(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: TextButton(
          onPressed: () async {
            pressEvent();
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(color),
          ),
          child: Padding(
            padding:
                const EdgeInsets.only(left: 8.0, right: 4.0, top: 4, bottom: 4),
            child: Text(
              '$text',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
        ),
      ),
    );
  }

  _playAnimation() {
    if (widget.animationLoop!) {
      _controller.repeat();
    } else {
      _controller.forward();
    }
  }

  _stylishDialogChange() {
    Widget child = _stylishDialogChange0();
    if (widget.alertType != StylishDialogType.NORMAL){
      if (widget.iconScale != 1)
        child = Transform.scale(
            scale: widget.iconScale,
            child: child
        );

      child = widget.iconScale == 1
            ? Padding(
              padding:  const EdgeInsets.fromLTRB(8, 12, 8, 8),
              child: child
            )
            : Padding(
                padding: EdgeInsets.only(
                    top: 12.0 * widget.iconScale,
                    left: 8 * widget.iconScale,
                    right: 8 * widget.iconScale,
                    bottom: 8 * widget.iconScale
                ),
                child: child
            );

    }
    return child;
  }

  _stylishDialogChange0() {
    switch (widget.alertType) {
      case StylishDialogType.PROGRESS:
        return CircularProgressIndicator(
          color: widget.color,
        );
      case StylishDialogType.SUCCESS:
        _playAnimation();
        return Container(
          alignment: Alignment.center,
          width: _sizeK,
          height: _sizeK,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(44),
            // color: Colors.white,
            border: Border.all(
              color: Colors.green,
              width: 2,
            ),
          ),
          padding: const EdgeInsets.all(4.0),
          child: SizeTransition(
            sizeFactor: _animation,
            axis: Axis.horizontal,
            axisAlignment: -1,
            child: const Icon(
              Icons.check,
              color: Colors.green,
              size: 38.0,
            ),
          ),
        );
      case StylishDialogType.INFO:
        _playAnimation();
        return ScaleTransition(
            scale: _animation,
            child: const Icon(
              Icons.info_outlined,
              color: Colors.blue,
              size: 44,
            ));
      case StylishDialogType.WARNING:
        _playAnimation();
        return ScaleTransition(
            scale: _animation,
            child: const Icon(
              Icons.info_outlined,
              color: Colors.amber,
              size: 44,
            ));
      case StylishDialogType.ERROR:
        _playAnimation();
        return Container(
          alignment: Alignment.center,
          width: _sizeK,
          height: _sizeK,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(44),
            // color: Colors.white,
            border: Border.all(
              color: Colors.red,
              width: 2,
            ),
          ),
          padding: const EdgeInsets.all(4.0),
          child: ScaleTransition(
              scale: _animation,
              child: const Icon(
                Icons.clear,
                color: Colors.red,
                size: 40,
              )),
        );

      default:
        return const SizedBox();
    }
  }

  Widget _stylishContentBoxStyle1() {
    return Transform.rotate(
      angle: -0.07,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: widget.borderRadius,
          color: widget.backgroundColor ?? Colors.white,
        ),
        padding: const EdgeInsets.all(1),
        child: Transform.rotate(
          angle: 0.07,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 12,
              ),
              if (widget.titleText != null) _titleTextWidget(widget.titleText),
              if (widget.contentText != null)
                _contentTextWidget(widget.contentText),
              if (widget.addView != null)
                Container(
                    padding: const EdgeInsets.only(
                        left: 10, top: 8, bottom: 4, right: 10),
                    child: widget.addView),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  ///Confirm
                  if (widget.confirmButton != null)
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: widget.confirmButton!,
                    )
                  else if (widget.confirmPressEvent != null)
                    _pressButtonWidgetStyle1(widget.confirmPressEvent,
                        Colors.black, widget.confirmText),

                  ///Cancel
                  if (widget.cancelButton != null)
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: widget.cancelButton!,
                    )
                  else if (widget.cancelPressEvent != null)
                    _pressButtonWidgetStyle1(widget.cancelPressEvent,
                        Colors.transparent, widget.cancelText,
                        textColor: Colors.black),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _pressButtonWidgetStyle1(pressEvent, color, text, {textColor}) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: GestureDetector(
        onTap: () async {
          pressEvent();
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: color,
          ),
          padding: const EdgeInsets.all(12),
          child: Text(
            '$text',
            textAlign: TextAlign.center,
            style: TextStyle(color: textColor ?? Colors.white, fontSize: 16),
          ),
        ),
      ),
    );
  }
}
