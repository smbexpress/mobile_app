// @dart=2.12
import 'package:flutter/material.dart';
import '../stylish_dialog.dart';

class DialogController extends ChangeNotifier {
  DialogController({
    this.listener,
  });

  Function(DialogStatus status)? listener;

  // setValue(DialogStatus status) {
  //   if (listener != null) listener!(status);
  //   notifyListeners();
  // }

  @override
  void dispose() {
    listener = null;
    super.dispose();
  }
}
