import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:smbex_app/src/models/shipment.dart';
import 'package:smbex_app/src/theme/extention.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/icon_text.dart';

import '../../i18n/i18n.dart';
import '../custom_color_scheme.dart';
import '../helpers/navigation.dart';
import '../models/address.dart';
import '../screens/tracking/tracking.dart';

Widget renderShipmentAddress(BuildContext context, TinyShipment order, {
  double horizontal: 10, double vertical: 15, ThemeData theme, withHeader:true}){
  return renderShipmentAddressAll(context, order.orderDate, order.status,
      order.from, order.to,
      horizontal:horizontal, vertical:vertical, theme:theme, withHeader:withHeader,
      trackingCode: order.name, key: order.id?.toString(), maxLines: 2, showStreet: false);
}

Widget renderShipmentAddressAll(BuildContext context, String orderDate, Status status,
    Address from, Address to, {double horizontal: 10, double vertical: 15, ThemeData theme,
      withHeader:true, String trackingCode, Object key, int maxLines=3, bool useContainer=false,
      bool showStreet = true, ValueChanged<Address> onSelect}){
  if (!context.mounted)
    return const SizedBox.shrink();
  theme = theme ?? Theme.of(context);
  final child = Column(
    children: <Widget>[

      if(withHeader) Container(
        padding: EdgeInsets.symmetric(horizontal: horizontal, vertical: vertical),
        child: Row(
          //mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            IconText(
              text: "#${trackingCode??key}",
              iconData: "${trackingCode??key}".length > 2
                ? Icons.copy
                : null,
              copyToClipboard: "${trackingCode??key}".length > 2,
            ),
            Spacer(),
            Chip(
                label: Text(status?.name?.toUpperCase()??'',
                  style: TextStyle(
                      color: status?.getColor(context)?.darken(25),
                      //fontWeight: FontWeight.w400,
                      fontSize: 10.0
                  ),
                ),
                side: BorderSide(color: status?.getColor(context)?.darken(10) ?? Colors.black26),
                backgroundColor: status?.getColor(context)?.withOpacity(.1),
                //padding: EdgeInsets.zero,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap
            ),
          ],
        ),
      ),
      if(withHeader) const Divider(height: 1,),
      Container(
        //constraints: BoxConstraints(h: maxLines * 52.0),
        padding: EdgeInsets.only(top: withHeader ? 10 : 0, bottom: orderDate != null ? 10 : 0),
        child: IntrinsicHeight(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(Icons.my_location, color: theme.errorColor),
                      Flexible(
                        child: Container(
                          width: 1.0,
                          color: Theme.of(context).primaryColorDark,
                        ),
                      ),
                      Icon(Icons.location_on, color: theme.colorScheme.success)
                    ],
                  )
              ),
              Expanded(
                flex: 5,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            from.name??'',
                            overflow: TextOverflow.clip,
                            maxLines: 2,
                            style: TextStyles.body.w500.opacity(.7)
                        ),
                        if (showStreet && from.street != null && from.facilityId == null)
                          Text(
                            from.street,
                            overflow: TextOverflow.clip,
                            maxLines: 2,
                            style: TextStyles.bodySm,
                          ),
                        Text(
                            from?.formattedRegion,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: TextStyles.bodySm.w400
                        ),
                        const SizedBox(height: 10,)
                      ],
                    ).ripple(
                        onSelect != null
                            ?()=> onSelect(from)
                            : null
                    ),
                    const Divider(height: .5,),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10,),
                        Text(
                            to.name??'',
                            overflow: TextOverflow.clip,
                            maxLines: 2,
                            style: TextStyles.body.w500.opacity(.7)
                        ),
                        if (showStreet && to.street != null && to.facilityId == null)
                          Text(
                            to.street,
                            overflow: TextOverflow.clip,
                            maxLines: 2,
                            style: TextStyles.bodySm,
                          ),
                        Text(
                            to?.formattedRegion,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: TextStyles.bodySm.w400
                        ),
                      ],
                    ).ripple(
                        onSelect != null
                            ?()=> onSelect(to)
                            : null
                    ),

                  ],
                ),
              )
            ],
          ),
        )
      ),
      if(orderDate != null) Divider(height: 1,),
      if(orderDate != null)
        Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: horizontal, vertical: vertical),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.access_time),
                    SizedBox(width: 10,),
                    Text(orderDate??"",
                        textAlign: TextAlign.justify,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        )
                    ),
                  ],
                ),
                if (trackingCode != null && trackingCode.length > 2)
                  TextButton(
                    onPressed: (){
                      Navigation.navigateTo(
                          context: context,
                          screen: TrackingPage(trackingCode: trackingCode)
                      );
                    },
                    child: Text(
                      tr.track,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    style: TextButton.styleFrom(
                        //foregroundColor: Theme.of(context).colorScheme.success,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap
                    ),
                  )
              ],
            )

        ),
    ],
  );
  return useContainer ? Container(
    padding: EdgeInsets.symmetric(horizontal: horizontal, vertical: vertical),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15.0),
    ),
    child: child
  ) : child;
}


Widget textField(BuildContext context, {keyboardType: TextInputType.text,
                        onSaved, validator, controller, hintText, IconData icon, labelText,
                        prefixIcon, prefix, suffixIcon, suffix,
                        readOnly: false, maxLines: 1, decoration,
                        TextStyle style, onChanged,
                        obscureText: false, autofocus:false, onTap,
                        TextDirection textDirection,
                        FocusNode focusNode,
  String initialValue, String counterText, String helperText}){

  if (focusNode == null && controller != null) {
     focusNode = PageStorage.of(context)?.readState(
        context, identifier: controller);
    if (focusNode == null) {
      focusNode = FocusNode();
      PageStorage.of(context)?.writeState(
          context, focusNode, identifier: controller);
    }
  } else {
    print("No focus");
  }
  var result = new TextFormField(
      controller: controller,
      initialValue: initialValue,
      style: style??TextStyles.title.copyWith(color: Theme.of(context).textTheme.bodyText1.color),
      keyboardType: keyboardType,
      onSaved: onSaved,
      validator: validator,
      readOnly: readOnly,
      maxLines: maxLines,
      obscureText: obscureText,
      textAlignVertical: TextAlignVertical.center,
      autofocus: autofocus,
      onTap: onTap,
      onChanged: onChanged,
      textDirection: textDirection,
      focusNode: focusNode,
      decoration: decoration??InputDecoration(
          hintText:  hintText,
          //icon: icon != null ? Icon(icon) : null,
          labelText:labelText,
          prefixIcon:prefixIcon ?? (icon != null ? Icon(icon) : null),
          prefix:prefix,
          suffixIcon:suffixIcon,
          suffix:suffix,
          helperText: helperText,
          counterText: counterText
      ),
      
  );
  return result;
}

Widget cartWidget(BuildContext context, {
  double horizontal: 20.0,
  double vertical: 15.0,
  bool hasBorder: true,
  bool hasShadow: false,
  double borderRadius:12.0,
  double blurRadius: 10.0,
  Widget child}){

  return Container(
      margin: EdgeInsets.symmetric(horizontal: horizontal, vertical: vertical),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: borderRadius > 0 ? BorderRadius.circular(borderRadius) : null,
        border: hasBorder
          ? Border.all(color: Theme.of(context).dividerColor)
          : null,
        boxShadow: hasShadow ? [

          BoxShadow(
              color: Theme.of(context).hintColor.withOpacity(0.15),
              offset: Offset(0, 3),
              blurRadius: blurRadius
          )
        ] :null,
      ),
      child: child
  );

}
