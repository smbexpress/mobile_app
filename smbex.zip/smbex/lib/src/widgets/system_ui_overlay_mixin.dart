
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';

mixin SystemUiOverlayMixin implements PopRouteObserver {
  static SystemUiOverlayStyle _lastStyle;
  SystemUiOverlayStyle _style;
  PopRouteNotify _popRouteNotify;
  String _route;

  bool onPop(String routeName) {
    if (routeName == _route ){
      if (_style != null) {
        SystemChrome.restoreSystemUIOverlays();
        SystemChrome.setSystemUIOverlayStyle(_style);
        print("SystemUiOverlayMixin:: restore style PopBack: $routeName");
      } else {
        print("SystemUiOverlayMixin:: PopBack: $routeName");
      }

      onPopBack();

      return true;
    }
    return false;
  }

  BuildContext get context;

  @protected
  void onPopBack() {}

  //void setState(Function fn);

  void initSystemUiOverlay(SystemUiOverlayStyle overlayStyle, [bool update=false]){
    _style = overlayStyle;
    if (update && _lastStyle != _style){
      SystemChrome.setSystemUIOverlayStyle(overlayStyle);
    }
    if (overlayStyle != null) {
      _lastStyle = overlayStyle;
      AppState state = Provider.of<AppState>(context, listen: false);
      _popRouteNotify = state.popRouteNotify;
      _route = _popRouteNotify.currentRoute;
      _popRouteNotify.addObserver(this);
    }
  }

  @protected
  void leave(){
    _popRouteNotify?.removeObserver(this);
  }

}