import 'package:flutter/material.dart';


enum TransitionType{
  LEFT,
  RIGHT,
  TOP,
  BOTTOM,
  SCALE,
  SLIDE,
  OPACITY,
  SCALE_OPACITY,
}

Widget createTransitions(
{   BuildContext context,
    Animation animation,
    Widget child,
    TransitionType type = TransitionType.BOTTOM
}
){
  //animation ??= context.
  switch(type){
    case TransitionType.OPACITY:{
      return FadeTransition(
          opacity: Tween<double>(
            begin: 0.0,
            end: 1.0,
          ).animate(animation),
          child: child
      );
    }
    case TransitionType.LEFT:
      {
        Tween<Offset> offsetTween = Tween<Offset>(
            begin: Offset(1.0, 0.0), end: Offset(0.0, 0.0));
        final Animation<Offset> slideInFromTheRightAnimation = offsetTween.animate(animation);
        return SlideTransition(
            position: Tween<Offset>(
                begin: Offset(-1.0, 0.0), end: Offset(0.0, 0.0))
                .animate(animation),
            child: child
        );
      }
    case TransitionType.RIGHT:
      return new SlideTransition(
        position: new Tween<Offset>(
          begin: const Offset(1.0, 0.0),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      );
    case TransitionType.TOP:
      return SlideTransition(
        position: new Tween<Offset>(
          begin: const Offset(0.0, -1.0),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      );
    case TransitionType.SCALE:
      return ScaleTransition(
        scale: new Tween<double>(
          begin: 0.0,
          end: 1.0,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Interval(
              0.00,
              0.50,
              curve: Curves.linear,
            ),
          ),
        ),
        child: ScaleTransition(
          scale: Tween<double>(
            begin: 1.5,
            end: 1.0,
          ).animate(
            CurvedAnimation(
              parent: animation,
              curve: Interval(
                0.50,
                1.00,
                curve: Curves.linear,
              ),
            ),
          ),
          child: child,
        ),
      );
    case TransitionType.SLIDE:{
      Animation<Offset> custom= Tween<Offset>(
          begin:Offset(1.0,1.0),end: Offset(0.0,0.0)).animate(animation);
      return SlideTransition(
          position: custom,
          child: child);
    }
    case TransitionType.SCALE_OPACITY:
      {
        final feed = Tween<double>(
          begin: 0.0,
          end: 1.0,
        );

        return createTransitions(
            context: context,
            animation: animation,
            type: TransitionType.OPACITY,
            child: createTransitions(
              context: context,
              animation: animation,
              child: child,
              type: TransitionType.SCALE,
            )
        );
      }
    case TransitionType.BOTTOM:
    default:
      return SlideTransition(
        position: new Tween<Offset>(
          begin: Offset(0.0, 1.0),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      );
  }

}

class TransitionPageRoute extends PageRouteBuilder {
  final Widget widget;
  final TransitionType type;
  TransitionPageRoute({@required this.widget, this.type=TransitionType.BOTTOM})
      : super(
      pageBuilder: (BuildContext context, Animation animation, Animation secondaryAnimation) {
        return widget;
      },
      transitionsBuilder: (BuildContext context, Animation animation, Animation secondaryAnimation, Widget child) {
        return createTransitions(context:context, animation: animation, child: child, type: type);
      }
  );
}
