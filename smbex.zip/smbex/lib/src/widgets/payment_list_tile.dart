
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:smbex_app/src/models/payment.dart';

import '../theme/text_styles.dart';

class PaymentListTile extends StatelessWidget{

  final Payment payment;

  const PaymentListTile({Key key, this.payment}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    print("Payment: brand: ${payment.method}, name: ${payment.name}");
    final cardName = payment.name.length < 5 && int.tryParse(payment.name) == null
             ? '**** **** ${payment.name}'
             : payment.name?? '';
    return ListTile(
        trailing: Icon(Icons.check, size: 32,),
        title: Text(cardName, style: TextStyles.bodySm),
        leading: Container(
          height: double.infinity,
          //width: 60,
          child: payment.icon.startsWith('http')
              ? CachedNetworkImage(
                  imageUrl: payment.icon,
                  placeholder: (context, url) =>
                      const SizedBox.square(
                          dimension: 32,
                          child: ClipRect(
                            child: CircularProgressIndicator(),
                          )
                      ),
                  errorWidget: (context, url, error) => const Icon(Icons.credit_card),
                  width: 40,
                  height: 40,
                )
              : Image.asset(
                  payment.icon,
                  width: 40,
                  height: 40,
                ),
        ),

    );
  }


}