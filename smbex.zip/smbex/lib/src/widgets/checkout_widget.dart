import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/models/payment_method.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/PaymentMethodsSheetWidget.dart';
import '../../i18n/i18n.dart';
import '../helpers/helper.dart';
import '../models/cart.dart';
import '../screens/checkout/checkout_provider.dart';

class CheckoutWidget extends StatefulWidget {
  final int id;
  final String type;
  CheckoutWidget({Key key, this.id, this.type}) : super(key: key);

  @override
  _CheckoutWidgetState createState() => _CheckoutWidgetState();
}

class _CheckoutWidgetState extends State<CheckoutWidget> {

  @override
  void initState() {
    Cart cart = Cart();
    cart.type = widget.type;
    context.read<CheckoutProvider>().initCart(context, cart, widget.id);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    ThemeData theme = Theme.of(context);
    final checkoutProvider = Provider.of<CheckoutProvider>(context);
    final paymentMethod = checkoutProvider.cartPaymentMethod;
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          const SizedBox(height: 10,),
          Divider(height: 1,),
          Material(
            color: theme.cardColor,
            child: ListTile(
              leading: paymentMethod != null
                  ? paymentMethod.icon.startsWith('http')
                      ? CachedNetworkImage(
                          imageUrl: paymentMethod.icon,
                          placeholder: (context, url) =>
                              const SizedBox.square(
                                dimension: 32,
                                child: ClipRect(
                                  child: CircularProgressIndicator(),
                                )
                              ),
                          errorWidget: (context, url, error) => const Icon(Icons.credit_card),
                          width: 40,
                          height: 40,
                        )
                        :
                         Image.asset(
                           paymentMethod.icon,
                           width: 40,
                           height: 40,
                         )
                   : null,
              trailing: checkoutProvider.loading
                ? const SizedBox.square(
                    dimension: 32,
                    child: CircularProgressIndicator()
                )
                : Text(
                    tr.buttons.changePaymentMethod,
                    style: TextStyle(
                        color: theme.colorScheme.secondary,
                        decoration: TextDecoration.underline
                    )
                 ),
              title: paymentMethod != null
                  ? Text(paymentMethod.name??'', style: TextStyles.bodySm)
                  : Text(tr.payment_options,  style: TextStyles.bodySm),
              dense: true,
              onTap: checkoutProvider.loading
                  ? null
                  : () {
                    if (checkoutProvider.hasCart)
                      _showCardSheetWidget(context, checkoutProvider);
                  },
            ),
          ),
          Divider(height: 1.6,),
          if (checkoutProvider.error != null)
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                child: Text(
                  Helper.getError(checkoutProvider.error.message),
                  style: TextStyle(color: Theme.of(context).errorColor),
                  textAlign: TextAlign.start,
                )
            ),
          if (checkoutProvider.message != null)
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                child: Text(
                  checkoutProvider.message,
                  style: TextStyle(color: Theme.of(context).errorColor),
                  textAlign: TextAlign.start,
                )
            ),
          if (!checkoutProvider.loading && !checkoutProvider.hasCart)
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Text(
                  tr.empty_cart,
                  textAlign: TextAlign.start,
                )
            ),

        ],
    );
  }

  void _showCardSheetWidget(BuildContext gContext,
      CheckoutProvider provider) async {
    //MaterialLocalizations.of(context).okButtonLabel
    showModalBottomSheet(
      context: gContext,
      isDismissible: false,
      isScrollControlled: true,
      enableDrag: false,
      useSafeArea: false,
      builder: (context) {
        return SafeArea(
            child: LayoutBuilder(
                builder: (context, box) {
                  final mq = MediaQuery.of(gContext);
                  final top = max(mq.padding.top, 20.0);
                  final height = box.maxHeight - top;
                  return ConstrainedBox(
                    constraints: BoxConstraints(maxHeight:height),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        //Container(height: top, color: Colors.transparent,),
                        SizedBox(
                          height: 48.0,
                          child: Card(
                            margin: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  InkWell(
                                    child: Icon(Icons.close),
                                    onTap: () {
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                  SizedBox(
                                    width: 10,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                        ConstrainedBox(
                            constraints: BoxConstraints(maxHeight:height - 48.0),
                            child: PaymentMethodsSheetWidget(
                              height: height,
                              paymentType: widget.type,
                              data: {'id': widget.id},
                              onSelect: (PaymentMethodItem item) {
                                Navigator.of(context).pop();
                                provider.setPaymentMethod(item);
                                //setState(() {});
                              },
                            )
                        )
                      ],
                    ),
                  );
                }
            )
        );
      },
    );

  }



}
