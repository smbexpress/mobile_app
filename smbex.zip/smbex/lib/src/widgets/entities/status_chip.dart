// Flutter imports:
import 'package:flutter/material.dart';

import '../../../constants.dart';

class StatusChip extends StatelessWidget {
  const StatusChip({
    this.addGap = false,
    this.width = 105,
    this.showState = false,
    @required this.label,
    @required this.color
  });

  final bool addGap;
  final double width;
  final bool showState;
  final Color color;
  final String label;
  @override
  Widget build(BuildContext context) {


    return Padding(
      padding: addGap ? EdgeInsetsDirectional.only(start: 16) : EdgeInsets.zero,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.all(Radius.circular(kBorderRadius)),
        ),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minWidth: width ?? 100,
            maxWidth: width ?? 200,
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 6, horizontal: 4),
            child: Text(
              label,
              style: TextStyle(fontSize: 13, color: Colors.white),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ),
    );
  }
}
