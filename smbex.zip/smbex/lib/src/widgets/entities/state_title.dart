// Flutter imports:
import 'package:flutter/material.dart';

class StateTitle extends StatelessWidget {
  const StateTitle({@required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {

    return Text(
      title,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }
}
