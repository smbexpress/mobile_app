// Flutter imports:
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';


import '../../app_actions.dart';
import '../../models/address.dart';
import '../actions_menu_button.dart';
import '../list_divider.dart';
import '../selected_indicator.dart';

class EntityListTile extends StatefulWidget {
  const EntityListTile({
    @required this.entity,
    @required this.isFilter,
    this.onEntityActionSelected,
    this.subtitle,
    this.client,
  });

  final String subtitle;
  final Entity entity;
  final bool isFilter;
  final Address client;
  final Function(BuildContext, Entity, EntityAction) onEntityActionSelected;

  @override
  _EntityListTileState createState() => _EntityListTileState();
}

class _EntityListTileState extends State<EntityListTile> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    if (widget.entity == null || widget.entity.isNew) {
      return SizedBox();
    }

    final isFilteredBy = false;

    final entityClient = widget.client ;
    final isHovered =
        (!RendererBinding.instance.mouseTracker.mouseIsConnected &&
                isFilteredBy) ||
            _isHovered;

    final leading = ActionMenuButton(
      iconData:
          isHovered ? Icons.more_vert : getEntityIcon(widget.entity.name),
      iconSize: isHovered ? null : 18,
      entityActions: getEntityActions(widget.entity, context),
      isSaving: false,
      entity: widget.entity,
      onSelected: (context, action) => widget.onEntityActionSelected != null
          ? widget.onEntityActionSelected(context, widget.entity, action)
          : handleEntityAction(widget.entity, action),
    );

    // we may have the id (so it's not considered new) but it hasn't yet been
    // created in the backend. ie, the invoice after converting a quote
    final trailing = widget.entity.isNew
        ? null
        : IgnorePointer(
            ignoring: !isHovered || widget.isFilter,
            child: IconButton(
              icon: Icon(Icons.chevron_right),
              onPressed: () => handleEntity(widget.entity),
            ),
          );

    return MouseRegion(
      onEnter: (event) => setState(() => _isHovered = true),
      onExit: (event) => setState(() => _isHovered = false),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          SelectedIndicator(
            isSelected: isFilteredBy,
            isMenu: true,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              onTap: () {
                inspectEntity(entity: widget.entity);
              },
              onLongPress: () =>
                  inspectEntity(entity: widget.entity, longPress: true),
              title: Text(
                getEntityTitle(widget.entity, context),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle:
                  (widget.subtitle ?? '').isEmpty
                      ? null
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if ((widget.subtitle ?? '').isNotEmpty)
                              Text(widget.subtitle),
                          ],
                        ),
              leading: leading,
              trailing: trailing,
              isThreeLine:
                  (widget.subtitle ?? '').isNotEmpty ,
            ),
          ),
          ListDivider(),
        ],
      ),
    );
  }
}

class EntitiesListTile extends StatefulWidget {
  const EntitiesListTile({
    @required this.isFilter,
    @required this.entity,
    this.title,
    this.subtitle,
    this.hideNew = false,
    this.canCreate
  });

  final Entity entity;
  final String title;
  final String subtitle;
  final bool isFilter;
  final bool hideNew;
  final bool canCreate;

  @override
  _EntitiesListTileState createState() => _EntitiesListTileState();
}

class _EntitiesListTileState extends State<EntitiesListTile> {
  bool _isHovered = false;

  void _onTap(BuildContext context) => handleEntity(widget.entity);

  void _onLongPress() {
    handleEntity(widget.entity, longPress: true);
  }

  @override
  Widget build(BuildContext context) {

    final isFilterMatch = false;

    return MouseRegion(
      onEnter: (event) => setState(() => _isHovered = true),
      onExit: (event) => setState(() => _isHovered = false),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          SelectedIndicator(
            isSelected: isFilterMatch,
            isMenu: true,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              title: Text(widget.title),
              subtitle: Text(widget.subtitle ?? ''),
              leading: _isHovered &&
                      !widget.hideNew &&
                      widget.canCreate
                  ? IconButton(
                      icon: Icon(Icons.add_circle_outline),
                      onPressed: _onLongPress,
                    )
                  : IgnorePointer(
                      child: IconButton(
                        icon:
                            Icon(getEntityIcon(widget.entity.name), size: 18.0),
                        onPressed: () => _onTap(context),
                      ),
                    ),
              trailing: IgnorePointer(
                child: IconButton(
                  icon: Icon(Icons.chevron_right),
                  onPressed: () => null,
                ),
              ),
              onTap: () => _onTap(context),
              onLongPress: _onLongPress,
            ),
          ),
          ListDivider(),
        ],
      ),
    );
  }
}
