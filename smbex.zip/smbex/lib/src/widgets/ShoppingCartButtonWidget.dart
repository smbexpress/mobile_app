import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/controllers/cart_controller.dart';

import '../../src/repository/account_repository.dart';

class ShoppingCartButtonWidget extends StatefulWidget
{
  const ShoppingCartButtonWidget ({
    this.iconColor,
    this.labelColor,
    Key key,
  }) : super(key: key);

  final Color iconColor;
  final Color labelColor;
  final bool show=false;
  @override
  _ShoppingCartButtonWidget createState () => _ShoppingCartButtonWidget();

}

  class _ShoppingCartButtonWidget extends StateMVC<ShoppingCartButtonWidget>{

    CartController _con;

  _ShoppingCartButtonWidget() : super(CartController()) {
  _con = controller;
  }

  @override
  void initState() {
  //_con.listenForCartsCount();
  super.initState();
  }
    @override
    Widget build(BuildContext context) {
      if(!widget.show){
        return SizedBox(height: 0,);
      }


      return TextButton(
        onPressed: () {
          if (currentAccount.value.valid && currentCart.value?.items?.length != null) {
            Navigator.of(context).pushNamed('/Cart');
          } else {
            Navigator.of(context).pushNamed('/Login');
          }
        },
        child: Stack(
          alignment: AlignmentDirectional.topEnd,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Icon(
                Icons.notifications,
                color: widget.iconColor,
                size: 28,
              ),
            ),
            Container(
              child: Text(
                "${currentCart.value?.items?.length}",
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.caption.merge(
                      TextStyle(color: Theme.of(context).primaryColor, fontSize: 9),
                    ),
              ),
              padding: EdgeInsets.all(0),
              decoration: BoxDecoration(color: widget.labelColor, borderRadius: BorderRadius.all(Radius.circular(10))),
              constraints: BoxConstraints(minWidth: 15, maxWidth: 15, minHeight: 15, maxHeight: 15),
            ),
          ],
        )
      );
    }
  }


