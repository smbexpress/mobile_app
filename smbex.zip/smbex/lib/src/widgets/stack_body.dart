import 'dart:math';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../helpers/measure_util.dart';
import '../helpers/size_change_notifier.dart';

const _constBoxConstraints = const BoxConstraints();

class StackBodyWidget extends StatefulWidget {
  final Widget header;
  final Widget body;
  final Widget footer;
  final BoxConstraints headerConstraints;
  final BoxConstraints footerConstraints;
  const StackBodyWidget(
      {Key key,
      this.body,
      this.header,
      this.headerConstraints = _constBoxConstraints,
      this.footer,
      this.footerConstraints = _constBoxConstraints})
      : super(key: key);

  @override
  State<StatefulWidget> createState() => _StackBodyWidgetState();
}

class _StackBodyWidgetState extends State<StackBodyWidget> {
  double headerHeight = 0.0;
  double footerHeight = 0.0;
  bool _disableChange = false;
  ValueNotifier<double> _sizeValue = ValueNotifier<double>(0);
  void initState() {
    super.initState();
    _calculateSizes();
  }

  void didUpdateWidget(covariant StackBodyWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    _disableChange = false;
    _calculateSizes();
  }

  void _calculateSizes() {
    headerHeight = footerHeight = 0.0;
    if (widget.header != null) {
      headerHeight = min(
              widget.headerConstraints.maxHeight ?? 1000,
              MeasureUtil.measureWidget(
                      IntrinsicHeight(
                        child: widget.header,
                      ),
                      widget.headerConstraints)
                  .height) +
          2;
    }
    if (widget.footer != null)
      footerHeight =
          MeasureUtil.measureWidget(widget.footer, widget.footerConstraints)
                  .height +
              2;

    _disableChange = true;
    _sizeValue.value = headerHeight + footerHeight;
    //setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    //print("headerHeight: $headerHeight");
    return ValueListenableBuilder(
        valueListenable: _sizeValue,
        builder: (context, totalSize, child) => Stack(
              fit: StackFit.expand,
              children: [
                if (widget.header != null)
                  SizedBox(
                    height: headerHeight,
                    child: NotificationListener<LayoutSizeChangeNotification>(
                      child: widget.header,
                      onNotification:
                          (LayoutSizeChangeNotification notification) {
                        final oldHeight = headerHeight;
                        headerHeight = min(notification.newSize.height + 2,
                            widget.headerConstraints.minHeight ?? 1000);
                        _sizeValue.value = headerHeight + footerHeight;
                        //print("**headerHeight: $headerHeight");
                        return true;
                      },
                    ),
                  ),
                Positioned(
                    top: headerHeight,
                    bottom: footerHeight + mq.padding.bottom,
                    left: 0.0,
                    right: 0.0,
                    child: widget.body),
                if (widget.footer != null)
                  Positioned(
                    bottom: mq.padding.bottom,
                    left: 0.0,
                    right: 0.0,
                    child: SizedBox(
                      height: footerHeight,
                      child: NotificationListener<LayoutSizeChangeNotification>(
                        child: widget.footer,
                        onNotification:
                            (LayoutSizeChangeNotification notification) {
                          final oldHeight = footerHeight;
                          footerHeight = notification.newSize.height + 2;
                          _sizeValue.value = headerHeight + footerHeight;
                          return true;
                        },
                      ),
                    ),
                  )
              ],
            ));
  }
}

class StackBodyMinWidget extends StatelessWidget {
  final Widget header;
  final Widget body;
  final Widget footer;
  final BoxConstraints headerConstraints;
  final BoxConstraints footerConstraints;

  const StackBodyMinWidget(
      {Key key,
      this.body,
      this.header,
      this.headerConstraints = _constBoxConstraints,
      this.footer,
      this.footerConstraints = _constBoxConstraints})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, boxConstraints) {
      final headerHeight = header != null
          ? MeasureUtil.measureWidget(
                  IntrinsicHeight(
                    child: header,
                  ),
                  headerConstraints)
              .height
          : 0;
      final footerHeight = header != null
          ? MeasureUtil.measureWidget(
                  IntrinsicHeight(
                    child: footer,
                  ),
                  footerConstraints)
              .height
          : 0;
      return Stack(
        fit: StackFit.expand,
        children: [
          if (header != null)
            SizedBox(
              height: headerHeight,
              child: header,
            ),
          Positioned(
              top: headerHeight,
              bottom: footerHeight,
              left: 0.0,
              right: 0.0,
              child: body),
          if (footer != null)
            Positioned(
                bottom: 0.0,
                left: 0.0,
                right: 0.0,
                child: SizedBox(height: footerHeight, child: footer))
        ],
      );
    });
  }
}
