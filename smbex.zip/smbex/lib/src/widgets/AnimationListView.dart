import 'package:flutter/material.dart';

//import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

import 'FadeAnimation.dart';

class AnimationListView extends StatelessWidget {
  @required final Widget child;
  AnimationListView({Key key, this.child}): super(key: key);

  @override
  Widget build(BuildContext context) {

    return FadeAnimation(.3, child, 50.0);
    /*
    return AnimationConfiguration.staggeredList(
      position: widget.index,
      duration: const Duration(milliseconds: 500),
      child: SlideAnimation(
        verticalOffset: 50.0,
        child: FadeInAnimation(
          child: widget.child
        ),
      )
    );

     */
  }
}
