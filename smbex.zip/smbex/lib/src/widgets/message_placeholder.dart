// @dart=2.12
import 'package:flutter/material.dart';
import 'package:smbex_app/src/models/model.dart';

import '../../i18n/i18n.dart';

class MessagePlaceholder extends StatelessWidget {
  MessagePlaceholder({
    this.title = 'Nothing Here',
    this.message = 'Add a new item to get started.',
    this.icon = Icons.sentiment_dissatisfied,
    this.iconColor,
    this.background,
    this.messageStyle,
    this.onRetry
  });

  factory MessagePlaceholder.error({
    String? title,
    String? message,
    ErrorResult? error,
    IconData? icon,
    Color? iconColor,
    Color? background,
    TextStyle? messageStyle,
    VoidCallback? onRetry
  }) => MessagePlaceholder(
      title: title ?? tr.oops,
      message: message ?? (error?.isNetwork == true
          ? tr.verify_your_internet_connection
          : tr.errorMessages.somethingWrong),
      icon: icon ?? Icons.error,
      iconColor: iconColor ?? Colors.red,
      background: background,
      onRetry: onRetry,
      messageStyle: messageStyle ?? const TextStyle(
          fontSize: 15.0,
          fontWeight: FontWeight.normal,
          color: Colors.red)
  );

  factory MessagePlaceholder.empty({
    String? title,
    String? message,
    IconData? icon,
    Color? iconColor,
    Color? background,
    TextStyle? messageStyle
  }) => MessagePlaceholder(
      title: title,
      message: (message ??(title == null ? tr.no_data_found : '')),
      icon: icon ?? Icons.folder_open,
      iconColor: iconColor ?? Colors.blueAccent,
      background: background,
      messageStyle: messageStyle ?? const TextStyle(
          fontSize: 15.0,
          fontWeight: FontWeight.normal,
          color: Colors.red)
  );

  final String? title;
  final String message;
  final IconData icon;
  final Color? iconColor;
  final Color? background;
  final TextStyle? messageStyle;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
            width: background != null ? 160 : 100,
            height: background != null ? 160: 100,
            child: Icon(
              this.icon,
              size: 100.0,
              color: iconColor,
            ),
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: background
            )
        ),
        SizedBox(
          height: 20.0,
        ),
        Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if(title != null)
              Text(
                title!,
                style: const TextStyle(
                  fontSize: 20.0, fontWeight: FontWeight.w700,
//                  color: textColor
                ),
              ),
            const SizedBox(
              height: 5.0,
            ),
            Text(
              message,
              style: messageStyle ?? const TextStyle(
                fontSize: 15.0,
                fontWeight: FontWeight.normal,
              ),
            ),
            if (onRetry != null)
              const SizedBox(
                height: 10.0,
              ),
            if (onRetry != null)
              OutlinedButton(
                  onPressed: onRetry,
                  child: Text(tr.retry)
              )
          ],
        )
      ],
    );
  }
}