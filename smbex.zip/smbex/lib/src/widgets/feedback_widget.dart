import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../i18n/i18n.dart';
import 'SmbWidget.dart';


class FeedbackResult {
  final String subject;
  final String body;
  final double rate;

  FeedbackResult(this.subject, this.body, this.rate);
}

class FeedbackInfo {
  final bool hasRate ;
  final bool hasSubject;
  final String sheetTitle;
  final String bodyHelp;
  final String submitTitle;
  final Function(BuildContext context, FeedbackResult result) callback;

  FeedbackInfo(
      {this.hasRate = false,
      this.hasSubject = false,
      this.sheetTitle,
      this.bodyHelp,
      this.submitTitle,
      this.callback});

}

class FeedbackWidget extends StatefulWidget {
  final FeedbackInfo feedback;
  const FeedbackWidget({Key key, @required this.feedback}) : super(key: key);

  @override
  _FeedbackWidgetState createState() => _FeedbackWidgetState();
}

class _FeedbackWidgetState extends State<FeedbackWidget> {
  bool isValid = false;
  double ratingBarValue = 0;
  TextEditingController textController1;
  TextEditingController textController2;

  @override
  void initState() {
    super.initState();
    textController1 = TextEditingController();
    textController2 = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          return GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom + 20),
              child: SingleChildScrollView(
                child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraints.maxHeight),
                    child: IntrinsicHeight(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(20, 24, 20, 0),
                              child: Text(
                                widget.feedback.bodyHelp,
                                textAlign: TextAlign.center,
                                style: Theme.of(context).textTheme.bodyLarge,
                              ),
                            ),
                          ),
                          if (widget.feedback.hasRate == true)
                            Padding(
                              padding: EdgeInsets.fromLTRB(0, 12, 0, 0),
                              child: RatingBar.builder(
                                onRatingUpdate: (newValue) {
                                  ratingBarValue = newValue;
                                  _checkIfValid();
                                },
                                itemCount: 5,
                                itemBuilder: (context, index) {
                                  return Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  );
                                },
                                direction: Axis.horizontal,
                                initialRating: ratingBarValue ??= 0,
                              ),
                            ),
                          if (widget.feedback.hasSubject == true)
                            Padding(
                              padding: EdgeInsets.fromLTRB(20, 20, 20, 12),
                              child: TextFormField(
                                controller: textController1,
                                obscureText: false,
                                decoration: createUnderLineDecoration(
                                  context,
                                  labelText: tr.subject,
                                  filled: false,
                                  contentPadding:
                                      EdgeInsetsDirectional.fromSTEB(
                                          20, 20, 0, 20),
                                ),
                                onChanged: (value) {
                                  _checkIfValid();
                                },
                              ),
                            ),
                          Padding(
                            padding: EdgeInsets.fromLTRB(20, 0, 20, 40),
                            child: TextFormField(
                              controller: textController2,
                              obscureText: false,
                              decoration: createUnderLineDecoration(
                                context,
                                labelText: tr.detail,
                                filled: true,
                                contentPadding: EdgeInsetsDirectional.fromSTEB(
                                    20, 20, 0, 20),
                              ),
                              maxLines: 3,
                              onChanged: (value) {
                                _checkIfValid();
                              },
                            ),
                          ),
                        ],
                      ),
                    )),
              ),
            ),
          );
        }),
        Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 40.0,
              child: ElevatedButton(
                onPressed: isValid
                    ? () async {
                        widget.feedback.callback?.
                          call(context, FeedbackResult(
                            textController1.text,
                            textController2.text,
                            ratingBarValue)
                        );
                      }
                    : null,
                child: Text(widget.feedback.submitTitle ?? tr.submit),
                style: TextButton.styleFrom(
                    //elevation: 2,
                    //primary: Theme.of(context).cardColor,
                    //onSurface: Colors.redAccent,
                    //backgroundColor: Theme.of(context).primaryColorDark,
                    shape: RoundedRectangleBorder()),
              ),
            ))
      ],
    );
  }

  void _checkIfValid() {
    FeedbackInfo info = widget.feedback;
    bool valid = true;
    if (info.hasSubject == true && textController1.text.isEmpty) {
      valid = false;
    } else if (info.hasRate == true && ratingBarValue == 0.0) {
      valid = false;
    } else if (textController2.text.isEmpty) {
      valid = false;
    }

    if (isValid != valid) {
      setState(() {
        isValid = valid;
      });
    }
  }
}

void showFeedbackBottomSheet(
    BuildContext context, FeedbackInfo feedback) async {
  final parentContext = context;
  showModalBottomSheet(
      context: context,
      isDismissible: true,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * .7,
          child: Stack(
            children: [
              Positioned(
                  top: 50,
                  //bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: MediaQuery.of(context).size.height * .7 - 50,
                    child: FeedbackWidget(
                      feedback: feedback,
                    ),
                  )),
              Container(
                  child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          feedback.sheetTitle ?? '',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                            icon: Icon(Icons.close),
                            onPressed: () => Navigator.of(context).pop()),
                      ],
                    ),
                  ),
                  Divider(
                    height: 2,
                    thickness: .7,
                  ),
                ],
              )),
            ],
          ),
        );
      });
}
