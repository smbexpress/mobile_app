import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart' hide Slider;

import '../models/slider.dart';
import '../theme/light_color.dart';

class CarouselWidget extends StatefulWidget {
  final Slider slider;
  const CarouselWidget({Key key, @required this.slider}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CarouselWidgetState();
}

class _CarouselWidgetState extends State<CarouselWidget> {
  PageController controller;
  int currentPage = 0;
  Timer timer;

  @override
  void initState() {
    super.initState();


    //didChangeDependencies
  }
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    timer?.cancel();
    controller?.dispose();
    controller = PageController(initialPage: 0);
    if (widget.slider.interval != null) {
      timer = Timer.periodic(
          Duration(
            seconds: widget.slider.interval,
          ), (Timer timer) {
        if (currentPage < widget.slider.slides.length - 1) {
          currentPage++;
        } else {
          currentPage = 0;
        }

        if (mounted && controller.hasClients) {
          print("CarouselWidget::animate");
          try {
            controller.animateToPage(currentPage,
                duration: const Duration(seconds: 1),
                curve: Curves.easeInCubic);
          } catch (e) {
            timer.cancel();
          }
        }
      });
    } else {
      timer = null;
    }
  }
  void dispose(){
    super.dispose();
    timer?.cancel();
    controller?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final slids = widget.slider.slides;
    return Stack(
        children: [
          Container(
            //margin: EdgeInsets.only(top: 10),
              height: widget.slider.height ?? 180.0,
              width: double.infinity,

              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.slider.radius ?? 20.0),
                boxShadow: [
                  BoxShadow(
                    offset: Offset(0, 10),
                    blurRadius: 30,
                    color: LightColor.shadow,
                  ),
                ],
              ),
              child: Material(
                clipBehavior: Clip.hardEdge,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(widget.slider.radius ?? 20.0)
                ),
                child: PageView.builder(
                  scrollDirection: Axis.horizontal,
                  padEnds: false,
                  onPageChanged: (int index) {
                    setState(() {
                      currentPage = index;
                    });
                  },
                  controller: controller,
                  physics: const BouncingScrollPhysics(),
                  itemCount: widget.slider.slides.length,
                  itemBuilder: (context, index) =>
                      InkWell(
                        onTap: (){

                        },
                        child: Container(
                            constraints: BoxConstraints.expand(),
                            decoration: BoxDecoration(
                              //borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: slids[index].imageUrl.startsWith("http")
                                      ? CachedNetworkImageProvider(
                                          slids[index].imageUrl,
                                        //fit: BoxFit.cover,
                                        //width: box.maxWidth + 6,
                                        //height: box.maxHeight + 6,
                                      )
                                      : AssetImage(
                                          slids[index].imageUrl,
                                      ),
                                  fit: BoxFit.cover,
                                )
                            )
                        ),
                      )

                )
              )
          ),
          Positioned(
              left: 0,
              right: 0,
              bottom: 12.0,
              child: Center(
                child: IntrinsicWidth(
                  child: Container(
                      padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 12.0),
                      //constraints: BoxConstraints.tightFor(width: 0),
                      decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.3),
                          borderRadius: BorderRadius.circular(16.0)
                      ),
                      child: CarouselIndicator(
                        count: slids.length,
                        index: currentPage,
                        height: 12.0,
                        width: 12.0,
                        activeColor: Theme.of(context).primaryColorDark,
                        color: Theme.of(context).cardColor,
                      )
                  ),
                ),
              )
          )
          //const SizedBox(height: 10.0,),

        ]);
  }
}

class CarouselIndicator extends StatefulWidget {
  /// width of the indicator
  final double width;

  /// height of the indicator
  final double height;

  /// space between indicators.
  final double space;

  /// count of indicator
  final int count;

  /// active color
  final Color activeColor;

  /// normal color
  final Color color;

  /// use this to give some radius to the corner indicator
  final double cornerRadius;

  /// duration for slide animation
  final int animationDuration;

  final int index;

  CarouselIndicator({
    Key key,
    this.width: 20.0,
    this.height: 6,
    this.space: 5.0,
    this.count,
    this.cornerRadius: 6,
    this.animationDuration: 300,
    this.color: Colors.black38,
    this.index,
    this.activeColor: Colors.black,
  })  : assert(count != null && count != 0),
        assert(index != null && index >= 0),
        super(key: key);

  @override
  State<StatefulWidget> createState() {
    return new _CarouselIndicatorState();
  }
}

class _CarouselIndicatorState extends State<CarouselIndicator>
    with TickerProviderStateMixin {
  /// [Tween] object of type double
  Tween<double> _tween;

  /// [AnimationController] object
  AnimationController _animationController;

  /// [Aniamtion] object
  Animation _animation;

  /// [Paint] object to paint our indicator
  Paint _paint = new Paint();

  /// Method to initilize [BasePainter] to paint indicators.
  BasePainter _createPainer() {
    return SlidePainter(widget, _animation.value, _paint);
  }

  @override
  Widget build(BuildContext context) {
    Widget child = new SizedBox(
      width: widget.count * widget.width + (widget.count - 1) * widget.space,
      height: widget.height,
      child: CustomPaint(
        painter: _createPainer(),
      ),
    );

    return new IgnorePointer(
      child: child,
    );
  }

  @override
  void initState() {
    /// for initial index=0 we do not want to change any value so setting [_tween] to (0.0,0.0),
    createAnimation(0.0, 0.0);
    super.initState();
  }

  @override
  void didUpdateWidget(CarouselIndicator oldWidget) {
    if (widget.index != oldWidget.index) {
      if (widget.index != 0) {
        _animationController.reset();

        /// for each new index we want to change value so setting [_tween] to (oldWidget.index,widget.index) so animation tween from old position to new position rather not start from 0.0 again and again.
        createAnimation(oldWidget.index.toDouble(), widget.index.toDouble());
        _animationController.forward();
      } else {
        _animationController.reset();
        createAnimation(oldWidget.index.toDouble(), 0.0);
        _animationController.forward();
      }
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void createAnimation(double begin, double end) {
    _tween = Tween(begin: begin, end: end);
    _animationController = AnimationController(
        vsync: this,
        duration: Duration(milliseconds: widget.animationDuration));
    _animation = _tween.animate(_animationController)
      ..addListener(() {
        setState(() {});
      });
  }
}

/// Base Painter class to draw indicator
abstract class BasePainter extends CustomPainter {
  final CarouselIndicator widget;
  final double page;
  final Paint _paint;

  BasePainter(this.widget, this.page, this._paint);

  /// This method will get body to class extending [BasePainter] and this method will draw the sliding indicator which slide over changing index.
  void draw(Canvas canvas, double space, double width, double height,
      double radius, double cornerRadius);

  @override
  void paint(Canvas canvas, Size size) {
    _paint.color = widget.color;
    double space = widget.space;
    double width = widget.width;
    double height = widget.height;
    double distance = width + space;
    double radius = width / 2;
    for (int i = 0, c = widget.count; i < c; ++i) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromCenter(
                  center: Offset((i * distance) + radius, radius),
                  width: width,
                  height: height),
              Radius.circular(widget.cornerRadius)),
          _paint);
    }

    _paint.color = widget.activeColor;
    draw(canvas, space, width, height, radius, widget.cornerRadius);
  }

  @override
  bool shouldRepaint(BasePainter oldDelegate) {
    return oldDelegate.page != page;
  }
}

/// This class we draw the indicator which slides.
class SlidePainter extends BasePainter {
  SlidePainter(CarouselIndicator widget, double page, Paint paint)
      : super(widget, page, paint);

  @override
  void draw(Canvas canvas, double space, double width, double height,
      double radius, double cornerRadius) {
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromCenter(
                center: Offset(radius + (page * (width + space)), radius),
                width: width,
                height: height),
            Radius.circular(cornerRadius)),
        _paint);
  }
}
