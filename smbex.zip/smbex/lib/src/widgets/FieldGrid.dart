// Flutter imports:
import 'package:flutter/material.dart';

import 'copy_to_clipboard.dart';
import 'list_divider.dart';


class FieldGrid extends StatelessWidget {
  const FieldGrid(this.fields);

  final Map<String, String> fields;

  @override
  Widget build(BuildContext context) {
    final textColor = Theme.of(context).textTheme.bodyText1.color;
    final List<Widget> fieldWidgets = [];

    fields.forEach((field, value) {
      if (value != null) {
        Widget text = Text(
          value.replaceAll('\n', ' '),
          overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 16),
        );

        if (value.contains('\n')) {
          text = Tooltip(
            message: value,
            child: text,
          );
        }

        if (value != null && value.isNotEmpty) {
          fieldWidgets.add(Material(
            color: Colors.transparent,
            child: CopyToClipboard(
              value: value,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Flexible(
                    child: Text(
                      field,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: textColor.withOpacity(.65),
                      ),
                    ),
                  ),
                  SizedBox(height: 4),
                  text,
                ],
              ),
            ),
          ));
        }
      }
    });

    if (fieldWidgets.isEmpty) {
      return Container();
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          color: Theme.of(context).cardColor,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: LayoutBuilder(builder: (context, constraints) {
              return GridView.count(
                physics: NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                shrinkWrap: true,
                primary: true,
                crossAxisCount: 2,
                children: fieldWidgets,
                childAspectRatio: ((constraints.maxWidth / 2) - 8) / 54,
              );
            }),
          ),
        ),
        ListDivider(),
      ],
    );
  }
}
