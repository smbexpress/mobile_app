// @dart=2.12

import 'package:flutter/material.dart';

enum AnimationIconType {
  NORMAL,
  PROGRESS,
  SUCCESS,
  INFO,
  WARNING,
  ERROR,
  CUSTOM,
}


const double _sizeK = 48.0;

class AnimationIcon extends StatefulWidget{
  
  final AnimationIconType iconType;
  final Widget? icon;
  final double scale;
  final bool animationLoop;
  final Color? color ;
  final Curve curve;
  final Duration duration;
  const AnimationIcon({
    Key? key, 
    this.iconType = AnimationIconType.INFO,
    this.scale = 1.0,
    this.animationLoop = false,
    this.color,
    this.icon,
    this.curve = Curves.fastOutSlowIn,
    this.duration = const Duration(milliseconds: 600)
  }) : super(key: key);
  
  
  @override
  State<StatefulWidget> createState() => _AnimationIconState();
}

class _AnimationIconState extends State<AnimationIcon>
    with TickerProviderStateMixin {
  final GlobalKey _key = GlobalKey<NavigatorState>();

  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _initializeAnimation();
  }

  @override
  void didUpdateWidget(covariant AnimationIcon oldWidget) {
    super.didUpdateWidget(oldWidget);

    ///dispose the current active controller and
    /// create a new one for changeiconType
    _controller.dispose();
    _initializeAnimation();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  _initializeAnimation() {
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: widget.curve,
    );
  }

  @override
  Widget build(BuildContext context) {

    Widget child = _buildIcon();

    if (widget.iconType != AnimationIconType.NORMAL){
      if (widget.scale != 1)
        child = Transform.scale(
            scale: widget.scale,
            child: child
        );

      child = widget.scale == 1
          ? Padding(
              padding:  const EdgeInsets.fromLTRB(8, 12, 8, 8),
              child: child
          )
          : Padding(
              padding: EdgeInsets.only(
                  top: 12.0 * widget.scale,
                  left: 8 * widget.scale,
                  right: 8 * widget.scale,
                  bottom: 8 * widget.scale
              ),
              child: child
          );
    }
    return child;
  }

  _playAnimation() {
    if (widget.animationLoop) {
      _controller.repeat();
    } else {
      _controller.forward();
    }
  }

  _buildIcon() {
    switch (widget.iconType) {
      case AnimationIconType.PROGRESS:
        return CircularProgressIndicator(
          color: widget.color,
        );
      case AnimationIconType.SUCCESS:
        _playAnimation();
        return Container(
          alignment: Alignment.center,
          width: _sizeK,
          height: _sizeK,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(44),
            // color: Colors.white,
            border: Border.all(
              color: Colors.green,
              width: 2,
            ),
          ),
          padding: const EdgeInsets.all(4.0),
          child: SizeTransition(
            sizeFactor: _animation,
            axis: Axis.horizontal,
            axisAlignment: -1,
            child: const Icon(
              Icons.check,
              color: Colors.green,
              size: 38.0,
            ),
          ),
        );
      case AnimationIconType.INFO:
        _playAnimation();
        return ScaleTransition(
            scale: _animation,
            child: const Icon(
              Icons.info_outlined,
              color: Colors.blue,
              size: _sizeK,
            ));
      case AnimationIconType.WARNING:
        _playAnimation();
        return ScaleTransition(
            scale: _animation,
            child: const Icon(
              Icons.info_outlined,
              color: Colors.amber,
              size: _sizeK,
            ));
      case AnimationIconType.ERROR:
        _playAnimation();
        return Container(
          alignment: Alignment.center,
          width: _sizeK,
          height: _sizeK,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(44),
            // color: Colors.white,
            border: Border.all(
              color: Colors.red,
              width: 2,
            ),
          ),
          padding: const EdgeInsets.all(4.0),
          child: ScaleTransition(
              scale: _animation,
              child: const Icon(
                Icons.clear,
                color: Colors.red,
                size: 40,
              )),
        );

      default:
        return const SizedBox();
    }
  }


}