import 'package:flutter/material.dart';

import '../../i18n/i18n.dart';
import '../models/address.dart';
import '../theme/extention.dart';
import '../theme/text_styles.dart';

class SelectAddressWidget extends StatelessWidget {
  final VoidCallback onTap;
  ValueChanged onSelect;
  final Address from;
  final Address to;
  final double height;
  final bool useFullAddress;
  final bool editable;
  SelectAddressWidget(
      this.from,
      this.to,{
        this.onSelect,
        this.onTap,
        this.height: 40,
        this.useFullAddress = false,
        this.editable = false
  });

  String selectedAddress;
  List<Map<String, dynamic>> listAddress = [
    {"id": 1, "title": "San Antonio"},
    {"id": 2, "title": "Los Angeles"},
    {"id": 3, "title": "Mt San Antonio"},
    {"id": 4, "title": "Simi Valley"},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              width: 28,
              //height: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  SizedBox(height: 10,),
                  Icon(Icons.location_on, color: Theme.of(context).errorColor),
                  Container(
                    height: height + 20,
                    child: VerticalDivider(width: 1,),
                  ),
                  RotatedBox(quarterTurns: 2,
                      child:  Icon(Icons.navigation, color: Theme.of(context).colorScheme.secondary)
                  ),
                  SizedBox(height: 10,),
                ],
              ),
            ),
            Expanded(
              //flex: 8,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Column(
                      mainAxisAlignment:MainAxisAlignment.spaceBetween,
                      crossAxisAlignment:CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text(
                            tr.from,
                            style: TextStyles.bodySm.w500.opacity(.5)
                        ),
                        const SizedBox(height: 5,),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                  (!useFullAddress
                                      ? from?.name
                                      : from?.formattedName)??"",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: useFullAddress
                                      ? TextStyles.body.opacity(.7)
                                      : TextStyles.body.w600.opacity(.7)
                              ),
                            )
                          ],
                        ),
                        if(from.valid)
                          Text(
                              from?.formattedRegion,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyles.bodySm.w400.opacity(.9)
                          )
                      ]
                  ).ripple(
                      onSelect != null
                          ? () => onSelect(true)
                          : null
                  ),

                  Container(
                      padding: EdgeInsets.symmetric(vertical: 2),
                      child: Divider()
                  ),

                  Column(
                    mainAxisAlignment:MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        tr.to,
                        style: TextStyles.bodySm.w500.opacity(.5),
                      ),
                      const SizedBox(height: 5,),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                                (!useFullAddress
                                    ? to?.name
                                    : to?.formattedName)??"",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: useFullAddress
                                    ? TextStyles.body.opacity(.7)
                                    : TextStyles.body.w600.opacity(.7)
                            ),
                          ),
                        ],
                      ),
                      if(to.valid)
                        Text(
                            to?.formattedRegion,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyles.bodySm.w400.opacity(.9)
                        )
                    ],
                  ).ripple(
                      onSelect != null
                          ? () => onSelect(false)
                          : null
                  ),

                ],
              ),
            )
          ],
        )
    );
  }
}
