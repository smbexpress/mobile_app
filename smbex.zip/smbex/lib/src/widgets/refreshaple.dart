
import 'package:flutter/cupertino.dart';

mixin Refreshaple<W extends StatefulWidget> on State<W>{

  void refresh();

}