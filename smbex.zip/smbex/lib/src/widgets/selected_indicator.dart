// Flutter imports:
import 'package:flutter/material.dart';

import '../../constants.dart';

class SelectedIndicator extends StatelessWidget {
  const SelectedIndicator({this.child, this.isSelected, this.isMenu = false});

  final Widget child;
  final bool isSelected;
  final bool isMenu;

  @override
  Widget build(BuildContext context) {
    final enableDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Material(
      color: isSelected
          ? Color(enableDarkMode
              ? (isMenu
                  ? kDefaultDarkSelectedColorMenu
                  : kDefaultDarkSelectedColor)
              : (isMenu
                  ? kDefaultLightSelectedColorMenu
                  : kDefaultLightSelectedColor))
          : Theme.of(context).cardColor,
      child: child,
    );
  }
}
