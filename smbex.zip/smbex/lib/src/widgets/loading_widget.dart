
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';

import '../helpers/connection_status_singleton.dart';
import '../models/model.dart';

class LoadingWidget extends StatefulWidget{

  final Widget child;
  final bool isLoading;
  final bool showLoadingText;
  final Widget loadingWidget;
  final bool alwaysShowRetry;
  final VoidCallback onRetry;
  final ErrorResult error;

  LoadingWidget({
    Key key,
    this.isLoading=false,
    this.child,
    this.showLoadingText=false,
    this.loadingWidget,
    this.alwaysShowRetry,
    this.onRetry,
    this.error
  }): super(key: key);

  @override
  _LoadingWidget createState() => _LoadingWidget();

}


class _LoadingWidget extends State<LoadingWidget> with SingleTickerProviderStateMixin{

  bool loading = false;
  Animation<double> animation;
  AnimationController controller;
  StreamSubscription _connectSub;

  @override
  void initState() {
    super.initState();

    if (widget.onRetry != null){
      _connectSub = ConnectionStatusSingleton.getInstance()
          .connectionChange.listen((connected) {
            if (connected && widget.error?.isNetwork == true){
              widget.onRetry();
            }
      });
    }

    controller = AnimationController(duration: Duration(milliseconds: 500), vsync: this);
    animation = Tween<double>(begin: 0, end: 1).animate(controller);
    
    //Future.delayed(Duration(seconds: 2), ()=> _connectionChanged(true) );
    //Future.delayed(Duration(seconds: 10), ()=> _connectionChanged(false) );

    animation.addStatusListener((status) {
      setState((){});
    });
    //controller.forward();
    if (widget.isLoading){
      controller.forward();
    }


  }

  void _connectionChanged(bool hasConnection) {
    loading = hasConnection;
    hasConnection ? controller.forward() : controller.reverse();
    setState((){ });
  }

  @override
  void dispose() {
    controller.dispose();
    _connectSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = controller.isAnimating || widget.isLoading;
    Widget child =
        widget.error != null
            ? MessagePlaceholder.error(
                error: widget.error,
                onRetry: widget.error.isNetwork || (widget.alwaysShowRetry??true)
                         ? widget.onRetry : null
              )
            : widget.child;

    return Stack(
        fit: StackFit.expand,
        children: [
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            top: 0,
            child: isLoading ? child ?? SizedBox() : buildStatus(context),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            top: 0,
            child: isLoading ? buildStatus(context) : child ?? SizedBox(),
          )
        ]
      );

  }

  Widget buildStatus(BuildContext context){
    final loadingColor = Theme.of(context).primaryColorDark;
    return AnimatedBuilder(
        animation: animation,
        builder: (context, child)=>
          Material(
                color: Colors.transparent,
                child: Opacity(
                  //color: Colors.grey.withOpacity(animation.value * .3),
                  //height: MediaQuery.of(context).size.height,
                  //constraints: BoxConstraints.expand(),
                  opacity: animation.value,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      /*
                      RipplesAnimation(
                        color: loadingColor??Colors.blueAccent,
                        size: 30,
                        child: CircularProgressIndicator(color: Colors.white,),
                        duration: const Duration(milliseconds: 4000)
                      ,),

                       */
                      //SizedBox(height: 20,),
                      if (widget.loadingWidget != null)
                        widget.loadingWidget,

                      if (widget.loadingWidget == null)
                        CircularProgressIndicator(color: loadingColor,),
                      if (widget.loadingWidget == null)
                        SizedBox(height: 20,),
                      if (widget.loadingWidget == null && widget.showLoadingText)
                        Text("Please wait!", style: TextStyle(fontSize: 14, color: Colors.black),),
                    ],
                  ),
                ),
            ),

    );
  }

  void _rebuild(){
    setState((){});
  }

  void didUpdateWidget(LoadingWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isLoading != oldWidget.isLoading){
        widget.isLoading ? controller.forward() : controller.reverse();
    }
  }

}