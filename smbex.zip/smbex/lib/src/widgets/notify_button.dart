// @dart=2.12
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../notification_provider.dart';

class NotifyButton extends StatefulWidget {
  const NotifyButton({
    this.iconColor,
    this.labelColor,
    this.iconSize,
    Key? key,
  }) : super(key: key);

  final Color? iconColor;
  final Color? labelColor;
  final double? iconSize;
  @override
  _NotifyButtonState createState() => _NotifyButtonState();
}

class _NotifyButtonState extends State<NotifyButton> {
  int counter = 0;
  @override
  void initState() {
    //_con.listenForCartsCount();
    super.initState();
    notificationCounter.addListener(_countChanged);
    //Provider.of<NotificationProvider>(context, listen: false);
  }

  void dispose() {
    super.dispose();
    notificationCounter.removeListener(_countChanged);
  }

  void _countChanged(){
    setState((){});
  }

  @override
  Widget build(BuildContext context) {

    return Stack(
      alignment: Alignment.center,
      fit: StackFit.passthrough,

      children: <Widget>[
        Icon(Icons.notifications, size: widget.iconSize,),
        notificationCounter.value != 0? Positioned(
          right: 0,
          top: 0,
          child: Container(
            padding: EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
              //borderRadius: BorderRadius.circular(6),
            ),
            constraints: BoxConstraints(
              minWidth: 14,
              minHeight: 14,
            ),
            child: Text(
              '${notificationCounter.value}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 8,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ) : SizedBox.shrink(),

      ],
    );
  }

}
