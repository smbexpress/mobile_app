import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/payment_method.dart';
import 'package:smbex_app/src/theme/text_styles.dart';
import 'package:smbex_app/src/widgets/message_placeholder.dart';

import '../../i18n/i18n.dart';
import '../screens/wallet/widgets.dart';

typedef PaymentCardFn = Future<bool> Function(BuildContext, PaymentCard);

class PaymentMethodsSheetWidget extends StatefulWidget {
  final ValueChanged<PaymentMethodItem> onSelect;
  final String paymentType;
  final double height;
  final Map<String, dynamic> data;
  final PaymentCardFn onEdit;
  final PaymentCardFn onDelete;
  final bool showCardsOnly;
  PaymentMethodsSheetWidget(
      {Key key,
      this.paymentType,
      this.height,
      this.onSelect,
      this.data,
      this.onEdit,
      this.onDelete,
      this.showCardsOnly})
      : super(key: key);

  @override
  _PaymentMethodsSheetWidgetState createState() =>
      _PaymentMethodsSheetWidgetState();
}

class _PaymentMethodsSheetWidgetState extends State<PaymentMethodsSheetWidget> {
  ResultItems<PaymentMethod> paymentMethods = ResultItems();
  List<PaymentCard> cards = [];

  Future loadPaymentMethods() {
    if (paymentMethods.loading) return Future<bool>.value(false);
    cards.clear();
    setState(() {
      paymentMethods.setLoading(true);
    });
    return ResultItems.get<PaymentMethod>(
        "${widget.paymentType}/payment_methods",
        data: widget.data,
        func: (data) => PaymentMethod.fromJSON(data)).then((value) {
      if (!value.hasError) {
        for (final pm in value.items) {
          if (pm.cards?.isNotEmpty == true) {
            cards.addAll(pm.cards);
          }
        }

        cards?.sort((item1, item2) {
          return item1.isDefault || item2.isDefault ? 0 : 1;
        });
      }
      if (mounted)
        setState(() {
          paymentMethods.update(value);
        });
    });
  }

  @override
  void initState() {
    super.initState();
    loadPaymentMethods();
  }

  @override
  Widget build(BuildContext context) {
    if (paymentMethods.loading)
      return Container(
        padding: EdgeInsets.all(30),
        child: CircularProgressIndicator(),
        alignment: Alignment.center,
        height: 100,
        color: Theme.of(context).scaffoldBackgroundColor,
        width: double.infinity,
      );

    if (paymentMethods.hasError)
      return Container(
        //padding: EdgeInsets.only(bottom: 80),
        color: Theme.of(context).dialogBackgroundColor,
        width: double.infinity,
        child: MessagePlaceholder.error(
          error: paymentMethods.error,
          onRetry: loadPaymentMethods,
        ),
      );
    final childs = createPaymentMethods(context, paymentMethods.items);

    if (childs.isEmpty) {
      childs.add(MessagePlaceholder.empty(
        message: tr.paymentMethodUnavailable,
      ));
    }

    return ListView(
      shrinkWrap: true,
      //primary: true,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 30),
      children: [
        ...childs,
      ],
    );
  }

  List<Widget> createPaymentMethods(
      BuildContext context, List<PaymentMethod> pms) {
    List<Widget> widgets = [];

    if (cards.isNotEmpty) {
      cards.forEach((card) {
        widgets.add(const Divider(
          height: 1,
        ));
        PaymentMethodItem item = card.toItem();
        widgets.add(createPaymentMethodItemTile(context, item,
            selectable: widget.onSelect != null,
            isSelected: card.isDefault,
            onTap: () => widget.onSelect?.call(item),
            onEdit: widget.onEdit != null
                ? () async {
                    final edited = await widget.onEdit(context, card);
                    if (edited) {
                      loadPaymentMethods();
                    }
                  }
                : null,
            onDelete: widget.onDelete != null
                ? () {
                    setState(() {});
                    WidgetsBinding.instance.addPostFrameCallback((_) async {
                      final deleted = await widget.onDelete(context, card);
                      if (deleted) {
                        loadPaymentMethods();
                        Fluttertoast.showToast(
                          toastLength: Toast.LENGTH_LONG,
                          msg: tr.payment_card_updated_successfully,
                        );
                      }
                    });
                  }
                : null));
      });
      widgets.add(const Divider(
        height: 1,
      ));
      widgets.add(const SizedBox(
        height: 5,
      ));
    }

    if (widget.showCardsOnly == true) return widgets;

    for (PaymentMethod pm in pms) {
      if ((pm.brands?.isNotEmpty == true)) {
        PaymentMethodItem item = pm.toItem();
        widgets.add(createPaymentMethodItemTile(context, item,
            selectable: widget.onSelect != null,
            isSelected: false,
            onTap: () => widget.onSelect?.call(item)));
        if (false && pm.brands?.isNotEmpty == true) {
          widgets.add(Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                    child: ElevatedButton(
                  onPressed: () {
                    widget.onSelect(pm.toItem());
                  },
                  child: Text(tr.addNewCreditCard),
                ))
              ],
            ),
          ));
        }
      } else {
        widgets.add(const SizedBox(
          height: 10,
        ));
        PaymentMethodItem item = pm.toItem();
        widgets.add(createPaymentMethodItemTile(context, item,
            selectable: widget.onSelect != null,
            isSelected: pm.isDefault,
            onTap: () => widget.onSelect(item)));
      }
    }
    return widgets;
  }

  Widget createPaymentMethodItemTile(
      BuildContext context, PaymentMethodItem item,
      {bool isSelected,
      bool selectable,
      VoidCallback onEdit,
      VoidCallback onDelete,
      VoidCallback onTap}) {
    Widget trailing;
    if (selectable == true) {
      trailing = Container(
        //alignment: Alignment.center,
        height: double.infinity,
        child: Icon(
          isSelected == true
              ? Icons.radio_button_checked
              : Icons.radio_button_off,
          size: 24,
          color: isSelected == true ? Color(0xFF3A76E2) : Colors.grey,
        ),
      );
    } else if (onEdit != null || onDelete != null) {
      trailing = PopupMenuButton(
          icon: Icon(Icons.more_vert),
          itemBuilder: (BuildContext context) {
            List<PopupMenuEntry> items = [
              if (onEdit != null)
                PopupMenuItem(
                  onTap: onEdit,
                  child: Row(
                    children: [
                      const Icon(Icons.edit),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(tr.edit)
                    ],
                  ),
                ),
              if (onDelete != null)
                PopupMenuItem(
                  onTap: onDelete,
                  child: Row(
                    children: [
                      const Icon(
                        Icons.delete,
                        color: Colors.redAccent,
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(tr.buttons.remove)
                    ],
                  ),
                ),
            ];

            return items;
          });
    }

    bool expired = item.isCard && item.card.expired;
    return ListTile(
        key: ValueKey(item.id),
        title: Row(
          mainAxisAlignment:
              item.isCard ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [Text(item.name)],
        ),
        subtitle: item.description?.isNotEmpty == true ||
                item.card?.expire?.isNotEmpty == true
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //Text(item.name, style: TextStyles.titleM),
                  if (!item.isCard)
                    Text(
                      item.description ?? "",
                      maxLines: 1,
                    ),
                  if (item.isCard && item.card.expire != null)
                    Text(
                      '${tr.exp_date}: ${item.card.expire ?? ''}',
                      style: item.card.expired
                          ? TextStyle(
                              color: Theme.of(context).colorScheme.error)
                          : null,
                    ),
                ],
              )
            : null,
        leading: Container(
          height: double.infinity,
          //width: 60,
          child: item.icon.startsWith('http')
              ? CachedNetworkImage(
                  imageUrl: item.icon,
                  placeholder: (context, url) => CircularProgressIndicator(),
                  errorWidget: (context, url, error) => Icon(Icons.credit_card),
                  width: 60,
                  height: 60,
                )
              : Image.asset(
                  item.icon,
                  width: 40,
                  height: 40,
                ),
        ),
        trailing: trailing,
        dense: false,
        //isThreeLine: true,
        onTap: onTap);
  }
}
