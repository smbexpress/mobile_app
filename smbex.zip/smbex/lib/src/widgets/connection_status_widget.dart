
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/helpers/upgrader.dart';

import '../../i18n/i18n.dart';
import '../helpers/connection_status_singleton.dart';

class ConnectionStatusWidget extends StatefulWidget{

  final WidgetBuilder builder;
  final Widget child;
  final VoidCallback onConnect;
  ConnectionStatusWidget({
    Key key,
    this.builder,
    this.child,
    this.onConnect
  }): super(key: key);

  @override
  _ConnectionStatusWidget createState() => _ConnectionStatusWidget();

}


class _ConnectionStatusWidget extends State<ConnectionStatusWidget> with SingleTickerProviderStateMixin{

  StreamSubscription _connectionChangeStream;
  bool _hasConnection = true;
  AnimationController controller;
  Animation<Offset> offset;

  @override
  void initState() {
    ConnectionStatusSingleton connectionStatus = ConnectionStatusSingleton.getInstance();
    _connectionChangeStream = connectionStatus.connectionChange.listen(_connectionChanged);
    controller = AnimationController(vsync: this, value: 0.0, duration: Duration(milliseconds: 500));
    offset = Tween<Offset>(begin: const Offset(0.0, -1.0), end: const Offset(0.0, 0.0)).animate(controller);
    //controller.reverse();
    //Future.delayed(Duration(seconds: 2), ()=> _connectionChanged(false) );
    //Future.delayed(Duration(seconds: 10), ()=> _connectionChanged(true) );
    //connectionStatus.
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _connectionChanged(connectionStatus.hasConnection);
      _checkConnection(connectionStatus.hasConnection);
    });

    super.initState();
  }

  void _checkConnection(bool hasConnection) async{
    //final hasConnection = ConnectionStatusSingleton.getInstance().hasConnection;
    final newHasConnection = await ConnectionStatusSingleton.getInstance().checkConnection();
    if (newHasConnection != hasConnection){
      _connectionChanged(newHasConnection);
    }
  }

  void _connectionChanged(bool hasConnection) {
    if (_hasConnection == hasConnection) return;
    _hasConnection = hasConnection;
    if (_hasConnection){
      widget.onConnect?.call();
    }
    hasConnection == false ? controller.forward() : controller.reverse();
    setState((){});
  }

  @override
  Widget build(BuildContext context) {

    final childWidget = Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      top: 0,
      child: widget.child ?? widget.builder?.call(context) ?? SizedBox(),
    );

    final statusWidget =
        Positioned(
          child: buildStatus(context),
          left: 0,
          right: 0,
          bottom: 0,
          top: 0,
        );


    return Stack(
          fit: StackFit.expand,
          children:[childWidget, statusWidget],
    );
  }

  @override
  void dispose() {
    _connectionChangeStream?.cancel();
    controller?.dispose();

    super.dispose();
  }

  Widget buildStatus(BuildContext context){

    return SlideTransition(
          position: offset,
          //height: _hasConnection ? 0 : MediaQuery.of(context).size.height,
          //duration: Duration(milliseconds: 500),
          //curve: Curves.easeInOutCubic,
          child: Material(
            color: Colors.transparent,
            child: Container(
              color: Colors.black.withOpacity(.5),
              //height: MediaQuery.of(context).size.height,
              //constraints: BoxConstraints.expand(),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Icon(
                    Icons.wifi_off,
                    color: Colors.deepOrange,
                    size: 100,
                  ),
                  SizedBox(height: 20,),
                  //Text("Internet connection is not available!!", style: TextStyle(fontSize: 14, color: Colors.deepOrange),),
                  Text(S.of(context).verify_your_internet_connection, style: TextStyle(fontSize: 16, color: Colors.white),)
                ],
              ),
            ),
          ),
    );
  }

}

typedef ConnectionChangeBuilder = Widget Function(BuildContext contex, bool connected);

class ConnectionChangeWidget extends StatelessWidget {
  final Widget child;
  final VoidBoolCallback onChange;
  final ConnectionChangeBuilder builder;
  const ConnectionChangeWidget({Key key, this.child, this.onChange, this.builder}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool hasConnection = ConnectionStatusSingleton.getInstance().hasConnection;
    return StreamBuilder(
        initialData: hasConnection,
        stream: ConnectionStatusSingleton.getInstance().connectionChange,
        builder: (context, snapshot) {
          bool oldValue = hasConnection;
          hasConnection = snapshot.data;
          if (oldValue != hasConnection){
            onChange?.call(hasConnection);
          }

          return child ?? builder?.call(context, hasConnection);
        }
    );
  }
}