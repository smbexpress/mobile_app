import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

class HyperpayController extends ControllerMVC {
  GlobalKey<ScaffoldState> scaffoldKey;
  String url = "";
  double progress = 0;

  HyperpayController(this.url) {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }
  @override
  void initState() {

    setState(() {});
    super.initState();
  }
}
