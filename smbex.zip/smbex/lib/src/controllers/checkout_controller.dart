import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smbex_app/src/api.dart';

import './cart_controller.dart';
import '../models/cart.dart';
import '../models/model.dart';
import '../models/payment.dart';
import '../models/payment_method.dart';

ValueNotifier<Transaction> currentTransaction = new ValueNotifier(null);

class CheckoutController extends CartController {
  Payment payment;
  Transaction transaction;
  void loadStatus(String id){
    ResultItem.get<dynamic>("payment/status/poll?id=${id}").then((ResultItem<dynamic> result) => {
      result.error
    });
  }

  Future<void> loadCart() async{
    this.cart = currentCart.value;
    return Future<void>.value();
  }


  Future<ResultItem<dynamic>> getPaymentStatus() async {
    if (currentTransaction.value == null)
      return ResultItem(error: ErrorResult(message: "The transaction is not available!"));

    return ResultItem.get<dynamic>("payment/status/poll", data: {'id': currentTransaction.value.id});
  }
  
  void checkout(PaymentMethod pm){

    List<int> ids = cart.items.map((e) => e.id).toList();
    setState((){
      loading = true;
    });
    ResultItem.of<dynamic>(Api().post("${cart.type}/checkout", data: {'ids': ids,
      'type': cart.type, 'route': cart.route}), null)
        .then((value) {
          setState((){
            error = value.error;
            transaction = value.item['tx']??null;
            cart = value.item['cart']??currentCart.value;
            loading = false;
          });
    });
  }
  

}
