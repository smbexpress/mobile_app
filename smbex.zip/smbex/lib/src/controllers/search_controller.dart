import 'package:mvc_pattern/mvc_pattern.dart';

import '../api.dart';
import '../models/model.dart';
import '../models/shipment.dart';
import '../repository/search_repository.dart';

class SearchController extends ControllerMVC {
  ResultItems<TinyShipment> result = ResultItems();

  SearchController() {
    //listenForStores();
    //listenForProducts();
  }

  /*void listenForStores({String search}) async {
    if (search == null) {
      search = await getRecentSearch();
    }
    Address _address = deliveryAddress.value;
    final Stream<Store> stream = await searchStores(search, _address);
    stream.listen((Store _store) {
      setState(() => stores.add(_store));
    }, onError: (a) {
      print(a);
    }, onDone: () {});
  }*/

  void listenForProducts({search}) async {
    if (search == null) {
      search = await getRecentSearch();
    } else {
      List l = List();
      l.add(search);
      search = l;
    }
    List filter = [];
    search.forEach((str) {
      filter.add('"$str"');
    });
    print("----Do Search----");

    ResultItems<TinyShipment> searchResult =
      await ResultItems.of(Api().post("shipments/list",
          data: {'filter': "name in(${filter.join(',')})", 'limit': 10}),  (data)=> TinyShipment.fromJSON(data));

    setState(() {
      result = searchResult;
    });

  }

  Future<void> refreshSearch(search) async {

    setState(() {
      result.clear();
    });
    //listenForStores(search: search);
    listenForProducts(search: search);
  }

  void saveSearch(String search) {
    setRecentSearch(search);
  }
}
