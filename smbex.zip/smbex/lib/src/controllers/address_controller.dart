import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/helpers/helper.dart';

import '../../i18n/i18n.dart';
import '../helpers/maps_util.dart';
import '../models/address.dart';
import '../models/branch.dart';
import '../models/model.dart';
import '../repository/account_repository.dart' as accountRepo;
import '../repository/app_repository.dart' as appRepo;
import '../repository/settings_repository.dart';
import '../screens/branch/branch_provider.dart';
import '../widgets/SmbWidget.dart';

final ValueNotifier<Address> deliveryAddress = new ValueNotifier(new Address());

final ValueNotifier<Address> pickupAddress =
    new ValueNotifier(Address.fromJSON({'isPickup': true}));

final ValueNotifier<Address> lastAddress = new ValueNotifier(new Address());

class AddressController extends ControllerMVC {
  GlobalKey<ScaffoldState> scaffoldKey;
  Address address;
  bool pickup;
  List<Address> addressList = [];
  bool saveComplete = false;
  ValueNotifier<Address> notifier = new ValueNotifier(null);
  bool loading = false;
  ErrorResult error;

  Future<ResultItem<Address>> addAddress(Address address) {
    loading = true;
    setState(() {});
    return accountRepo.addAddress(address).then((value) {
      if (!value.hasError) {
        setState(() {
          address = value.item;
          addressList.insert(0, value.item);
          saveComplete = true;
          notifier.value = value.item;
        });
        Fluttertoast.showToast(msg: tr.the_address_updated_successfully,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.CENTER,
            textColor: Colors.white);

      } else {
        showNotifyDialog(
          context,
          error: value.error,
        );
      }
      return value;
    }).whenComplete(() {
      loading = false;
      setState(() {});
    });
  }

  Future<ResultItem<Address>> updateAddress(Address address) {
    loading = true;
    setState(() {});
    return accountRepo
        .updateAddress(address)
        .then((ResultItem<Address> result) {
      if (!result.hasError) {
        Address origin = addressList.singleWhere(
            (addr) => addr.id == address.id,
            orElse: () => address);
        int pos = addressList.indexOf(origin);
        print("Update address in: $pos");
        if (pos >= 0) {
          setState(() {
            address = result.item;
            addressList.removeAt(pos);
            addressList.insert(pos, result.item);
            saveComplete = true;
            notifier.value = result.item;
          });
        } else {
          setState(() {
            saveComplete = true;
          });
        }

        Fluttertoast.showToast(msg: tr.the_address_updated_successfully,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.CENTER,
            textColor: Colors.white);
      } else {
        showNotifyDialog(
          scaffoldKey?.currentContext,
          error: result.error,
        );
      }
      return result;
    }).whenComplete(() {
      loading = false;
      setState(() {});
    });
  }

  Future<ResultItem<Address>> save(Address address) {
    if (address.id == 0 || address.id == null) {
      return addAddress(address);
    }
    return updateAddress(address);
  }

  Future removeAddress(Address address) async {
    return accountRepo.removeAddress(address).then((value) {
      if (!value.hasError) {
        setState(() {
          addressList.remove(address);
        });
        showSnackBar(context,
            message: S.tr.delivery_address_removed_successfully,
            contentType: ContentType.SUCCESS);
      } else {
        showSnackBar(context,
            error: value.error);
      }
    });
  }

  void searchAddresses(bool pickup, [String query, bool forceBranch]) async {
    print("AddressController::searchAddresses");
    loading = true;
    error = null;
    setState(() {});
    addressList?.clear();

    Future<ResultItems<Address>> result =
      accountRepo.searchAddress(query, pickup, forceBranch);

    final branchProvider = context.read<BranchProvider>();
    await branchProvider.branches();

    result.then((result) async{
      if (!result.hasError) {
        addressList.addAll(result.items);
        await _syncAddressesWithBranches();

        print("AddressController::searchAddresses: ${result.items}");
        setState(() {});
      } else {
        print("AddressController::searchAddresses error: ${result.error}");
        //showSnackBar(context, error: result.error );
        error = result.error;
      }
    }).whenComplete(() {
      loading = false;
      setState(() {});
    });
  }

  Future<City> cityLookup(int countryId, String keyword,
      {pickup: 'a', dropoff: 'a'}) async {
    final ResultItems<City> item = await appRepo.cityLookup(countryId, keyword,
        pickup: pickup, dropoff: dropoff);

    if (item.hasError) {
      debugPrint(item.error.toString());
    }
    return !item.hasError && item.length > 0 ? item.items[0] : null;
  }

  Future<void> changeAddress(Address address) async {
    if (address.isPickup) {
      setState(() {
        pickupAddress.value = address;
      });
    } else {
      setState(() {
        deliveryAddress.value = address;
      });
    }
  }

  Future<Address> setCurrentLocation(bool isPickup) async {
    var location = new Location();
    Address _address = Address.fromJSON({'isPickup': isPickup});
    if (!(await location.serviceEnabled())) {
      if (!(await location.requestService())) {
        return null;
      }
    }

    PermissionStatus status = await location.hasPermission();

    if (status == PermissionStatus.DENIED_FOREVER) return null;

    if (status == PermissionStatus.DENIED) {
      status = await location.requestPermission();
      if (status == PermissionStatus.DENIED_FOREVER ||
          status == PermissionStatus.DENIED) {
        return null;
      }
    }
    final account = accountRepo.currentAccount.value;

    final whenDone = new Completer<Address>();
    location.getLocation().then((_locationData) async {
      if (whenDone.isCompleted) return;

      _address.lat = _locationData != null ? _locationData?.latitude : 0;
      _address.lng = _locationData != null ? _locationData?.longitude : 0;

      print("start get location ");
      var result = null;
      try {
        result = await MapsUtil.reverseGeocode(
            new LatLng(_address.lat, _address.lng),
            settingNotifier.value.googleMapsKey);
      } catch (e, stack) {
        debugPrintStack(label: e.toString(), stackTrace: stack);
      }

      if (whenDone.isCompleted) return;

      if (result != null) {
        Country country = appRepo.countries.singleWhere(
            (country) => country.code == result.country.shortName,
            orElse: () => null);
        City city = country != null
            ? await cityLookup(country.id, result.city.shortName)
            : null;

        if (whenDone.isCompleted) return;

        if (city != null) {
          _address = Address.fromJSON({
            'isPickup': isPickup,
            'street': result.formattedAddress,
            'city': city,
            'country': country,
            'province': result.locality,
            'district': result.subLocalityLevel1,
            'lat': result.latLng.latitude,
            'lng': result.latLng.longitude,
            'zip': result.postalCode,
          });
          whenDone.complete(_address);
          return;
        }
        if (city == null) {
          if (lastAddress.value.city != null) {
            _address.copy(lastAddress.value);
          } else if (account.defaultAddress?.city != null) {
            _address.copy(account.defaultAddress);
          } else {
            _address = Address.fromJSON({
              'isPickup': isPickup,
              'street': result.formattedAddress,
              'country': country,
              'province': result.locality,
              'district': result.subLocalityLevel1,
              'lat': result.latLng.latitude,
              'lng': result.latLng.longitude,
              'zip': result.postalCode
            });
          }
          lastAddress.value = _address;
        }
        whenDone.complete(_address);
      } else {
        print("get location not found");
        whenDone.complete(_address);
      }
      return null;
    }).timeout(Duration(seconds: 20), onTimeout: () async {
      whenDone.complete(null);
      print("get location timeout");
      return null;
    }).catchError((e) {
      print("get location error: $e");
      whenDone.complete(null);
      return null;
    });
    return whenDone.future;
  }

  Future<Address> loadAddress(Address address) async{
    ResultItem<Address> result =
      await ApiRequest.of(
          'addresses/${address.id}',
          serializer: (data) => Address.fromJSON(data),
          timeout: 20
      )
      .once();
    if (result.hasError) {
      //if (address.facilityId != null && address.facility == null)
      //showErrorDialog(context, error: result.error);

      return address;
    }
    if (result.item.facilityId != null && result.item.facility == null)
      await BranchProvider.syncAddressWithBranch(context, [result.item]);
    return result.item;
  }


  void _syncAddressesWithBranches() async{
    if (address != null) {
      await BranchProvider.syncAddressWithBranch(context, [address]);
    } else {
      await BranchProvider.syncAddressWithBranch(context, addressList);
    }
  }

}
