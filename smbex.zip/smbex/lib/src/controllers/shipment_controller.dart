import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import '../config.dart';
import './cart_controller.dart';
import '../../i18n/i18n.dart';
import '../models/address.dart';
import '../models/model.dart';
import '../models/shipment.dart';

ValueNotifier<int> _changeNotifier = new ValueNotifier(0);

final LoadState<Shipment> editShipmentState =
    LoadState(null, until: Duration(minutes: 30));
final LoadState<ShipmentMeta> shipmentMetaLoadState =
    LoadState<ShipmentMeta>(null, until: Duration(minutes: 30));
final LoadState<WorkingTimes> workingTimesLoadState =
    LoadState<WorkingTimes>(null, until: Duration(minutes: 30));

class ShipmentController extends ControllerMVC {
  GlobalKey<ScaffoldState> scaffoldKey;
  Shipment shipment;
  ResultItems<Rate> rates = ResultItems();
  ResultItems<Package> packages = ResultItems();

  Shipment _old;
  ErrorResult errorResult;
  ValueChanged vm;
  bool valid = false;
  bool loading = false;
  Function retryFunc;
  Widget errorWidget;
  int pageIndex = 0;
  bool edit = true;
  List<LoadMore<TinyShipment>> loadMoreList;
  ShipmentController([this.edit = true]) {
    scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  @override
  void initState() {
    super.initState();
    _changeNotifier.addListener(this._onNotifierChange);
  }

  @override
  void dispose() {
    _changeNotifier.removeListener(this._onNotifierChange);
    if (edit &&
        shipment != null &&
        shipment.package != null &&
        !shipment.valid) {
      Shipment shipment = this.shipment;
      if (shipment.meta != null && editShipmentState.validate()) {
        shipment.meta['created'] = new DateTime.now();
        shipment.meta['packages'] = packages;
        shipment.meta['valid'] = valid;
        shipment.meta['pageIndex'] = pageIndex;
        shipment.meta['rates'] = rates;
        editShipmentState.update(shipment, null);
      }
    } else {
      editShipmentState.reset();
      shipmentMetaLoadState.reset();
      workingTimesLoadState.reset();
    }
    super.dispose();
  }

  void _onNotifierChange() {
    if (loadMoreList != null) {
      for (LoadMore<TinyShipment> lm in loadMoreList) lm.refresh();
    }
  }

  void reset() {
    packages.clear();
    rates.clear();
    shipment?.rate = null;
    pageIndex = 0;
    valid = false;
    retryFunc = null;
    errorResult = null;
    editShipmentState.reset();
    shipmentMetaLoadState.reset();
    workingTimesLoadState.reset();
  }

  void newShipment() async {
    if (loading) return;
    loading = true;
    _newShipment();
  }

  void _newShipment() async {
    Shipment shipment = edit ? editShipmentState.value : null;
    if (shipment != null && shipment.package != null) {
      if (shipment.valid) {
        editShipmentState.reload();
        final resultShip = await getShipment(shipment.id);
        editShipmentState.update(resultShip.item, resultShip.error);
        errorResult = resultShip.error;
        this.shipment = shipment;
        loading = false;
        _trigger();
        print("Restore valid shipment!!");
        return;
      } else if (editShipmentState.validate() && shipment.meta != null) {
        this.shipment = shipment;
        final meta = shipment.meta;
        _old = Shipment.fromJSON({});
        shipment.copyTo(_old);
        packages = meta['packages'] ?? packages;
        valid = meta['valid'] ?? false;
        pageIndex = meta['pageIndex'] ?? 0;
        rates = meta['rates'] ?? rates;
        print("Shipment still valid!!");
        loading = false;
        editShipmentState.update(shipment);
        _trigger();
        notifyListeners();
        return;
      } else {
        reset();
      }
    }
    _loadMeta();
  }

  void _loadMeta() async {
    final value = await ResultItem.of(
        Api().get("shipments/meta"), (data) => ShipmentMeta.fromJSON(data),
        timeout: 15);
    shipmentMetaLoadState.update(value.item, value.error);
    loading = false;
    if (value.hasError) {
      retryFunc = this.newShipment;
      errorResult = value.error;
      setState(() {});
      return;
    }
    retryFunc = null;
    errorResult = null;
    Shipment newShip = Shipment.fromJSON({});
    newShip.codCurrency = shipmentMetaLoadState.value.codCurrency;
    newShip.from = shipmentMetaLoadState.value.fromAddress ?? newShip.from;
    if (newShip.from.facilityId != null)
      await BranchProvider.syncAddressWithBranch(context, [newShip.from]);

    shipment = newShip;
    editShipmentState.update(shipment);
    setState(() {});
    setFromAddress(newShip.from);
  }

  void _loadWorkingTime() async {
    if (shipment?.from?.city?.valid != true || !edit) return;

    workingTimesLoadState.reload(WorkingTimes(items: []));
    final value = await ResultItem.of(
        Api().get("app/pickup_times", data: {'city_id': shipment.from.city.id}),
        (data) => WorkingTimes.fromJSON(data),
        timeout: 15);

    workingTimesLoadState.update(value.item, value.error);
  }

  void setFromAddress(Address address) {
    bool loadWorkingTime = address?.city != shipment.from?.city ||
        workingTimesLoadState.value == null;

    shipment.from = address;
    if (edit && loadWorkingTime) _loadWorkingTime();

    setState(() {});
  }

  void setToAddress(Address address) {
    shipment.to = address;
  }

  void setShipment(Shipment newShipment) {
    shipment = newShipment;
  }

  void backup() {
    editShipmentState.value = shipment;
  }

  void restore() {}

  Future<ResultItem<Shipment>> getShipment(int shipmentId) async {
    if (loading) return ResultItem(item: shipment);

    loading = true;

    this.errorResult = null;
    retryFunc = null;
    setState(() {});
    editShipmentState.reload();
    Future<ResultItem<Shipment>> future =
        ResultItem.of(Api().get("shipments/$shipmentId"), (data) {
      return Shipment.fromJSON(data);
    }, timeout: 15);
    ResultItem<Shipment> resultItem;
    future.then((result) async {
      resultItem = result;
      if (result.hasError) {
        this.errorResult = result.error;
        this.shipment = null;
        retryFunc = () => getShipment(shipmentId);
      } else {
        this.shipment = result.item;
        retryFunc = null;
        await BranchProvider.syncAddressWithBranch(
            scaffoldKey.currentContext, [shipment.from, shipment.to]);
      }
      editShipmentState.update(result.item, result.error);
      this.errorResult = result.error;
    }).catchError((onError) {
      if (onError is ErrorResult) {
        errorResult = onError;
        editShipmentState.error = onError;
      }

      throw onError;
    }).whenComplete(() {
      loading = false;
      Config.log("update state", runtimeType);
      setState(() => {});

      return resultItem;
    });

    return future;
  }

  static Future<ResultItems<TinyShipment>> _getLoadMore(
      LoadArgs loadArgs, int offset) async {
    Map<String, dynamic> args = Map.of(loadArgs.args);

    args['offset'] = offset;
    Future<ResultItems<TinyShipment>> result = ResultItems.of(
        Api().post("shipments/list", data: args),
        (data) => TinyShipment.fromJSON(data),
        timeout: 15);
    //final ResultItems<Shipment> result = await repo.getShipmentsWith(args);
    return result;
  }

  static LoadMore<TinyShipment> getShipmentLoadMore(
      Map<String, dynamic> args, LoadMoreNotify<TinyShipment> onLoadMore) {
    LoadArgs loadArgs = LoadArgs(args: args);
    var loadMore = LoadMore<TinyShipment>(loadArgs,
        loadMoreProvider: _getLoadMore, onLoadMore: onLoadMore);

    return loadMore;
  }

  static Future<ResultItems<TinyShipment>> _getInLoadMore(
      LoadArgs loadArgs, int offset) async {
    Map<String, dynamic> args = Map.of(loadArgs.args);

    args['offset'] = offset;
    Future<ResultItems<TinyShipment>> result = ResultItems.of(
        Api().post("deliveries/list", data: args),
        (data) => TinyShipment.fromJSON(data),
        timeout: 15);
    //final ResultItems<Shipment> result = await repo.getShipmentsWith(args);
    return result;
  }

  static LoadMore<TinyShipment> getInShipmentLoadMore(
      Map<String, dynamic> args, LoadMoreNotify<TinyShipment> onLoadMore) {
    LoadArgs loadArgs = LoadArgs(args: args);
    var loadMore = LoadMore<TinyShipment>(loadArgs,
        loadMoreProvider: _getInLoadMore, onLoadMore: onLoadMore);

    return loadMore;
  }

  Future<ResultItems<Package>> getPackages(Address from, Address to) async {
    bool exactAddressValid = from.validId && to.validId;
    Map<String, dynamic> args = {
      'from_address': exactAddressValid
          ? from.id
          : {'country': from.country.code, 'city': from.city.id},
      'to_address': exactAddressValid
          ? to.id
          : {'country': to.country.code, 'city': to.city.id}
    };

    debugPrint("getPackages: $args");
    return ResultItems.of(
            Api().post("shipments/packages", data: args, withAuth: false),
            (data) => Package.fromJSON(data),
            timeout: 20)
        .then((value) {
      print("Getting packages: $value");
      ResultItems<Package> packages = value;
      if (!packages.hasError) {
        this.packages = packages;
        shipment.package = this.packages.length > 0
            ? this.packages.items[0]
            : Package.fromJSON({});
      } else {
        print("Error: ${packages.error}");
      }
      return packages;
    });
  }

  Future<ResultItems<Rate>> getRates() async {
    Address from = shipment.from;
    Address to = shipment.to;
    Package package = shipment.package;
    double weight = shipment.weight;
    double cod = shipment.cod;
    shipment.rate = null;
    final exactAddressValid = from.validId && to.validId;
    Map<String, dynamic> args = {
      'from_address': exactAddressValid
          ? from.id
          : {'country': from.country.code, 'city': from.city.id},
      'to_address': exactAddressValid
          ? to.id
          : {'country': to.country.code, 'city': to.city.id},
      'parcels': [
        {'qty': 1, 'weight': weight}
      ],
      'package_type': package.code,
      if (package.isWeight) 'weight': weight,
      if (package.hasCod) 'cod': cod,
      if (package.hasCod) 'cod_currency': shipment.codCurrency
    };

    this.rates.clear();
    print("Request Rate: ${args}");
    return ResultItems.of(
        Api().post("shipments/rates", data: args, withAuth: false),
        (data) => Rate.fromJSON(data)).then((value) {
      rates = value;
      return rates;
    });
  }

  Future<ResultItem<Shipment>> save(
      Shipment shipment, BuildContext context) async {
    if (!edit) return null;
    this.errorResult = null;
    Map args = shipment.toMap();
    if (!shipment.package.hasCod) {
      args.remove('cod');
      args.remove('codCurrency');
    }
    if (!shipment.package.isWeight) {
      args.remove('weight');
    }
    args['service'] = shipment.rate.code;

    print("Will save shipment: $args");
    setState(() {
      loading = true;
    });

    var request = shipment.valid
        ? Api().put("shipments/${shipment.id}", data: args)
        : Api().post("shipments", data: args);

    Future<ResultItem<Shipment>> result = ResultItem.of(
        request, (data) => Shipment.fromJSON(data),
        printResult: true);

    ResultItem<Shipment> resultItem;
    return result.then((newShipmentResult) {
      resultItem = newShipmentResult;
      if (!resultItem.hasError) {
        setState(() {
          this.shipment = resultItem.item;
          editShipmentState.reset();
          loading = false;
        });
        editShipmentState.reset();
        shipmentMetaLoadState.reset();
        workingTimesLoadState.reset();
        _changeNotifier.value = _changeNotifier.value + 1;
      } else {
        errorResult = resultItem.error;
        _onError(this.errorResult);
      }
      return resultItem;
    }, onError: _onError).whenComplete(() {
      loading = false;
      return resultItem;
    });
  }

  void changeState(fn) {
    setState(fn);
  }

  void validate(int pageIndex, BuildContext context) {
    Shipment shipment = this.shipment;
    if (_old == null) {
      _old = Shipment.fromJSON({});
    }
    this.pageIndex = pageIndex;
    retryFunc = null;
    errorWidget = null;
    errorResult = null;
    if (pageIndex == 0) {
      if (loading) {
        print("Currentlly loading!!");
        return;
      }
      bool addressValid = edit
          ? shipment.from.valid && shipment.to.valid
          : shipment.from.city.valid && shipment.to.city.valid;

      bool pickupChanged = _old.from.city.id != shipment.from.city.id;
      bool cityChanged =
          pickupChanged || _old.to?.country?.id != shipment.to?.country?.id;

      bool currentValid = valid;
      print("addressValid: $addressValid, cityChanged:$cityChanged");
      print("G");
      if ((addressValid && cityChanged) || (packages.isEmpty && addressValid)) {
        print("Shipment valid stage 0");
        if (pickupChanged) {
          shipment.pickupDate = null;
          shipment.pickupTime = null;
        }
        if (cityChanged) {
          if (packages != null) packages.clear();
        }
        currentValid = false;
        retryFunc = () {
          loading = true;
          errorWidget = null;
          errorResult = null;
          setState(() {});
          getPackages(shipment.from, shipment.to).then((value) {
            print("Has Loading : ${value}");
            if (!value.hasError) {
              valid = !edit ||
                  (shipment.pickupTime != null && shipment.pickupDate != null);
              _success();
            } else {
              _onError(
                value.error,
              );
            }
          }, onError: _onError).whenComplete(_onComplete);
        };
        retryFunc();
      } else if (!edit) {
        currentValid = addressValid && !packages.isEmpty;
      } else if (shipment.pickupTime != null && shipment.pickupDate != null) {
        if (_old.pickupTime.start != shipment.pickupTime.start ||
            _old.pickupTime.end != shipment.pickupTime.end ||
            _old.pickupDate != shipment.pickupDate) {
          shipment.copyTo(_old);
        }
        currentValid = addressValid;
      } else {
        currentValid = false;
      }
      if (currentValid != valid) {
        errorWidget = null;
        retryFunc = null;
        errorResult = null;
        valid = currentValid;
        _trigger();
      }
      if (!valid) {
        _trace();
      }
    } else if (pageIndex == 1) {
      bool valid,
          validPkg,
          validQty,
          validWeight,
          validMaxItems,
          valiCod,
          valiContent;
      valid = validPkg = validQty =
          validWeight = validMaxItems = valiCod = valiContent = false;
      if (shipment.package.valid) {
        Package p = shipment.package;
        int qty = p.qty;
        validPkg = true;
        shipment.qty = 1;
        validQty = true;

        if (!p.isWeight ||
            (shipment.hasWeight &&
                (!p.hasMaxWeight || shipment.weight <= p.weight))) {
          validWeight = true;
        }

        if (!p.hasCod || !shipment.hasCod || shipment.cod <= p.maxCod) {
          valiCod = true;
        }
        if (!edit ||
            (shipment.content != null && shipment.content.length >= 4)) {
          valiContent = true;
        }
      }
      print(
          "validWeight: $validWeight, valiCod: $valiCod, valiContent: $valiContent");
      valid = validQty && validWeight && valiCod && valiContent;

      if (valid != this.valid) {
        this.valid = valid;
        _trigger();
      }
    } else if (pageIndex == 2) {
      this.pageIndex = 2;
      bool currentValid = valid;
      if (_old.cod != shipment.cod ||
          _old.codCurrency != shipment.codCurrency ||
          _old.weight != shipment.weight ||
          _old.package != shipment.package ||
          _old.parcelCount != shipment.parcelCount ||
          rates.isEmpty) {
        rates.clear();
        shipment.rate = Rate.EMPTY;
        currentValid = !edit;
        if (!loading) {
          retryFunc = () {
            loading = true;
            errorWidget = null;
            errorResult = null;
            setState(() {});

            getRates().then((value) {
              print("Has Loading : ${value}");
              if (!value.hasError) {
                //valid = true;
                _success();
              } else {
                _onError(
                  value.error,
                );
              }
            }, onError: _onError).whenComplete(_onComplete);
          };
          setState(() {
            loading = true;
          });
          Future.delayed(Duration(milliseconds: 200), retryFunc);
          //Future.delayed(Duration(seconds: 10), retryFunc);
          //return;
        }
      } else {
        if (shipment.rate?.valid == true) {
          currentValid = true;
        }
      }
      if (currentValid != valid) {
        valid = currentValid;
        _trigger();
      }
    }
  }

  void _trace() {
    if (shipment == null) return;
    if (!shipment.from.valid) print("Address from not valid!");
    if (!shipment.to.valid) print("Address to not valid!");

    final pt = shipment.pickupTime;

    if (shipment.pickupDate == null) print("PickupDate is not valid!");
  }

  void codChanged() {}

  String validateInput(String name, String input) {
    print("validate $name:$input");
    if (name == "weight") {
      final value = double.tryParse(input);
      if (value == null || value == 0) return "Weight is not valid";
      if (shipment.package.hasMaxWeight && value > shipment.package.weight) {
        return "The maximum weight must be ${shipment.package.weight} KG";
      }
      return null;
    } else if (name == "cod") {
      final value = double.tryParse(input);
      if (value == null) return null;
      Map<String, double> currencies = shipmentMetaLoadState.value.currencies;
      final currencyRate = currencies[shipment.codCurrency] ?? 1;
      final codValue = value / currencyRate;
      if (shipment.package.hasCod && codValue > shipment.package.maxCod) {
        return "The maximum amount must be ${shipment.codCurrency} ${shipment.package.maxCod * currencyRate}";
      }
      return null;
    } else if (name == "content") {
      if (input == null || input.trim().length < 4)
        return tr.form.minErrorText(4);
    }
    return null;
  }

  void _success() {
    retryFunc = null;
    errorWidget = null;
    errorResult = null;
    shipment.copyTo(_old);
    loading = false;
    _trigger();
  }

  void _onError(error) {
    print("Error loading : $error");
    if (error is! ErrorResult) error = new ErrorResult(code: 0, message: error);
    showSnackBar(
      context,
      error: error,
    );
    if (loading) {
      loading = false;
      setState(() {});
    }
  }

  void _onComplete() {
    if (loading) {
      loading = false;
      setState(() {});
    }
  }

  void _trigger() {
    setState(() => {});
  }

  getTrackingSteps(BuildContext context) {}

  createCheckout() {
    CartController ctr = new CartController();
    ctr.addCartItem(shipment.id, shipment.name, 'shipments', '').then((value) {
      if (ctr.error != null) {
        showSnackBar(
          scaffoldKey.currentContext,
          error: ctr.error,
        );
      } else {
        Navigator.of(scaffoldKey.currentContext).pushNamed("/Cart");
      }
    });
  }
}
