import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/api.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/oppwa/oppwa.dart';

import '../../i18n/i18n.dart';
import '../config.dart';
import '../models/cart.dart';
import '../models/model.dart';
import '../models/payment_method.dart';
import '../models/route_argument.dart';
import '../theme/text_styles.dart';
import '../widgets/CreditCardCVVSheetWidget.dart';
import '../widgets/SmbWidget.dart';

ValueNotifier<Cart> currentCart = new ValueNotifier(null);
ValueNotifier<Transaction> currentTx = new ValueNotifier(null);

class CartController extends ControllerMVC {
  Cart cart = currentCart.value != null ? currentCart.value : Cart();
  bool loading = false;
  ErrorResult error;
  ScaffoldState scaffoldState;
  ResultItems<PaymentMethod> paymentMethods = ResultItems();
  String message;
  ValueNotifier<String> paymentStatus = ValueNotifier(null);
  OverlayEntry loader;
  bool _isRequest = false ;
  CartController() {
    if (cart.type == null)
      loadCart();
  }

  void initState() {
    super.initState();
    scaffoldState = context.findAncestorStateOfType<ScaffoldState>();
    currentCart.addListener(_onChange);
    if (this.scaffoldState != null)
      loader = Helper.overlayLoader(this.scaffoldState);
  }

  void dispose() {
    super.dispose();
    currentCart.removeListener(_onChange);
  }

  void _onChange(){
    loading = false;
    cart = currentCart.value != null ? currentCart.value : Cart();
    setState(() {});
  }


  Future<void> addCartItem(int id, String name, String type, String route) {
    if (loading)
       return Future<void>.value();
    if (cart.type != type || cart.route != route){
      cart = Cart.fromJSON({'type': type, 'route': route, 'items': [{'id': id, 'name':name }]});
    }
    setState(() {loading = true; message= null; error= null;});
    return _updateCart(ResultItem.of<Cart>(Api().post("${type}/cart_add", data: {'ids': [id], 'route': route}),
            (res) => Cart.fromJSON(res)));
  }

  Future<void> removeCartItem(CartItem item){
    if (cart == null || cart.items == null || cart.items.isEmpty){
      return Future<void>.value();
    }
    List<int> ids = item == null ? cart.items.map((e) => e.id).toList() : [item.id];
    cart.items.remove(item);
    setState(() {loading = true; message= null; error= null;});
    return _updateCart(ResultItem.of<Cart>(Api().post("${cart.type}/cart_remove", data: {'ids': ids, 'route': cart.route}),
            (res) => Cart.fromJSON(res)));
  }

  Future<void> loadCart() async{
    if (loading)
      return Future<void>.value();
    setState(() {loading = true;});
    String type = cart.type != null ? cart.type : 'app';
    return _updateCart(ResultItem.get<Cart>("${type}/cart",
           func:  (res) => Cart.fromJSON(res)));
  }

  Future<void> requestCart(Cart cart, int id) async{
    if (loading)
      return Future<void>.value();
    currentCart.value = this.cart = cart;
    _isRequest = true;
    setState(() {loading = true;});
    String type = cart.type != null ? cart.type : 'app';
    return _updateCart(ResultItem.post<Cart>("${type}/cart",
        data: {'id': id},
        func:  (res) => Cart.fromJSON(res)));
  }

  void setPaymentMethod(BuildContext context, PaymentMethodItem item) {
    PaymentCard card = item.ref is PaymentCard ?  item.ref as PaymentCard : null;
    PaymentMethod method = card != null ? card.method : item.ref as PaymentMethod;
    method.defaultCart = card;
    cart.paymentMethod = item;
  }

  Future<void> _updateCart(Future<ResultItem<Cart>> cartResult){
    error = null;
    return cartResult.then((ResultItem<Cart> result) {
      print("_updateCart: ${result.data}");
      if (!result.hasError){
        result.item.paymentMethod = cart.paymentMethod != null ? cart.paymentMethod : result.item.paymentMethod;
        cart = currentCart.value = result.item;
      } else {
        error = result.error;
        currentCart.value = cart;
      }
    });
  }

  void goCheckout(BuildContext context, PaymentMethodItem item) {

    PaymentCard card = item.ref is PaymentCard ?  item.ref as PaymentCard : null;
    PaymentMethod method = card != null ? card.method : item.ref as PaymentMethod;
    cart.paymentMethod = card != null ? item : cart.paymentMethod;

    setState(() {error = null; message = null;});

    Map<String, dynamic> data = {
      'acquirer_id': int.parse(method.id),
      'ids': cart.items.map((e) => e.id).toList(),
      'with_tokens': false,
      'with_pm': false
    };

    if (card != null){
      data['payment_token_id'] = int.parse(item.id);
    }
    data['route'] = cart.route;

    _showLoading();

    ResultItem.of<dynamic>(Api().post("${cart.type}/checkout",data: data), null)
        .then((ResultItem<dynamic> result){

      if (!result.hasError) {
        print("checkout result: ${result.item}");
        print("notification_url: ${result.item['notification_url']}");
        Transaction tx = result.item['tx'] != null ? Transaction.fromJSON(result.item['tx']) : null;
        Cart txCart = result.item['cart'] != null ? Cart.fromJSON(result.item['cart']) : null;
        txCart.paymentMethod = item;
        setState(() {
          loading = false;
          message = tx == null ? "Warning: Cart was updated" : null;
        });
        //currentCart.value = txCart;
        _setTransaction(tx, txCart);

      } else {
        print("Receive error post checkout with data: ${data}");
        setState(() {
          loading = false;
          error = result.error;
        });
        currentTx.value = null;
      }
    }).whenComplete(_hideLoading);
  }

  void _setTransaction(Transaction tx, Cart txCart){
    currentTx.value = tx;
    if (tx != null) {
        String status = tx.status;
        paymentStatus.value = status;
        if(status != 'error' && tx.provider == 'hyperpay'){
          Map<String, dynamic> data = {
            'checkoutId': tx.checkoutId,
            'brand': tx.brands,
            'amount': tx.mode == 'test' ? tx.amount?.toInt()?.toDouble() : tx.amount,
            'currency': tx.currency,
            'mode': tx.mode == 'test'? 'TEST' : 'LIVE',
            'type': 'ReadyUI',
            'country': tx.country
          };
          if (txCart.paymentMethod.ref is PaymentCard){
            PaymentCard card = cart.paymentMethod.ref as PaymentCard;
            data.addAll({
              'type': 'token',
              'tokenId': card.ref,
              'cvv': card.cvv
            });
          }
          Config.log("Send Oppwa checkout: $data");
          Oppwa.checkout(data).then((value) {
            print("Oppwa checkout result: ${value}");
            if (value is Map) {
              String status = value['status'];
              setState(() {
                paymentStatus.value = status;
                message = value['message']??null;
              });
              if (status == 'sync' || status == 'success') {
                setPaymentMethod(context, txCart.paymentMethod);
                _checkPaymentStatus(tx, status);
              }
              else if (status == 'redirect') {
                tx.redirectUrl = message;
                _transactionRedirect(tx, message);
                message = null;
              }
              else {
                tx.message = value['message'] ?? null;
                _transactionFailed(tx, status);
              }
            }
          },
          onError:(error, stackTrace){
            Config.error(error, stackTrace, runtimeType);
            paymentStatus.value = 'error';
            tx.message = '$error';
            _transactionFailed(tx, 'error');
          });
       } else {
          setState(() {
            paymentStatus.value = tx.status;
            message = tx.message;
          });

          if (status == 'done' || status == 'pending') {
            _transactionSuccess(tx, status);
          } else{
            _transactionFailed(tx, status);
          }
        }
    }

  }

  void _checkPaymentStatus(Transaction tx, String status){
    String resourcePath =  message;
    setState(() {loading = true; error = null; message = null;});

    if (resourcePath != null){
      Api().get("payment/hp/result", data: {"txId": tx.id.toString(), "resourcePath": resourcePath})
          .then((value) {
            print("Send Payment resourcePath: ${value.body}");
          })
          .whenComplete(() => _getPaymentStatus(tx, status));
    } else {
      _getPaymentStatus(tx, status);
    }

  }
  void _getPaymentStatus(Transaction tx, String status){
    _getPaymentStatus0(tx, status, 1);
  }

  void _getPaymentStatus0(Transaction tx, String status, int retry){

    Future<ResultItem<dynamic>> result = ResultItem.get<dynamic>("payments/status/poll?id=${tx.id}");

    result.then((result){
      print("PaymentStatus: ${result.item}");
      if (!result.hasError) {
           dynamic item = result.item;
           bool success = item['success']??false;
           String error = item['error'];
           if (success){
             List<dynamic> transactions = item['transactions']??[];
             transactions.forEach((element) {
               if (element['id'] == tx.id){
                   String state = element['state'];
                   tx.update(element);
                   if ((state == 'pending' || state == 'done')){
                     _transactionSuccess(tx, state);
                   } else if (state == 'cancel' || state == 'error'){
                     _transactionFailed(tx, state, false);
                   }
               }
             });
           } else if (error != null){
             if (error == 'tx_process_retry'){
               if (retry < 5) {
                 Future.delayed(Duration(seconds: 3), () =>
                     _getPaymentStatus0(tx, status, retry + 1));
                 return;
               } else {
                 result.error = ErrorResult.tryError("Unable to get payment status!");
               }
             } else if (error == 'no_tx_found'){
               loadCart();
               error = "No transaction for this cart";
               result.error = ErrorResult.tryError("No transaction for current cart!");
              }

             else {
               result.error = ErrorResult.tryError(error);
             }
           }
      }
      _showSnackBar(result.error);

      setState(() {
        loading = false;
      });
    });
  }

  void _transactionSuccess(Transaction tx, String status){
    if (this.scaffoldState != null && !_isRequest){
      Navigator.of(scaffoldState.context).pop();
    }

  }

  void _transactionFailed(Transaction tx, String status, [bool fromUi=true]){
    if (status == 'failed' || status == 'error') {
      _showSnackBar(tx.message );
    }
    if (status == 'cancel'){
      _showSnackBar(tx.message );
      if (scaffoldState != null && !_isRequest)
        Navigator.of(scaffoldState.context).pop();
    }
  }

  void _transactionRedirect(Transaction tx, String redirect) async{
    /*
    Object result = await Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => HyperpayPaymentWidget(url: redirect, cart: cart, tx: tx)));
    */
    print("_transaction Redirect: ${redirect}");
  }

  void _showLoading(){
    if (loader != null && scaffoldState != null){
      Overlay.of(scaffoldState.context).insert(loader);
    }
  }
  void _hideLoading(){
    if (loader != null) {
      Helper.hideLoader(loader);
    }
  }

  void _showSnackBar(dynamic message){
    Config.log("_showSnackBar: $message", runtimeType);
    if (message != null && scaffoldState != null)
      showSnackBar(
        scaffoldState.context,
        error: message,
        showTitle: false,
        duration: Duration(seconds: 10),
    );
  }

  void showPaymentCardCVVSheetWidget(BuildContext context) async {
    final navigator = context.findAncestorStateOfType<NavigatorState>();
    final parentContext = context;

    final scaffoldState = context.findAncestorStateOfType<ScaffoldState>();

    //AnimationController animationController = BottomSheet.createAnimationController(navigator);
    double oldAnimValue = 0;
    GlobalKey<FormState> formKey = new GlobalKey<FormState>();
    GlobalKey<State> stateKey = new GlobalKey<State>();
    ValueNotifier csvValueNotifier = ValueNotifier("");
    await showModalBottomSheet(
      context: parentContext,
      isDismissible: false,
      isScrollControlled: true,
      useRootNavigator: false,
      //transitionAnimationController: animationController,
      enableDrag: false,
      builder: (context) {
        return LayoutBuilder(
            key: stateKey,
            builder: (context, box) {
              final mq = MediaQuery.of(context);

              return SafeArea(
                  //maintainBottomViewPadding: true,
                  minimum: EdgeInsets.only(bottom: mq.viewInsets.bottom),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(width: 10,),
                            Text(tr.payment_options, style: TextStyles.title,),
                            const Spacer(),
                            InkWell(
                              child: Icon(Icons.close),
                              onTap: () {
                                csvValueNotifier.dispose();
                                //animationController.dispose();
                                Navigator.of(context).pop();
                                //FocusScope.of(context).unfocus();

                              },
                            ),
                            const SizedBox(width: 10,)
                          ],
                        ),
                      ),
                      Divider(height: .5,),
                      CreditCardCVVSheetWidget(
                        onChange: (){
                          csvValueNotifier.value = (cart.paymentMethod.ref as PaymentCard).cvv;
                          print("csvValueNotifier: ${csvValueNotifier.value}") ;
                        },
                        formKey: formKey,
                        paymentCard: cart.paymentMethod.ref as PaymentCard,
                        cardNumberDecoration: InputDecoration(
                            labelText: 'Card number',
                            hintText: 'XXXX XXXX XXXX XXXX',
                            isDense: true,
                            contentPadding: const EdgeInsets.all(10),
                            prefix: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: CachedNetworkImage(
                                imageUrl: cart.paymentMethod.icon,
                                placeholder: (context, url) => CircularProgressIndicator(),
                                errorWidget: (context, url, error) => Icon(Icons.credit_card) ,
                                width: 24,
                                height: 24,
                              ),
                            )
                        ),
                      ),
                      ValueListenableBuilder(
                          valueListenable: csvValueNotifier,
                          builder: (context, value, child) => Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                        child: Text(
                                          "Pay Now",
                                          //style: TextStyles.title.copyWith(color:LightColor.white),
                                        ),
                                        style: ElevatedButton.styleFrom(
                                            shape: RoundedRectangleBorder()
                                        ),
                                        onPressed: value?.length == 3
                                          ? (){
                                            if (formKey.currentState.validate()){
                                              csvValueNotifier.dispose();
                                              //animationController.dispose();
                                              Navigator.of(context).pop();
                                              goCheckout(parentContext, cart.paymentMethod);
                                            }
                                        }
                                        : null
                                    ),
                                  )
                                ],
                          ),
                      )

                    ],
                  )
              );
            }
        );
      },
    );
    //csvValueNotifier.dispose();
    //animationController.dispose();
  }

}
