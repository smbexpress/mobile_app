import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:smbex_app/src/screens/profile_field.dart';

import '../../i18n/i18n.dart';
import '../helpers/helper.dart';
import '../models/account.dart';
import '../models/address.dart';
import '../models/model.dart';
import '../repository/account_repository.dart' as repository;
import '../widgets/SmbWidget.dart';

class AccountController extends ControllerMVC {
  Account account = new Account();
  bool hidePassword = true;
  bool loading = false;
  GlobalKey<FormState> loginFormKey;
  GlobalKey<ScaffoldState> scaffoldKey;
  OverlayEntry loader;
  List<Country> countries;
  List<Region> regions;
  ErrorResult error;
  AccountController() {
    account = repository.currentAccount.value;
    loader = Helper.overlayLoader(context);
    loginFormKey = new GlobalKey<FormState>();
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  void login() async {
    _doSave("login");
  }

  void register() async {

    if (account.mobile == null){
      Navigator.of(scaffoldKey.currentContext).pushReplacementNamed("/Login", arguments: 0);
    } else {
      _doSave("register");
    }
  }

  void regPassword(){
    if (loginFormKey?.currentState?.validate() == true) {
      loginFormKey.currentState.save();
      account.action = Account.ACT_REG_PASSWORD;
      Navigator.of(scaffoldKey.currentContext).pushReplacementNamed("/SignUp2");
    }
  }


  void verify() {
    _doSave("verify");
  }

  void verify2() {
    _doSave("verify2");
  }

  void resetPassword() {
    _doSave("forget");
  }

  void forget() {
    print("forget");
    _doSave("forget");
  }

  void test() {
    print("test");
    _doSave("test");
  }

  void confirm() {
    print("controllr:confirm: ${account.action}");
    if (account.action == Account.ACT_FORGET) {
        print("save forget");
        forget();
    }else{
      _doSave("confirm");
    }

  }

  void logout() {
    _doSave("logout");
    repository.logout().then((value) => null);
    Helper.hideLoader(loader);
    Navigator.of(scaffoldKey.currentContext).pushReplacementNamed('/Page', arguments: 2);
  }

  void complete() {
    FocusScope.of(context).unfocus();
    if (loginFormKey.currentState?.validate() == true) {
      loginFormKey.currentState.save();
      ///Overlay.of(context).insert(loader);

      if (account.action == Account.ACT_REGISTER){
        updateAction(Account.ACT_REG_PASSWORD);
        Navigator.of(scaffoldKey.currentContext).pushReplacementNamed("/SignUp");
        print("Goto to password");
      }
      else if (account.action == Account.ACT_REG_PASSWORD){
        _doSave("register");
      }
      else if (account.action == Account.ACT_UPDATE){
        ///Navigator.of(context).popAndPushNamed("SignUp");
      }
      else if (account.action == Account.ACT_REGISTER){
        ///Navigator.of(context).popAndPushNamed("SignUp");
      }
    }

  }
  void _doSave(String action){
    if (loading)
      return;
    loading = true;
    FocusScope.of(context).unfocus();
    if (loginFormKey.currentState?.validate() == true) {
      loginFormKey.currentState.save();
      Overlay.of(scaffoldKey.currentContext).insert(loader);
      _doSend(action);
    }
  }

  Future<ResultItem<Account>> _doSend(String action){
      print("Account doSend: $action");
      Future<ResultItem<Account>> result = null;
      String toPage = null;
      int args = 0;
      switch(action){
        case "login":
          result = repository.login(account);
          break;
        case "register":
          result = repository.register(account);
          break;
        case "test":
          result = repository.test(account);
          break;
        case "verify":
          result = repository.verify(account);
          break;
        case "forget":
          result = repository.forget(account);
          account.password = 'forget';
          break;
        case "confirm":
          result = repository.confirm(account);
          break;
        default:
          result = repository.login(account);
      }
      error = null;
      result.then((value) async{
        print("*********Controller account received*********:${value.data}");
          if(value.hasError){
            if (action == 'verify' && value.error.code == 100){
              updateAction(Account.ACT_REGISTER);
              toPage = "/SignUp";
              Navigator.of(scaffoldKey.currentContext)
                  .pushReplacementNamed(toPage);
            } else {
              showSnackBar(scaffoldKey?.currentState.context,
                error: value.error,
              );
              setState(() {
                error = value.error;
              });
            }
          } else {

            final otpSent = value.data['otp_sent'];
            final passPassword = value.data['use_password'] ?? false;
            Account newAccount = repository.currentAccount.value;
            this.account = newAccount;

              if (otpSent == true){
                account.otp = value.data['otp'];
                toPage = "/Verify";
                updateAction(action == 'forget' ? Account.ACT_UPDATE_FORGET_PASSWORD : Account.ACT_VERIFY);
              }
              else if (passPassword == true) {
                updateAction(Account.ACT_LOGIN_PASSWORD);
                toPage = "/Login";
              }
              else if (account.exists && account.verified){
                if (account.action == Account.ACT_UPDATE_FORGET_PASSWORD){
                  updateAction(account.action == Account.ACT_UPDATE_FORGET_PASSWORD ?
                       Account.ACT_UPDATE_FORGET_PASSWORD : Account.ACT_UPDATE_PASSWORD);
                  toPage = "/Reset";
                }
                else if (account.valid){
                  updateAction(Account.ACT_NORMAL);
                  print("Goto to login: ${account.id}");
                  toPage = "/Home";
                  args = 2;
                }
                else {
                  updateAction(Account.ACT_LOGIN_PASSWORD);
                  toPage = "/Login";
                }
              }
              else if (!account.verified){
                if ("test" == action){
                  return _doSend('confirm');
                }
              }
              else if (!account.exists){
                if (account.verified){
                  updateAction(Account.ACT_REGISTER);
                  toPage = "/SignUp";
                } else {
                  return _doSend('confirm');
                }
              }
              else {
                if (!account.valid){
                  print("Goto to login: ${account.id}");
                  toPage = "/Home";
                  args = 2;
                } else {
                  print("Account Valid: ${account.valid}");
                  updateAction(Account.ACT_NORMAL);
                  toPage = "/Home";
                  args = 2;
                }

              }

              if (toPage == null){
                toPage = "/Home";
                args = 2;
              }

              print("Redirect to: $toPage");
            Navigator.of(scaffoldKey.currentContext)
                .pushReplacementNamed(toPage, arguments: args);
          }
          Helper.hideLoader(loader);
          loading = false;
          return value;
      }, onError: (e, stack) {
        Helper.hideLoader(loader);
        loading = false;
        debugPrintStack(stackTrace: stack, label: e.toString());
      }).whenComplete(() {
        Helper.hideLoader(loader);
        loading = false;
      });

  }


  void update(int action, [Map<String,dynamic> data=null]) {

    FocusScope.of(context).unfocus();
    if (loginFormKey.currentState?.validate() == true) {
      loginFormKey.currentState.save();
      data = data?? _getSavedData(action);
      if (data == null)
          return;
        loading = true;
      Overlay.of(context).insert(loader);
      repository.updateWithData(data).then((value)  {
        if (value.hasError){
          showSnackBar(context, error: value.error);
        } else {
          if (value.data['email_sent'] == true){
            showSnackBar(context,
                showTitle: false,
                message: tr.verifyYourEmail,
                contentType: ContentType.INFO
            );
          } else {
            showSnackBar(context,
                title: tr.done,
                message: tr.profile_settings_updated_successfully,
                contentType: ContentType.SUCCESS
            );

          }

        }
      }).whenComplete(() => {
          Helper.hideLoader(loader),
          loading = false
      });
    }
  }

  void updateAction(int action){
    account.action = action;
  }

  Map<String,dynamic> _getSavedData(int action) {
      switch (action) {
        case Account.ACT_UPDATE_NAME:
          return {'name': account.name};
        case Account.ACT_UPDATE_PASSWORD:
          return {'password': account.password};
        case Account.ACT_UPDATE_EMAIL:
          return {'email': account.email};
        case Account.ACT_UPDATE_MOBILE:
          return {'mobile': account.mobile};

      }
  }

}
