import 'package:mvc_pattern/mvc_pattern.dart';

import '../../src/repository/slider_repository.dart';
import '../models/model.dart';
import '../models/slider.dart';

class SliderController extends ControllerMVC {
  List<Slider> sliders = <Slider>[];

  SliderController() {
    listenForSliders();
  }

  void listenForSliders({String message}) async {
    getSliders().then((ResultItems<Slider> _slider) {
      setState(() {
        if (_slider.items != null)
          sliders.addAll(_slider.items) ;
      });
    });
  }

  Future<void> refreshSliders() async {
    sliders.clear();
    listenForSliders(message: 'Sliders refreshed successfully');
  }
}
