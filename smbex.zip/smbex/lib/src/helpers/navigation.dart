import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum NavigationRouteStyle {
  cupertino,
  material,
}

class Navigation {
  static Future<T> navigateTo<T>({
    @required BuildContext context,
    @required Widget screen,
    NavigationRouteStyle style,
  }) async {
    Route route;
    style ??= defaultTargetPlatform == TargetPlatform.iOS ? NavigationRouteStyle.cupertino :  NavigationRouteStyle.material;
    if (style == NavigationRouteStyle.cupertino) {
      route = CupertinoPageRoute<T>(builder: (_) => screen);
    } else {
      route = MaterialPageRoute<T>(builder: (_) => screen);
    }

    return await Navigator.push<T>(context, route);
  }

}