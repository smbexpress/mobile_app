import 'package:http/http.dart';

String getNetworkException(Response response){
  String msg = null;

  switch (response.statusCode) {
    case 400:
    case 401:
    case 403:
      msg = "NetworkExceptions.unauthorisedRequest()";
      break;
    case 404:
      msg = "NetworkExceptions.notFound()";
      break;
    case 409:
      msg = "NetworkExceptions.conflict()";
      break;
    case 408:
      msg = "NetworkExceptions.requestTimeout()";
      break;
    case 500:
      msg = "NetworkExceptions.internalServerError()";
      break;
    case 503:
      msg = "NetworkExceptions.serviceUnavailable()";
      break;
    default:
      var responseCode = response.statusCode;
      msg = "Received invalid status code: $responseCode";
  }

  if (response.reasonPhrase != null){
    msg = response.reasonPhrase + ":" +msg;
  }

  return msg;
}