import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:vector_math/vector_math.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:html/parser.dart';
import 'package:intl/intl.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/models/app.dart';
import 'package:smbex_app/src/models/model.dart';
import 'package:smbex_app/src/models/shipment.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../repository/settings_repository.dart';
import '../widgets/CircularLoadingWidget.dart';
//import 'dart:mirrors';

class Helper
{

  static isError(dynamic data) {
    return !isSuccess(data);
  }

  static isSuccess(dynamic data) {
    if (data is Map) {
      return ((data['success'] as bool) ?? false);
    }
    return (data is bool && data as bool);
  }


  static String getError(dynamic data, {bool nullIfNotDebug=false, String fallback}) {
    if (nullIfNotDebug && !Config.isDebug)
      return data is String ? data : fallback;

    if (!Config.isDebug && fallback != null)
      return fallback;

    print(data);
    String error;
    dynamic code;
    if (data is Map) {
        Object err = data['error']??null;
        if (err is String){
          error = err;
        }
        else if (err is Map){
          error =  err['message'];
        }
        else if (data['message'] is String){
          error =  data['message'];
          code = data['code'];
        }
        final fieldsError = data['fields']?.map((f) => getError(f))?.toList()?.join('\n');
        if (fieldsError != null){
          error = '$error\n$fieldsError';
        }
    } else if (data is String) {
      error = data;
    } else if (data is ErrorResult) {
      ErrorResult errResult = data;
      error = getError(errResult.message)??'';
      if (errResult.hasFields){
        if (errResult.fields is List){
          List ss = errResult.fields;
          ss.forEach((element) {
            if (element is Map){
              Map eMap = element;
              error += '\n${eMap['label']}:  ${eMap['message']}';
            } else{
              error += "\n$element";
            }
          }) ;
        } else {
          Map eMap = errResult.fields;
          eMap.forEach((key, value) {
            error += "\n$value";
          });
        }
      }
    } else if(data != null){
       error = data.toString();
    } else {
       error = '';
    }

    return error;
  }

  // for mapping data retrieved form json array
  static getData (Map<String, dynamic> data) {
    return data['data'] ?? [];
  }


  static int getIntData (Map<String, dynamic> data) {
    return (data['data'] as int) ?? 0;
  }

  static int getIntVar (Map<String, dynamic> data, String key) {
    return (data[key] as int) ?? 0;
  }

  static bool getBoolData (Map<String, dynamic> data) {
    return (data['data'] as bool) ?? false;
  }

  static getObjectData (Map<String, dynamic> data) {
    return data['data'] ?? new Map<String, dynamic>();
  }

  static Future<Uint8List> getBytesFromAsset (String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(
        data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png)).buffer
        .asUint8List();
  }

  static Future<Marker> getMarker (Map<String, dynamic> res) async {
    final Uint8List markerIcon = await getBytesFromAsset(
        'assets/img/marker.png', 120);
    final Marker marker = Marker(
        markerId: MarkerId(res['id']),
        icon: BitmapDescriptor.fromBytes(markerIcon),
//        onTap: () {
//          //print(res.name);
//        },
        anchor: Offset(0.5, 0.5),
        infoWindow: InfoWindow(
            title: res['name'],
            snippet: res['distance'].toStringAsFixed(2) + ' mi',
            onTap: () {
              print('infowi tap');
            }),
        position: LatLng(
            double.parse(res['latitude']), double.parse(res['longitude'])));

    return marker;
  }

  static Future<Marker> getMyPositionMarker (double latitude,
      double longitude) async {
    final Uint8List markerIcon = await getBytesFromAsset(
        'assets/img/my_marker.png', 120);
    final Marker marker = Marker(
        markerId: MarkerId(Random().nextInt(100).toString()),
        icon: BitmapDescriptor.fromBytes(markerIcon),
        anchor: Offset(0.5, 0.5),
        position: LatLng(latitude, longitude));

    return marker;
  }

  static List<Icon> getStarsList (double rate, {double size = 18}) {
    var list = <Icon>[];
    list = List.generate(rate.floor(), (index) {
      return Icon(Icons.star, size: size, color: Color(0xFFFFB24D));
    });
    if (rate - rate.floor() > 0)
    {
      list.add(Icon(Icons.star_half, size: size, color: Color(0xFFFFB24D)));
    }
    list.addAll(
        List.generate(5 - rate.floor() - (rate - rate.floor()).ceil(), (index) {
          return Icon(Icons.star_border, size: size, color: Color(0xFFFFB24D));
        }));
    return list;
  }


//  static Future<List> getPriceWithCurrency(double myPrice) async {
//    final Setting _settings = await getCurrentSettings();
//    List result = [];
//    if (myPrice != null) {
//      result.add('${myPrice.toStringAsFixed(2)}');
//      if (_settings.currencyRight) {
//        return '${myPrice.toStringAsFixed(2)} ' + _settings.defaultCurrency;
//      } else {
//        return _settings.defaultCurrency + ' ${myPrice.toStringAsFixed(2)}';
//      }
//    }
//    if (_settings.currencyRight) {
//      return '0.00 ' + _settings.defaultCurrency;
//    } else {
//      return _settings.defaultCurrency + ' 0.00';
//    }
//  }

  static Widget getPrice (double myPrice, BuildContext context,
      {TextStyle style, String currency}) {

    style ??= Theme
        .of(context)
        .textTheme
        .titleMedium;
    if (myPrice < 0) {
      style = style.copyWith(color: LightColor.red);
    }
    try
    {
      Company company = Api().company;
      Currency cur = company.getCurrency(currency);
      String symbol = cur?.symbol??settingNotifier.value?.defaultCurrency??"";

      return RichText(
        softWrap: false,
        overflow: TextOverflow.fade,
        maxLines: 1,
        text: (cur?.position?? 'after') == 'after'
            ? TextSpan(
                text: symbol,
                style: style,
                children: <TextSpan>[
                  TextSpan(
                      text: myPrice.toStringAsFixed(2) ?? '', style: style),
                ],
              )
            : TextSpan(
                text: myPrice.toStringAsFixed(2) ?? '',
                style: style,
                children: <TextSpan>[
                  TextSpan(
                      text: symbol,
                      style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: style.fontSize - 2.0
                      )
                  ),
                ],
              ),
      );
    } catch (e)
    {
      return Text('');
    }
  }



  static String getDistance (double distance) {
    String unit = settingNotifier.value.distanceUnit;
    if (unit == 'km')
    {
      distance *= 1.60934;
    }
    return distance != null
        ? distance.toStringAsFixed(2) + " " + trans(unit)
        : "";
  }


  static String skipHtml (String htmlString) {
    if (htmlString == null) return "";
    var document = parse(htmlString);
    String parsedString = parse(document.body.text).documentElement.text;
    return parsedString;
  }


  static OverlayEntry overlayLoader (context) {
    OverlayEntry loader = OverlayEntry(builder: (context) {
      final size = MediaQuery
          .of(context)
          .size;
      return Positioned(
        height: size.height,
        width: size.width,
        top: 0,
        left: 0,
        child: Material(
          color: Theme
              .of(context)
              .primaryColor
              .withOpacity(0.4),
          child: CircularLoadingWidget(height: 200),
        ),
      );
    });
    return loader;
  }

  static hideLoader (OverlayEntry loader) {
    Timer(Duration(milliseconds: 500), () {
      try {
        loader?.remove();
      } catch (e){}
    });
  }

  static String limitString (String text,
      {int limit = 24, String hiddenText = "..."}) {
    return text.substring(0, min<int>(limit, text.length)) +
        (text.length > limit ? hiddenText : '');
  }

  static String getCreditCardNumber (String number) {
    String result = '';
    if (number != null && number.isNotEmpty && number.length == 16)
    {
      result = number.substring(0, 4);
      result += ' ' + number.substring(4, 8);
      result += ' ' + number.substring(8, 12);
      result += ' ' + number.substring(12, 16);
    }
    return result;
  }

  static String trans (String text) {
    switch (text)
    {
      case "App\\Notifications\\StatusChangedOrder":
        return S.tr.order_status_changed;
      case "App\\Notifications\\NewOrder":
        return S.tr.new_order_from_client;
      case "km":
        return S.tr.km;
      case "mi":
        return S.tr.mi;
      default:
        return "";
    }
  }

  static Map<String, dynamic> merge(dynamic map1, dynamic map2 ){
    map1.addAll(map2);
    return map1;
  }


  static DateFormat _dateFormat = DateFormat('yyyy-MM-dd', 'en_US');
  static DateFormat _dateTimeFormat = DateFormat('yyyy-MM-dd HH:mm', 'en-US');

  static String formatDate(DateTime date){
     return date != null ? _dateFormat.format(date) : null;
  }

  static String formatDatetime(DateTime date) {
    return date != null ? _dateTimeFormat.format(date) : null;
  }

  static DateTime parseDate(String date){
    try {
      return date != null ? _dateFormat.parse(date) : null;
    } catch(e){
      print("Helper::parseDate $date error $e");
    }
    return null;
  }

  static DateTime parseServerDate(String date){
    try {
      return date != null ? DateTime.parse(date) : null;
    } catch(e){
      print("Helper::parseDate $date error $e");
    }
    return null;
  }

  static shiftDateTime(String datetime){
    return datetime??"";
  }

  static String shortFormatDatetime(DateTime date) {
    return date != null ? _dateTimeFormat.format(date) : null;
  }

  //static divmode()

  static formatTimeRange(BuildContext context, double start, double end) {

    if (start == null || end == null)
       return "--:--   --:--";

    start = start??8;
    end = end??start + 1;

    int shour =  (start).floor();
    int smin = (start * 60.0 % 60.0).round();
    int ehour = (end %24).floor();
    int emin = (end * 60.0 % 60.0).round();

    if (smin == 60) {
      smin = 0;
      shour += 1;
    }
    shour = shour % 24;

    if (emin == 60) {
      emin = 0;
      ehour += 1;
    }
    ehour = ehour % 24;

    final startTm = TimeOfDay(hour: shour, minute: smin);
    final endTm = TimeOfDay(hour: ehour, minute: emin);

    return startTm.format(context) + " - " + endTm.format(context);
  }



  static String correctPhone(String phone){
    if(phone.startsWith("+")){
      phone = phone.substring(1);
    }
    while(phone.startsWith("0")){
      phone = phone.substring(1);
    }
    return phone;
  }

  /*
  static Map modelToMap(dynamic obj) {

    InstanceMirror instance_mirror = reflect(obj);
    var class_mirror = instance_mirror.type;

    for (var v in class_mirror.declarations.values) {

      if (v is VariableMirror) {
        var name = MirrorSystem.getName(v.simpleName);
        if (v.isStatic || v.isPrivate || v.isFinal || v.isConst)
           continue;

      }
    }
  }
  */

  static List<T> map<T>(List source, T f(el)){
    List<T> list = <T>[];
    if (source == null)
      return list;

    source.forEach((el) => list.add(f(el)));
    return list;
  }

  static valueToMap(value, [String key='name']) {
    if (value == null || value is String){
      return {'id': 0, key: value};
    }
    return value;
  }

  static Widget getCreditCardIcon(BuildContext context, String brand, {double width, double height}){
    new AssetImage("assets/img/${brand.toLowerCase()}.png");
  }

  static String countryCodeToEmoji(String countryCode) {
    // 0x41 is Letter A
    // 0x1F1E6 is Regional Indicator Symbol Letter A
    // Example :
    // firstLetter U => 20 + 0x1F1E6
    // secondLetter S => 18 + 0x1F1E6
    // See: https://en.wikipedia.org/wiki/Regional_Indicator_Symbol
    final int firstLetter = countryCode.codeUnitAt(0) - 0x41 + 0x1F1E6;
    final int secondLetter = countryCode.codeUnitAt(1) - 0x41 + 0x1F1E6;
    return String.fromCharCode(firstLetter) + String.fromCharCode(secondLetter);
  }

  static bool isValidCords(double lat, double lng) {
    return lat != null && lng != null;
  }

  /// Calculates the distance between the supplied coordinates in meters.
  ///
  /// The distance between the coordinates is calculated using the Haversine
  /// formula (see https://en.wikipedia.org/wiki/Haversine_formula). The
  /// supplied coordinates [startLatitude], [startLongitude], [endLatitude] and
  /// [endLongitude] should be supplied in degrees.
  static double distanceBetween(
      double startLatitude,
      double startLongitude,
      double endLatitude,
      double endLongitude,
      ) {
    var earthRadius = 6378137.0;
    var dLat = _toRadians(endLatitude - startLatitude);
    var dLon = _toRadians(endLongitude - startLongitude);

    num a = pow(sin(dLat / 2), 2) +
        pow(sin(dLon / 2), 2) *
            cos(_toRadians(startLatitude)) *
            cos(_toRadians(endLatitude));
    var c = 2 * asin(sqrt(a));

    return earthRadius * c;
  }

  static _toRadians(double degree) {
    return degree * pi / 180;
  }

  /// Calculates the initial bearing between two points
  ///
  /// The initial bearing will most of the time be different than the end
  /// bearing, see https://www.movable-type.co.uk/scripts/latlong.html#bearing.
  /// The supplied coordinates [startLatitude], [startLongitude], [endLatitude]
  /// and [endLongitude] should be supplied in degrees.
  static double bearingBetween(
      double startLatitude,
      double startLongitude,
      double endLatitude,
      double endLongitude,
      ) {
    var startLongitudeRadians = radians(startLongitude);
    var startLatitudeRadians = radians(startLatitude);
    var endLongitudeRadians = radians(endLongitude);
    var endLatitudeRadians = radians(endLatitude);

    var y = sin(endLongitudeRadians - startLongitudeRadians) *
        cos(endLatitudeRadians);
    var x = cos(startLatitudeRadians) * sin(endLatitudeRadians) -
        sin(startLatitudeRadians) *
            cos(endLatitudeRadians) *
            cos(endLongitudeRadians - startLongitudeRadians);

    return degrees(atan2(y, x));
  }

  static Map<K,V> removeNulls<K,V>(Map<K,V> input) {
    input.removeWhere((key, value) => value == null || (value is String &&  value.isEmpty));
    return input;
  }

  static void launchWebsite(String endpoint) async{
    final lang = (await SharedPreferences.getInstance()).getString('language');
    if (!endpoint.startsWith('http:') && !endpoint.startsWith('https:'))
      endpoint = 'https://smb.express/$endpoint/';
    if (!endpoint.contains('?'))
      endpoint = '$endpoint?';

    launchUrlString('${endpoint}lang=$lang', mode: LaunchMode.externalApplication);

  }

  static String formatDuration(num time) {
    if (time ==null)
      return "";
    int hour =  (time).floor();
    int minute = ((time - hour) * 60).round();
    return "$hour:$minute";
  }


}


