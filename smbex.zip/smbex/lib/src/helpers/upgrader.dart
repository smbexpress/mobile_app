/*
 * Copyright (c) 2018 Larry Aasen. All rights reserved.
 */

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../i18n/i18n.dart';
import '../api.dart';
import '../config.dart';
import '../models/model.dart';

/// Signature of callbacks that have no arguments and return bool.
typedef BoolCallback = bool Function();

/// Signature of callbacks that have a bool argument and no return.
typedef VoidBoolCallback = void Function(bool value);

/// There are two different dialog styles: Cupertino and Material
enum UpgradeDialogStyle { cupertino, material }

/// A class to define the configuration for the appcast. The configuration
/// contains two parts: a URL to the appcast, and a list of supported OS
/// names, such as "android", "ios".
class AppcastConfiguration {
  final List<String> supportedOS;
  final String url;

  AppcastConfiguration({
    this.supportedOS,
    this.url,
  });
}

/// A singleton class to configure the upgrade dialog.
class Upgrader {
  static Upgrader _singleton = Upgrader._internal();

  /// The appcast configuration ([AppcastConfiguration]) used by [Appcast].
  /// When an appcast is configured for iOS, the iTunes lookup is not used.
  AppcastConfiguration appcastConfig;

  /// Duration until alerting user again
  Duration durationUntilAlertAgain = const Duration(days: 3);

  /// For debugging, always force the upgrade to be available.
  bool debugDisplayAlways = false;

  /// For debugging, display the upgrade at least once once.
  bool debugDisplayOnce = false;

  /// Enable print statements for debugging.
  bool debugLogging = Config.isDebug;

  final notInitializedExceptionMessage =
      'initialize() not called. Must be called first.';

  /// Called when the ignore button is tapped or otherwise activated.
  /// Return false when the default behavior should not execute.
  BoolCallback onIgnore;

  /// Called when the later button is tapped or otherwise activated.
  /// Return false when the default behavior should not execute.
  BoolCallback onLater;

  /// Called when the update button is tapped or otherwise activated.
  /// Return false when the default behavior should not execute.
  BoolCallback onUpdate;

  /// Called when the user taps outside of the dialog and [canDismissDialog]
  /// is false. Also called when the back button is pressed. Return true for
  /// the screen to be popped. Not used by [UpgradeCard].
  BoolCallback shouldPopScope;

  /// Called when [Upgrader] determines that an upgrade may or may not be
  /// displayed. The [value] parameter will be true when it should be displayed,
  /// and false when it should not be displayed. One good use for this callback
  /// is logging metrics for your app.
  VoidBoolCallback willDisplayUpgrade;

  /// Hide or show Ignore button on dialog (default: true)
  bool showIgnore = true;

  /// Hide or show Later button on dialog (default: true)
  bool showLater = true;

  /// Hide or show release notes (default: true)
  bool showReleaseNotes = true;

  /// Can alert dialog be dismissed on tap outside of the alert dialog. Not used by [UpgradeCard]. (default: false)
  bool canDismissDialog = false;

  /// The country code that will override the system locale. Optional. Used only for iOS.
  String countryCode;

  /// The minimum app version supported by this app. Earlier versions of this app
  /// will be forced to update to the current version. Optional.
  String _minorAppVersion;

  /// The upgrade dialog style. Optional. Used only on UpgradeAlert. (default: material)
  UpgradeDialogStyle dialogStyle = UpgradeDialogStyle.material;

  /// The target platform.
  TargetPlatform platform = defaultTargetPlatform;


  bool _displayed = false;
  bool _initCalled = false;

  String _installedVersion;
  String _appStoreVersion;
  String _appStoreURL;
  String _releaseNotes;
  String _updateAvailable;
  DateTime _lastTimeAlerted;
  String _lastVersionAlerted;
  String _userIgnoredVersion;
  bool _hasAlerted = false;
  bool _isCriticalUpdate = false;

  factory Upgrader() {
    return _singleton;
  }

  Upgrader._internal();


  void installAppStoreVersion(String version) {
    _appStoreVersion = version;
  }

  void installAppStoreListingURL(String url) {
    _appStoreURL = url;
  }

  Future<bool> initialize() async {
    if (_initCalled) {
      return true;
    }

    _initCalled = true;

    _installedVersion = Config.version;
    await _getSavedPrefs();

    await _updateVersionInfo();



    return true;
  }

  Future<bool> _updateVersionInfo() async {
    // The  country code of the locale, defaulting to `US`.
    final country = countryCode ?? findCountryCode();
    if (debugLogging) {
      print('upgrader: countryCode: $country');
    }

    Map<String, String> device = await Api().getPlatformInfo();
    final map = <String,dynamic>{};
    map['platform'] = device.remove('platform');
    map['device_uuid'] = device.remove('device_uuid');
    map['device'] = device;
    map['version'] = Config.version;

    ResultItem appResult = await ResultItem.of(Api().get('app/version', data: map), null);

    if (appResult.hasError)
      throw appResult.error;

    _appStoreVersion ??= appResult.item['app_version'];
    _minorAppVersion ??= appResult.item['minor_version'];
    _appStoreURL ??= appResult.item['app_store_url'];
    _releaseNotes ??= appResult.item['release_notes'];

    return true;
  }


  bool _verifyInit() {
    if (!_initCalled) {
      throw (notInitializedExceptionMessage);
    }
    return true;
  }

  String appName() {
    _verifyInit();
    return tr.appName;
  }

  String currentAppStoreListingURL() => _appStoreURL;

  String currentAppStoreVersion() => _appStoreVersion;

  String currentInstalledVersion() => _installedVersion;

  String get releaseNotes => _releaseNotes;

  String message() {
    return S.tr.upgradeMessage(S.tr.appName);
  }

  /// Only called by [UpgradeAlert].
  Future checkVersion({@required BuildContext context}) async {
    if (!_displayed) {
      final shouldDisplay = shouldDisplayUpgrade();
      if (debugLogging) {
        print(
            'upgrader: shouldDisplayReleaseNotes: ${shouldDisplayReleaseNotes()}');
        print(
            'upgrader: shouldDisplay: ${shouldDisplay}');
      }
      if (shouldDisplay) {
        _displayed = true;
        await _showDialog(
            context: context,
            title: S.tr.upgradeUpdateApp,
            message: message(),
            releaseNotes: shouldDisplayReleaseNotes() ? _releaseNotes : null,
            canDismissDialog: canDismissDialog
        );
        _displayed = false;
      }
    }
    return Future.value();
  }

  bool blocked() {
    return belowMinAppVersion() || _isCriticalUpdate;
  }

  bool shouldDisplayUpgrade() {
    final isBlocked = blocked();

    if (debugLogging) {
      print('upgrader: blocked: $isBlocked');
      print('upgrader: debugDisplayAlways: $debugDisplayAlways');
      print('upgrader: debugDisplayOnce: $debugDisplayOnce');
      print('upgrader: hasAlerted: $_hasAlerted');
    }

    // If installed version is below minimum app version, or is a critical update,
    // disable ignore and later buttons.
    if (isBlocked) {
      showIgnore = false;
      showLater = false;
    }
    bool rv = true;
    if (debugDisplayAlways || (debugDisplayOnce && !_hasAlerted)) {
      rv = true;
    } else if (!isUpdateAvailable()) {
      rv = false;
    } else if (isBlocked) {
      rv = true;
    } else if (isTooSoon() || alreadyIgnoredThisVersion()) {
      rv = false;
    }
    if (debugLogging) {
      print('upgrader: shouldDisplayUpgrade: $rv');
    }
    // Call the [willDisplayUpgrade] callback when available.
    if (willDisplayUpgrade != null) {
      willDisplayUpgrade(rv);
    }
    return rv;
  }

  /// Is installed version below minimum app version?
  bool belowMinAppVersion() {
    var rv = false;
    if (_minorAppVersion != null) {
      try {
        final minVersion = int.tryParse(_minorAppVersion.replaceAll(".", ""))??0;
        final installedVersion = int.tryParse(_installedVersion.replaceAll(".", ""))??0;
        print('upgrader: minVersion: $minVersion');
        print('upgrader: installedVersion: $installedVersion');
        rv = installedVersion < minVersion;
      } catch (e) {
        print(e);
      }
    } else {
      print('upgrader: error _minorAppVersion is null');
    }
    return rv;
  }

  bool isTooSoon() {
    if (_lastTimeAlerted == null) {
      return false;
    }

    final lastAlertedDuration = DateTime.now().difference(_lastTimeAlerted);
    final rv = lastAlertedDuration < durationUntilAlertAgain;
    if (rv && debugLogging) {
      print('upgrader: isTooSoon: true');
    }
    return rv;
  }

  bool alreadyIgnoredThisVersion() {
    final rv =
        _userIgnoredVersion != null && _userIgnoredVersion == _appStoreVersion;
    if (rv && debugLogging) {
      print('upgrader: alreadyIgnoredThisVersion: true');
    }
    return rv;
  }

  bool isUpdateAvailable() {
    if (debugLogging) {
      print('upgrader: appStoreVersion: $_appStoreVersion');
      print('upgrader: installedVersion: $_installedVersion');
      print('upgrader: minAppVersion: $_minorAppVersion');
    }
    if (_appStoreVersion == null || _installedVersion == null) {
      if (debugLogging) {
        print('upgrader: isUpdateAvailable: false');
      }
      return false;
    }

    if (_updateAvailable == null) {
      final appStoreVersion = int.tryParse(_appStoreVersion.replaceAll(".", ""))??0;
      final installedVersion =  int.tryParse(_installedVersion.replaceAll(".", ""))??0;

      final available = appStoreVersion > installedVersion;
      _updateAvailable = available ? _appStoreVersion : null;
    }
    if (debugLogging) {
      print('upgrader: isUpdateAvailable: ${_updateAvailable != null}');
    }
    return _updateAvailable != null;
  }

  bool shouldDisplayReleaseNotes() {
    return showReleaseNotes && (_releaseNotes?.isNotEmpty ?? false);
  }

  /// Determine the current country code, either from the context, or
  /// from the system-reported default locale of the device. The default
  /// is `US`.
  String findCountryCode({BuildContext context}) {
    Locale locale;
    if (context != null) {
      locale = Localizations.maybeLocaleOf(context);
    } else {
      // Get the system locale
      locale = WidgetsBinding.instance.window.locale;
    }
    final code = locale == null || locale.countryCode == null
        ? 'US'
        : locale.countryCode;
    return code;
  }

  void _showDialog(
      {@required BuildContext context,
      @required String title,
      @required String message,
      @required String releaseNotes,
      @required bool canDismissDialog}) async{
    if (debugLogging) {
      print('upgrader: showDialog title: $title');
      print('upgrader: showDialog message: $message');
      print('upgrader: showDialog releaseNotes: $releaseNotes');
    }

    // Save the date/time as the last time alerted.
    await saveLastAlerted();

    return showDialog(
      barrierDismissible: canDismissDialog,
      context: context,
      //barrierColor: Colors.transparent,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async => _shouldPopScope(),
          child: dialogStyle == UpgradeDialogStyle.material
              ? _alertDialog(title, message, releaseNotes, context)
              : _cupertinoAlertDialog(title, message, releaseNotes, context),
        );
      },
    );
  }

  /// Called when the user taps outside of the dialog and [canDismissDialog]
  /// is false. Also called when the back button is pressed. Return true for
  /// the screen to be popped. Defaults to false.
  bool _shouldPopScope() {
    if (debugLogging) {
      print('upgrader: onWillPop called');
    }
    if (shouldPopScope != null) {
      final should = shouldPopScope();
      if (debugLogging) {
        print('upgrader: shouldPopScope=$should');
      }
      return should;
    }

    return false;
  }

  AlertDialog _alertDialog(String title, String message, String releaseNotes,
      BuildContext context) {
    Widget notes;
    if (releaseNotes != null) {
      notes = Padding(
          padding: const EdgeInsets.only(top: 15.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
             Text('${S.tr.upgradeReleaseNotes}:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              Text(
                releaseNotes,
                maxLines: 15,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ));
    }
    return AlertDialog(
      title: Text(title),

      content: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(message),
          Padding(
              padding: const EdgeInsets.only(top: 15.0),
              child: Text(S.tr.upgradePrompt),),
          if (notes != null) notes,
        ],
      )),
      actions: <Widget>[
        if (showIgnore)
          TextButton(
              child:
                  Text(S.tr.buttons.ignore),
              onPressed: () => onUserIgnored(context, true)),
        if (showLater)
          TextButton(
              child: Text(S.tr.buttons.later),
              onPressed: () => onUserLater(context, true)),
        TextButton(
            child: Text(S.tr.buttons.updateNow),
            onPressed: () => onUserUpdated(context, !blocked())),
      ],
    );
  }

  CupertinoAlertDialog _cupertinoAlertDialog(
      String title,
      String message,
      String releaseNotes,
      BuildContext context) {
    Widget notes;
    if (releaseNotes != null) {
      notes = Padding(
          padding: const EdgeInsets.only(top: 15.0),
          child: Column(
            children: <Widget>[
              Text('${S.tr.upgradeReleaseNotes}:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              Text(
                releaseNotes,
                maxLines: 14,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ));
    }
    return CupertinoAlertDialog(
      title: Text(title),
      content: Column(
        // mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(message),
          Padding(
              padding: const EdgeInsets.only(top: 15.0),
              child: Text(S.tr.upgradePrompt)),
          if (notes != null) notes,
        ],
      ),
      actions: <Widget>[
        if (showIgnore)
          CupertinoDialogAction(
              child:
                  Text(S.tr.buttons.ignore),
              onPressed: () => onUserIgnored(context, true)),
        if (showLater)
          CupertinoDialogAction(
              child: Text(S.tr.buttons.later),
              onPressed: () => onUserLater(context, true)),
        CupertinoDialogAction(
            isDefaultAction: true,
            child: Text(S.tr.buttons.updateNow),
            onPressed: () => onUserUpdated(context, !blocked())),
      ],
    );
  }

  void onUserIgnored(BuildContext context, bool shouldPop) {
    if (debugLogging) {
      print('upgrader: button tapped: ignore');
    }

    // If this callback has been provided, call it.
    var doProcess = true;
    if (onIgnore != null) {
      doProcess = onIgnore();
    }

    if (doProcess) {
      _saveIgnored();
    }

    if (shouldPop) {
      _pop(context);
    }
  }

  void onUserLater(BuildContext context, bool shouldPop) {
    if (debugLogging) {
      print('upgrader: button tapped: later');
    }

    // If this callback has been provided, call it.
    var doProcess = true;
    if (onLater != null) {
      doProcess = onLater();
    }

    if (doProcess) {}

    if (shouldPop) {
      _pop(context);
    }
  }

  void onUserUpdated(BuildContext context, bool shouldPop) {
    if (debugLogging) {
      print('upgrader: button tapped: update now');
    }

    // If this callback has been provided, call it.
    var doProcess = true;
    if (onUpdate != null) {
      doProcess = onUpdate();
    }

    if (doProcess) {
      _sendUserToAppStore();
    }

    if (shouldPop) {
      _pop(context);
    }
  }

  static Future<bool> clearSavedSettings() async {
    var prefs = await SharedPreferences.getInstance();
    await prefs.remove('userIgnoredVersion');
    await prefs.remove('lastTimeAlerted');
    await prefs.remove('lastVersionAlerted');
    resetSingleton();
    return true;
  }

  static void resetSingleton() {
    _singleton = Upgrader._internal();
  }

  void _pop(BuildContext context) {
    Navigator.of(context).pop();
    _displayed = false;
  }

  bool get isDisplayed => _displayed;

  Future<bool> _saveIgnored() async {
    var prefs = await SharedPreferences.getInstance();

    _userIgnoredVersion = _appStoreVersion;
    await prefs.setString('userIgnoredVersion', _userIgnoredVersion);
    return true;
  }

  Future<bool> saveLastAlerted() async {
    var prefs = await SharedPreferences.getInstance();
    _lastTimeAlerted = DateTime.now();
    await prefs.setString('lastTimeAlerted', _lastTimeAlerted.toString());

    _lastVersionAlerted = _appStoreVersion;
    await prefs.setString('lastVersionAlerted', _lastVersionAlerted);

    _hasAlerted = true;
    return true;
  }

  Future<bool> _getSavedPrefs() async {
    var prefs = await SharedPreferences.getInstance();
    final lastTimeAlerted = prefs.getString('lastTimeAlerted');
    if (lastTimeAlerted != null) {
      _lastTimeAlerted = DateTime.parse(lastTimeAlerted);
    }

    _lastVersionAlerted = prefs.getString('lastVersionAlerted');

    _userIgnoredVersion = prefs.getString('userIgnoredVersion');

    return true;
  }

  void _sendUserToAppStore() async {
    if (_appStoreURL == null || _appStoreURL.isEmpty) {
      if (debugLogging) {
        print('upgrader: empty _appStoreListingURL');
      }
      return;
    }

    if (debugLogging) {
      print('upgrader: launching: $_appStoreURL');
    }
    if (_appStoreURL.startsWith("http")) {
      final uri = Uri.parse(_appStoreURL);
      await launchUrl(uri);
      return;
    }

    if (await canLaunchUrlString(_appStoreURL)) {
      try {
        await launchUrlString(_appStoreURL);
      } catch (e) {
        if (debugLogging) {
          print('upgrader: launch to app store failed: $e');
        }
      }
    } else {}
  }
}
