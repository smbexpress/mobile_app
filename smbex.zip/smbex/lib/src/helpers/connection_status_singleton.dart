import 'dart:async'; //For StreamController/Stream
import 'dart:io'; //InternetAddress utility

import 'package:connectivity_plus/connectivity_plus.dart';

import 'Debouncer.dart';

class ConnectionStatusSingleton {
  //This creates the single instance by calling the `_internal` constructor specified below
  static final ConnectionStatusSingleton _singleton = new ConnectionStatusSingleton._internal();
  ConnectionStatusSingleton._internal();

  //This is what's used to retrieve the instance through the app
  static ConnectionStatusSingleton getInstance() => _singleton;
  //This tracks the current connection status
  bool _hasConnection = false;
  bool _hasPendingCheck = false;

  bool get hasConnection => _hasConnection;

  //This is how we'll allow subscribing to connection changes
  StreamController<bool> connectionChangeController = new StreamController.broadcast();

  //flutter_connectivity
  final Connectivity _connectivity = Connectivity();

  final Debouncer _debouncer = Debouncer(delay: const Duration(milliseconds: 1500));
  final Debouncer _reCheckDebouncer = Debouncer(delay: const Duration(milliseconds: 10000));

  //Hook into flutter_connectivity's Stream to listen for changes
  //And check the connection status out of the gate
  void initialize() {
    _connectivity.onConnectivityChanged.listen(_connectionChange);
    checkConnection();
  }

  Stream<bool> get connectionChange => connectionChangeController.stream;

  //A clean up method to close our StreamController
  //   Because this is meant to exist through the entire application life cycle this isn't
  //   really an issue
  void dispose() {
    connectionChangeController.close();
  }

  //flutter_connectivity's listener
  void _connectionChange(ConnectivityResult result) {
    //checkConnection();
    if (result == ConnectivityResult.none) {
      //checkConnection();
      _debouncer(checkConnection);
    } else {
      _debouncer(checkConnection);
      _hasPendingCheck = false;
      checkConnection();
    }
  }

  //The test to actually see if there is a connection
  Future<bool> checkConnection() async {

    if (_hasPendingCheck) {
      _debouncer(checkConnection);
      return _hasConnection;
    }

    bool previousConnection = hasConnection;
    _hasPendingCheck = true;

    try {
      try {
        final result = await InternetAddress.lookup('google.com')
            .timeout(const Duration(seconds: 5));
        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
          _hasConnection = true;
          //clear re-check
          _reCheckDebouncer(()=> null);
        } else {
          _hasConnection = false;
        }
      } on SocketException catch (_) {
        _hasConnection = false;
      }

      //The connection status changed send out an update to all listeners
      if (_hasPendingCheck && previousConnection != _hasConnection) {
        connectionChangeController.add(_hasConnection);
      }

      if (!_hasConnection) {
        _reCheckDebouncer(checkConnection);
      }

    } finally {
      _hasPendingCheck = false;

    }

    return _hasConnection;
  }
}