// @dart=2.12

class Cache<K, V extends Object> {
  Map<K, WeakReference<V>> _cache = {};


  V? operator [](K? key) {
    if (key != null){
      final ref = _cache[key!];
      if (ref != null){
          final target = ref.target;
          if (target == null){
            _cache.remove(key);
            return null;
          }
          return target;
      }
      return null;
    }
  }

  void operator []=(K key, V value){
    _cache[key] = WeakReference(value);
  }

  void clear(){
    _cache.clear();
  }


}