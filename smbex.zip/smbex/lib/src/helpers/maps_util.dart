import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart' show BuildContext;
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';
import 'package:osm_nominatim/osm_nominatim.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../i18n/i18n.dart';
import '../models/Step.dart';
import '../widgets/picker/place_picker/entities/entities.dart';

import 'network_exception.dart';



class MapsUtil {
  static const BASE_URL = "https://maps.googleapis.com/maps/api/directions/json?";

  static bool _testGoogle = false;
  static bool _useGoogle = false;

  static MapsUtil _instance = new MapsUtil.internal();
  static LocationData _mucLocation;

  MapsUtil.internal();

  factory MapsUtil() => _instance;
  final JsonDecoder _decoder = new JsonDecoder();


  static void initLocation(BuildContext context) async{
     var location = await getGpsLocation(context);
     if (location == null){
       _mucLocation ??=  LocationData.fromMap(
         {
           'latitude': 0.0,
           'longitude': 0.0,
           'altitude': 0.0,
           'time': 0.0,
           'speed_accuracy': 0.0,
           'heading': 0.0,
           'accuracy': 0.0,
         }
       );
     }

  }


  Future<dynamic> get(String url) {
    return http.get(Uri.parse(BASE_URL + url)).then((http.Response response) {
      String res = response.body;
      int statusCode = response.statusCode;
//      print("API Response: " + res);
      if (statusCode < 200 || statusCode > 400 || json == null) {
        res = "{\"status\":" + statusCode.toString() + ",\"message\":\"error\",\"response\":" + res + "}";
        throw new Exception(res);
      }

      List<LatLng> steps;
      try {
        steps = parseSteps(_decoder.convert(res)["routes"][0]["legs"][0]["steps"]);
      } catch (e) {
        // throw new Exception(e);
      }

      return steps;
    });
  }

  List<LatLng> parseSteps(final responseBody) {
    List<Step> _steps = responseBody.map<Step>((json) {
      return new Step.fromJson(json);
    }).toList();
    List<LatLng> _latLang = _steps.map((Step step) => step.startLatLng).toList();
    return _latLang;
  }

  Future<String> getAddressName(LatLng location, String apiKey) async {

    try {
      var endPoint =
          'https://maps.googleapis.com/maps/api/geocode/json?latlng=${location?.latitude},${location?.longitude}&language=${lang}&key=$apiKey';
      var response = jsonDecode((await http.get(Uri.parse(endPoint))).body);

      return response['results'][0]['formatted_address'];
    } catch (e) {
      print(e);
      return S.tr.unknown + '4';
    }
  }

  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png)).buffer.asUint8List();
  }

  static Future<LocationResult> reverseByGoogle(LatLng location, String apiKey) async {
    var endPoint =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${location?.latitude},${location?.longitude}&language=${lang}&key=$apiKey';
    var response = jsonDecode((await http.get(Uri.parse(endPoint))).body);

    if (response['results'] == null) {
      throw Error();
    }

    final result = response['results'][0];
    String name, locality, postalCode, country, administrativeAreaLevel1, administrativeAreaLevel2, city, subLocalityLevel1, subLocalityLevel2;
    bool isOnStreet = false;
    if (result['address_components'] is List<dynamic> && result['address_components'].length != null && result['address_components'].length > 0){
      for (var i = 0; i < result['address_components'].length; i++){
        var tmp = result['address_components'][i];
        var types = tmp["types"] as List<dynamic>;
        var shortName = tmp['short_name'];
        if (types == null) {
          continue;
        }
        if (i == 0) {
          // [street_number]
          name = shortName;
          isOnStreet = types.contains('street_number');
          // other index 0 types
          // [establishment, point_of_interest, subway_station, transit_station]
          // [premise]
          // [route]
        }
        else if (i == 1 && isOnStreet) {
          if (types.contains('route')) {
            name += ", $shortName";
          }
        }
        else {
          if (types.contains("sublocality_level_1")){
            subLocalityLevel1 = shortName;
          }
          else if (types.contains("sublocality_level_2")){
            subLocalityLevel2 = shortName;
          }
          else if (types.contains("locality")){
            locality = shortName;
          }
          else if (types.contains("administrative_area_level_2")){
            administrativeAreaLevel2 = shortName;
          }
          else if (types.contains("administrative_area_level_1")){
            administrativeAreaLevel1 = shortName;
          }
          else if (types.contains("country")){
            country = shortName;
          }
          else if (types.contains('postal_code')){
            postalCode = shortName;
          }
        }
      }
    }
    locality = locality ?? administrativeAreaLevel1;
    city = locality;
    final locationResult = LocationResult()
      ..name = name
      ..locality = locality
      ..latLng = location
      ..formattedAddress = result['formatted_address']
      ..placeId = result['place_id']
      ..postalCode = postalCode
      ..country = AddressComponent(name: country, shortName: country)
      ..administrativeAreaLevel1 = AddressComponent(name: administrativeAreaLevel1, shortName: administrativeAreaLevel1)
      ..administrativeAreaLevel2 = AddressComponent(name: administrativeAreaLevel2, shortName: administrativeAreaLevel2)
      ..city = AddressComponent(name: city, shortName: city)
      ..subLocalityLevel1 = AddressComponent(name: subLocalityLevel1, shortName: subLocalityLevel1)
      ..subLocalityLevel2 = AddressComponent(name: subLocalityLevel2, shortName: subLocalityLevel2);
    return locationResult;

  }


  static Future<LocationResult> reverseByNominatim(LatLng latLng,
      {String language}) async{
    final place = await Nominatim.reverseSearch(
        lat: latLng.latitude,
        lon: latLng.longitude,
        addressDetails: true,
        language: language ?? 'en',
    );
    print("MapsUtil::reverseByNominatim latLng: $latLng,  place: ${place.address}");
    final locationResult = _placeToLocation(place)
      ..latLng = latLng;

    return locationResult;
  }


  static Future<LocationResult> reverseGeocode(LatLng location, String apiKey) async {
    if (_useGoogle || _testGoogle){
      try {
        final result = reverseByGoogle(location, apiKey);
        _useGoogle = true;
        return result;
      } catch (e, stack){
        if (_useGoogle){
          rethrow;
        }
      }
      finally {
        _testGoogle = false;
      }

    }
    return reverseByNominatim(location);
  }


  static Future<List<AutoCompleteItem>> searchByNominatim(String search,
      {String language, String countryCodes}) async{

    List<AutoCompleteItem> result = [];
    final places = await Nominatim.searchByName(
        query: search,
        countryCodes: countryCodes?.split(','),
        language: language,
        addressDetails: true
    );
    String searchLower = search.toLowerCase();
    for (final place in places){
      final offset = place.displayName.toLowerCase().indexOf(searchLower);
      final item = AutoCompleteItem()
      ..offset = offset
      ..length = offset >= 0 ? search.length : 0
      ..text = place.displayName
      ..place = place
      ..id = place.placeId?.toString();

      result.add(item);
    }
    print("MapsUtil::searchByNominatim query: $search, result: $result");

    return result;
  }

  static Future<List<AutoCompleteItem>> searchByGoogle(String search,
      {String apiKey, String language, String countryCodes}) async{

    final uri = Uri.https(
      'maps.googleapis.com',
      '/maps/api/place/autocomplete/json',
      {
        'apiKey': apiKey,
        'input': search,
        if (countryCodes != null) 'countryCodes': countryCodes,
        if (language != null) 'lang': language,

      },
    );
    final response = await http.get(uri);

    if (response.statusCode != 200) {
      throw Exception(getNetworkException(response));
    }

    final data = json.decode(response.body);

    List<dynamic> predictions = data['predictions'];

    if (predictions == null) {
      throw Exception();
    }
    final items = [];
    for (dynamic t in predictions) {
      final aci = AutoCompleteItem()
        ..id = t['place_id']
        ..text = t['description']
        ..offset = t['matched_substrings'][0]['offset']
        ..length = t['matched_substrings'][0]['length'];

      items.add(aci);
    }

    return items;
  }

  static Future<List<AutoCompleteItem>> searchPlace(String search,
      {String apiKey, String language, String countryCodes}){

    if (_useGoogle || _testGoogle){
      try {
        final result = searchByGoogle(search,
            apiKey: apiKey,
            language: language,
            countryCodes: countryCodes
        );
        _useGoogle = true;
        return result;
      } catch (e, stack){
        if (_useGoogle){
          rethrow;
        }
      }
      finally {
        _testGoogle = false;
      }

    }

    return searchByNominatim(search,
        language: language,
        countryCodes: countryCodes
    );

  }

  static LocationResult _placeToLocation(Place place) {
    final address = place.address;
    String name = address[place.category]??'',
        road = address['road'],
        suburb = address['suburb'],
        district = address['municipality'],
        province = address['province'],
        city = address['city'],
        state = address['state'],
        country = address['country'],
        countryCode = address['country_code'],
        postcode = address['postcode'];

    if (road != null){
      name += ', $road';
    }
    if (suburb != null){
      name += ', $suburb';
    }
    final locationResult = LocationResult()
      ..name = name
      ..locality = (district ?? city ?? province ?? state)
      ..latLng = LatLng(place.lat, place.lon)
      ..formattedAddress = place.displayName
      ..placeId = place.placeId?.toString()
      ..postalCode = postcode
      ..district = district
      ..country = AddressComponent(name: country, shortName: countryCode?.toUpperCase())
      ..administrativeAreaLevel1 = AddressComponent(name: province, shortName: province)
      ..administrativeAreaLevel2 = AddressComponent(name: state, shortName: state)
      ..city = AddressComponent(name: city, shortName: city)
      ..subLocalityLevel1 = AddressComponent(name: state, shortName: state)
      ..subLocalityLevel2 = AddressComponent(name: state, shortName: state);

    return locationResult;

  }

  static Future<LatLng> decodePlace(dynamic place, String apiKey) async{
    if (place is Place){
      return LatLng(place.lat, place.lon);
    }
    final uri = Uri.https(
      'maps.googleapis.com',
      '/maps/api/place/details/json',
      {
        'apiKey': apiKey,
        'placeid': place,
      },
    );

    final response = await http.get(uri);

    if (response.statusCode != 200) {
      throw Exception(getNetworkException(response));
    }

    final data = json.decode(response.body);
    final result = data['result'];

    if (result == null) {
      throw Exception();
    }

    final location = result['geometry']['location'];
    return LatLng(location['lat'], location['lng']);

  }

  static Future<LocationData> getGpsLocation(
      BuildContext context, {bool request = false, bool pop = false}) async {
    var location = new Location();
    if (!(await location.serviceEnabled())) {
      if (!(await location.requestService())) {
        return _mucLocation;
      }
    }

    PermissionStatus status = await location.hasPermission();

    if (status == PermissionStatus.DENIED_FOREVER)
      return _mucLocation;


    if (status == PermissionStatus.DENIED) {
      status = await location.requestPermission();
      if (
      status == PermissionStatus.DENIED_FOREVER ||
          status == PermissionStatus.DENIED
      ) {
        return _mucLocation;
      }
    }

    final loc = await location.getLocation();
    setLastLocation(LatLng(loc.latitude, loc.longitude));
    return loc;
  }

  static Future<LatLng> getLastLocation() async{
    final lastLocation = (await SharedPreferences.getInstance()).getString('gps_last_location')?.split(',');
    if (lastLocation != null){
      return LatLng(double.tryParse(lastLocation[0]), double.tryParse(lastLocation[1]));
    }
    return null;
  }

  static void setLastLocation(LatLng latLng) async{
    (await SharedPreferences.getInstance()).
    setString('gps_last_location', '${latLng.latitude},${latLng.longitude}');
  }


  static Future<bool> launchMap(double lat, double lng) async{
    var mapSchema = 'geo:$lat,$lng';
    if (await launchUrlString(mapSchema)) {
      return await launchUrlString(mapSchema);
    } else {
      throw 'Could not launch $mapSchema';
    }
  }

}
