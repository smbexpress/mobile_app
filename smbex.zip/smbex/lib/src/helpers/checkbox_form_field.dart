import 'package:flutter/material.dart';

class CheckboxFormField extends FormField<bool> {
  CheckboxFormField({
      @required BuildContext context,
      Widget title,
      FormFieldSetter<bool> onSaved,
      Function(bool) onChanged,
      FormFieldValidator<bool> validator,
      bool initialValue = false,
      AutovalidateMode autovalidateMode = AutovalidateMode.onUserInteraction
  })
      : super(
            onSaved: onSaved,
            validator: validator,
            initialValue: initialValue,
            autovalidateMode: autovalidateMode,

            builder: (FormFieldState<bool> state) {
              return CheckboxListTile(
                dense: state.hasError,
                title: title,
                value: state.value,
                onChanged: (value){
                  onChanged?.call(value);
                  state.didChange(value);
                },
                subtitle: state.hasError
                    ? Text(
                        state.errorText,
                        style: TextStyle(color: Theme.of(context).errorColor),
                      )
                    : null,
                controlAffinity: ListTileControlAffinity.leading,
              );
            });
}
