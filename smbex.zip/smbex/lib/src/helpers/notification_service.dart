import 'dart:io';

import 'package:flutter/foundation.dart';
//import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  //NotificationService a singleton object
  static final NotificationService _notificationService = NotificationService._internal();
  static bool _inited = false;

  factory NotificationService() {
    return _notificationService;
  }

  NotificationService._internal();

  static const channelId = '123';

  // ignore: prefer_typing_uninitialized_variables
  var _androidNotificationDetails;
  var _iosNotificationDetails;
  var _platformChannelSpecifics;
  var _platformNotificationsPlugin;

  //final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    if (_inited) return;
    _inited = true;
    /*
    const InitializationSettings initializationSettings =
      InitializationSettings(
          android: AndroidInitializationSettings('ic_launcher'),
          iOS: IOSInitializationSettings(
            requestAlertPermission: true,
            requestBadgePermission: true,
            requestSoundPermission: true
          )
      );

    await flutterLocalNotificationsPlugin.initialize(
        initializationSettings,
        onSelectNotification: (message) => selectNotification(message)
    );
    await createChannel();

     */
  }

  createChannel() async {
    /*
    if (defaultTargetPlatform == TargetPlatform.android){
      var notificationChannel = const AndroidNotificationChannel(
        'high_importance_channel',
        'App Notification',
        playSound: true,
        importance: Importance.high,
      );
      _platformNotificationsPlugin = await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await _platformNotificationsPlugin.createNotificationChannel(notificationChannel);


      _platformChannelSpecifics = const AndroidNotificationDetails(
        'high_importance_channel',
        'App Notification',
        channelDescription: "CHANNEL_DESCRIPTION",
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        //icon: 'ic_launcher',
        styleInformation: DefaultStyleInformation(true, true),
        channelAction: AndroidNotificationChannelAction.update
      );

    } else {
      _platformNotificationsPlugin = await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();

      _platformChannelSpecifics = IOSNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );
    }

     */

  }

  Future<void> showNotifications(message) async {
    //flutterLocalNotificationsPlugin.show(id, title, body, notificationDetails)
    /*
    await _platformNotificationsPlugin?.show(
      0,
      message.notification.title,
      message.notification.body,
        notificationDetails: _platformChannelSpecifics
      //payload: message.data != null ? message.data['id'] : null,
    );

     */
    /*
    await _platformNotificationsPlugin.show(
      0,
      message.notification.title,
      message.notification.body,
      null,
      //_platformChannelSpecifics,
      //payload: message.data != null ? message.data['id'] : null,
    );

     */
  }

  Future<void> scheduleNotifications() async {
//    await flutterLocalNotificationsPlugin.zonedSchedule(0, "Notification Title", "This is the Notification Body!",
//        tz.TZDateTime.now(tz.local).add(const Duration(seconds: 5)), NotificationDetails(android: _androidNotificationDetails),
//        androidAllowWhileIdle: true, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
  }

  Future<void> cancelNotifications(int id) async {
    //await flutterLocalNotificationsPlugin.cancel(id);
  }

  Future<void> cancelAllNotifications() async {
   // await flutterLocalNotificationsPlugin.cancelAll();
  }
}

Future<void> selectNotification(String payload) async {

}
