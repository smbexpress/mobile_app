
import 'dart:async';

import '../config.dart';

typedef OnError = void Function(Object error, StackTrace trace);

class LiveDataTrigger{

  Timer _timer;
  int _interval;
  int _retryInterval;
  Function onTrigger;
  bool _canceled;
  OnError _onError;
  int _retriesCount = 0;
  String _name;
  int _maxReties;

  LiveDataTrigger(this.onTrigger,
      {int interval=20, int retryInterval, OnError onError, String name, int maxReties})
      : _interval = interval,
        _retryInterval = retryInterval,
        _name = name??'',
        _maxReties = maxReties,
        _onError =  onError;

  void start(){
    if (_timer?.isActive == true)
      return;
    _canceled = false;
    _retriesCount = 0;
    _next();
  }

  void stop(){
    if (_timer?.isActive == true)
      _timer.cancel();

    _canceled = true;
  }

  void _next(){
    _timer = Timer(Duration(seconds: _interval),  _onTrigger);
  }

  bool get isActive => _timer?.isActive == true;

  void _onTrigger(){

    Config.log("$_name trigger", runtimeType);

    if (_retryInterval == null){
      onTrigger();
      return;
    }

    try {
      onTrigger();
      _retriesCount = 0;
      _next();
    } catch(e, stack){
      _retriesCount++;
      Config.error("$_name $e", stack, runtimeType);
      _canceled = true;
      if (_maxReties != null && _retriesCount >= _maxReties){
        Config.log("$_name stoped after reached max reties of $_maxReties", runtimeType);
      } else {
        Config.log("$_name retry of $_retriesCount after $_retryInterval seconds ", runtimeType);
        _canceled = false;
        final oldTimer = _timer;
        Future.delayed(Duration(seconds: _retryInterval), () {
          if (_canceled == true || oldTimer != _timer) {
            return;
          }
          _next();
        });
      }
      _onError?.call(e, stack);
    }
  }



}