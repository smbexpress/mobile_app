// @dart=2.12

import 'dart:async';
import 'dart:ui';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart'
    show
        BorderRadius,
        BuildContext,
        EdgeInsets,
        GlobalKey,
        Radius,
        ScaffoldMessengerState,
        SnackBarBehavior,
        WidgetsBinding;

import 'package:provider/provider.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/helpers/helper.dart';
import 'package:smbex_app/src/repository/account_repository.dart'
    as AccountRepo;
import 'package:smbex_app/src/widgets/SmbWidget.dart';

import 'api.dart';
import 'app_state.dart';
import 'helpers/Debouncer.dart';
import 'helpers/live_data_trigger.dart';
import 'helpers/notification_service.dart';
import 'helpers/upgrader.dart';
import 'models/model.dart';
import 'models/notification.dart';
import 'models/route_argument.dart';

typedef MessageListener = void Function(RemoteMessage message);
typedef PollingListener = void Function(Map<String, dynamic>);

final ValueNotifier<int> notificationCounter = ValueNotifier(0);

class NotificationProvider extends ChangeNotifier {
  final List<Notification> _notes = [];

  bool _loading = false;
  ErrorResult? _error;
  int _lastUpdate = 0;
  late List _pollResult = [{}];
  StreamSubscription? _onAppOpen;
  StreamSubscription? _onMessage;
  BuildContext _context;
  final List<MessageListener> _listeners = [];
  final Set<LiveCommand> _commands = {};

  late LiveDataTrigger _liveDataTrigger;
  final scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>(
      debugLabel: "@NotificationProvider:scaffoldMessengerKey");
  final Debouncer _debouncer =
      Debouncer(delay: const Duration(milliseconds: 100));

  NotificationProvider(BuildContext context) : this._context = context {
    _liveDataTrigger = LiveDataTrigger(
      poll,
      name: "Notification",
      interval: 30,
      retryInterval: 40,
    );
  }
  BuildContext get context => _context;
  void set context(BuildContext context) => _context = context;

  Future<ResultItem> _readCounter() async {
    return ResultItem.get('notifications/count',
        func: (count) => count is int ? count : int.parse(count));
  }

  Future<ErrorResult?> load([bool clear = true]) async {
    if (_loading) return Future.value();

    int current = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    if ((current - _lastUpdate) < 60 &&
        notificationCounter.value == 0 &&
        _error == null) return Future.value();

    _lastUpdate = current;
    _loading = true;
    _error = null;
    //WidgetsBinding.instance.addPostFrameCallback((tm) => notifyListeners());

    Future.microtask(notifyListeners);
    try {
      final list = await ResultItems.get<Notification>('notifications/list',
          func: (data) => Notification.fromJSON(data));

      if (list.hasError) {
        _error = list.error;
        return list.error;
      } else {
        _notes.clear();
        _notes.addAll(list.items);
        if (clear) {
          ResultItem.of(Api().post('notifications/read'), null).then((value) {
            if (!value.hasError) {
              notificationCounter.value = 0;
            }
          });
        }
      }
    } finally {
      _loading = false;
      notifyListeners();
    }
    return _error;
  }

  bool get isLoading => _loading;
  ErrorResult? get error => _error;
  List<Notification> get notifications => _notes;

  // It is assumed that all messages contain a data field with the key 'type'
  Future<void> setupFcm() async {
    //_onAppOpen?.cancel();
    //_onMessage?.cancel();
    //_liveDataTrigger.start();

    print("NotificationProvider::setupFcm");
    final notificationService = NotificationService();
    await notificationService.init();

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
    // Also handle any interaction when the app is in the background via a
    // Stream listener
    _onAppOpen = FirebaseMessaging.onMessageOpenedApp.listen(_clickAction);

    // Get any messages which caused the application to open from
    // a terminated state.
    FirebaseMessaging.instance.getInitialMessage().then(_handleMessage);

    await FirebaseMessaging.instance.getToken();

    _onMessage =
        FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      _handleMessage(message);
      if (message.notification != null) {
        //notificationService.showNotifications(message.notification);
        showSnackBar(_context,
            contentType: ContentType.WARNING,
            title: message.notification!.title,
            message: message.notification!.body,
            duration: const Duration(seconds: 5),
            borderRadius: const BorderRadius.all(const Radius.circular(8.0)),
            margin: EdgeInsets.symmetric(horizontal: 15.0, vertical: 30.0),
            behavior: SnackBarBehavior.floating,
            useRootContext: false);
      }
    });

    _liveDataTrigger.start();

    _readCounter().then((value) {
      _poll();
      if (!value.hasError) notificationCounter.value = value.item;
    });
  }

  void dropFcm() async {
    _onAppOpen?.cancel();
    _onMessage?.cancel();
    _liveDataTrigger.stop();
    _onAppOpen = null;
    _onMessage = null;
  }

  void _handleMessage(RemoteMessage? message) {
    Config.debug("NotificationProvider::_handleMessage: $message", runtimeType);
    if (message == null) return;

    RemoteNotification? notification = message.notification;
    AndroidNotification? android = message.notification?.android;
    _handleMessageAction(message);
    if (notification != null && !kIsWeb) {
      if (notification.body == null) return;
      notificationCounter.value++;
      if (hasListeners) {
        load(false);
      }
    }
  }

  void _clickAction(RemoteMessage message) {
    Config.log("_clickAction: ${message.data}", runtimeType);
    final data = message.data;
    final model = data['model'];
    final resId = data['res_id'];
    final action = data['action'];

    var route;
    var args;
    switch (model) {
      case 'shipments':
        route = '/ShipmentDetail';
        args = RouteArgument(id: resId?.toString());
        break;
      case 'deliveries':
        route = '/Delivery';
        args = RouteArgument(id: resId?.toString());
        break;
      case 'tracking':
        route = '/Tracking';
        args = RouteArgument(id: resId?.toString());
        break;
      case 'account':
        switch (action) {
          case 'update':
            AccountRepo.test(AccountRepo.currentAccount.value);
            break;
        }
        break;
    }

    if (route != null) {
      Provider.of<AppState>(_context, listen: false)
          .navigatorKey
          .currentState
          ?.pushNamed(route, arguments: args);
    } else {
      _handleMessage(message);
    }
  }

  void _handleMessageAction(RemoteMessage message) {
    final action = message.data['action'];
    if (action == null) {
      return;
    }
    final sentTime = message.sentTime;

    if (sentTime != null) {
      final duration = DateTime.now().difference(sentTime);
      if (duration.inDays > 1) return;
    }
    if (action == 'upgrade') {
      if (!Upgrader().isDisplayed) {
        Upgrader.clearSavedSettings();
        Upgrader().initialize();
        Upgrader().checkVersion(context: _context);
      }
    } else if (action == 'logout') {
      AccountRepo.logout();
    } else {
      dispatch(message);
    }
  }

  void dispose() {
    super.dispose();
    _onMessage?.cancel();
    _onAppOpen?.cancel();
    _liveDataTrigger?.stop();
    _listeners.clear();
    _commands.clear();
  }

  void addMessageListener(MessageListener listener) {
    _listeners.add(listener);
  }

  void removeMessageListener(MessageListener listener) {
    _listeners.remove(listener);
  }

  void dispatch(RemoteMessage message) {
    _listeners.forEach((listener) => listener(message));
  }

  void startPolling([bool pollNow = true]) {
    if (_commands.isNotEmpty) {
      if (!_liveDataTrigger.isActive) _liveDataTrigger.start();
      if (pollNow) poll();
    }
  }

  void stopPolling() {
    if (_liveDataTrigger.isActive) {
      _liveDataTrigger.stop();
    }
  }

  void poll() {
    _debouncer(_poll);
  }

  void _poll() {
    final commands =
        _commands.where((cmd) => cmd._active).map((e) => e.toMap()).toList();

    //Config.result("request commands: $commands", NotificationProvider);
    if (commands.isEmpty) return;

    ResultItems.of<Map<String, dynamic>>(
        Api().post('app/exec', data: {"commands": commands}),
        (data) => data.cast<String, dynamic>()).then((result) {
      Config.result("Command Results: ${result.items}", NotificationProvider);
      if (result != _pollResult && !result.hasError) {
        _pollResult = result.items;
        for (final item in result.items) {
          pushCommandResponse(item['key'], item);
        }
      } else {
        Config.error("Error while request server:\n${result.error}",
            StackTrace.empty, NotificationProvider);
      }
    });
  }

  void pushCommandResponse(String key, dynamic result) {
    final command = _findCommand(key);
    Config.result(
        "commands trigger: key: ${key},result: $result", NotificationProvider);
    if (command != null) {
      if (command.last != null) {
        command.last = DateTime.now();
      }
      WidgetsBinding.instance
          .addPostFrameCallback((timeStamp) => command.listener(result));
    }
  }

  void addLiveCommand(LiveCommand command) {
    _commands.add(command);
    if (_onMessage != null) {
      _liveDataTrigger.start();
      //_poll();
    }
  }

  void removeLiveCommand(String key) {
    _commands.removeWhere((cmd) => cmd.key == key);
    if (_commands.isEmpty) {
      _liveDataTrigger.stop();
    }
  }

  void setCommandState(String key, bool active) {
    _findCommand(key)?._active = active;
  }

  void updateCommandWith(String key,
      {Map<String, dynamic>? args, DateTime? last}) {
    final command = _findCommand(key)?.updateWith(args: args, last: last);
    if (command != null) {
      removeLiveCommand(key);
      addLiveCommand(command);
    }
  }

  LiveCommand? _findCommand(String key) {
    try {
      return _commands.firstWhere((cmd) => cmd.key == key);
    } catch (e) {}
    return null;
  }
}

class LiveCommand {
  final String key;
  final String model;
  final String method;
  final Map<String, dynamic>? args;
  DateTime? last;
  final PollingListener listener;
  bool _active = true;
  LiveCommand(
      {required this.key,
      required this.model,
      required this.method,
      required this.listener,
      this.args,
      this.last,
      bool active = true})
      : _active = active;

  LiveCommand updateWith({Map<String, dynamic>? args, DateTime? last}) =>
      LiveCommand(
          key: key,
          model: model,
          method: method,
          listener: listener,
          args: args ?? this.args,
          last: last ?? this.last);

  @override
  int get hashCode => key.hashCode ^ model.hashCode ^ method.hashCode;

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is LiveCommand &&
        key == other.key &&
        model == other.model &&
        method == other.method &&
        listener == other.listener;
  }

  Map<String, dynamic> toMap([bool withActive = false]) => {
        "key": key,
        "model": model,
        "method": method,
        if (args != null) "args": args,
        if (last != null) "last": Helper.formatDatetime(last!.toUtc()),
        if (withActive) "active": _active
      };
}
