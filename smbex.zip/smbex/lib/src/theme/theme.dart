import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'light_color.dart';

class AppTheme {
  const AppTheme();

  static final ColorScheme _colorScheme = ColorScheme.fromSwatch(
      primarySwatch: MaterialColor(
        LightColor.accent.value,
        <int, Color>{
          50: Color(0xFFE3F2FD),
          100: Color(0xFFBBDEFB),
          200: Color(0xFF90CAF9),
          300: Color(0xFF64B5F6),
          400: Color(0xFF42A5F5),
          500: Color(0xFF3686f0),
          600: Color(0xFF1E88E5),
          700: Color(0xFF1976D2),
          800: Color(0xFF1565C0),
          900: Color(0xFF0D47A1),
        },
      ),
      primaryColorDark: const Color(0xFF1976D2),
      accentColor: LightColor.accent,
      cardColor: LightColor.white,
      backgroundColor: LightColor.background);

  static SystemUiOverlayStyle get whiteOverlayStyle => _whiteOverlayStyle;
  static SystemUiOverlayStyle get blueOverlayStyle => _blueOverlayStyle;
  static SystemUiOverlayStyle get transOverlayStyle => _transOverlayStyle;

  static SystemUiOverlayStyle _whiteOverlayStyle = SystemUiOverlayStyle.light
      .copyWith(
          statusBarColor: Colors.white,
          statusBarBrightness: Brightness.light,
          statusBarIconBrightness: Brightness.dark,
          systemNavigationBarIconBrightness: Brightness.dark,
          systemNavigationBarColor: Colors.white,
          systemNavigationBarDividerColor: Colors.grey.shade200);

  static SystemUiOverlayStyle _blueOverlayStyle = _whiteOverlayStyle.copyWith(
      statusBarColor: _colorScheme.secondary,
      statusBarBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.light);

  static SystemUiOverlayStyle _transOverlayStyle = _whiteOverlayStyle.copyWith(
      statusBarColor: Colors.transparent,
      statusBarBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.light);

  static ThemeData lightTheme = ThemeData(
    colorScheme: _colorScheme,

    elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      //textStyle: TextStyle(fontSize: 18)
    )),
    outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      //textStyle: TextStyle(color: LightColor.white)
    )),
    //primaryColor: LightColor.white,
    backgroundColor: LightColor.white,
    iconTheme: IconThemeData(color: LightColor.iconColor),
    bottomAppBarColor: LightColor.white,
    dividerColor: LightColor.grey70,
    scaffoldBackgroundColor: LightColor.background,
    cardColor: LightColor.white,
    canvasColor: LightColor.white,
    shadowColor: LightColor.shadow,
    hintColor: LightColor.iconColor.withOpacity(.8),
    //useMaterial3: true,
    primaryTextTheme:
        TextTheme(subtitle1: TextStyle(color: LightColor.titleTextColor)),

    appBarTheme: AppBarTheme(
        //backgroundColor: LightColor.white,
        titleTextStyle: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
        //iconTheme: IconThemeData(color: LightColor.iconColor), //
        systemOverlayStyle: blueOverlayStyle),
    tabBarTheme: TabBarTheme(
      labelColor: LightColor.accent,
      unselectedLabelColor: LightColor.lightBlack,
    ),
    inputDecorationTheme: const InputDecorationTheme(
        focusColor: LightColor.black,
        contentPadding: EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        /*
        hintStyle:  TextStyle(
          color: LightColor.lightBlack50,

        ),
        labelStyle: TextStyle(
          color: LightColor.lightBlack,
        ),*/

        border: OutlineInputBorder(
          borderSide: BorderSide(
            color: LightColor.lightBlack50,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(8.0),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: LightColor.lightBlack50,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(8.0),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: LightColor.accent,
            width: 2.0,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(8.0),
          ),
        ),
        disabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: LightColor.grey,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(8.0),
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: LightColor.red,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(8.0),
          ),
        )),
    textTheme: TextTheme(
      headline1: h1Style,
      headline2: h2Style,
      headline3: h3Style,
      headline4: h4Style,
      headline5: h5Style,
      headline6: h6Style,
      bodyText1: titleStyle,
      bodyText2: subTitleStyle,
      subtitle1: titleStyle,
      subtitle2: subTitleStyle,
    ),
  );

  static TextStyle titleStyle =
      const TextStyle(color: LightColor.titleTextColor, fontSize: 16.0 * 1.2);
  static TextStyle subTitleStyle =
      const TextStyle(color: LightColor.subTitleTextColor, fontSize: 12 * 1.2);

  static TextStyle h1Style =
      const TextStyle(fontSize: 24, fontWeight: FontWeight.bold);
  static TextStyle h2Style =
      const TextStyle(fontSize: 22, color: LightColor.titleTextColor);
  static TextStyle h3Style =
      const TextStyle(fontSize: 20, color: LightColor.titleTextColor);
  static TextStyle h4Style =
      const TextStyle(fontSize: 18, color: LightColor.titleTextColor);
  static TextStyle h5Style =
      const TextStyle(fontSize: 16, color: LightColor.titleTextColor);
  static TextStyle h6Style =
      const TextStyle(fontSize: 14, color: LightColor.titleTextColor);

  static List<BoxShadow> shadow = <BoxShadow>[
    BoxShadow(color: Color(0xfff8f8f8), blurRadius: 10, spreadRadius: 15),
  ];

  static EdgeInsets padding =
      const EdgeInsets.symmetric(horizontal: 20, vertical: 10);
  static EdgeInsets hPadding = const EdgeInsets.symmetric(
    horizontal: 10,
  );

  static double fullWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  static double fullHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }
}

class ThemPageHeaderClipper extends CustomClipper<Path> {
  final double start;
  final double end;
  ThemPageHeaderClipper({
    this.start = 40.0,
    this.end = 40.0,
  });
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - start);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - end);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
