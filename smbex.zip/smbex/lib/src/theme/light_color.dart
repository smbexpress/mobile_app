import 'package:flutter/material.dart';

class LightColor {

  static const Color white = Colors.white;

  static const Color background = Color(0XFFF4F7FF);

  static const Color titleTextColor = const Color(0xff000000);
  static const Color subTitleTextColor = const Color(0xff1b1718);

  static const Color blue = Color(0xff2633C5);
  static const Color skyBlue = Color(0xff71b4fb);
  static const Color lightBlue = Color(0xff7fbcfb);
  static const Color extraLightBlue = Color(0xffd9eeff);


  static const Color orange = Color(0xfffa8c73);
  static const Color lightOrange = Color(0xfffa9881);

  static const Color purple = Color(0xff8873f4);
  static const Color purpleLight = Color(0xff9489f4);
  static const Color purpleExtraLight = Color(0xffb1a5f6);

  static const Color grey = Color(0xffb8bfce);
  static const Color grey70 = Color(0xb3b8bfce);
  static const Color iconColor = Color(0xff575757);
  static const Color green = Color(0xff267F00);
  static const Color lightGreen = Color(0xff5ed6c3);

  static const Color red = Color(0xffCE0000);
  static const Color lightRed = Color(0xffE41848);

  static const Color black = Color(0xff20262C);
  static const Color lightBlack = Color(0xff5F5F60);
  static const Color lightBlack50 = Color(0xb35f5f60);
  static const Color shadow = Color(0x88b8bfce);
  static const Color accent = Color(0xFF3686f0);

}
