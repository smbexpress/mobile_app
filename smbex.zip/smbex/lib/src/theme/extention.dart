import 'package:flutter/material.dart';

import 'light_color.dart';

extension TextStyleHelpers on TextStyle {
  TextStyle get bold => copyWith(fontWeight: FontWeight.bold);
  TextStyle get white => copyWith(color: LightColor.white);
  TextStyle get subTitleColor => copyWith(color: LightColor.subTitleTextColor);
  TextStyle get accent => copyWith(color: LightColor.accent);
  TextStyle scale(double size) => copyWith(fontSize: size);
  TextStyle get w400 => copyWith(fontWeight: FontWeight.w400);
  TextStyle get w500 => copyWith(fontWeight: FontWeight.w500);
  TextStyle get w600 => copyWith(fontWeight: FontWeight.w600);
  TextStyle opacity(double opacity) => copyWith(color: LightColor.subTitleTextColor.withOpacity(opacity));
}

extension PaddingHelper on Widget {
  Padding get p16 => Padding(padding: EdgeInsets.all(16), child: this);

  /// Set padding according to `value`
  Padding p(double value) =>
      Padding(padding: EdgeInsets.all(value), child: this);

  /// Horizontal Padding 16
  Padding get hP4 => Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: this);
  Padding get hP8 => Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: this);
  Padding get hP16 => Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: this);

  /// Vertical Padding 16
  Padding get vP16 =>
      Padding(padding: EdgeInsets.symmetric(vertical: 16), child: this);
  Padding get vP8 =>
      Padding(padding: EdgeInsets.symmetric(vertical: 8), child: this);
  Padding get vP4 =>
      Padding(padding: EdgeInsets.symmetric(vertical: 8), child: this);
}

extension Extented on Widget {
  Expanded get extended => Expanded(
        child: this,
      );
}
extension CornerRadius on Widget {
  ClipRRect get circular=> ClipRRect(
    borderRadius: BorderRadius.all(Radius.circular(1000)),
    child: this,
  );
}
extension OnPressed on Widget {
  Widget  ripple(Function onPressed, {
    BorderRadiusGeometry borderRadius = const BorderRadius.all(Radius.circular(5)),
    OutlinedBorder shape,
    Color splashColor
  }) => Stack(
      children: <Widget>[
        this,
        Positioned(
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          child: TextButton(
            style: TextButton.styleFrom(
              shape: shape ?? RoundedRectangleBorder(
                  borderRadius: borderRadius
              ),
              foregroundColor: splashColor
            ),
            onPressed: onPressed,
            child: Container()
          ),
        )
      ],
    );
}

extension ExAlignment on Widget{
  Widget get alignTopCenter => Align(child: this,alignment: Alignment.topCenter,);
  Widget get alignCenter => Align(child: this,alignment: Alignment.center,);
  Widget get alignBottomCenter => Align(child: this,alignment: Alignment.bottomCenter,);
  Widget get alignBottomLeft => Align(child: this,alignment: Alignment.bottomLeft,);
}

extension ColorExtension on Color {
  /// Convert the color to a darken color based on the [percent]
  Color darken([int percent = 40]) {
    assert(1 <= percent && percent <= 100);
    final value = 1 - percent / 100;
    return Color.fromARGB(
        alpha, (red * value).round(), (green * value).round(), (blue * value).round());
  }
}