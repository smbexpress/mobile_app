import 'package:flutter/material.dart';

import 'light_color.dart';

class FontSizes {
  static double scale = 1.2;
  static double get body => 14 * scale;
  static double get bodySm => 12 * scale;
  static double get title => 16 * scale;
  static double get titleM => 18 * scale;
  static double get sizeXL => 22 * scale;
  static double get sizeXXl => 28 * scale;
}
 
class TextStyles {
  static TextStyle get title => TextStyle(fontSize: FontSizes.title, color: LightColor.titleTextColor);
  static TextStyle get titleM =>TextStyle(fontSize: FontSizes.titleM, color: LightColor.titleTextColor);
  static TextStyle get titleXL =>TextStyle(fontSize: FontSizes.sizeXL, color: LightColor.titleTextColor);
  static TextStyle get titleNormal => title.copyWith(fontWeight: FontWeight.w500, color: LightColor.titleTextColor);
  static TextStyle get titleMedium => titleM.copyWith(fontWeight: FontWeight.w300, color: LightColor.titleTextColor);
  static TextStyle get h1Style => TextStyle(fontSize: FontSizes.sizeXXl, fontWeight: FontWeight.bold, color: LightColor.titleTextColor);
 
  static TextStyle get body => TextStyle(fontSize: FontSizes.body, fontWeight: FontWeight.w400);
  static TextStyle get bodySm => body.copyWith(fontSize: FontSizes.bodySm);
}