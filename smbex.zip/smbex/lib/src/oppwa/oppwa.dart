import 'package:flutter/services.dart';

class Oppwa {

  static const _platform = const MethodChannel('smbex.oppwa.fultter/channel');

  static Future<dynamic> checkout(Map<String, dynamic> data) async {
    try {
      final dynamic result = await _platform.invokeMethod('checkout', data);
      return Future.value(result);
    } on PlatformException catch (e) {
      return Future.error(e);
    }
  }
}