
import 'package:flutter/material.dart';

class EntityAction {
  final String name;
  final IconData icon;
  const EntityAction(this.name, [this.icon]);

  @override
  String toString() => name;
}


class Entity<D>{
  Entity({
    this.name,
    this.id,
    this.args,
    this.data,
    this.isNew
  });

  final String name;
  final dynamic id;
  final Map<String, dynamic> args;
  final D data;
  final bool isNew;

  dynamic getData(String key){
    return args != null ? args[key] : null;
  }
}


void inspectEntity({
  Entity entity,
  String action,
  bool longPress=false
}) {

}

void handleEntityAction(Entity entity, EntityAction action){

}

void handleEntity(Entity entity, {
  EntityAction action,
  bool longPress=false
}) {

}


IconData getEntityIcon(String entityType){
  return Icons.access_time;
}


String getEntityTitle(Entity entity, BuildContext context){
  return entity.name;
}

String getActionTitle(EntityAction action, BuildContext context){
  return action.name;
}

List<EntityAction> getEntityActions(Entity entity, BuildContext context){
  return [];
}