
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smbex_app/src/repository/account_repository.dart';
import 'package:smbex_app/src/screens/address/addresses.dart';
import 'package:smbex_app/src/screens/address/show_address.dart';
import 'package:smbex_app/src/screens/bill/bills.dart';
import 'package:smbex_app/src/screens/branch/BranchesScreen.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/screens/delivery/address_validation.dart';
import 'package:smbex_app/src/screens/delivery/delivery_screen.dart';
import 'package:smbex_app/src/screens/notifications.dart';
import 'package:smbex_app/src/screens/otp_verification.dart';
import 'package:smbex_app/src/screens/payment/transactions.dart';
import 'package:smbex_app/src/screens/profile.dart';
import 'package:smbex_app/src/screens/shipment/create_shipment_screen.dart';
import 'package:smbex_app/src/screens/shipment/shipment_detail.dart';
import 'package:smbex_app/src/screens/shipment/shipments.dart';
import 'package:smbex_app/src/screens/reset_password.dart';
import 'package:smbex_app/src/screens/signup.dart';
import 'package:smbex_app/src/screens/tracking/tracking.dart';
import 'package:smbex_app/src/screens/wallet/wallet.dart';
import 'package:smbex_app/src/theme/light_color.dart';
import 'package:smbex_app/src/widgets/fab_fill_transition.dart';

import 'src/models/route_argument.dart';
import 'src/screens/cart.dart';
import 'src/screens/checkout.dart';
import 'src/screens/languages.dart';
import 'src/screens/order_success.dart';
import 'src/screens/pages.dart';
import 'src/screens/payment/payment_methods.dart';
import 'src/screens/signin.dart';
import 'src/screens/splash_screen.dart';
//ConnectionStatusWidget
class RouteGenerator {

  static PageRouteBuilder<dynamic> buildFabRoute(
      GlobalKey key,
      Widget child,
      Widget icon){

    final RenderBox box = key.currentContext.findRenderObject();
    final Rect sourceRect = box.localToGlobal(Offset.zero) & box.size;

    return PageRouteBuilder<dynamic>(
      pageBuilder: (BuildContext context, _, __) => FabFillTransition(
          source: sourceRect,
          icon: icon,
          child: child
      ),
      transitionDuration: const Duration(milliseconds: 350),
    );
  }

  static Route<T> buildConnectionStatusRoute<T>(
      WidgetBuilder builder,
      RouteSettings settings,
      [bool auth=true]
      ){
    var route;
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      return CupertinoPageRoute<T>(builder: builder, settings: settings);
    }
    return MaterialPageRoute<T>(builder: builder, settings: settings);
  }

  static Route<dynamic> generateRoute(RouteSettings settings) {
    // Getting arguments passed in while calling Navigator.pushNamed
    final args = settings.arguments;
    switch (settings.name) {
      case '/':
      case '/Splash':
        return MaterialPageRoute(builder: (_) => SplashScreen(), settings: settings);
      case '/Reset':
        return buildConnectionStatusRoute((_) => ResetPasswordWidget(), settings, false);
      case '/Reset':
        return buildConnectionStatusRoute((_) => ResetPasswordWidget(), settings, false);
      case '/Login':
        return buildConnectionStatusRoute((_) => SignInWidget(), settings, false);
      case '/SignUp':
        return buildConnectionStatusRoute((_) => SignUpWidget(), settings, false);
      case '/Verify':
        return buildConnectionStatusRoute((_) => OtpVerificationWidget(), settings, false);
      case '/Home':
        return buildConnectionStatusRoute((_) => PagesWidget(currentTab: args), settings, false);
      case '/Tracking':
        {
          final trackArgs = args as RouteArgument;
          return buildConnectionStatusRoute((_) => TrackingPage(trackingCode:trackArgs?.id), settings,
              false);
        }
      case '/PaymentMethods':
        return buildConnectionStatusRoute((_) => PaymentMethodsWidget(), settings);
      case '/Profile':
        return buildConnectionStatusRoute((_) => ProfileScreen(), settings);
      case '/DeliveryAddresses':
      case '/Addresses':
        return buildConnectionStatusRoute((_) => AddressesScreen(routeArgument: args as RouteArgument), settings);
      case "/AddressShow":
        return buildConnectionStatusRoute((_) => AddressesShowScreen(args: args as RouteArgument), settings);

     case '/Shipments':
        {
          final filterArgs = args as RouteArgument;
          return buildConnectionStatusRoute((_) => ShipmentsWidget(args: filterArgs,), settings);
        }
      //case '/ShipmentEdit':
      case '/DeliveryValidation':
        {
          final validationArgs = args as RouteArgument;
          return buildConnectionStatusRoute((_) =>
              AddressesValidateScreen(args: validationArgs,), settings);
        }
      case '/PickupValidation':
        {
          final validationArgs = args as RouteArgument;
          return buildConnectionStatusRoute((_) =>
              AddressesValidateScreen(args: validationArgs, isDelivery: false,),
              settings);
        }
      case '/ShipmentEdit':
      case '/Rate':
        {

          final page = CreateShipmentScreen(
              edit: settings.name != '/Rate',
              routeArgument: args is RouteArgument ? args : null
          );
          if (args is GlobalKey) {
            return buildFabRoute(args, page,
                Icon(currentAccount.value.valid? Icons.add : Icons.home, size: 24, color: LightColor.accent,));
          }
          return buildConnectionStatusRoute((_) => page, settings);
        }
      case '/ShipmentDetail':
        return buildConnectionStatusRoute((_) => ShipmentDetailScreen(args: args as RouteArgument), settings);
      case '/Delivery':
        return buildConnectionStatusRoute((_) => DeliveryScreen(args: args as RouteArgument), settings);
      case '/Checkout':
        return buildConnectionStatusRoute((_) => CheckoutScreen(), settings);
      case '/Cart':
        return buildConnectionStatusRoute((_) => CartWidget(), settings);
      case '/CashOnDelivery':
        return buildConnectionStatusRoute((_) => OrderSuccessWidget(args: RouteArgument(param: 'Cash on Delivery')), settings);
      case '/PayOnPickup':
        return buildConnectionStatusRoute((_) => OrderSuccessWidget(args: RouteArgument(param: 'Pay on Pickup')), settings);
      case "/Notifications":
        return buildConnectionStatusRoute((_) => NotificationsPage(), settings);
      case '/OrderSuccess':
        return buildConnectionStatusRoute((_) => OrderSuccessWidget(args: args as RouteArgument), settings);
      case '/Languages':
        return buildConnectionStatusRoute((_) => LanguagesScreen(), settings, false);
      case '/LanguageSetup':
        return buildConnectionStatusRoute((_) => LanguageSetupScreen(), settings, false);
      //case '/Help':
      //  return buildConnectionStatusRoute((_) => HelpWidget(), settings, false);
      case '/Branches':
        //return MaterialPageRoute(builder: (_) => SmbMainScreen());
        return buildConnectionStatusRoute((_) => BranchScreen(), settings, false);
      case '/Wallet':
      //return MaterialPageRoute(builder: (_) => SmbMainScreen());
        return buildConnectionStatusRoute((_) => Wallet(), settings, true);
      case '/Transactions':
        return buildConnectionStatusRoute((_) => TransactionList(), settings, true);
      case '/Bills':
        return buildConnectionStatusRoute((_) => BillList(), settings, true);
      default:
        // If there is no such named route in the switch statement, e.g. /third
        return MaterialPageRoute(builder: (_) => Scaffold(
                body: Container(child: Center(
                  child: Text("Page ${settings.name} not found"),
                ),)
            ),
            settings: settings
        );
    }
  }
}
