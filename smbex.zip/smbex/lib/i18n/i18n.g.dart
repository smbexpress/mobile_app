// @dart=2.12

/*
 * Generated file. Do not edit.
 *
 * Locales: 2
 * Strings: 794 (397.0 per locale)
 *
 * Built on 2023-03-07 at 00:06 UTC
 */

import 'package:flutter/widgets.dart';

const AppLocale _baseLocale = AppLocale.en;
AppLocale _currLocale = _baseLocale;

/// Supported locales, see extension methods below.
///
/// Usage:
/// - LocaleSettings.setLocale(AppLocale.en) // set locale
/// - Locale locale = AppLocale.en.flutterLocale // get flutter locale from enum
/// - if (LocaleSettings.currentLocale == AppLocale.en) // locale check
enum AppLocale {
	en, // 'en' (base locale, fallback)
	ar, // 'ar'
}

/// Method A: Simple
///
/// No rebuild after locale change.
/// Translation happens during initialization of the widget (call of t).
///
/// Usage:
/// String a = t.someKey.anotherKey;
I18nEn _t = _currLocale.translations;
I18nEn get t => _t;

/// Method B: Advanced
///
/// All widgets using this method will trigger a rebuild when locale changes.
/// Use this if you have e.g. a settings page where the user can select the locale during runtime.
///
/// Step 1:
/// wrap your App with
/// TranslationProvider(
/// 	child: MyApp()
/// );
///
/// Step 2:
/// final t = Translations.of(context); // Get t variable.
/// String a = t.someKey.anotherKey; // Use t variable.
class Translations {
	Translations._(); // no constructor

	static I18nEn of(BuildContext context) {
		final inheritedWidget = context.dependOnInheritedWidgetOfExactType<_InheritedLocaleData>();
		if (inheritedWidget == null) {
			throw 'Please wrap your app with "TranslationProvider".';
		}
		return inheritedWidget.translations;
	}
}

class LocaleSettings {
	LocaleSettings._(); // no constructor

	/// Uses locale of the device, fallbacks to base locale.
	/// Returns the locale which has been set.
	static AppLocale useDeviceLocale() {
		final locale = AppLocaleUtils.findDeviceLocale();
		return setLocale(locale);
	}

	/// Sets locale
	/// Returns the locale which has been set.
	static AppLocale setLocale(AppLocale locale) {
		_currLocale = locale;
		_t = _currLocale.translations;

		// force rebuild if TranslationProvider is used
		_translationProviderKey.currentState?.setLocale(_currLocale);

		return _currLocale;
	}

	/// Sets locale using string tag (e.g. en_US, de-DE, fr)
	/// Fallbacks to base locale.
	/// Returns the locale which has been set.
	static AppLocale setLocaleRaw(String rawLocale) {
		final locale = AppLocaleUtils.parse(rawLocale);
		return setLocale(locale);
	}

	/// Gets current locale.
	static AppLocale get currentLocale {
		return _currLocale;
	}

	/// Gets base locale.
	static AppLocale get baseLocale {
		return _baseLocale;
	}

	/// Gets supported locales in string format.
	static List<String> get supportedLocalesRaw {
		return AppLocale.values
			.map((locale) => locale.languageTag)
			.toList();
	}

	/// Gets supported locales (as Locale objects) with base locale sorted first.
	static List<Locale> get supportedLocales {
		return AppLocale.values
			.map((locale) => locale.flutterLocale)
			.toList();
	}
}

/// Provides utility functions without any side effects.
class AppLocaleUtils {
	AppLocaleUtils._(); // no constructor

	/// Returns the locale of the device as the enum type.
	/// Fallbacks to base locale.
	static AppLocale findDeviceLocale() {
		final String? deviceLocale = WidgetsBinding.instance.window.locale.toLanguageTag();
		if (deviceLocale != null) {
			final typedLocale = _selectLocale(deviceLocale);
			if (typedLocale != null) {
				return typedLocale;
			}
		}
		return _baseLocale;
	}

	/// Returns the enum type of the raw locale.
	/// Fallbacks to base locale.
	static AppLocale parse(String rawLocale) {
		return _selectLocale(rawLocale) ?? _baseLocale;
	}
}

// context enums

// interfaces generated as mixins

// translation instances

late I18nEn _translationsEn = I18nEn.build();
late I18nAr _translationsAr = I18nAr.build();

// extensions for AppLocale

extension AppLocaleExtensions on AppLocale {

	/// Gets the translation instance managed by this library.
	/// [TranslationProvider] is using this instance.
	/// The plural resolvers are set via [LocaleSettings].
	I18nEn get translations {
		switch (this) {
			case AppLocale.en: return _translationsEn;
			case AppLocale.ar: return _translationsAr;
		}
	}

	/// Gets a new translation instance.
	/// [LocaleSettings] has no effect here.
	/// Suitable for dependency injection and unit tests.
	///
	/// Usage:
	/// final t = AppLocale.en.build(); // build
	/// String a = t.my.path; // access
	I18nEn build() {
		switch (this) {
			case AppLocale.en: return I18nEn.build();
			case AppLocale.ar: return I18nAr.build();
		}
	}

	String get languageTag {
		switch (this) {
			case AppLocale.en: return 'en';
			case AppLocale.ar: return 'ar';
		}
	}

	Locale get flutterLocale {
		switch (this) {
			case AppLocale.en: return const Locale.fromSubtags(languageCode: 'en');
			case AppLocale.ar: return const Locale.fromSubtags(languageCode: 'ar');
		}
	}
}

extension StringAppLocaleExtensions on String {
	AppLocale? toAppLocale() {
		switch (this) {
			case 'en': return AppLocale.en;
			case 'ar': return AppLocale.ar;
			default: return null;
		}
	}
}

// wrappers

GlobalKey<_TranslationProviderState> _translationProviderKey = GlobalKey<_TranslationProviderState>();

class TranslationProvider extends StatefulWidget {
	TranslationProvider({required this.child}) : super(key: _translationProviderKey);

	final Widget child;

	@override
	_TranslationProviderState createState() => _TranslationProviderState();

	static _InheritedLocaleData of(BuildContext context) {
		final inheritedWidget = context.dependOnInheritedWidgetOfExactType<_InheritedLocaleData>();
		if (inheritedWidget == null) {
			throw 'Please wrap your app with "TranslationProvider".';
		}
		return inheritedWidget;
	}
}

class _TranslationProviderState extends State<TranslationProvider> {
	AppLocale locale = _currLocale;

	void setLocale(AppLocale newLocale) {
		setState(() {
			locale = newLocale;
		});
	}

	@override
	Widget build(BuildContext context) {
		return _InheritedLocaleData(
			locale: locale,
			child: widget.child,
		);
	}
}

class _InheritedLocaleData extends InheritedWidget {
	final AppLocale locale;
	Locale get flutterLocale => locale.flutterLocale; // shortcut
	final I18nEn translations; // store translations to avoid switch call

	_InheritedLocaleData({required this.locale, required Widget child})
		: translations = locale.translations, super(child: child);

	@override
	bool updateShouldNotify(_InheritedLocaleData oldWidget) {
		return oldWidget.locale != locale;
	}
}

// pluralization feature not used

// helpers

final _localeRegex = RegExp(r'^([a-z]{2,8})?([_-]([A-Za-z]{4}))?([_-]?([A-Z]{2}|[0-9]{3}))?$');
AppLocale? _selectLocale(String localeRaw) {
	final match = _localeRegex.firstMatch(localeRaw);
	AppLocale? selected;
	if (match != null) {
		final language = match.group(1);
		final country = match.group(5);

		// match exactly
		selected = AppLocale.values
			.cast<AppLocale?>()
			.firstWhere((supported) => supported?.languageTag == localeRaw.replaceAll('_', '-'), orElse: () => null);

		if (selected == null && language != null) {
			// match language
			selected = AppLocale.values
				.cast<AppLocale?>()
				.firstWhere((supported) => supported?.languageTag.startsWith(language) == true, orElse: () => null);
		}

		if (selected == null && country != null) {
			// match country
			selected = AppLocale.values
				.cast<AppLocale?>()
				.firstWhere((supported) => supported?.languageTag.contains(country) == true, orElse: () => null);
		}
	}
	return selected;
}

// translations

// Path: <root>
class I18nEn {

	/// You can call this constructor and build your own translation instance of this locale.
	/// Constructing via the enum [AppLocale.build] is preferred.
	I18nEn.build();

	late final I18nEn _root = this; // ignore: unused_field

	// Translations
	String get appName => 'SMB Express';
	String get recent_reviews => 'Recent Reviews';
	String get login => 'Login';
	String get skip => 'Skip';
	String get about => 'About';
	String get submit => 'Submit';
	String get verify => 'Verify';
	String get verify_phone => 'Verify Phone';
	String get select_your_preferred_languages => 'Select your preferred languages';
	String get order_id => 'Order Id';
	String get checkout => 'Checkout';
	String get payment_mode => 'Payment Mode';
	String get paymentMethod => 'Payment Method';
	String get paymentMethods => 'Payment Methods';
	String get paymentCard => 'Payment card';
	String get select_your_preferred_payment_mode => 'Select your preferred payment mode';
	String get or_checkout_with => 'Or Checkout With';
	String get subtotal => 'Subtotal';
	String get total => 'Total';
	String get confirm_payment => 'Confirm Payment';
	String get menu => 'Menu';
	String get information => 'Information';
	String get options => 'Options';
	String get reviews => 'Reviews';
	String get quantity => 'Quantity';
	String get add_to_cart => 'Add to Cart';
	String get faq => 'Faq';
	String get help_supports => 'Help & Supports';
	String get app_language => 'App Language';
	String get i_forgot_password => 'I forgot password ?';
	String get i_dont_have_an_account => 'I don\'t have an account?';
	String get notifications => 'Notifications';
	String get notification_settings => 'Notification settings';
	String get confirmation => 'Confirmation';
	String get your_order_has_been_successfully_submitted => 'Your order has been successfully submitted!';
	String get tax => 'TAX';
	String get profile => 'Profile';
	String get favorites => 'Favorites';
	String get home => 'Home';
	String get payment_options => 'Payment Options';
	String get cash_on_delivery => 'Cash on delivery';
	String get cash_on_delivery_amount => 'Amount of cash on delivery';
	String get paypal_payment => 'PayPal Payment';
	String get recent_shipments => 'Recent Shipment';
	String get settings => 'Settings';
	String get profile_settings => 'Profile Settings';
	String get full_name => 'Full name';
	String get email => 'Email';
	String get phone => 'Phone';
	String get address => 'Address';
	String get addresses => 'Addresses';
	String get payments_settings => 'Payments Settings';
	String get default_credit_card => 'Default Credit Card';
	String get app_settings => 'App Settings';
	String get languages => 'Languages';
	String get english => 'English';
	String get help_support => 'Help & Support';
	String get register => 'Register';
	String get lets_start_with_register => 'Let\'s Start with register!';
	String get should_be_more_than_3_letters => 'Should be more than 3 letters';
	String get john_doe => 'John Doe';
	String get should_be_a_valid_email => 'Should be a valid email';
	String get should_be_more_than_6_letters => 'Should be more than 6 letters';
	String get password => 'Password';
	String get i_have_account_back_to_login => 'I have account? Back to login';
	String get tracking_order => 'Tracking Order';
	String get reset_cart => 'Reset Cart?';
	String get cart => 'Cart';
	String get shopping_cart => 'Shopping Cart';
	String get lets_start_with_login => 'Let\'s Start with Login!';
	String get should_be_more_than_3_characters => 'Should be more than 3 characters';
	String get reset => 'Reset';
	String get close => 'Close';
	String get application_preferences => 'Application Preferences';
	String get help__support => 'Help & Support';
	String get light_mode => 'Light Mode';
	String get dark_mode => 'Dark Mode';
	String get log_out => 'Log out';
	String get version => 'Version';
	String get empty_cart => 'Cart is empty';
	String get no_data_found => 'No data found';
	String get start_exploring => 'Start Exploring';
	String get empty_notification_list => 'Notification list is empty';
	String get payment_settings => 'Payment Settings';
	String get not_a_valid_number => 'Not a valid number';
	String get not_a_valid_date => 'Not a valid date';
	String get not_a_valid_cvc => 'Not a valid CVC';
	String get cancel => 'Cancel';
	String get save => 'Save';
	String get edit => 'Edit';
	String get not_a_valid_full_name => 'Not a valid full name';
	String get email_address => 'Email Address';
	String get not_a_valid_email => 'Not a valid email';
	String get not_a_valid_phone => 'Not a valid phone';
	String get not_a_valid_address => 'Not a valid address';
	String get not_a_valid_address_description => 'Not a valid address Description';
	String get not_a_valid_biography => 'Not a valid biography';
	String get your_biography => 'Your biography';
	String get your_address => 'Your Address';
	String get search => 'Search';
	String get recents_search => 'Recents Search';
	String get verify_your_internet_connection => 'Please, verify your internet connection';
	String get carts_refreshed_successfuly => 'Carts refreshed successfully';
	String get notifications_refreshed_successfuly => 'Notifications refreshed successfully';
	String get order_refreshed_successfuly => 'Order refreshed successfully';
	String get orders_refreshed_successfuly => 'Orders refreshed successfully';
	String get profile_settings_updated_successfully => 'Profile settings updated successfully';
	String get payment_settings_updated_successfully => 'Payment settings updated successfully';
	String get tracking_refreshed_successfuly => 'Tracking refreshed successfully';
	String get welcome => 'Welcome';
	String get wrong_email_or_password => 'Wrong email or password';
	String get addresses_refreshed_successfuly => 'Addresses refreshed successfuly';
	String get add => 'Add';
	String get new_address_added_successfully => 'New Address added successfully';
	String get the_address_updated_successfully => 'The address updated successfully';
	String get long_press_to_edit_item_swipe_item_to_delete_it => 'Long press to edit item, swipe item to delete it';
	String get add_delivery_address => 'Add Shipping Address';
	String get home_address => 'Home Address';
	String get description => 'Description';
	String get hint_full_address => '12 Street, City 21663, Country';
	String get full_address => 'Full Address';
	String get email_to_reset_password => 'Email to reset password';
	String get send_password_reset_link => 'Send link';
	String get i_remember_my_password_return_to_login => 'I remember my password return to login';
	String get your_reset_link_has_been_sent_to_your_email => 'Your reset link has been sent to your email';
	String get error_verify_email_settings => 'Error! Verify email settings';
	String get guest => 'Guest';
	String get you_must_signin_to_access_to_this_section => 'You must sign-in to access to this section';
	String get reviews_refreshed_successfully => 'Reviews refreshed successfully!';
	String get delivery_fee => 'SHipping Fee';
	String get order_status_changed => 'Order status changed';
	String get new_order_from_client => 'New order from client';
	String get shopping => 'Shopping';
	String get delivery_or_pickup => 'Delivery or Pickup';
	String get payment_card_updated_successfully => 'Payment card updated successfully';
	String get deliverable => 'Deliverable';
	String get not_deliverable => 'Not Deliverable';
	String get items => 'Items';
	String get delivery => 'Delivery';
	String get pickup => 'Pickup';
	String get closed => 'Closed';
	String get open => 'Open';
	String get km => 'Km';
	String get mi => 'mi';
	String get current_location => 'Current location';
	String get delivery_address_removed_successfully => 'Delivery Address removed successfully';
	String get add_new_delivery_address => 'Add new delivery address';
	String get stores_near_to_your_current_location => 'Stores near to your current location';
	String get stores_near_to => 'Stores near to';
	String get near_to => 'Near to';
	String get near_to_your_current_location => 'Near to your current location';
	String get pickup_your_product_from_the_store => 'Pickup your product from the store';
	String get confirm_your_delivery_address => 'Confirm your shipping address';
	String get filter => 'Filter';
	String get clear => 'Clear';
	String get apply_filters => 'Apply Filters';
	String get fields => 'Fields';
	String get all => 'All';
	String get unknown => 'Unknown';
	String get click_on_the_stars_below_to_leave_comments => 'Click on the stars below to leave comments';
	String get visa_card => 'Visa Card';
	String get mastercard => 'MasterCard';
	String get paypal => 'PayPal';
	String get pay_on_pickup => 'Pay on Pickup';
	String get click_to_credit_card_payment => 'Click to pay using credit card';
	String get click_to_pay_cash_on_delivery => 'Click to pay cash on delivery';
	String get click_to_pay_on_pickup => 'Click to pay on pickup';
	String get this_email_account_exists => 'This email account exists';
	String get this_account_not_exist => 'This account not exist';
	String get card_number => 'CARD NUMBER';
	String get expiry_date => 'EXPIRY ON';
	String get cvv => 'CVV';
	String get your_credit_card_not_valid => 'Your credit card not valid';
	String get number => 'Number';
	String get exp_date => 'Exp Date';
	String get cvc => 'CVC';
	String get verify_your_account => 'Verify Your Account';
	String otpSentTo(Object phone) => 'Sending OTP to $phone, Please validate your mobile number';
	String get detail => 'Detail';
	String get review => 'Review';
	String get featured => 'Featured';
	String get your_reviews => 'Product Reviews';
	String get make_it_default => 'Set as default';
	String get this_notification_was_removed => 'This notification was removed';
	String get unpaid => 'Unpaid';
	String get shipped => 'Shipped';
	String get on_the_way => 'On the Way';
	String get preparing => 'Preparing';
	String get completeYourProfileDetailsToContinue => 'Complete your profile details to continue';
	String get select_country => 'Select Country';
	String get select_city => 'Select city';
	String get pickup_addresses => 'Pickup Addresses';
	String get delivery_addresses => 'Delivery Addresses';
	String get pickup_address => 'Pickup Address';
	String get delivery_address => 'Delivery Address';
	String get default_address => 'Default Address';
	String get your_mobile => 'Your mobile number';
	String get arrived => 'Arrived';
	String get delivered => 'Delivered';
	String get cancelled => 'Cancelled';
	String get in_origin => 'In Origin';
	String get plate_number => 'Plate Number';
	String get optional => 'Optional';
	String get model_year => 'Model Year';
	String get booking_notes => 'Booking Notes';
	String get pickup_date => 'Pickup Date';
	String get pickup_time => 'Pickup Time';
	String get notes => 'Notes';
	String get send => 'Send';
	String get shipmentDetail => 'Shipment detail';
	String get newShipment => 'New shipment';
	String get editShipment => 'Edit shipment';
	String get new_address => 'New address';
	String get yes => 'Yes';
	String get zip => 'ZIP';
	String get street => 'Street Address';
	String get city => 'City';
	String get country => 'Country';
	String get mobile => 'Mobile';
	String get booking_id => 'Booking id';
	String get should_be_a_valid_phone => 'Should be a valid phone number';
	String smsHasBeenSentTo(Object phone) => 'SMS has been sent to $phone';
	String get phoneToSendSms => 'Phone to send SMS';
	String get yourPhoneNumber => 'Your Phone Number';
	String get resend => 'Re-Send';
	String get edit_name => 'Edit Name';
	String get change_password => 'Change Password';
	String get track_shipment => 'Track Shipment';
	String get tracking_results => 'Tracking Results';
	String get add_address => 'Add Address';
	String get edit_address => 'Edit Address';
	String get select_pick_addess => 'Select Pickup Address';
	String get selectDefaultAddress => 'Select Delivery Address';
	String get select_pick_date => 'Select Pickup Date';
	String get select_pic_time => 'Select Pickup Time';
	String get warning => 'Warning';
	String get error => 'Error';
	String get upgradePrompt => 'Would you like to update it now?';
	String upgradeMessage(Object appName) => 'A new version of $appName is available!';
	String get upgradeReleaseNotes => 'Release Notes';
	String get upgradeUpdateApp => 'Update App?';
	String get logoutConfirm => 'Are you sure?\nLogout of your account?';
	String get privacy => 'privacy';
	String get termAndConditions => 'Term and conditions';
	String get shipment => 'Shipment';
	String get shipments => 'Shipments';
	String get shipment_list => 'Shipment List';
	String get rate => 'Rate';
	String get from_country => 'From country';
	String get from_city => 'From city';
	String get to_country => 'To country';
	String get to_city => 'To city';
	String get branch => 'Branch';
	String get branches => 'Branches';
	String get content => 'Content';
	String get setup => 'Setup';
	String get rateShipment => 'Rate Shipment';
	String get pickupDate => 'Pickup Date';
	String get pickupTime => 'Pickup Time';
	String get selectValidShippingAddressFirst => 'Select valid shipping address first!';
	String get itemRate => 'Item Rate';
	String get noRateAvailable => 'No rate available!';
	String get cancelShipment => 'Cancel shipment';
	String get createReturnShipment => 'Create return shipment';
	String get showPdfLabel => 'Show PDF label';
	String get pdfLabel => 'PDF label';
	String get selectAction => 'Select Action';
	String get shipmentCreatedSuccess => 'Shipment created successfully';
	String get done => 'Done';
	String get oops => 'oops!';
	String get account => 'Account';
	String get general => 'General';
	String get accountSettings => 'Account settings';
	String get tapBackAgainToLeave => 'Tap back again to leave';
	String get packageType => 'Package type';
	String get packageInfo => 'Package information';
	String get service => 'Service';
	String get weight => 'Weight';
	String get trackShipment => 'Track shipment';
	String get track => 'Track';
	String get setTrackingShipment => 'Write tracking code';
	String get eta => 'Estimated delivery date';
	String get copiedToClipboard => 'Copied :value to the clipboard';
	String get saveAsDefault => 'Save as default';
	String get saveToUseLater => 'Save to use it later';
	String get shipFromBranch => 'Shipping from branch';
	String get deliveryToBranch => 'Delivery to a branch';
	String get selectBranch => 'Select branch';
	String get from => 'From';
	String get to => 'To';
	String get more => 'More';
	String get retry => 'Retry';
	String get enableLocation => 'Enable location service';
	String get enableLocationPermission => 'Enable location permission';
	String get outgoing => 'Outgoing';
	String get outgoingShipments => 'Outgoing shipments';
	String get incoming => 'Incoming';
	String get incomingShipments => 'Incoming shipments';
	String get balance => 'Balance';
	String get acceptTerm => 'Accept term & condition';
	String get saveTrackingHistory => 'Save to tracking history';
	String get removeTrackingHistory => 'Remove from tracking history';
	String get trackingHistory => 'Tracking history';
	String get notSetYet => 'Not set yet';
	String get payNow => 'Pay now';
	String get home_init_line1 => 'Delivery what you need';
	String get home_init_line2 => 'Just stay at home';
	String get workingTime => 'Working time';
	String get tapToSelectPackageType => 'Tap to select package type';
	String get selectRate => 'Choose suitable rate';
	String get verifyYourEmail => 'Please check your inbox to verify the email.';
	String get shareApp => 'Share App';
	String get shareTitle => 'Install SMB Express App';
	String get shareText => 'Create a shipping label, track shipment status and manage your addresses wherever you are with the SMB express mobile app';
	String get addNewCreditCard => 'Add new credit card';
	late final I18nButtonsEn buttons = I18nButtonsEn._(_root);
	late final I18nStatusMapEn statusMap = I18nStatusMapEn._(_root);
	late final I18nErrorMessagesEn errorMessages = I18nErrorMessagesEn._(_root);
	late final I18nFormEn form = I18nFormEn._(_root);
	String get showWaybillInvoice => 'Show waybill invoice';
	String get waybillInvoice => 'Waybill invoice';
	String get deliveryConfirm => 'Delivery info confirmation';
	String get pickupConfirm => 'Pickup info confirmation';
	String get selectOnMap => 'Select from maps';
	String confirmDeleteAddress(Object address) => 'You have chosen to delete the address: "$address".\nAre you sure you want to delete?';
	String get subject => 'Subject';
	String get loginOrSignupDes => 'Login or signup your account';
	String get accountSettingsDes => 'Account settings & profile information';
	String get browsePickupAddressDes => 'Browse your pickup address list';
	String get browseDeliveryAddressDes => 'Browse your delivery address list';
	String get openPrivacyDes => 'Open privacy policy';
	String get helpTopicsDes => 'Help topics';
	String get openTermsDes => 'Open terms & conditions';
	String get infoAboutDes => 'Information about us';
	String get senFeedback => 'Send feedback';
	String get senFeedbackDes => 'Your comments will be of interest to us';
	String get paymentMethodUnavailable => 'Payment methods currently unavailable';
	String get paymentDoneSuccess => 'Payment completed successfully.';
	String get creditCard => 'Credit card';
	String get cash => 'Cash';
	String get writeFeedbackToUs => 'What would you rate smb express?';
	String get writeFeedback => 'Write feedback';
	String get sendFeedback => 'Send feedback';
	String get writeComment => 'Write comment';
	String get askQuestion => 'Ask question';
	String get parcelQuantity => 'Parcel quantity';
	String get bills => 'Bills';
	String get bill => 'Bill';
	String get myBills => 'My bills';
	String get transactions => 'Transactions';
	String get transaction => 'transaction';
	String emptyItemList(Object items) => 'The list of $items is empty!';
	String confirmDeleteItem(Object entity, Object item) => 'You have chosen to delete $entity: "$item".\nAre you sure you want to delete?';
	String get confirmShipmentTermLink => 'By confirming, You are agree to our ';
	String get addressNotSupported => 'Our shipping is not supported the selected location!';
	String get tapToSelectLocation => 'Tap to select this location';
}

// Path: buttons
class I18nButtonsEn {
	I18nButtonsEn._(this._root);

	final I18nEn _root; // ignore: unused_field

	// Translations
	String get yes => 'Yes';
	String get No => 'No';
	String get discard => 'Discard';
	String get ignore => 'Ignore';
	String get later => 'Later';
	String get update => 'Update';
	String get submit => 'Submit';
	String get publish => 'Publish';
	String get backToScan => 'Back to scan';
	String get ok => 'OK';
	String get cancel => 'Cancel';
	String get clear => 'Clear';
	String get delete => 'Delete';
	String get remove => 'Remove';
	String get add => 'Add';
	String get copy => 'Copy';
	String get scan => 'Scan';
	String get save => 'Save';
	String get back => 'Back';
	String get send => 'Send';
	String get updateNow => 'Update Now';
	String get next => 'Next';
	String get previous => 'Previous';
	String get changePaymentMethod => 'Select';
	String get finish => 'Finish';
	String get confirm => 'Confirm';
}

// Path: statusMap
class I18nStatusMapEn {
	I18nStatusMapEn._(this._root);

	final I18nEn _root; // ignore: unused_field

	// Translations
	String get shipped => 'Shipped';
	String get inTransit => 'In Transit';
	String get arrived => 'Arrived';
	String get delivered => 'Delivered';
}

// Path: errorMessages
class I18nErrorMessagesEn {
	I18nErrorMessagesEn._(this._root);

	final I18nEn _root; // ignore: unused_field

	// Translations
	String get somethingWrong => 'Something went wrong';
}

// Path: form
class I18nFormEn {
	I18nFormEn._(this._root);

	final I18nEn _root; // ignore: unused_field

	// Translations
	String get requiredErrorText => 'This field cannot be empty.';
	String minErrorText(Object min) => 'Value must be greater than or equal to $min.';
	String minLengthErrorText(Object minLength) => 'Value must have a length greater than or equal to $minLength';
	String maxErrorText(Object max) => 'Value must be less than or equal to $max';
	String maxLengthErrorText(Object maxLength) => 'Value must have a length less than or equal to $maxLength';
	String get emailErrorText => 'This field requires a valid email address.';
	String get integerErrorText => 'This field requires a valid integer.';
	String equalErrorText(Object value) => 'This field value must be equal to $value.';
	String notEqualErrorText(Object value) => 'This field value must not be equal to $value.';
	String get urlErrorText => 'This field requires a valid URL address.';
	String get matchErrorText => 'Value does not match pattern.';
	String get numericErrorText => 'Value must be numeric.';
	String get creditCardErrorText => 'This field requires a valid credit card number.';
	String get ipErrorText => 'This field requires a valid IP.';
	String get dateStringErrorText => 'This field requires a valid date string.';
}

// Path: <root>
class I18nAr extends I18nEn {

	/// You can call this constructor and build your own translation instance of this locale.
	/// Constructing via the enum [AppLocale.build] is preferred.
	I18nAr.build()
		: super.build();

	@override late final I18nAr _root = this; // ignore: unused_field

	// Translations
	@override String get appName => 'SMB Express';
	@override String get recent_reviews => 'المراجعات الأخيرة';
	@override String get login => 'تسجيل الدخول';
	@override String get skip => 'تجاهل';
	@override String get about => 'عن';
	@override String get submit => 'أرسل';
	@override String get verify => 'التحقق';
	@override String get verify_phone => 'التحقق من رقم الجوال';
	@override String get select_your_preferred_languages => 'اختر لغتك المفضلة';
	@override String get order_id => 'رقم الطلب';
	@override String get checkout => 'السداد';
	@override String get payment_mode => 'طريقة السداد';
	@override String get paymentMethod => 'طريقة الدفع';
	@override String get paymentMethods => 'طٌرق الدفع';
	@override String get paymentCard => 'بطاقة الدفع';
	@override String get select_your_preferred_payment_mode => 'اختر طريقة السداد المفضلة';
	@override String get or_checkout_with => 'أو السداد عبر';
	@override String get subtotal => 'الإجمالي الفرعي';
	@override String get total => 'الإجمالي';
	@override String get confirm_payment => 'تأكيد السداد';
	@override String get menu => 'القائمة';
	@override String get information => 'معلومات';
	@override String get options => 'خيارات';
	@override String get reviews => 'مراجعات';
	@override String get quantity => 'الكمية';
	@override String get add_to_cart => 'إضافة الى السلة';
	@override String get faq => 'التعليمات';
	@override String get help_supports => 'المساعدة';
	@override String get app_language => 'اللغة';
	@override String get i_forgot_password => 'نسيت كلمة المرور ?';
	@override String get i_dont_have_an_account => 'لا أملك حساب?';
	@override String get notifications => 'الإشعارات';
	@override String get notification_settings => 'إعدادات الإشعارات';
	@override String get confirmation => 'التأكيد';
	@override String get your_order_has_been_successfully_submitted => 'تم ارسال طلبك بنجاح';
	@override String get tax => 'ضريبة';
	@override String get profile => 'الملف الشخصي';
	@override String get favorites => 'المفضلة';
	@override String get home => 'الرئيسية';
	@override String get payment_options => 'خيارات السداد';
	@override String get cash_on_delivery => 'الدفع عند الاستلام';
	@override String get cash_on_delivery_amount => 'مبلغ الدفع عند الاستلام';
	@override String get paypal_payment => 'السداد عبر باي بال';
	@override String get recent_shipments => 'الشحنات الأخيرة';
	@override String get settings => 'الإعدادات';
	@override String get profile_settings => 'إعدادات الملف الشخصي';
	@override String get full_name => 'الأسم الكامل';
	@override String get email => 'البريد الإلكتروني';
	@override String get phone => 'رقم الجوال';
	@override String get address => 'العنوان';
	@override String get addresses => 'العناوين';
	@override String get payments_settings => 'إعدادات السداد';
	@override String get default_credit_card => 'بطاقة الإئتمان الإفتراضية';
	@override String get app_settings => 'إعدادات التطبيق';
	@override String get languages => 'اللغات';
	@override String get english => 'English';
	@override String get help_support => 'المساعدة';
	@override String get register => 'التسجيل';
	@override String get lets_start_with_register => '!لنبدأ بالتسجيل';
	@override String get should_be_more_than_3_letters => 'يجب أن يكون أكثر من 3 أحرف';
	@override String get john_doe => 'فلان الفلاني';
	@override String get should_be_a_valid_email => 'يجب ادخال بريد إلكتروني مفعل';
	@override String get should_be_more_than_6_letters => 'يجب أن يكون أكثر من 6 أحرف';
	@override String get password => 'كلمة السر';
	@override String get i_have_account_back_to_login => 'لديك حساب؟ العودة لتسجيل الدخول';
	@override String get tracking_order => 'تتبع الطلب';
	@override String get reset_cart => 'إعادة تعيين السلة?';
	@override String get cart => 'السلة';
	@override String get shopping_cart => 'سلة التسوق';
	@override String get lets_start_with_login => '!لنبدأ بالتسجيل';
	@override String get should_be_more_than_3_characters => 'يجب أن يكون أكثر من 3 أحرف';
	@override String get reset => 'إعادة تعيين';
	@override String get close => 'إغلاق';
	@override String get application_preferences => 'تفضيلات التطبيق';
	@override String get help__support => 'المساعدة';
	@override String get light_mode => 'الوضع المضيء';
	@override String get dark_mode => 'الوضع الداكن';
	@override String get log_out => 'تسجيل الخروج';
	@override String get version => 'النسخة';
	@override String get empty_cart => 'السلة فارغه';
	@override String get no_data_found => 'لا توجد بيانات';
	@override String get start_exploring => 'ابدأ رحلة الإستكشاف';
	@override String get empty_notification_list => 'قائمة الإشعارات فارغه';
	@override String get payment_settings => 'إعدادات السداد';
	@override String get not_a_valid_number => 'رقم غير صالح';
	@override String get not_a_valid_date => 'تاريخ غير صالح';
	@override String get not_a_valid_cvc => 'كود التحقق من البطاقة غير صالح';
	@override String get cancel => 'إلغاء';
	@override String get save => 'حفظ';
	@override String get edit => 'تعديل';
	@override String get not_a_valid_full_name => 'الإسم الكامل غير صالح';
	@override String get email_address => 'البريد الإلكتروني';
	@override String get not_a_valid_email => 'البريد الإلكتروني غير صالح';
	@override String get not_a_valid_phone => 'رقم الجوال غير صالح';
	@override String get not_a_valid_address => 'العنوان غير صالح';
	@override String get not_a_valid_address_description => 'توصيف العنوان غير صالح';
	@override String get not_a_valid_biography => 'سيرة غير صحيحة';
	@override String get your_biography => 'سيرتك الشخصية';
	@override String get your_address => 'عنوانك';
	@override String get search => 'بحث';
	@override String get recents_search => 'عمليات البحث الأخيرة';
	@override String get verify_your_internet_connection => 'الرجاء التحقق من خدمة الإنترنت';
	@override String get carts_refreshed_successfuly => 'تم تحديث السلة بنجاح';
	@override String get notifications_refreshed_successfuly => 'تم تحديث الإشعارات بنجاح';
	@override String get order_refreshed_successfuly => 'تم تحديث الطلب بنجاح';
	@override String get orders_refreshed_successfuly => 'تم تحديث الطلبات بنجاح';
	@override String get profile_settings_updated_successfully => 'تم تحديث إعدادات الملف الشخصي بنجاح';
	@override String get payment_settings_updated_successfully => 'تم تحديث اعدادات السداد بنجاح';
	@override String get tracking_refreshed_successfuly => 'تم تحديث التتبع بنجاح';
	@override String get welcome => 'مرحبا';
	@override String get wrong_email_or_password => 'خطأ في البريد الإلكتروني أو كلمة السر';
	@override String get addresses_refreshed_successfuly => 'تم تحديث العناوين بنجاح';
	@override String get add => 'إضافة';
	@override String get new_address_added_successfully => 'تم إضافة العنوان الجديد بنجاح';
	@override String get the_address_updated_successfully => 'تم تحديث العوان بنجاح';
	@override String get long_press_to_edit_item_swipe_item_to_delete_it => 'للتعديل قم بالضغط مطولا على العنصر, للحذف قم بالتمرير';
	@override String get add_delivery_address => 'إضافة عنوان مرسل';
	@override String get home_address => 'العنوان الرئيسي للمرسل';
	@override String get description => 'الوصف';
	@override String get hint_full_address => 'الدولة، المدينة ، الحي ، الشارع ، أقرب معلم ، رقم المبنى، الدور';
	@override String get full_address => 'العنوان الكامل';
	@override String get email_to_reset_password => 'البريد الإلكتروني لإعادة تعيين كلمة المرور';
	@override String get send_password_reset_link => 'ارسال رابط';
	@override String get i_remember_my_password_return_to_login => 'أتذكر كلمة المرور، العودة لتسجيل الدخول';
	@override String get your_reset_link_has_been_sent_to_your_email => 'تم ارسال رابط اعادة التعيين على بريدك الإلكتروني';
	@override String get error_verify_email_settings => 'خطأ! التحقق من إعدادات البريد الإلكتروني';
	@override String get guest => 'ضيف';
	@override String get you_must_signin_to_access_to_this_section => 'يجب تسجيل الدخول';
	@override String get reviews_refreshed_successfully => 'تم تحديث المراجعات بنجاح!';
	@override String get delivery_fee => 'رسوم السحن';
	@override String get order_status_changed => 'تم تغيير حالة الطلب';
	@override String get new_order_from_client => 'لديك طلب جديد من عميل';
	@override String get shopping => 'تسوق';
	@override String get delivery_or_pickup => 'توصيل أو استلام';
	@override String get payment_card_updated_successfully => 'تم تحديث بطاقة السداد بنجاح';
	@override String get deliverable => 'قابل للتوصيل';
	@override String get not_deliverable => 'غير قابل للتوصيل';
	@override String get items => 'عناصر';
	@override String get delivery => 'توصيل';
	@override String get pickup => 'استلام';
	@override String get closed => 'مغلق';
	@override String get open => 'مفتوح';
	@override String get km => 'كيلومتر';
	@override String get mi => 'ميل';
	@override String get current_location => 'الموقع الحالي';
	@override String get delivery_address_removed_successfully => 'تم إزالة عنوان التوصيل بنجاح';
	@override String get add_new_delivery_address => 'اضافة عنوان توصيل جديد';
	@override String get stores_near_to_your_current_location => 'فروع قريبة من موقعك الحالي';
	@override String get stores_near_to => 'فروع قريبة الى';
	@override String get near_to => 'قريب الى';
	@override String get near_to_your_current_location => 'قريب من موقعك الحالي';
	@override String get pickup_your_product_from_the_store => 'استلام الشحنة من الفرع';
	@override String get confirm_your_delivery_address => 'تأكيد عنوان الشحن الخاص بك';
	@override String get filter => 'فرز';
	@override String get clear => 'مسح';
	@override String get apply_filters => 'تطبيق الفرز';
	@override String get fields => 'حقول';
	@override String get all => 'الكل';
	@override String get unknown => 'غير معروف';
	@override String get click_on_the_stars_below_to_leave_comments => 'اضغط على النجوم أدناه لترك تعليق';
	@override String get visa_card => 'بطاقة فيزا';
	@override String get mastercard => 'بطاقة ماستر';
	@override String get paypal => 'باي بال';
	@override String get pay_on_pickup => 'السداد عند ارسال الشحنة';
	@override String get click_to_credit_card_payment => 'للسداد عبر البطاقة الإئتمانية';
	@override String get click_to_pay_cash_on_delivery => 'للسداد عند تسليم توصيل الشحنة';
	@override String get click_to_pay_on_pickup => 'للسداد عند ارسال الشحنة';
	@override String get this_email_account_exists => 'البريد الإلكتروني مسجل مسبقا';
	@override String get this_account_not_exist => 'الحساب غير مسجل';
	@override String get card_number => 'رقم البطاقة';
	@override String get expiry_date => 'تاريخ الإنتهاء';
	@override String get cvv => 'cvv';
	@override String get your_credit_card_not_valid => 'البطاقة الإئتمانية غير صالحة';
	@override String get number => 'رقم';
	@override String get exp_date => 'تنتهي في';
	@override String get cvc => 'CVC';
	@override String get verify_your_account => 'التحقق من حسابك';
	@override String otpSentTo(Object phone) => 'يتم ارسال رقم التحقق الى $phone, الرجاء التأكد من جوالك';
	@override String get detail => 'التفاصيل';
	@override String get review => 'مراجعة';
	@override String get featured => 'متميز';
	@override String get your_reviews => 'مراجعة الخدمة';
	@override String get make_it_default => 'التعيين كافتراضي';
	@override String get this_notification_was_removed => 'تم ازالة الإشعار';
	@override String get unpaid => 'غير مدفوع';
	@override String get shipped => 'تم الشحن';
	@override String get on_the_way => 'في الطريق';
	@override String get preparing => 'التحظير';
	@override String get completeYourProfileDetailsToContinue => 'الرجاء اكمال ملفك الشخصي للمتابعة';
	@override String get select_country => 'اختر الدولة';
	@override String get select_city => 'اختر المدينة';
	@override String get pickup_addresses => 'عناوين الإلتقاط';
	@override String get delivery_addresses => 'عناوين التوصيل';
	@override String get pickup_address => 'عنوان الإلتقاط';
	@override String get delivery_address => 'عنوان التوصيل';
	@override String get default_address => 'العنوان الافتراضي';
	@override String get your_mobile => 'رقم جوالك';
	@override String get arrived => 'وصلت';
	@override String get delivered => 'تم التوصيل';
	@override String get cancelled => 'تم الإلغاء';
	@override String get in_origin => 'في المصدر';
	@override String get plate_number => 'رقم اللوحة';
	@override String get optional => 'اختياري';
	@override String get model_year => 'سنة الموديل';
	@override String get booking_notes => 'ملاحظات الحجز';
	@override String get pickup_date => 'تاريخ الإلتقاط';
	@override String get pickup_time => 'وقت الإلتقاط';
	@override String get notes => 'ملاحظات';
	@override String get send => 'ارسال';
	@override String get shipmentDetail => 'تفاصيل الشحنة';
	@override String get newShipment => 'شحنة جديدة';
	@override String get editShipment => 'تعديل على الشحنة';
	@override String get new_address => 'عنوان جديد';
	@override String get yes => 'نعم';
	@override String get zip => 'رمز';
	@override String get street => 'الشارع';
	@override String get city => 'المدينة';
	@override String get country => 'الدولة';
	@override String get mobile => 'الجوال';
	@override String get booking_id => 'رقم الحجز';
	@override String get should_be_a_valid_phone => 'يجب أن يكون رقم جوال صالح';
	@override String smsHasBeenSentTo(Object phone) => 'تم ارسال رسالة نصية الى $phone';
	@override String get phoneToSendSms => 'رقم الجوال لارسال رسالة نصية';
	@override String get yourPhoneNumber => 'رقم جوالك';
	@override String get resend => 'اعادة ارسال';
	@override String get edit_name => 'تعديل الاسم';
	@override String get change_password => 'تغيير كلمة السر';
	@override String get track_shipment => 'تتبع شحنة';
	@override String get tracking_results => 'نتائج التتبع';
	@override String get add_address => 'اضافة عنوان';
	@override String get edit_address => 'تعديل عنوان';
	@override String get select_pick_addess => 'اختر عنوان إلتقاط';
	@override String get select_deliv_address => 'اختر عنوان توصيل';
	@override String get select_pick_date => 'اختر تاريخ إلتقاط';
	@override String get select_pic_time => 'اختر وقت إلتقاط';
	@override String get warning => 'تحذير';
	@override String get error => 'خطأ';
	@override String get upgradePrompt => 'هل تود التحيث الآن؟';
	@override String upgradeMessage(Object appName) => 'يوجد اصدار جديدة من $appName';
	@override String get upgradeReleaseNotes => 'ملاحظات الإصدار';
	@override String get upgradeUpdateApp => 'تحديث التطبيق؟';
	@override String get logoutConfirm => 'تأكيد تسجيل الخروج من الحساب، هل أنت متأكد؟';
	@override String get privacy => 'الخصوصية';
	@override String get termAndConditions => 'الشروط والأحكام';
	@override String get shipment => 'شحنة';
	@override String get shipments => 'شحنات';
	@override String get shipment_list => 'قائمة الشحنات';
	@override String get rate => 'السعر';
	@override String get from_country => 'من الدولة';
	@override String get from_city => 'من المدينة';
	@override String get to_country => 'الى الدولة';
	@override String get to_city => 'الى المدينة';
	@override String get branch => 'فرع';
	@override String get branches => 'فروع';
	@override String get content => 'محتوى';
	@override String get setup => 'اعداد';
	@override String get rateShipment => 'سعر الشحنة';
	@override String get pickupDate => 'تاريخ الإلتقاط';
	@override String get pickupTime => 'وقت الإلتقاط';
	@override String get selectValidShippingAddressFirst => 'أولا، اختر عنوان ارسال صالح';
	@override String get itemRate => 'سعر العنصر';
	@override String get noRateAvailable => 'لا يتوفر سعر!';
	@override String get cancelShipment => 'إلغاء الشحنة';
	@override String get createReturnShipment => 'انشاء استعادة شحنة';
	@override String get showPdfLabel => 'اضهار ملصق الشحن';
	@override String get pdfLabel => 'ملصق الشحن';
	@override String get selectAction => 'اختر اجراء';
	@override String get shipmentCreatedSuccess => 'تم انشاء الشحنة بنجاح';
	@override String get done => 'تم';
	@override String get oops => 'oops!';
	@override String get account => 'حساب';
	@override String get general => 'عام';
	@override String get accountSettings => 'اعدادات الحساب';
	@override String get tapBackAgainToLeave => 'للمغادرة اضغط مرتين للخلف';
	@override String get packageType => 'نوع الشحنة';
	@override String get packageInfo => 'معلومات الشحنة';
	@override String get service => 'خدمة';
	@override String get weight => 'وزن';
	@override String get trackShipment => 'تتبع الشحنة';
	@override String get track => 'تتبع';
	@override String get setTrackingShipment => 'اكتب كود التتبع';
	@override String get eta => 'تاريخ التوصيل المتوقع';
	@override String get copiedToClipboard => 'تم النسخ';
	@override String get saveAsDefault => 'الحفظ كافتراضي';
	@override String get saveToUseLater => 'الحفظ للاستخدام لاحقا';
	@override String get shipFromBranch => 'الشحن من الفرع';
	@override String get deliveryToBranch => 'التوصيل للفرع';
	@override String get selectBranch => 'اختر فرع';
	@override String get from => 'من';
	@override String get to => 'الى';
	@override String get more => 'اكثر';
	@override String get retry => 'اعادة المحاولة';
	@override String get enableLocation => 'تمكين خدمة تحديد الموقع';
	@override String get enableLocationPermission => 'تمكين أذونات تحديد الموقع';
	@override String get outgoing => 'صادر';
	@override String get outgoingShipments => 'شحنات صادرة';
	@override String get incoming => 'وارد';
	@override String get incomingShipments => 'شحنات واردة';
	@override String get balance => 'الرصيد';
	@override String get acceptTerm => 'الموافقة على الشروط والأحكام';
	@override String get saveTrackingHistory => 'الحفظ في سجل التتبع';
	@override String get removeTrackingHistory => 'الحذف من سجل التتبع';
	@override String get trackingHistory => 'سجل التتبع';
	@override String get notSetYet => 'لم تحدد بعد';
	@override String get payNow => 'السداد الآن';
	@override String get home_init_line1 => 'توصيل كل ما تتمنى';
	@override String get home_init_line2 => 'من والى منزلك';
	@override String get workingTime => 'ساعات العمل';
	@override String get tapToSelectPackageType => 'انقر لتحديد نوع الشحنة';
	@override String get selectRate => 'اختر السعر المناسب';
	@override String get verifyYourEmail => 'يرجى مراجعة صندوق الوارد للتحقق من الايميل';
	@override String get shareApp => 'مشاركة التطبيق';
	@override String get shareTitle => 'تنصيب تطبيق SMB اكسبرس';
	@override String get shareText => 'انشاء شحنات وصدرها اينما كنت وحيثما تريد باستخدام تطبيق SMB اكسبرس';
	@override late final I18nButtonsAr buttons = I18nButtonsAr._(_root);
	@override late final I18nStatusMapAr statusMap = I18nStatusMapAr._(_root);
	@override late final I18nErrorMessagesAr errorMessages = I18nErrorMessagesAr._(_root);
	@override late final I18nFormAr form = I18nFormAr._(_root);
	@override String get showWaybillInvoice => 'عرض فاتورة البوليصة';
	@override String get waybillInvoice => 'فاتورة البوليصة';
	@override String get deliveryConfirm => 'تأكيد معلومات التسليم';
	@override String get pickupConfirm => 'تأكيد معلومات الشحن';
	@override String get selectOnMap => 'الاختيار من الخارطة';
	@override String confirmDeleteAddress(Object address) => 'لقد قمت باختيار حذف العنوان: "$address".\nهل انت متأكد تريد الحذف؟';
	@override String get subject => 'الموضوع';
	@override String get loginOrSignupDes => 'تسجيل الدخول او انشاء حساب';
	@override String get accountSettingsDes => 'اعدادات الحساب والملف الشخصي';
	@override String get browsePickupAddressDes => 'استعراض عتاوين المرسل';
	@override String get browseDeliveryAddressDes => 'استعراض عنواين التسليم';
	@override String get openPrivacyDes => 'فتح سياسة الخصوصية';
	@override String get helpTopicsDes => 'دليل التعليمات';
	@override String get openTermsDes => 'استراض الشروط والاحكام';
	@override String get infoAboutDes => 'تفاصيل اكثر من نحن';
	@override String get senFeedback => 'ارسل رأيك';
	@override String get senFeedbackDes => 'ستكون ملاحظاتكم محل اهتمامنا';
	@override String get paymentMethodUnavailable => 'طرق الدفع غير متوفرة حاليا';
	@override String get paymentDoneSuccess => 'تم الدفع بنجاح.';
	@override String get creditCard => 'بطاقة اتمانية';
	@override String get cash => 'نقد';
	@override String get writeFeedbackToUs => 'ما تقييمك لـ smb Express?';
	@override String get writeFeedback => 'كتابة ملاحظات';
	@override String get sendFeedback => 'إرسال الملاحظات';
	@override String get writeComment => 'اكتب التعليق';
	@override String get askQuestion => 'ضع استفسارك';
	@override String get parcelQuantity => 'عدد الصناديق';
	@override String get bills => 'الفواتير';
	@override String get bill => 'فاتورة';
	@override String get myBills => 'فواتيري';
	@override String get transactions => 'عمليات مالية';
	@override String get transaction => 'عملية مالية';
	@override String emptyItemList(Object items) => 'قائمة $items فارغة!';
	@override String confirmDeleteItem(Object entity, Object item) => 'لقد اخترت حذف $entity: "$item".\nهل أنت متأكد أنك تريد حذف؟';
	@override String get confirmShipmentTermLink => 'من خلال التأكيد ، فإنك توافق على ';
	@override String get addressNotSupported => 'خدمات الشحن لدينا لايدعم الموقع الذي تم اختيارة!';
	@override String get tapToSelectLocation => 'انقر لتحديد هذا الموقع';
}

// Path: buttons
class I18nButtonsAr extends I18nButtonsEn {
	I18nButtonsAr._(I18nAr root) : this._root = root, super._(root);

	@override final I18nAr _root; // ignore: unused_field

	// Translations
	@override String get yes => 'نعم';
	@override String get No => 'لا';
	@override String get discard => 'تجاهل';
	@override String get ignore => 'تجاهل';
	@override String get later => 'لاحقا';
	@override String get update => 'تحديث';
	@override String get submit => 'ارسال';
	@override String get publish => 'نشر';
	@override String get backToScan => 'العودة للمسح';
	@override String get ok => 'حسنا';
	@override String get cancel => 'إلغاء';
	@override String get clear => 'مسح';
	@override String get delete => 'حذف';
	@override String get remove => 'حذف';
	@override String get add => 'اضافة';
	@override String get copy => 'نسخ';
	@override String get scan => 'مسح';
	@override String get save => 'حفظ';
	@override String get back => 'عودة';
	@override String get send => 'ارسال';
	@override String get updateNow => 'حدث الآن';
	@override String get next => 'التالي';
	@override String get previous => 'السابق';
	@override String get finish => 'انهاء';
	@override String get confirm => 'تأكيد';
}

// Path: statusMap
class I18nStatusMapAr extends I18nStatusMapEn {
	I18nStatusMapAr._(I18nAr root) : this._root = root, super._(root);

	@override final I18nAr _root; // ignore: unused_field

	// Translations
	@override String get shipped => 'تم الشحن';
	@override String get inTransit => 'في مرحلة العبور';
	@override String get arrived => 'وصلت';
	@override String get delivered => 'تم التوصيل';
}

// Path: errorMessages
class I18nErrorMessagesAr extends I18nErrorMessagesEn {
	I18nErrorMessagesAr._(I18nAr root) : this._root = root, super._(root);

	@override final I18nAr _root; // ignore: unused_field

	// Translations
	@override String get somethingWrong => 'حدث خطأ';
}

// Path: form
class I18nFormAr extends I18nFormEn {
	I18nFormAr._(I18nAr root) : this._root = root, super._(root);

	@override final I18nAr _root; // ignore: unused_field

	// Translations
	@override String get requiredErrorText => 'لايمكن ترك هذا الحقل خاليا.';
	@override String minErrorText(Object min) => 'القيمة المدخلة يجب أن تكون أكبر او تساوي $min.';
	@override String minLengthErrorText(Object minLength) => 'القيمة المدخلة يجب أن تكون أكبر أو تساوي $minLength';
	@override String maxErrorText(Object min) => 'القيمة المدخلة يجب أن تكون أقل أو تساوي $min.';
	@override String maxLengthErrorText(Object maxLength) => 'القيمة المخلة يجب أن تكون أقل أو تساوي $maxLength';
	@override String get emailErrorText => 'يتطلب هذا الحق بريد إلكتروني صالح.';
	@override String get integerErrorText => 'يتطلب هذا الحق اعداد صحيحة.';
	@override String equalErrorText(Object value) => 'يتطلب هذا الحقل قيمة تساوي $value.';
	@override String notEqualErrorText(Object value) => 'قيمة هذاالحقل يجب ألا تساوي $value.';
	@override String get urlErrorText => 'يتطلب هذا الحقل عنوان ألكتروني صالح.';
	@override String get matchErrorText => 'القيمة غير مطابقة للنمط.';
	@override String get numericErrorText => 'القيمة المدخلة يجب أن تكون فقط أرقام';
	@override String get creditCardErrorText => 'يتطلب هذا الحقل رقم بطاقة ائتمانية صالح.';
	@override String get ipErrorText => 'يتطلب هذا الحقل رقم IP صالح';
	@override String get dateStringErrorText => 'يتطلب هذا الحقل تسلسل تاريخ صحيح.';
}
