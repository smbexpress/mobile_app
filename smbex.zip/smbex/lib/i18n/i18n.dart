// @dart=2.12

import 'package:flutter/material.dart';

import 'i18n.g.dart';

export 'i18n.g.dart' show t, LocaleSettings, TranslationProvider;

I18nEn get tr => t;

String get lang => LocaleSettings.baseLocale.name;


class S{
	static I18nEn of(BuildContext context) => t;
	static I18nEn get tr => t;
}