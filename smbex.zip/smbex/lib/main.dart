import 'dart:async';

import 'package:country_codes/country_codes.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lifecycle/lifecycle.dart';
import 'package:provider/provider.dart';
//import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smbex_app/src/config.dart';
import 'package:smbex_app/src/helpers/size_config.dart';
import 'package:smbex_app/src/notification_provider.dart';
import 'package:smbex_app/src/screens/branch/branch_provider.dart';
import 'package:smbex_app/src/screens/checkout/checkout_provider.dart';
import 'package:smbex_app/src/screens/delivery/delivery_provider.dart';

import 'i18n/i18n.g.dart';
import 'route_generator.dart';
import 'src/app_state.dart';
import 'src/models/setting.dart';
import 'src/repository/settings_repository.dart' as settingRepo;
import 'src/theme/theme.dart';

var _firebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyB6hitCiH0sExvE_SxZA8_ZyW4dLM7L1no',
  projectId: 'courier-app-ee31b',
  appId: '1:552302475201:ios:5b2eb81cdefbd5c2866140',
  messagingSenderId: '552302475201',
);

FirebaseMessaging firebaseMessaging;
Future<void> main() async {
  //SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);
  WidgetsFlutterBinding.ensureInitialized();

  if (!kIsWeb) {
    await Firebase.initializeApp(options: _firebaseOptions);
    firebaseMessaging = FirebaseMessaging.instance;
    FirebaseMessaging.onBackgroundMessage(onBackgroundMessageHandler);
    await CountryCodes.init();
    final locale = CountryCodes.detailsForLocale();
    if (locale.dialCode != null) {
      Config.defaultCountryCode = locale.dialCode;
    }
  }

  final prefs = await SharedPreferences.getInstance();
  final lang = prefs.getString('language');
  if (lang != null) {
    LocaleSettings.setLocaleRaw(lang);
  } else {
    LocaleSettings.useDeviceLocale();
  }

  var child = MultiProvider(
    providers: [
      ChangeNotifierProvider<AppState>(
        create: (context) => AppState(firebaseMessaging),
      ),
      ChangeNotifierProvider<NotificationProvider>(
          create: (context) => NotificationProvider(context)),
      ChangeNotifierProvider<BranchProvider>(
        create: (context) => BranchProvider(context),
      ),
      ChangeNotifierProvider<DeliveryProvider>(
        create: (context) => DeliveryProvider(),
      ),
      ChangeNotifierProvider<CheckoutProvider>(
        create: (context) => CheckoutProvider(),
      ),

    ],
    child: TranslationProvider(child: MyApp()),
  );
  if (Config.isDebug) {
    return runApp(child);
  }

  await runZonedGuarded(() async {
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    runApp(child);
  }, (error, stackTrace) {
    FirebaseCrashlytics.instance.recordError(error, stackTrace);
  });
  /*
  await SentryFlutter.init(
        (options) {
      options.dsn = Config.SENTRY_DNS;
      options.release = const String.fromEnvironment('SENTRY_RELEASE',
          defaultValue: Config.version);
      options.dist = Config.version;
      options.beforeSend = (SentryEvent event, {dynamic hint}) {
        final account = currentAccount;
        final reportErrors = true;//account?.reportErrors ?? false;

        if (!reportErrors) {
          return null;
        }
        /*
        event = event.copyWith(
          environment: '${store.state.environment}'.split('.').last,
          extra: <String, dynamic>{
            'server_version': account?.currentVersion ?? 'Unknown',
            'route': state.uiState.currentRoute,
          },
        );*/

        return event;
      };
    },
    appRunner: () => runApp(child),
  );

   */
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  static final FirebaseAnalyticsObserver _kFirebaseAnalyticsObserver =
      FirebaseAnalyticsObserver(analytics: FirebaseAnalytics.instance);

  @override
  void initState() {
    super.initState();

    FToast().init(context);
    //final notificationProvider = Provider.of<NotificationProvider>(context, listen: false);
    //notificationProvider.setupFcm();
  }

  void checkVersion() async{

  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    //read Branch hold to use it later
    context.read<BranchProvider>();
    AppState state = Provider.of<AppState>(context);
    Setting _setting = settingRepo.settingNotifier.value;

    return MaterialApp(
        navigatorKey: state.navigatorKey,
        scaffoldMessengerKey:
            context.read<NotificationProvider>().scaffoldMessengerKey,
        title: _setting.appName,
        initialRoute: '/Splash',
        onGenerateRoute: RouteGenerator.generateRoute,
        debugShowCheckedModeBanner: false,
        locale: TranslationProvider.of(context).flutterLocale,
        supportedLocales: LocaleSettings.supportedLocales,
        localizationsDelegates: [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        //localeListResolutionCallback: const Locale('en', ''),
        theme: AppTheme.lightTheme,
        //theme: ThemeData(primarySwatch: Colors.blue,),
        navigatorObservers: [
          defaultLifecycleObserver,
          state.createNavigatorObserver(),
          _kFirebaseAnalyticsObserver
          //SentryNavigatorObserver(),
        ],
        builder: (context, child) {
          SizeConfig().init(context);
          context.read<NotificationProvider>().context = context;
          return child ?? const SizedBox.shrink();
        });
  }

  void didChangeLocales(List<Locale> locale) {
    print("Locals changed: ${locale}");
  }
}
