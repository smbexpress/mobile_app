package com.smb.smbex;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.embedding.engine.plugins.activity.ActivityAware;
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding;
import io.flutter.embedding.engine.plugins.PluginRegistry;
import io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.PluginRegistry.Registrar;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.embedding.engine.plugins.shim.ShimPluginRegistry;
import android.util.Log;
/**
 * SmbexOppwaPlugin
 */
public class SmbexOppwaPlugin implements FlutterPlugin, ActivityAware {
    private static final String TAG = "SmbexOppwaPlugin";
    @Nullable
    private MethodCallHandlerImpl methodCallHandler;
    //@Nullable
    //private StreamHandlerImpl streamHandlerImpl;
    public Registrar registrar;
    @Nullable
    private SmbexOppwa smbexOppwa;

    private FlutterPluginBinding pluginBinding;
    private ActivityPluginBinding activityBinding;
    private Activity activity;
    private HiddenLifecycleReference hiddenLifecycleReference;

    public SmbexOppwaPlugin(){
        Log.d(TAG, "*********SmbexOppwaPlugin*****************");
    }

    public static void registerWith(Registrar registrar) {
        SmbexOppwaPlugin plugin = new SmbexOppwaPlugin();

        plugin.smbexOppwa = new SmbexOppwa(registrar.context(), registrar.activity());

        MethodCallHandlerImpl handler = new MethodCallHandlerImpl(plugin.smbexOppwa);
        handler.startListening(registrar.messenger());
        plugin.setup(null, registrar);

        //StreamHandlerImpl streamHandlerImpl = new StreamHandlerImpl(SmbexOppwa);
        //streamHandlerImpl.startListening(registrar.messenger());
    }

    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding binding) {
        pluginBinding = binding;
        smbexOppwa = new SmbexOppwa(binding.getApplicationContext(), /* activity= */ null);
        methodCallHandler = new MethodCallHandlerImpl(smbexOppwa);
        methodCallHandler.startListening(binding.getBinaryMessenger());

        //streamHandlerImpl = new StreamHandlerImpl(smbexOppwa);
        //streamHandlerImpl.startListening(binding.getBinaryMessenger());
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        pluginBinding = null;
        if (methodCallHandler != null) {
            methodCallHandler.stopListening();
            methodCallHandler = null;
        }
        /*
        if (streamHandlerImpl != null) {
            streamHandlerImpl.stopListening();
            streamHandlerImpl = null;
        }*/

        smbexOppwa = null;
    }

    @Override
    public void onAttachedToActivity(@NonNull ActivityPluginBinding binding) {
        setup(binding, null);
    }

    @Override
    public void onDetachedFromActivity() {
       tearDown();
    }

    @Override
    public void onDetachedFromActivityForConfigChanges() {
        if (hiddenLifecycleReference != null && hiddenLifecycleReference.getLifecycle() != null)
            hiddenLifecycleReference.getLifecycle().removeObserver(smbexOppwa);
        hiddenLifecycleReference = null;
    }

    @Override
    public void onReattachedToActivityForConfigChanges(@NonNull ActivityPluginBinding binding) {
        //onAttachedToActivity(binding);
        if (binding.getLifecycle() instanceof  HiddenLifecycleReference) {
            hiddenLifecycleReference = (HiddenLifecycleReference) binding.getLifecycle();
            if (hiddenLifecycleReference.getLifecycle() != null)
                hiddenLifecycleReference.getLifecycle().addObserver(smbexOppwa);
        }
    }

    private void setup(ActivityPluginBinding binding, final Registrar registrar) {

        if (registrar != null) {
            this.activity = registrar.activity();
            // V1 embedding setup for activity listeners.
            registrar.addActivityResultListener(smbexOppwa);
            registrar.addNewIntentListener(smbexOppwa);
        } else {

            activityBinding = binding;
            this.activity = binding.getActivity();
            // V2 embedding setup for activity listeners.
            binding.addActivityResultListener(smbexOppwa);
            binding.addOnNewIntentListener(smbexOppwa);
            if (binding.getLifecycle() instanceof  HiddenLifecycleReference) {
                hiddenLifecycleReference = (HiddenLifecycleReference) binding.getLifecycle();
                if (hiddenLifecycleReference.getLifecycle() != null)
                    hiddenLifecycleReference.getLifecycle().addObserver(smbexOppwa);
            }
        }
        smbexOppwa.setActivity(binding.getActivity());
    }

    private void tearDown() {
        if (smbexOppwa != null) {
            activityBinding.removeActivityResultListener(smbexOppwa);
            activityBinding.removeOnNewIntentListener(smbexOppwa);
            if (hiddenLifecycleReference != null && hiddenLifecycleReference.getLifecycle() != null)
                hiddenLifecycleReference.getLifecycle().removeObserver(smbexOppwa);
            hiddenLifecycleReference = null;
            smbexOppwa.unBindService();
            smbexOppwa = null;
        }
    }

}
