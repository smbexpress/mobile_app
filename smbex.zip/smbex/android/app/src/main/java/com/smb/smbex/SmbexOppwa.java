package com.smb.smbex;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;

import com.oppwa.mobile.connect.checkout.dialog.CheckoutActivity;
import com.oppwa.mobile.connect.checkout.meta.CheckoutSettings;
import com.oppwa.mobile.connect.checkout.meta.CheckoutStorePaymentDetailsMode;
import com.oppwa.mobile.connect.exception.PaymentError;
import com.oppwa.mobile.connect.exception.PaymentException;
import com.oppwa.mobile.connect.payment.BrandsValidation;
import com.oppwa.mobile.connect.payment.CheckoutInfo;
import com.oppwa.mobile.connect.payment.ImagesRequest;
import com.oppwa.mobile.connect.payment.PaymentParams;
import com.oppwa.mobile.connect.payment.card.CardPaymentParams;
import com.oppwa.mobile.connect.payment.token.TokenPaymentParams;
import com.oppwa.mobile.connect.provider.Connect;
import com.oppwa.mobile.connect.provider.ITransactionListener;
import com.oppwa.mobile.connect.provider.OppPaymentProvider;
import com.oppwa.mobile.connect.provider.Transaction;
import com.oppwa.mobile.connect.provider.TransactionType;


import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.PluginRegistry;

public class SmbexOppwa implements ITransactionListener, MethodChannel.Result,
        PluginRegistry.ActivityResultListener, PluginRegistry.NewIntentListener,
        LifecycleEventObserver{
    private static final String TAG = SmbexOppwa.class.getSimpleName();
    private static final String SCHEME = "com.smb.smbex.payment";
    Activity activity;
    final Context applicationContext;
    private MethodChannel.Result result;
    private final Handler handler = new Handler(Looper.getMainLooper());

    String checkoutId;
    String type;
    String number;
    String holder;
    String cvv;
    String month;
    String year;
    String brand;
    String mode;
    String lang;

    String MadaRegex = "";
    String ptMadaVExp = "";
    String ptMadaMExp = "";

    private boolean _serviceStarted;
    private String resourcePath;
    private TransactionState transactionState;


   SmbexOppwa(Context applicationContext, Activity activity) {
        this.applicationContext = applicationContext;
        this.activity = activity;
   }

    void setActivity(Activity activity) {
        this.activity = activity;
        bindService();
    }

    void bindService() {
        if (mode == null || _serviceStarted)
            return;
        _serviceStarted = true;
        //Intent intent = new Intent(applicationContext, ConnectService.class);
        //applicationContext.startService(intent);
        //applicationContext.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    void unBindService() {
        if (_serviceStarted) {
            //applicationContext.unbindService(serviceConnection);
        }
    }


    boolean check(String ccNumber) {
        int sum = 0;
        boolean alternate = false;
        for (int i = ccNumber.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(ccNumber.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);

    }


    @Override
    public void success(final Object result) {
        handler.post(() -> {
            try {
                this.result.success(result);
            } catch (Exception ex){}
        });
    }

    @Override
    public void error(
            final String errorCode, final String errorMessage, final Object errorDetails) {
        handler.post(() -> {
            try {
                result.error(errorCode, errorMessage, errorDetails);
            } catch (Exception ex){}
        });
    }

    @Override
    public void notImplemented() {
        handler.post(() -> result.notImplemented());
    }

    Transaction transaction = null;

    void onMethodCall(MethodCall call, MethodChannel.Result result) {

        this.result = result;
        if (call.method.equals("checkout")) {
            mode = call.argument("mode");
            type = call.argument("type");
            checkoutId = call.argument("checkoutId");
            brand = call.argument("brand");
            lang  = call.argument("lang");
            bindService();

            if (brand.equals("STC_PAY")) {
                openStcPay(checkoutId);
            }
            else if (type.equals("ReadyUI")) {
                openCheckoutUI(checkoutId);
            }
            else if (type.equals("token")) {
                String tokenId = call.argument("tokenId");
                cvv = call.argument("cvv");
                openTokenCheckout(tokenId, cvv);
            } else {
                number = call.argument("card_number");
                holder = call.argument("holder_name");
                year = call.argument("year");
                month = call.argument("month");
                cvv = call.argument("cvv");
                ptMadaVExp = call.argument("MadaRegexV");
                ptMadaMExp = call.argument("MadaRegexM");
                openCustomUI(checkoutId);
            }
        }
        else if (call.method.equals("start")) {
            mode = call.argument("mode");
            bindService();
        }
        else {
            notImplemented();
        }
    }

    private void openCheckoutUI(String checkoutId) {

        Set<String> paymentBrands = new LinkedHashSet<String>(Arrays.asList(brand.split(" ")));

        CheckoutSettings settings = new CheckoutSettings(
                    checkoutId,
                    paymentBrands,
                    mode.equals("LIVE")
                            ? Connect.ProviderMode.LIVE
                            : Connect.ProviderMode.TEST
                )
                .setShopperResultUrl(SCHEME +"://result")
                .setStorePaymentDetailsMode(CheckoutStorePaymentDetailsMode.PROMPT);

        if (lang != null)
            settings.setLocale(lang);

        // CHECKOUT BROADCAST RECEIVER
        ComponentName componentName =
                new ComponentName(
                activity.getPackageName(),
                        CheckoutBroadcastReceiver.class.getName());

        /* Set up the Intent and start the checkout activity. */
        Intent intent = settings.createCheckoutActivityIntent(activity, componentName);

        activity.startActivityForResult(intent, CheckoutActivity.REQUEST_CODE_CHECKOUT);
    }

    private void openCustomUI(String checkoutId) {

        Toast.makeText(applicationContext, "Waiting..", Toast.LENGTH_LONG).show();
        boolean result = check(number);
        if (!result) {

            Toast.makeText(applicationContext, "Card Number is Invalid", Toast.LENGTH_LONG).show();

        } else if (!CardPaymentParams.isNumberValid(number)) {

            Toast.makeText(applicationContext, "Card Number is Invalid", Toast.LENGTH_LONG).show();

        } else if (!CardPaymentParams.isHolderValid(holder)) {

            Toast.makeText(applicationContext, "Card Holder is Invalid", Toast.LENGTH_LONG).show();

        } else if (!CardPaymentParams.isExpiryYearValid(year)) {

            Toast.makeText(applicationContext, "Expiry Year is Invalid", Toast.LENGTH_LONG).show();

        } else if (!CardPaymentParams.isExpiryMonthValid(month)) {

            Toast.makeText(applicationContext, "Expiry Month is Invalid", Toast.LENGTH_LONG).show();

        } else if (!CardPaymentParams.isCvvValid(cvv)) {

            Toast.makeText(applicationContext, "CVV is Invalid", Toast.LENGTH_LONG).show();
        } else {

            String firstNumber = String.valueOf(number.charAt(0));

            // To add MADA

            if (brand.equals("mada")) {
                String bin = number.substring(0, 6);

                if (bin.matches(ptMadaVExp) || bin.matches(ptMadaMExp)) {

                    brand = "MADA";

                } else {

                    Toast.makeText(applicationContext, "This card is not Mada card", Toast.LENGTH_LONG).show();
                }
            } else {

                if (firstNumber.equals("4")) {

                    brand = "VISA";


                } else if (firstNumber.equals("5")) {

                    brand = "MASTER";
                }

            }

            try {

                PaymentParams paymentParams =
                        new CardPaymentParams(
                            checkoutId,
                            brand,
                            number,
                            holder,
                            month,
                            year,
                            cvv
                    );


                paymentParams.setShopperResultUrl(SCHEME+"://result");

                Transaction transaction = new Transaction(paymentParams);
                OppPaymentProvider paymentProvider =
                        new OppPaymentProvider(applicationContext,
                                mode.equals("LIVE") ? Connect.ProviderMode.LIVE : Connect.ProviderMode.TEST);
                paymentProvider.submitTransaction(transaction, this);
            } catch (PaymentException e) {

                Log.e(TAG, e.getLocalizedMessage(), e);

                flutterDispatch("error",
                        e.getError() != null
                                ? e.getError().getErrorMessage()
                                : e.getLocalizedMessage());
            }

        }
    }

    private void openTokenCheckout(String tokenId, String cvv) {
        try {
            TokenPaymentParams token = new TokenPaymentParams(checkoutId, tokenId, brand, cvv);
            token.setShopperResultUrl(SCHEME+"://result");

            Transaction transaction = new Transaction(token);

            OppPaymentProvider paymentProvider =
                    new OppPaymentProvider(applicationContext,
                            mode.equals("LIVE") ? Connect.ProviderMode.LIVE : Connect.ProviderMode.TEST);

            paymentProvider.submitTransaction(transaction, this);

        } catch (PaymentException e) {
            Log.e(TAG, e.getLocalizedMessage(), e);
            flutterDispatch("error",
                    e.getError() != null
                            ? e.getError().getErrorMessage()
                            : e.getLocalizedMessage());
        }
    }

    private void openStcPay(String checkoutId){
        try {
            PaymentParams paymentParams = new PaymentParams(checkoutId, "STC_PAY");
            paymentParams.setShopperResultUrl(SCHEME+"://result");
            Transaction transaction = new Transaction(paymentParams);
            OppPaymentProvider paymentProvider =
                    new OppPaymentProvider(applicationContext,
                            mode.equals("LIVE") ? Connect.ProviderMode.LIVE : Connect.ProviderMode.TEST);
            paymentProvider.submitTransaction(transaction, this);
        } catch (PaymentException e) {
            Log.e(TAG, e.getLocalizedMessage(), e);
            flutterDispatch("error",
                    e.getError() != null
                            ? e.getError().getErrorMessage()
                            : e.getLocalizedMessage());
        }
    }



    @Override
    public void brandsValidationRequestSucceeded(BrandsValidation brandsValidation) {

    }

    @Override
    public void brandsValidationRequestFailed(PaymentError paymentError) {

    }

    @Override
    public void imagesRequestSucceeded(ImagesRequest imagesRequest) {

    }

    @Override
    public void imagesRequestFailed() {

    }

    @Override
    public void paymentConfigRequestSucceeded(CheckoutInfo checkoutInfo) {
        this.resourcePath = checkoutInfo.getResourcePath();
    }

    @Override
    public void paymentConfigRequestFailed(PaymentError paymentError) {
        Log.e(TAG, paymentError.getErrorMessage());
    }

    @Override
    public void transactionCompleted(Transaction transaction) {
        if (transaction == null) {
            return;
        }

        if (transaction.getTransactionType() == TransactionType.SYNC) {
            Log.i(TAG, "transactionCompleted:"+resourcePath);
            flutterDispatch("sync", resourcePath);
        } else {
            Log.i(TAG, "transactionCompleted redirect:"+transaction.getRedirectUrl());
            /* wait for the callback in the s */
            //flutterDispatch("redirect", transaction.getRedirectUrl());
            Uri uri = Uri.parse(transaction.getRedirectUrl());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            activity.startActivity(intent);
        }
    }

    @Override
    public void transactionFailed(Transaction transaction, PaymentError paymentError) {
        //Log.i(TAG, "transactionFailed:"+resourcePath);
        transactionFailed(transaction, paymentError, "failed");
    }

    private void transactionFailed(Transaction transaction, PaymentError paymentError, String status) {

        if (paymentError != null) {
            Log.e(TAG, "transactionFailed:" + paymentError.getErrorMessage() +
                    ", code:" + paymentError.getErrorCode());
            Log.e(TAG, "transactionFailed: errorInfo:" + paymentError.getErrorInfo());
        }
        flutterDispatch(status, paymentError != null ? paymentError.getErrorMessage() :
                "shopper canceled the checkout process");
    }

    private void flutterDispatch(String status, String message) {
        Map<String, Object> data = new HashMap<>();
        data.put("status", status);
        data.put("checkoutId", checkoutId);
        if (message != null)
            data.put("message", message);
        Log.e(TAG, "flutterDispatch: status: " + status + ", message: " + message);
        success(data);
    }

    @Override
    public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CheckoutActivity.REQUEST_CODE_CHECKOUT) {
            Log.e(TAG, "onActivityResult: " + resultCode + ", SCHEME:" + (data != null ? data.getScheme() : null));
            if (data == null )
                return false;
            Transaction transaction = data.getParcelableExtra(CheckoutActivity.CHECKOUT_RESULT_TRANSACTION);
            switch (resultCode) {
                case CheckoutActivity.RESULT_OK:

                    /* resource path if needed */
                    String resourcePath = data.getStringExtra(CheckoutActivity.CHECKOUT_RESULT_RESOURCE_PATH);

                    if (transaction.getTransactionType() == TransactionType.SYNC) {
                        /* check the result of synchronous transaction */
                        transactionState = TransactionState.COMPLETED;
                        flutterDispatch("sync", resourcePath);
                    } else {
                        /*
                            onNewIntent() might be already invoked if activity was destroyed in background,
                            make sure you don't overwrite COMPLETED state
                        */
                        if (transactionState != TransactionState.COMPLETED) {
                            transactionState = TransactionState.PENDING;
                        }
                        /* wait for the asynchronous transaction callback in the onNewIntent() */
                        //flutterDispatch("redirect", transaction.getRedirectUrl());
                    }

                    break;
                case CheckoutActivity.RESULT_CANCELED:
                    /* shopper canceled the checkout process */
                {
                    PaymentError error = data.getParcelableExtra(CheckoutActivity.CHECKOUT_RESULT_ERROR);
                    transactionFailed(transaction, error, "canceled");
                    Toast.makeText(applicationContext, "canceled", Toast.LENGTH_LONG).show();
                }
                //error("2","Canceled","");

                break;
                case CheckoutActivity.RESULT_ERROR:
                    /* error occurred */

                    PaymentError error = data.getParcelableExtra(CheckoutActivity.CHECKOUT_RESULT_ERROR);

                    Toast.makeText(applicationContext, error.getErrorMessage(), Toast.LENGTH_LONG).show();

                    Log.e("errorrr", String.valueOf(error.getErrorInfo()));

                    Log.e("errorrr2", String.valueOf(error.getErrorCode()));

                    Log.e("errorrr3", error.getErrorMessage());

                    Log.e("errorrr4", String.valueOf(error.describeContents()));

                    transactionFailed(transaction, error, "error");
                    //error("3","Checkout Result Error","");

            }
        }
        return true;
    }


    @Override
    public boolean onNewIntent(Intent intent) {
        if (intent != null && SCHEME.equals(intent.getScheme())) {
            flutterDispatch("success", null);
            transactionState = TransactionState.COMPLETED;
            return true;
        }
        return false;
    }

    @Override
    public void onStateChanged(@NonNull LifecycleOwner source,
                               @NonNull Lifecycle.Event event) {
        if(event == Lifecycle.Event.ON_RESUME ) {
            if (transactionState == TransactionState.PENDING) {
                Log.d(TAG, "Cancelling.");
                transactionState = null;
                flutterDispatch("canceled", null);
            }
            else if (transactionState == TransactionState.COMPLETED) {
                Log.d(TAG, "Cancelling.");
                transactionState = null;
                flutterDispatch("success", null);
            }
        }
    }

}


enum TransactionState {
    NEW,
    PENDING,
    COMPLETED
}