package com.smb.smbex;

import android.os.Build;
import android.util.Log;
import androidx.annotation.Nullable;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;

final class MethodCallHandlerImpl implements MethodCallHandler {
    private static final String TAG = "MethodCallHandlerImpl";

    private final SmbexOppwa smbexOppwa;
    @Nullable
    private MethodChannel channel;

    private static final String METHOD_CHANNEL_NAME = "smbex.oppwa.fultter/channel";

    MethodCallHandlerImpl(SmbexOppwa smbexOppwa) {
        this.smbexOppwa = smbexOppwa;
    }

    @Override
    public void onMethodCall(MethodCall call, Result result) {
        if (smbexOppwa.activity == null) {
            result.error("NO_ACTIVITY", null, null);
            return;
        }
        smbexOppwa.onMethodCall(call, result);
    }

    /**
     * Registers this instance as a method call handler on the given
     * {@code messenger}.
     */
    void startListening(BinaryMessenger messenger) {
        if (channel != null) {
            Log.wtf(TAG, "Setting a method call handler before the last was disposed.");
            stopListening();
        }

        channel = new MethodChannel(messenger, METHOD_CHANNEL_NAME);
        channel.setMethodCallHandler(this);
    }

    /**
     * Clears this instance from listening to method calls.
     */
    void stopListening() {
        if (channel == null) {
            Log.d(TAG, "Tried to stop listening when no MethodChannel had been initialized.");
            return;
        }

        channel.setMethodCallHandler(null);
        channel = null;
    }

}
