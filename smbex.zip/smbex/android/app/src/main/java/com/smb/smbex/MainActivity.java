package com.smb.smbex;

import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;

public class MainActivity extends FlutterActivity {

    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        android.util.Log.i("MainActivity", "**********MainActivity***********8");
        flutterEngine.getPlugins().add(new SmbexOppwaPlugin());
        //R.mipmap.notification_icon

    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        createNotificationChannels();
    }


    @TargetApi(Build.VERSION_CODES.O)
    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION).build();
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationManager notificationManager =
                (NotificationManager)getApplicationContext()
                        .getSystemService(NOTIFICATION_SERVICE);

        NotificationChannel eventChannel = new NotificationChannel("event_channel_id",
                "Event", NotificationManager.IMPORTANCE_HIGH);
        eventChannel.setShowBadge(true);
        eventChannel.enableLights(true);
        eventChannel.setSound(uri, audioAttributes);
        eventChannel.setDescription("Update on events");
        notificationManager.createNotificationChannel(eventChannel);

        NotificationChannel promoChannel = new NotificationChannel("promotion_channel_id",
                "Promotion", NotificationManager.IMPORTANCE_LOW);

        promoChannel.setDescription("Promotions events");
        notificationManager.createNotificationChannel(promoChannel);


        NotificationChannel messageChannel = new NotificationChannel("message_channel_id",
                "Message", NotificationManager.IMPORTANCE_HIGH);
        messageChannel.setDescription("In-App Chat messages");
        eventChannel.setShowBadge(true);
        eventChannel.enableLights(true);
        eventChannel.setSound(uri, audioAttributes);
        notificationManager.createNotificationChannel(messageChannel);

    }
}
